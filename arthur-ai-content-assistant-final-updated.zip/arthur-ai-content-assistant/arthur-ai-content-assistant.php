<?php
/**
 * Plugin Name: Arthur AI Content Assistant
 * Description: AI assistant to create and edit WordPress content.
 * Author: Arthur
 * Version: 3.2.1
 * GitHub Plugin URI: BAJOHNSWEB/workbot
 * Primary Branch: main
 */


if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'ARTHUR_AI_PLUGIN_DIR' ) ) {
    define( 'ARTHUR_AI_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-settings.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-action-interface.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-actions-registry.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-module-interface.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-modules.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-service.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-rest.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-frontend.php';

require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-login-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-admin-customiser.php';
// Load post editor customiser to apply editor related behaviours
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-post-editor-customiser.php';

// Load additional customisers for profile, security, site, media and WooCommerce
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-profile-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-security-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-site-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-media-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-woo-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-woocommerce-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-account-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-email-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-theme-customiser.php';

// Load forms and integrations customisers
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-forms-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-integrations-customiser.php';

// Load events/bookings/calendar customisers
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-events-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-bookings-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-calendar-integrations.php';

// Load memberships, subscriptions, LMS and dashboard customisers
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-memberships-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-subscriptions-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-lms-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-member-dashboard.php';

// Load SEO, redirects and social customisers
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-seo-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-redirects-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-social-customiser.php';

// Load performance, privacy, analytics and backup customisers
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-performance-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-privacy-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-integrations-customiser.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/class-arthur-ai-analytics-customiser.php';
// DB housekeeping helper is loaded via its own class file below



// Core actions
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/actions/class-arthur-ai-action-create-post.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/actions/class-arthur-ai-action-update-post-image-text.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/actions/class-arthur-ai-action-rewrite-post-body.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/actions/class-arthur-ai-action-append-note.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/actions/class-arthur-ai-action-replace-snippet.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/actions/class-arthur-ai-action-insert-after-heading.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/actions/class-arthur-ai-action-insert-at-bottom.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/actions/class-arthur-ai-action-bulk-create-posts.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/actions/class-arthur-ai-action-generate-summary-post.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/actions/class-arthur-ai-action-publish-post.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/actions/class-arthur-ai-action-update-menu-add-items.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/actions/class-arthur-ai-action-replace-frontend-snippet.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/actions/class-arthur-ai-action-replace-in-elementor-data.php';
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/actions/class-arthur-ai-action-replace-in-block-template.php';

// Login customisation actions – load only if files exist
$arthur_ai_login_action_files = array(
    'includes/actions/customisation/login/class-arthur-ai-action-change-login-logo.php',
    'includes/actions/customisation/login/class-arthur-ai-action-change-login-bg-color.php',
    'includes/actions/customisation/login/class-arthur-ai-action-change-login-bg-image.php',
    'includes/actions/customisation/login/class-arthur-ai-action-change-login-button-colors.php',
    'includes/actions/customisation/login/class-arthur-ai-action-set-login-message.php',
    'includes/actions/customisation/login/class-arthur-ai-action-toggle-login-links.php',
    'includes/actions/customisation/login/class-arthur-ai-action-change-login-form-style.php',
    'includes/actions/customisation/login/class-arthur-ai-action-toggle-login-form-alignment.php',
    'includes/actions/customisation/login/class-arthur-ai-action-set-login-footer-text.php',
    'includes/actions/customisation/login/class-arthur-ai-action-set-login-custom-css.php',
    'includes/actions/customisation/login/class-arthur-ai-action-set-login-logo-link.php',
);

foreach ( $arthur_ai_login_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Admin customisation actions – load only if files exist
$arthur_ai_admin_action_files = array(
    'includes/actions/customisation/admin/class-arthur-ai-action-change-admin-toolbar-colors.php',
    'includes/actions/customisation/admin/class-arthur-ai-action-change-admin-menu-colors.php',
    'includes/actions/customisation/admin/class-arthur-ai-action-set-admin-footer-text.php',
    'includes/actions/customisation/admin/class-arthur-ai-action-set-admin-custom-css.php',
    'includes/actions/customisation/admin/class-arthur-ai-action-hide-admin-menu-items.php',
    'includes/actions/customisation/admin/class-arthur-ai-action-rename-admin-menu-item.php',
    'includes/actions/customisation/admin/class-arthur-ai-action-reorder-admin-menu-items.php',
    'includes/actions/customisation/admin/class-arthur-ai-action-add-admin-menu-page.php',
    'includes/actions/customisation/admin/class-arthur-ai-action-add-admin-submenu-page.php',
    'includes/actions/customisation/admin/class-arthur-ai-action-hide-admin-menu-items-by-role.php',
    'includes/actions/customisation/admin/class-arthur-ai-action-move-admin-settings.php',
    'includes/actions/customisation/admin/class-arthur-ai-action-collapse-admin-menu.php',
);

foreach ( $arthur_ai_admin_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Profile/user customisation actions – load only if files exist
$arthur_ai_profile_action_files = array(
    'includes/actions/customisation/profile/class-arthur-ai-action-force-strong-passwords.php',
    'includes/actions/customisation/profile/class-arthur-ai-action-rename-user-roles.php',
    'includes/actions/customisation/profile/class-arthur-ai-action-create-user-role.php',
    'includes/actions/customisation/profile/class-arthur-ai-action-hide-profile-fields.php',
    'includes/actions/customisation/profile/class-arthur-ai-action-add-profile-fields.php',
    'includes/actions/customisation/profile/class-arthur-ai-action-redirect-on-login.php',
    'includes/actions/customisation/profile/class-arthur-ai-action-redirect-on-logout.php',
    'includes/actions/customisation/profile/class-arthur-ai-action-disable-admin-bar-for-non-admins.php',
);
foreach ( $arthur_ai_profile_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Security customisation actions
$arthur_ai_security_action_files = array(
    'includes/actions/customisation/security/class-arthur-ai-action-rename-login-url.php',
    'includes/actions/customisation/security/class-arthur-ai-action-disable-xml-rpc.php',
    'includes/actions/customisation/security/class-arthur-ai-action-disable-file-editing.php',
    'includes/actions/customisation/security/class-arthur-ai-action-limit-login-attempts.php',
    'includes/actions/customisation/security/class-arthur-ai-action-auto-logout-inactive-users.php',
    'includes/actions/customisation/security/class-arthur-ai-action-hide-wp-version.php',
    'includes/actions/customisation/security/class-arthur-ai-action-disable-rest-api-for-guests.php',
);
foreach ( $arthur_ai_security_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Additional security actions
$arthur_ai_security_action_files_add = array(
    'includes/actions/customisation/security/class-arthur-ai-action-manage-security-firewall.php',
    'includes/actions/customisation/security/class-arthur-ai-action-run-malware-scan.php',
    'includes/actions/customisation/security/class-arthur-ai-action-configure-password-policy.php',
    'includes/actions/customisation/security/class-arthur-ai-action-generate-security-report.php',
    'includes/actions/customisation/security/class-arthur-ai-action-configure-region-based-cookie-rules.php',
);
foreach ( $arthur_ai_security_action_files_add as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Site settings/misc customisation actions
$arthur_ai_settings_action_files = array(
    'includes/actions/customisation/settings/class-arthur-ai-action-change-site-title.php',
    'includes/actions/customisation/settings/class-arthur-ai-action-change-site-tagline.php',
    'includes/actions/customisation/settings/class-arthur-ai-action-change-permalink-structure.php',
    'includes/actions/customisation/settings/class-arthur-ai-action-add-google-analytics-snippet.php',
    'includes/actions/customisation/settings/class-arthur-ai-action-add-custom-head-html.php',
    'includes/actions/customisation/settings/class-arthur-ai-action-add-custom-footer-html.php',
    'includes/actions/customisation/settings/class-arthur-ai-action-toggle-comments-global.php',
    'includes/actions/customisation/settings/class-arthur-ai-action-add-cookie-banner-basic.php',
    'includes/actions/customisation/settings/class-arthur-ai-action-force-https-redirects.php',
    // Extended core settings actions
    'includes/actions/settings/class-arthur-ai-action-configure-general-settings.php',
    'includes/actions/settings/class-arthur-ai-action-configure-writing-settings.php',
    'includes/actions/settings/class-arthur-ai-action-configure-reading-settings.php',
    'includes/actions/settings/class-arthur-ai-action-configure-media-settings.php',
    'includes/actions/settings/class-arthur-ai-action-configure-permalink-bases.php',
    'includes/actions/settings/class-arthur-ai-action-flush-rewrite-rules-safely.php',
);
foreach ( $arthur_ai_settings_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Media customisation actions
$arthur_ai_media_action_files = array(
    'includes/actions/customisation/media/class-arthur-ai-action-auto-optimise-images.php',
    'includes/actions/customisation/media/class-arthur-ai-action-auto-rename-uploads.php',
    'includes/actions/customisation/media/class-arthur-ai-action-replace-media-file.php',
    'includes/actions/customisation/media/class-arthur-ai-action-add-image-sizes.php',
    'includes/actions/customisation/media/class-arthur-ai-action-convert-images-to-webp.php',
    'includes/actions/customisation/media/class-arthur-ai-action-generate-image-alt-text-ai.php',
    'includes/actions/customisation/media/class-arthur-ai-action-bulk-delete-unused-media.php',
    'includes/actions/customisation/media/class-arthur-ai-action-upload-media-items.php',
    'includes/actions/customisation/media/class-arthur-ai-action-regenerate-image-sizes.php',
    'includes/actions/customisation/media/class-arthur-ai-action-bulk-update-media-meta.php',
    'includes/actions/customisation/media/class-arthur-ai-action-update-media-taxonomies.php',
    'includes/actions/customisation/media/class-arthur-ai-action-replace-brand-assets.php',
    'includes/actions/customisation/media/class-arthur-ai-action-optimise-existing-images-batch.php',
);
foreach ( $arthur_ai_media_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// WooCommerce customisation actions
$arthur_ai_woo_action_files = array(
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-woocommerce-change-add-to-cart-text.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-woocommerce-add-product-tab.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-woocommerce-change-checkout-fields.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-woocommerce-require-phone.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-woocommerce-postcode-validation.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-woocommerce-auto-tag-orders.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-woocommerce-custom-thankyou-message.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-woocommerce-update-email-templates.php',
    // Core Woo product management actions
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-create-product.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-bulk-edit-products.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-duplicate-product.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-update-product-attributes.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-update-product-categories.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-reorganise-product-taxonomy.php',
    // Additional WooCommerce actions for products, checkout, orders, emails, account and e‑commerce operations
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-update-product-tags.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-rewrite-product-descriptions.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-generate-product-usps.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-assign-cross-sells.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-customise-checkout-fields.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-set-guest-checkout-mode.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-add-checkout-instructions.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-edit-order-details.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-bulk-update-order-statuses.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-generate-order-response.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-customise-woo-emails.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-adjust-email-triggers.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-add-my-account-endpoint.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-merge-my-account-dashboard.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-manage-coupons.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-configure-shipping.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-configure-tax-rates.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-manage-subscriptions.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-manage-bookings.php',
    'includes/actions/customisation/woocommerce/class-arthur-ai-action-manage-memberships.php',
);
foreach ( $arthur_ai_woo_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Theme/design customisation actions
$arthur_ai_theme_action_files = array(
    'includes/actions/customisation/theme/class-arthur-ai-action-change-site-logo.php',
    'includes/actions/customisation/theme/class-arthur-ai-action-change-site-icon.php',
    'includes/actions/customisation/theme/class-arthur-ai-action-set-header-logo-variants.php',
    'includes/actions/customisation/theme/class-arthur-ai-action-update-global-design-tokens.php',
    'includes/actions/customisation/theme/class-arthur-ai-action-update-global-button-styles.php',
    'includes/actions/customisation/theme/class-arthur-ai-action-edit-header-layout.php',
    'includes/actions/customisation/theme/class-arthur-ai-action-edit-footer-layout.php',
    'includes/actions/customisation/theme/class-arthur-ai-action-manage-block-template.php',
    'includes/actions/customisation/theme/class-arthur-ai-action-define-block-pattern.php',
    'includes/actions/customisation/theme/class-arthur-ai-action-apply-pattern-to-posts.php',
    'includes/actions/customisation/theme/class-arthur-ai-action-duplicate-elementor-template.php',
    'includes/actions/customisation/theme/class-arthur-ai-action-update-elementor-widget-content.php',
    'includes/actions/customisation/theme/class-arthur-ai-action-tune-elementor-responsive-layout.php',
    'includes/actions/customisation/theme/class-arthur-ai-action-add-frontend-responsive-css.php',
    'includes/actions/customisation/theme/class-arthur-ai-action-standardise-section-spacing.php',
    'includes/actions/customisation/theme/class-arthur-ai-action-apply-layout-grid.php',
);
foreach ( $arthur_ai_theme_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Navigation and site structure actions – load only if files exist
$arthur_ai_navigation_action_files = array(
    'includes/actions/customisation/navigation/class-arthur-ai-action-create-or-update-nav-menu.php',
    'includes/actions/customisation/navigation/class-arthur-ai-action-update-nav-menu-items.php',
    'includes/actions/customisation/navigation/class-arthur-ai-action-rename-nav-menu-labels.php',
    'includes/actions/customisation/navigation/class-arthur-ai-action-set-role-based-menus.php',
    'includes/actions/customisation/navigation/class-arthur-ai-action-create-core-pages.php',
    'includes/actions/customisation/navigation/class-arthur-ai-action-reorganise-page-hierarchy.php',
    'includes/actions/customisation/navigation/class-arthur-ai-action-assign-page-templates-bulk.php',
    'includes/actions/customisation/navigation/class-arthur-ai-action-configure-widget-area.php',
    'includes/actions/customisation/navigation/class-arthur-ai-action-update-sidebar-blocks.php',
    'includes/actions/customisation/navigation/class-arthur-ai-action-insert-internal-links.php',
    'includes/actions/customisation/navigation/class-arthur-ai-action-fix-broken-internal-links.php',
    'includes/actions/customisation/navigation/class-arthur-ai-action-generate-index-page.php',
    'includes/actions/customisation/navigation/class-arthur-ai-action-manage-sitemap-inclusion.php',
);
foreach ( $arthur_ai_navigation_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// SEO, marketing and social actions – load only if files exist
$arthur_ai_seo_action_files = array(
    'includes/actions/customisation/seo/class-arthur-ai-action-update-seo-meta.php',
    'includes/actions/customisation/seo/class-arthur-ai-action-set-schema-markup.php',
    'includes/actions/customisation/seo/class-arthur-ai-action-apply-seo-optimised-content.php',
    'includes/actions/customisation/seo/class-arthur-ai-action-set-indexing-flags.php',
    'includes/actions/customisation/seo/class-arthur-ai-action-configure-sitemap-settings.php',
    'includes/actions/customisation/seo/class-arthur-ai-action-cleanup-redirected-or-orphaned-content.php',
    'includes/actions/customisation/seo/class-arthur-ai-action-manage-redirects.php',
    'includes/actions/customisation/seo/class-arthur-ai-action-configure-404-logging-and-redirects.php',
    'includes/actions/customisation/seo/class-arthur-ai-action-set-social-meta.php',
    'includes/actions/customisation/seo/class-arthur-ai-action-apply-social-share-snippets.php',
    'includes/actions/customisation/seo/class-arthur-ai-action-create-landing-page.php',
    'includes/actions/customisation/seo/class-arthur-ai-action-duplicate-landing-page-for-ab.php',
);
foreach ( $arthur_ai_seo_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Forms and lead capture actions – load only if files exist
$arthur_ai_forms_action_files = array(
    'includes/actions/customisation/forms/class-arthur-ai-action-create-form-from-brief.php',
    'includes/actions/customisation/forms/class-arthur-ai-action-update-form-fields.php',
    'includes/actions/customisation/forms/class-arthur-ai-action-create-multistep-form.php',
    'includes/actions/customisation/forms/class-arthur-ai-action-embed-form-on-pages.php',
    'includes/actions/customisation/forms/class-arthur-ai-action-set-form-style-preset.php',
    'includes/actions/customisation/forms/class-arthur-ai-action-configure-form-notifications.php',
    'includes/actions/customisation/forms/class-arthur-ai-action-configure-form-confirmations.php',
    'includes/actions/customisation/forms/class-arthur-ai-action-export-form-entries.php',
    'includes/actions/customisation/forms/class-arthur-ai-action-tag-form-leads.php',
    'includes/actions/customisation/forms/class-arthur-ai-action-configure-form-webhooks.php',
    'includes/actions/customisation/forms/class-arthur-ai-action-configure-form-crm-mapping.php',
    'includes/actions/customisation/forms/class-arthur-ai-action-configure-form-payments.php',
    'includes/actions/customisation/forms/class-arthur-ai-action-toggle-form-logging.php',
);
foreach ( $arthur_ai_forms_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Performance, caching & housekeeping actions
$arthur_ai_performance_action_files = array(
    'includes/actions/customisation/performance/class-arthur-ai-action-configure-page-cache.php',
    'includes/actions/customisation/performance/class-arthur-ai-action-clear-site-cache.php',
    'includes/actions/customisation/performance/class-arthur-ai-action-configure-asset-optimisation.php',
    'includes/actions/customisation/performance/class-arthur-ai-action-configure-lazy-loading.php',
    'includes/actions/customisation/performance/class-arthur-ai-action-run-db-housekeeping.php',
    'includes/actions/customisation/performance/class-arthur-ai-action-optimise-database-tables.php',
    'includes/actions/customisation/performance/class-arthur-ai-action-inspect-scheduled-tasks.php',
    'includes/actions/customisation/performance/class-arthur-ai-action-adjust-cron-tasks.php',
    // Extended performance actions
    'includes/actions/customisation/performance/class-arthur-ai-action-configure-cdn.php',
    'includes/actions/customisation/performance/class-arthur-ai-action-cdn-purge-cache.php',
    'includes/actions/customisation/performance/class-arthur-ai-action-configure-object-cache.php',
    'includes/actions/customisation/performance/class-arthur-ai-action-flush-object-cache.php',
    'includes/actions/customisation/performance/class-arthur-ai-action-configure-housekeeping-profile.php',
    'includes/actions/customisation/performance/class-arthur-ai-action-run-housekeeping-profile.php',
);
foreach ( $arthur_ai_performance_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// System/inspection/meta actions
$arthur_ai_system_action_files = array(
    'includes/actions/customisation/system/class-arthur-ai-action-list-entities.php',
    'includes/actions/customisation/system/class-arthur-ai-action-scan-content-issues.php',
    'includes/actions/customisation/system/class-arthur-ai-action-get-settings-snapshot.php',
    'includes/actions/customisation/system/class-arthur-ai-action-inspect-options-bundle.php',
    'includes/actions/customisation/system/class-arthur-ai-action-apply-options-bundle.php',
    'includes/actions/customisation/system/class-arthur-ai-action-preview-change-plan.php',
    'includes/actions/customisation/system/class-arthur-ai-action-export-change-plan.php',
    // Additional system/meta actions for planning and checkpoints
    'includes/actions/customisation/system/class-arthur-ai-action-simulate-changes.php',
    'includes/actions/customisation/system/class-arthur-ai-action-execute-change-plan.php',
    'includes/actions/customisation/system/class-arthur-ai-action-create-site-checkpoint.php',
    'includes/actions/customisation/system/class-arthur-ai-action-list-site-checkpoints.php',
    'includes/actions/customisation/system/class-arthur-ai-action-rollback-to-checkpoint.php',
    'includes/actions/customisation/system/class-arthur-ai-action-list-arthur-action-log.php',
);
foreach ( $arthur_ai_system_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Meta introspection actions – load only if files exist
$arthur_ai_meta_action_files = array(
    'includes/actions/meta/class-arthur-ai-action-site-inventory-map.php',
    'includes/actions/meta/class-arthur-ai-action-list-plugins-themes.php',
    'includes/actions/meta/class-arthur-ai-action-list-posts.php',
    'includes/actions/meta/class-arthur-ai-action-list-users.php',
    'includes/actions/meta/class-arthur-ai-action-list-orders.php',
    'includes/actions/meta/class-arthur-ai-action-list-products.php',
    'includes/actions/meta/class-arthur-ai-action-list-events.php',
    'includes/actions/meta/class-arthur-ai-action-list-memberships.php',
);
foreach ( $arthur_ai_meta_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Plugin/theme/core lifecycle actions
$arthur_ai_lifecycle_action_files = array(
    // Plugin lifecycle
    'includes/actions/lifecycle/class-arthur-ai-action-activate-plugins.php',
    'includes/actions/lifecycle/class-arthur-ai-action-deactivate-plugins.php',
    'includes/actions/lifecycle/class-arthur-ai-action-delete-plugins.php',
    'includes/actions/lifecycle/class-arthur-ai-action-toggle-plugin-auto-updates.php',
    'includes/actions/lifecycle/class-arthur-ai-action-list-plugins-status.php',
    // Theme lifecycle
    'includes/actions/lifecycle/class-arthur-ai-action-install-theme.php',
    'includes/actions/lifecycle/class-arthur-ai-action-activate-theme.php',
    'includes/actions/lifecycle/class-arthur-ai-action-delete-theme.php',
    'includes/actions/lifecycle/class-arthur-ai-action-toggle-theme-auto-updates.php',
    // Core update and settings
    'includes/actions/lifecycle/class-arthur-ai-action-update-core.php',
    'includes/actions/lifecycle/class-arthur-ai-action-configure-core-auto-update.php',
    'includes/actions/lifecycle/class-arthur-ai-action-update-translations.php',
    'includes/actions/lifecycle/class-arthur-ai-action-check-filesystem-health.php',
);
foreach ( $arthur_ai_lifecycle_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// New security actions
$arthur_ai_security_action_files_add = array(
    'includes/actions/customisation/security/class-arthur-ai-action-toggle-file-editing.php',
    'includes/actions/customisation/security/class-arthur-ai-action-toggle-xmlrpc.php',
    'includes/actions/customisation/security/class-arthur-ai-action-toggle-wp-version-exposure.php',
    'includes/actions/customisation/security/class-arthur-ai-action-configure-rest-api-restrictions.php',
    'includes/actions/customisation/security/class-arthur-ai-action-configure-login-url-obfuscation.php',
    'includes/actions/customisation/security/class-arthur-ai-action-configure-login-rate-limiting.php',
    'includes/actions/customisation/security/class-arthur-ai-action-configure-two-factor-auth.php',
    'includes/actions/customisation/security/class-arthur-ai-action-audit-roles-and-capabilities.php',
    'includes/actions/customisation/security/class-arthur-ai-action-report-inactive-users.php',
    'includes/actions/customisation/security/class-arthur-ai-action-update-privacy-and-terms-pages.php',
    'includes/actions/customisation/security/class-arthur-ai-action-configure-cookie-banner.php',
    'includes/actions/customisation/security/class-arthur-ai-action-process-privacy-requests.php',
);
foreach ( $arthur_ai_security_action_files_add as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Integrations, automation, analytics and backup actions
$arthur_ai_integrations_action_files = array(
    'includes/actions/customisation/integrations/class-arthur-ai-action-configure-email-marketing-integration.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-configure-crm-integration.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-configure-global-webhooks.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-configure-automation-rules.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-configure-nurture-sequences.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-configure-tracking-scripts.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-configure-tracking-events.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-create-analytics-dashboard-page.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-import-data-batch.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-export-data-batch.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-configure-import-field-mapping.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-trigger-site-backup.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-configure-backup-schedule.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-store-backup-restore-checklist.php',
    // New SSO and directory sync actions
    'includes/actions/customisation/integrations/class-arthur-ai-action-configure-sso-provider.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-configure-sso-mapping.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-configure-sso-modes.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-test-sso-connection.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-configure-directory-sync.php',
    'includes/actions/customisation/integrations/class-arthur-ai-action-run-directory-sync.php',
);
foreach ( $arthur_ai_integrations_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Analytics actions
$arthur_ai_analytics_action_files = array(
    'includes/actions/customisation/analytics/class-arthur-ai-action-query-analytics-metrics.php',
    'includes/actions/customisation/analytics/class-arthur-ai-action-query-analytics-funnels.php',
    'includes/actions/customisation/analytics/class-arthur-ai-action-list-tracking-events.php',
    'includes/actions/customisation/analytics/class-arthur-ai-action-toggle-tracking-event.php',
    'includes/actions/customisation/analytics/class-arthur-ai-action-configure-action-logging.php',
    'includes/actions/customisation/analytics/class-arthur-ai-action-report-system-errors.php',
);
foreach ( $arthur_ai_analytics_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Multisite actions
$arthur_ai_multisite_action_files = array(
    'includes/actions/customisation/multisite/class-arthur-ai-action-manage-subsites.php',
    'includes/actions/customisation/multisite/class-arthur-ai-action-configure-environment-profiles.php',
    'includes/actions/customisation/multisite/class-arthur-ai-action-get-current-environment.php',
);
foreach ( $arthur_ai_multisite_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Developer tools actions
$arthur_ai_developer_action_files = array(
    'includes/actions/customisation/developer/class-arthur-ai-action-manage-code-snippets.php',
    'includes/actions/customisation/developer/class-arthur-ai-action-rollback-snippet-on-error.php',
    'includes/actions/customisation/developer/class-arthur-ai-action-edit-theme-template-file.php',
    'includes/actions/customisation/developer/class-arthur-ai-action-rollback-theme-template-file.php',
);
foreach ( $arthur_ai_developer_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Events and bookings actions – load only if files exist
$arthur_ai_events_action_files = array(
    'includes/actions/customisation/events/class-arthur-ai-action-create-event.php',
    'includes/actions/customisation/events/class-arthur-ai-action-duplicate-event.php',
    'includes/actions/customisation/events/class-arthur-ai-action-update-event-details.php',
    'includes/actions/customisation/events/class-arthur-ai-action-manage-event-tickets.php',
    'includes/actions/customisation/events/class-arthur-ai-action-update-ticket-caps.php',
    'includes/actions/customisation/events/class-arthur-ai-action-manage-event-attendees.php',
    'includes/actions/customisation/events/class-arthur-ai-action-configure-event-booking-rules.php',
    'includes/actions/customisation/events/class-arthur-ai-action-close-event-bookings.php',
    'includes/actions/customisation/events/class-arthur-ai-action-customise-event-views.php',
    'includes/actions/customisation/events/class-arthur-ai-action-create-my-bookings-dashboard.php',
    'includes/actions/customisation/events/class-arthur-ai-action-sync-event-tickets-with-woo.php',
    'includes/actions/customisation/events/class-arthur-ai-action-configure-external-calendar-sync.php',
);
foreach ( $arthur_ai_events_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Membership, subscription and LMS actions – load only if files exist
$arthur_ai_membership_action_files = array(
    'includes/actions/customisation/memberships/class-arthur-ai-action-create-membership-level.php',
    'includes/actions/customisation/memberships/class-arthur-ai-action-protect-content-by-membership.php',
    'includes/actions/customisation/memberships/class-arthur-ai-action-configure-membership-signup-flow.php',
    'includes/actions/customisation/memberships/class-arthur-ai-action-create-subscription-plan.php',
    'includes/actions/customisation/memberships/class-arthur-ai-action-configure-subscription-renewal-flows.php',
    'includes/actions/customisation/memberships/class-arthur-ai-action-configure-course-structure.php',
    'includes/actions/customisation/memberships/class-arthur-ai-action-manage-student-enrolment.php',
    'includes/actions/customisation/memberships/class-arthur-ai-action-create-my-membership-dashboard.php',
    'includes/actions/customisation/memberships/class-arthur-ai-action-configure-member-recommendations.php',
    'includes/actions/customisation/memberships/class-arthur-ai-action-map-membership-to-courses.php',
    // LMS creation actions
    'includes/actions/customisation/lms/class-arthur-ai-action-create-or-update-course.php',
    'includes/actions/customisation/lms/class-arthur-ai-action-create-or-update-lessons.php',
    'includes/actions/customisation/lms/class-arthur-ai-action-create-or-update-quizzes.php',
    'includes/actions/customisation/lms/class-arthur-ai-action-apply-generated-lesson-content.php',
);
foreach ( $arthur_ai_membership_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Post/editor customisation actions – load only if files exist
$arthur_ai_editor_action_files = array(
    'includes/actions/customisation/editor/class-arthur-ai-action-disable-gutenberg.php',
    'includes/actions/customisation/editor/class-arthur-ai-action-enable-gutenberg-blocks.php',
    'includes/actions/customisation/editor/class-arthur-ai-action-disable-gutenberg-blocks.php',
    'includes/actions/customisation/editor/class-arthur-ai-action-set-auto-reusable-block.php',
    'includes/actions/customisation/editor/class-arthur-ai-action-disable-comments.php',
    'includes/actions/customisation/editor/class-arthur-ai-action-hide-featured-image-box.php',
    'includes/actions/customisation/editor/class-arthur-ai-action-hide-tags-categories-box.php',
    'includes/actions/customisation/editor/class-arthur-ai-action-add-custom-fields.php',
    'includes/actions/customisation/editor/class-arthur-ai-action-set-title-placeholder.php',
    'includes/actions/customisation/editor/class-arthur-ai-action-set-default-featured-image.php',
    'includes/actions/customisation/editor/class-arthur-ai-action-set-default-category.php',
    'includes/actions/customisation/editor/class-arthur-ai-action-duplicate-post.php',
    'includes/actions/customisation/editor/class-arthur-ai-action-bulk-duplicate-posts.php',
    'includes/actions/customisation/editor/class-arthur-ai-action-lock-pages.php',
);

foreach ( $arthur_ai_editor_action_files as $relative_path ) {
    $path = ARTHUR_AI_PLUGIN_DIR . $relative_path;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// Modules
require_once ARTHUR_AI_PLUGIN_DIR . 'includes/modules/class-arthur-ai-module-content.php';

// Admin
require_once ARTHUR_AI_PLUGIN_DIR . 'admin/class-arthur-ai-admin-page.php';

/**
 * Initialise the Arthur AI plugin components.
 */
function arthur_ai_content_assistant_init() {
    Arthur_AI_Settings::init();
    Arthur_AI_Frontend::init();
    Arthur_AI_Login_Customiser::init();
    // Initialise admin customisations
    Arthur_AI_Admin_Customiser::init();
    // Initialise profile, security, site, media and Woo customisers where available
    if ( class_exists( 'Arthur_AI_Profile_Customiser' ) ) {
        Arthur_AI_Profile_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Security_Customiser' ) ) {
        Arthur_AI_Security_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Site_Customiser' ) ) {
        Arthur_AI_Site_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Media_Customiser' ) ) {
        Arthur_AI_Media_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Woo_Customiser' ) ) {
        Arthur_AI_Woo_Customiser::init();
    }
    // Initialise WooCommerce customiser for checkout, shipping, tax and guest checkout
    if ( class_exists( 'Arthur_AI_WooCommerce_Customiser' ) ) {
        Arthur_AI_WooCommerce_Customiser::init();
    }
    // Initialise post/editor customisations
    if ( class_exists( 'Arthur_AI_Post_Editor_Customiser' ) ) {
        Arthur_AI_Post_Editor_Customiser::init();
    }

    // Initialise theme/design customiser
    if ( class_exists( 'Arthur_AI_Theme_Customiser' ) ) {
        Arthur_AI_Theme_Customiser::init();
    }

    // Initialise navigation and sitemap customisers
    if ( class_exists( 'Arthur_AI_Nav_Customiser' ) ) {
        Arthur_AI_Nav_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Sitemap_Customiser' ) ) {
        Arthur_AI_Sitemap_Customiser::init();
    }

    // Initialise SEO, redirects and social customisers
    if ( class_exists( 'Arthur_AI_SEO_Customiser' ) ) {
        Arthur_AI_SEO_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Redirects_Customiser' ) ) {
        Arthur_AI_Redirects_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Social_Customiser' ) ) {
        Arthur_AI_Social_Customiser::init();
    }

    // Initialise account and email customisers
    if ( class_exists( 'Arthur_AI_Account_Customiser' ) ) {
        Arthur_AI_Account_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Email_Customiser' ) ) {
        Arthur_AI_Email_Customiser::init();
    }

    // Initialise forms and integrations customisers
    if ( class_exists( 'Arthur_AI_Forms_Customiser' ) ) {
        Arthur_AI_Forms_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Integrations_Customiser' ) ) {
        Arthur_AI_Integrations_Customiser::init();
    }

    // Initialise events, bookings and calendar customisers
    if ( class_exists( 'Arthur_AI_Events_Customiser' ) ) {
        Arthur_AI_Events_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Bookings_Customiser' ) ) {
        Arthur_AI_Bookings_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Calendar_Integrations' ) ) {
        Arthur_AI_Calendar_Integrations::init();
    }

    // Initialise memberships, subscriptions, LMS and member dashboard customisers
    if ( class_exists( 'Arthur_AI_Memberships_Customiser' ) ) {
        Arthur_AI_Memberships_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Subscriptions_Customiser' ) ) {
        Arthur_AI_Subscriptions_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Lms_Customiser' ) ) {
        Arthur_AI_Lms_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Member_Dashboard' ) ) {
        Arthur_AI_Member_Dashboard::init();
    }


    // Core actions
    Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_Post() );
    Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Post_Image_Text() );
    Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Rewrite_Post_Body() );
    Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Append_Note() );
    Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Replace_Snippet() );
    Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Insert_After_Heading() );
    Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Insert_At_Bottom() );
    Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Bulk_Create_Posts() );
    Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Generate_Summary_Post() );
    Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Publish_Post() );
    Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Menu_Add_Items() );
    Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Replace_Frontend_Snippet() );
    Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Replace_In_Elementor_Data() );
    Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Replace_In_Block_Template() );

    // Login customisation actions – only register if classes exist
    if ( class_exists( 'Arthur_AI_Action_Change_Login_Logo' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Change_Login_Logo() );
    }

    if ( class_exists( 'Arthur_AI_Action_Change_Login_Bg_Color' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Change_Login_Bg_Color() );
    }

    if ( class_exists( 'Arthur_AI_Action_Change_Login_Bg_Image' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Change_Login_Bg_Image() );
    }

    if ( class_exists( 'Arthur_AI_Action_Change_Login_Button_Colors' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Change_Login_Button_Colors() );
    }

    if ( class_exists( 'Arthur_AI_Action_Set_Login_Message' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Login_Message() );
    }

    if ( class_exists( 'Arthur_AI_Action_Toggle_Login_Links' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Toggle_Login_Links() );
    }

    if ( class_exists( 'Arthur_AI_Action_Change_Login_Form_Style' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Change_Login_Form_Style() );
    }

    if ( class_exists( 'Arthur_AI_Action_Toggle_Login_Form_Alignment' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Toggle_Login_Form_Alignment() );
    }

    if ( class_exists( 'Arthur_AI_Action_Set_Login_Footer_Text' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Login_Footer_Text() );
    }

    if ( class_exists( 'Arthur_AI_Action_Set_Login_Custom_CSS' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Login_Custom_CSS() );
    }

    if ( class_exists( 'Arthur_AI_Action_Set_Login_Logo_Link' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Login_Logo_Link() );
    }

    // Register admin customisation actions – only register if classes exist
    if ( class_exists( 'Arthur_AI_Action_Change_Admin_Toolbar_Colors' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Change_Admin_Toolbar_Colors() );
    }
    if ( class_exists( 'Arthur_AI_Action_Change_Admin_Menu_Colors' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Change_Admin_Menu_Colors() );
    }
    if ( class_exists( 'Arthur_AI_Action_Set_Admin_Footer_Text' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Admin_Footer_Text() );
    }
    if ( class_exists( 'Arthur_AI_Action_Set_Admin_Custom_CSS' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Admin_Custom_CSS() );
    }

    if ( class_exists( 'Arthur_AI_Action_Hide_Admin_Menu_Items' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Hide_Admin_Menu_Items() );
    }
    if ( class_exists( 'Arthur_AI_Action_Rename_Admin_Menu_Item' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Rename_Admin_Menu_Item() );
    }
    if ( class_exists( 'Arthur_AI_Action_Reorder_Admin_Menu_Items' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Reorder_Admin_Menu_Items() );
    }
    if ( class_exists( 'Arthur_AI_Action_Add_Admin_Menu_Page' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Add_Admin_Menu_Page() );
    }
    if ( class_exists( 'Arthur_AI_Action_Add_Admin_Submenu_Page' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Add_Admin_Submenu_Page() );
    }
    if ( class_exists( 'Arthur_AI_Action_Hide_Admin_Menu_Items_By_Role' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Hide_Admin_Menu_Items_By_Role() );
    }
    if ( class_exists( 'Arthur_AI_Action_Move_Admin_Settings' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Move_Admin_Settings() );
    }
    if ( class_exists( 'Arthur_AI_Action_Collapse_Admin_Menu' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Collapse_Admin_Menu() );
    }

    // Register post/editor customisation actions – only register if classes exist
    if ( class_exists( 'Arthur_AI_Action_Disable_Gutenberg' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Disable_Gutenberg() );
    }
    if ( class_exists( 'Arthur_AI_Action_Enable_Gutenberg_Blocks' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Enable_Gutenberg_Blocks() );
    }
    if ( class_exists( 'Arthur_AI_Action_Disable_Gutenberg_Blocks' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Disable_Gutenberg_Blocks() );
    }
    if ( class_exists( 'Arthur_AI_Action_Set_Auto_Reusable_Block' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Auto_Reusable_Block() );
    }
    if ( class_exists( 'Arthur_AI_Action_Disable_Comments' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Disable_Comments() );
    }
    if ( class_exists( 'Arthur_AI_Action_Hide_Featured_Image_Box' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Hide_Featured_Image_Box() );
    }
    if ( class_exists( 'Arthur_AI_Action_Hide_Tags_Categories_Box' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Hide_Tags_Categories_Box() );
    }
    if ( class_exists( 'Arthur_AI_Action_Add_Custom_Fields' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Add_Custom_Fields() );
    }
    if ( class_exists( 'Arthur_AI_Action_Set_Title_Placeholder' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Title_Placeholder() );
    }
    if ( class_exists( 'Arthur_AI_Action_Set_Default_Featured_Image' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Default_Featured_Image() );
    }
    if ( class_exists( 'Arthur_AI_Action_Set_Default_Category' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Default_Category() );
    }
    if ( class_exists( 'Arthur_AI_Action_Duplicate_Post' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Duplicate_Post() );
    }
    if ( class_exists( 'Arthur_AI_Action_Bulk_Duplicate_Posts' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Bulk_Duplicate_Posts() );
    }
    if ( class_exists( 'Arthur_AI_Action_Lock_Pages' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Lock_Pages() );
    }

    // Register profile/user customisation actions if classes exist
    if ( class_exists( 'Arthur_AI_Action_Force_Strong_Passwords' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Force_Strong_Passwords() );
    }
    if ( class_exists( 'Arthur_AI_Action_Rename_User_Roles' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Rename_User_Roles() );
    }
    if ( class_exists( 'Arthur_AI_Action_Create_User_Role' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_User_Role() );
    }
    if ( class_exists( 'Arthur_AI_Action_Hide_Profile_Fields' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Hide_Profile_Fields() );
    }
    if ( class_exists( 'Arthur_AI_Action_Add_Profile_Fields' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Add_Profile_Fields() );
    }
    if ( class_exists( 'Arthur_AI_Action_Redirect_On_Login' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Redirect_On_Login() );
    }
    if ( class_exists( 'Arthur_AI_Action_Redirect_On_Logout' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Redirect_On_Logout() );
    }
    if ( class_exists( 'Arthur_AI_Action_Disable_Admin_Bar_For_Non_Admins' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Disable_Admin_Bar_For_Non_Admins() );
    }

    // Register security customisation actions
    if ( class_exists( 'Arthur_AI_Action_Rename_Login_Url' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Rename_Login_Url() );
    }
    if ( class_exists( 'Arthur_AI_Action_Disable_Xml_Rpc' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Disable_Xml_Rpc() );
    }
    if ( class_exists( 'Arthur_AI_Action_Disable_File_Editing' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Disable_File_Editing() );
    }
    if ( class_exists( 'Arthur_AI_Action_Limit_Login_Attempts' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Limit_Login_Attempts() );
    }
    if ( class_exists( 'Arthur_AI_Action_Auto_Logout_Inactive_Users' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Auto_Logout_Inactive_Users() );
    }
    if ( class_exists( 'Arthur_AI_Action_Hide_Wp_Version' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Hide_Wp_Version() );
    }
    if ( class_exists( 'Arthur_AI_Action_Disable_Rest_Api_For_Guests' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Disable_Rest_Api_For_Guests() );
    }

    // Register site settings/misc customisation actions
    if ( class_exists( 'Arthur_AI_Action_Change_Site_Title' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Change_Site_Title() );
    }
    if ( class_exists( 'Arthur_AI_Action_Change_Site_Tagline' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Change_Site_Tagline() );
    }
    if ( class_exists( 'Arthur_AI_Action_Change_Permalink_Structure' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Change_Permalink_Structure() );
    }
    if ( class_exists( 'Arthur_AI_Action_Add_Google_Analytics_Snippet' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Add_Google_Analytics_Snippet() );
    }
    if ( class_exists( 'Arthur_AI_Action_Add_Custom_Head_Html' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Add_Custom_Head_Html() );
    }
    if ( class_exists( 'Arthur_AI_Action_Add_Custom_Footer_Html' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Add_Custom_Footer_Html() );
    }
    if ( class_exists( 'Arthur_AI_Action_Toggle_Comments_Global' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Toggle_Comments_Global() );
    }
    if ( class_exists( 'Arthur_AI_Action_Add_Cookie_Banner_Basic' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Add_Cookie_Banner_Basic() );
    }
    if ( class_exists( 'Arthur_AI_Action_Force_Https_Redirects' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Force_Https_Redirects() );
    }

    // Register media customisation actions
    if ( class_exists( 'Arthur_AI_Action_Auto_Optimise_Images' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Auto_Optimise_Images() );
    }
    if ( class_exists( 'Arthur_AI_Action_Auto_Rename_Uploads' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Auto_Rename_Uploads() );
    }
    if ( class_exists( 'Arthur_AI_Action_Replace_Media_File' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Replace_Media_File() );
    }
    if ( class_exists( 'Arthur_AI_Action_Add_Image_Sizes' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Add_Image_Sizes() );
    }
    if ( class_exists( 'Arthur_AI_Action_Convert_Images_To_Webp' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Convert_Images_To_Webp() );
    }
    if ( class_exists( 'Arthur_AI_Action_Generate_Image_Alt_Text_Ai' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Generate_Image_Alt_Text_Ai() );
    }
    if ( class_exists( 'Arthur_AI_Action_Bulk_Delete_Unused_Media' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Bulk_Delete_Unused_Media() );
    }

    // Additional media actions introduced for upload, regeneration, metadata and taxonomy management
    if ( class_exists( 'Arthur_AI_Action_Upload_Media_Items' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Upload_Media_Items() );
    }
    if ( class_exists( 'Arthur_AI_Action_Regenerate_Image_Sizes' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Regenerate_Image_Sizes() );
    }
    if ( class_exists( 'Arthur_AI_Action_Bulk_Update_Media_Meta' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Bulk_Update_Media_Meta() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Media_Taxonomies' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Media_Taxonomies() );
    }
    if ( class_exists( 'Arthur_AI_Action_Replace_Brand_Assets' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Replace_Brand_Assets() );
    }
    if ( class_exists( 'Arthur_AI_Action_Optimise_Existing_Images_Batch' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Optimise_Existing_Images_Batch() );
    }

    // Register SEO, marketing and social actions
    if ( class_exists( 'Arthur_AI_Action_Update_Seo_Meta' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Seo_Meta() );
    }
    if ( class_exists( 'Arthur_AI_Action_Set_Schema_Markup' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Schema_Markup() );
    }
    if ( class_exists( 'Arthur_AI_Action_Apply_Seo_Optimised_Content' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Apply_Seo_Optimised_Content() );
    }
    if ( class_exists( 'Arthur_AI_Action_Set_Indexing_Flags' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Indexing_Flags() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Sitemap_Settings' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Sitemap_Settings() );
    }
    if ( class_exists( 'Arthur_AI_Action_Cleanup_Redirected_Or_Orphaned_Content' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Cleanup_Redirected_Or_Orphaned_Content() );
    }
    if ( class_exists( 'Arthur_AI_Action_Manage_Redirects' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Manage_Redirects() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_404_Logging_And_Redirects' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_404_Logging_And_Redirects() );
    }
    if ( class_exists( 'Arthur_AI_Action_Set_Social_Meta' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Social_Meta() );
    }
    if ( class_exists( 'Arthur_AI_Action_Apply_Social_Share_Snippets' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Apply_Social_Share_Snippets() );
    }
    if ( class_exists( 'Arthur_AI_Action_Create_Landing_Page' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_Landing_Page() );
    }
    if ( class_exists( 'Arthur_AI_Action_Duplicate_Landing_Page_For_Ab' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Duplicate_Landing_Page_For_Ab() );
    }

    // Register performance, caching and housekeeping actions
    if ( class_exists( 'Arthur_AI_Action_Configure_Page_Cache' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Page_Cache() );
    }
    if ( class_exists( 'Arthur_AI_Action_Clear_Site_Cache' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Clear_Site_Cache() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Asset_Optimisation' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Asset_Optimisation() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Lazy_Loading' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Lazy_Loading() );
    }
    if ( class_exists( 'Arthur_AI_Action_Run_Db_Housekeeping' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Run_Db_Housekeeping() );
    }
    if ( class_exists( 'Arthur_AI_Action_Optimise_Database_Tables' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Optimise_Database_Tables() );
    }
    if ( class_exists( 'Arthur_AI_Action_Inspect_Scheduled_Tasks' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Inspect_Scheduled_Tasks() );
    }
    if ( class_exists( 'Arthur_AI_Action_Adjust_Cron_Tasks' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Adjust_Cron_Tasks() );
    }

    // Register new security actions
    if ( class_exists( 'Arthur_AI_Action_Toggle_File_Editing' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Toggle_File_Editing() );
    }
    if ( class_exists( 'Arthur_AI_Action_Toggle_Xmlrpc' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Toggle_Xmlrpc() );
    }
    if ( class_exists( 'Arthur_AI_Action_Toggle_Wp_Version_Exposure' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Toggle_Wp_Version_Exposure() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Rest_Api_Restrictions' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Rest_Api_Restrictions() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Login_Url_Obfuscation' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Login_Url_Obfuscation() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Login_Rate_Limiting' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Login_Rate_Limiting() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Two_Factor_Auth' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Two_Factor_Auth() );
    }
    if ( class_exists( 'Arthur_AI_Action_Audit_Roles_And_Capabilities' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Audit_Roles_And_Capabilities() );
    }
    if ( class_exists( 'Arthur_AI_Action_Report_Inactive_Users' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Report_Inactive_Users() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Privacy_And_Terms_Pages' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Privacy_And_Terms_Pages() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Cookie_Banner' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Cookie_Banner() );
    }
    if ( class_exists( 'Arthur_AI_Action_Process_Privacy_Requests' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Process_Privacy_Requests() );
    }

    // Register integration and automation actions
    if ( class_exists( 'Arthur_AI_Action_Configure_Email_Marketing_Integration' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Email_Marketing_Integration() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Crm_Integration' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Crm_Integration() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Global_Webhooks' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Global_Webhooks() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Automation_Rules' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Automation_Rules() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Nurture_Sequences' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Nurture_Sequences() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Tracking_Scripts' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Tracking_Scripts() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Tracking_Events' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Tracking_Events() );
    }
    if ( class_exists( 'Arthur_AI_Action_Create_Analytics_Dashboard_Page' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_Analytics_Dashboard_Page() );
    }
    if ( class_exists( 'Arthur_AI_Action_Import_Data_Batch' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Import_Data_Batch() );
    }
    if ( class_exists( 'Arthur_AI_Action_Export_Data_Batch' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Export_Data_Batch() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Import_Field_Mapping' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Import_Field_Mapping() );
    }
    if ( class_exists( 'Arthur_AI_Action_Trigger_Site_Backup' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Trigger_Site_Backup() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Backup_Schedule' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Backup_Schedule() );
    }
    if ( class_exists( 'Arthur_AI_Action_Store_Backup_Restore_Checklist' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Store_Backup_Restore_Checklist() );
    }

    // Register system/inspection/meta actions
    if ( class_exists( 'Arthur_AI_Action_List_Entities' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_List_Entities() );
    }
    if ( class_exists( 'Arthur_AI_Action_Scan_Content_Issues' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Scan_Content_Issues() );
    }
    if ( class_exists( 'Arthur_AI_Action_Get_Settings_Snapshot' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Get_Settings_Snapshot() );
    }
    if ( class_exists( 'Arthur_AI_Action_Inspect_Options_Bundle' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Inspect_Options_Bundle() );
    }
    if ( class_exists( 'Arthur_AI_Action_Apply_Options_Bundle' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Apply_Options_Bundle() );
    }
    if ( class_exists( 'Arthur_AI_Action_Preview_Change_Plan' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Preview_Change_Plan() );
    }
    if ( class_exists( 'Arthur_AI_Action_Export_Change_Plan' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Export_Change_Plan() );
    }

    // Initialise new customisers
    if ( class_exists( 'Arthur_AI_Performance_Customiser' ) ) {
        Arthur_AI_Performance_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Privacy_Customiser' ) ) {
        Arthur_AI_Privacy_Customiser::init();
    }
    if ( class_exists( 'Arthur_AI_Analytics_Customiser' ) ) {
        Arthur_AI_Analytics_Customiser::init();
    }

    // Register WooCommerce customisation actions
    if ( class_exists( 'Arthur_AI_Action_Woocommerce_Change_Add_To_Cart_Text' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Woocommerce_Change_Add_To_Cart_Text() );
    }
    if ( class_exists( 'Arthur_AI_Action_Woocommerce_Add_Product_Tab' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Woocommerce_Add_Product_Tab() );
    }
    if ( class_exists( 'Arthur_AI_Action_Woocommerce_Change_Checkout_Fields' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Woocommerce_Change_Checkout_Fields() );
    }
    if ( class_exists( 'Arthur_AI_Action_Woocommerce_Require_Phone' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Woocommerce_Require_Phone() );
    }
    if ( class_exists( 'Arthur_AI_Action_Woocommerce_Postcode_Validation' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Woocommerce_Postcode_Validation() );
    }
    if ( class_exists( 'Arthur_AI_Action_Woocommerce_Auto_Tag_Orders' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Woocommerce_Auto_Tag_Orders() );
    }
    if ( class_exists( 'Arthur_AI_Action_Woocommerce_Custom_Thankyou_Message' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Woocommerce_Custom_Thankyou_Message() );
    }
    if ( class_exists( 'Arthur_AI_Action_Woocommerce_Update_Email_Templates' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Woocommerce_Update_Email_Templates() );
    }

    // Register core WooCommerce product management actions
    if ( class_exists( 'Arthur_AI_Action_Create_Product' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_Product() );
    }
    if ( class_exists( 'Arthur_AI_Action_Bulk_Edit_Products' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Bulk_Edit_Products() );
    }
    if ( class_exists( 'Arthur_AI_Action_Duplicate_Product' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Duplicate_Product() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Product_Attributes' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Product_Attributes() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Product_Categories' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Product_Categories() );
    }
    if ( class_exists( 'Arthur_AI_Action_Reorganise_Product_Taxonomy' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Reorganise_Product_Taxonomy() );
    }

    // Register extended WooCommerce actions for product management, checkout, orders,
    // email customisation, account endpoints, coupons, shipping, tax and popular extensions
    if ( class_exists( 'Arthur_AI_Action_Update_Product_Tags' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Product_Tags() );
    }
    if ( class_exists( 'Arthur_AI_Action_Rewrite_Product_Descriptions' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Rewrite_Product_Descriptions() );
    }
    if ( class_exists( 'Arthur_AI_Action_Generate_Product_USPs' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Generate_Product_USPs() );
    }
    if ( class_exists( 'Arthur_AI_Action_Assign_Cross_Sells' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Assign_Cross_Sells() );
    }
    if ( class_exists( 'Arthur_AI_Action_Customise_Checkout_Fields' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Customise_Checkout_Fields() );
    }
    if ( class_exists( 'Arthur_AI_Action_Set_Guest_Checkout_Mode' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Guest_Checkout_Mode() );
    }
    if ( class_exists( 'Arthur_AI_Action_Add_Checkout_Instructions' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Add_Checkout_Instructions() );
    }
    if ( class_exists( 'Arthur_AI_Action_Edit_Order_Details' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Edit_Order_Details() );
    }
    if ( class_exists( 'Arthur_AI_Action_Bulk_Update_Order_Statuses' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Bulk_Update_Order_Statuses() );
    }
    if ( class_exists( 'Arthur_AI_Action_Generate_Order_Response' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Generate_Order_Response() );
    }
    if ( class_exists( 'Arthur_AI_Action_Customise_Woo_Emails' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Customise_Woo_Emails() );
    }
    if ( class_exists( 'Arthur_AI_Action_Adjust_Email_Triggers' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Adjust_Email_Triggers() );
    }
    if ( class_exists( 'Arthur_AI_Action_Add_My_Account_Endpoint' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Add_My_Account_Endpoint() );
    }
    if ( class_exists( 'Arthur_AI_Action_Merge_My_Account_Dashboard' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Merge_My_Account_Dashboard() );
    }
    if ( class_exists( 'Arthur_AI_Action_Manage_Coupons' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Manage_Coupons() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Shipping' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Shipping() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Tax_Rates' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Tax_Rates() );
    }
    if ( class_exists( 'Arthur_AI_Action_Manage_Subscriptions' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Manage_Subscriptions() );
    }
    if ( class_exists( 'Arthur_AI_Action_Manage_Bookings' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Manage_Bookings() );
    }
    if ( class_exists( 'Arthur_AI_Action_Manage_Memberships' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Manage_Memberships() );
    }

    // Register new content creation and editing actions
    if ( class_exists( 'Arthur_AI_Action_Duplicate_Post_Full' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Duplicate_Post_Full() );
    }
    if ( class_exists( 'Arthur_AI_Action_Convert_Post_Type' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Convert_Post_Type() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Headings_Structure' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Headings_Structure() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Meta_Fields_Single' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Meta_Fields_Single() );
    }
    if ( class_exists( 'Arthur_AI_Action_Bulk_Update_Meta_Fields' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Bulk_Update_Meta_Fields() );
    }
    if ( class_exists( 'Arthur_AI_Action_Map_Imported_Data_To_Meta' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Map_Imported_Data_To_Meta() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Post_Taxonomies' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Post_Taxonomies() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Post_Custom_Taxonomies' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Post_Custom_Taxonomies() );
    }
    if ( class_exists( 'Arthur_AI_Action_Insert_Blocks_In_Post' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Insert_Blocks_In_Post() );
    }
    if ( class_exists( 'Arthur_AI_Action_Restructure_Post_Into_Sections' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Restructure_Post_Into_Sections() );
    }
    if ( class_exists( 'Arthur_AI_Action_Convert_Classic_To_Blocks' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Convert_Classic_To_Blocks() );
    }
    if ( class_exists( 'Arthur_AI_Action_Wrap_Content_In_Pattern' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Wrap_Content_In_Pattern() );
    }
    if ( class_exists( 'Arthur_AI_Action_Moderate_Comments_By_Rules' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Moderate_Comments_By_Rules() );
    }
    if ( class_exists( 'Arthur_AI_Action_Reply_To_Comment' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Reply_To_Comment() );
    }
    if ( class_exists( 'Arthur_AI_Action_Bulk_Close_Comments_On_Old_Posts' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Bulk_Close_Comments_On_Old_Posts() );
    }

    // Register design/theme customisation actions
    if ( class_exists( 'Arthur_AI_Action_Change_Site_Logo' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Change_Site_Logo() );
    }
    if ( class_exists( 'Arthur_AI_Action_Change_Site_Icon' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Change_Site_Icon() );
    }
    if ( class_exists( 'Arthur_AI_Action_Set_Header_Logo_Variants' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Header_Logo_Variants() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Global_Design_Tokens' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Global_Design_Tokens() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Global_Button_Styles' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Global_Button_Styles() );
    }
    if ( class_exists( 'Arthur_AI_Action_Edit_Header_Layout' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Edit_Header_Layout() );
    }
    if ( class_exists( 'Arthur_AI_Action_Edit_Footer_Layout' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Edit_Footer_Layout() );
    }
    if ( class_exists( 'Arthur_AI_Action_Manage_Block_Template' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Manage_Block_Template() );
    }
    if ( class_exists( 'Arthur_AI_Action_Define_Block_Pattern' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Define_Block_Pattern() );
    }
    if ( class_exists( 'Arthur_AI_Action_Apply_Pattern_To_Posts' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Apply_Pattern_To_Posts() );
    }
    if ( class_exists( 'Arthur_AI_Action_Duplicate_Elementor_Template' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Duplicate_Elementor_Template() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Elementor_Widget_Content' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Elementor_Widget_Content() );
    }
    if ( class_exists( 'Arthur_AI_Action_Tune_Elementor_Responsive_Layout' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Tune_Elementor_Responsive_Layout() );
    }
    if ( class_exists( 'Arthur_AI_Action_Add_Frontend_Responsive_Css' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Add_Frontend_Responsive_Css() );
    }
    if ( class_exists( 'Arthur_AI_Action_Standardise_Section_Spacing' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Standardise_Section_Spacing() );
    }
    if ( class_exists( 'Arthur_AI_Action_Apply_Layout_Grid' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Apply_Layout_Grid() );
    }

    // Register navigation and site structure actions
    if ( class_exists( 'Arthur_AI_Action_Create_Or_Update_Nav_Menu' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_Or_Update_Nav_Menu() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Nav_Menu_Items' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Nav_Menu_Items() );
    }
    if ( class_exists( 'Arthur_AI_Action_Rename_Nav_Menu_Labels' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Rename_Nav_Menu_Labels() );
    }
    if ( class_exists( 'Arthur_AI_Action_Set_Role_Based_Menus' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Role_Based_Menus() );
    }
    if ( class_exists( 'Arthur_AI_Action_Create_Core_Pages' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_Core_Pages() );
    }
    if ( class_exists( 'Arthur_AI_Action_Reorganise_Page_Hierarchy' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Reorganise_Page_Hierarchy() );
    }
    if ( class_exists( 'Arthur_AI_Action_Assign_Page_Templates_Bulk' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Assign_Page_Templates_Bulk() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Widget_Area' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Widget_Area() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Sidebar_Blocks' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Sidebar_Blocks() );
    }
    if ( class_exists( 'Arthur_AI_Action_Insert_Internal_Links' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Insert_Internal_Links() );
    }
    if ( class_exists( 'Arthur_AI_Action_Fix_Broken_Internal_Links' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Fix_Broken_Internal_Links() );
    }
    if ( class_exists( 'Arthur_AI_Action_Generate_Index_Page' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Generate_Index_Page() );
    }
    if ( class_exists( 'Arthur_AI_Action_Manage_Sitemap_Inclusion' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Manage_Sitemap_Inclusion() );
    }

    // Register forms and lead capture actions
    if ( class_exists( 'Arthur_AI_Action_Create_Form_From_Brief' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_Form_From_Brief() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Form_Fields' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Form_Fields() );
    }
    if ( class_exists( 'Arthur_AI_Action_Create_Multistep_Form' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_Multistep_Form() );
    }
    if ( class_exists( 'Arthur_AI_Action_Embed_Form_On_Pages' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Embed_Form_On_Pages() );
    }
    if ( class_exists( 'Arthur_AI_Action_Set_Form_Style_Preset' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Set_Form_Style_Preset() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Form_Notifications' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Form_Notifications() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Form_Confirmations' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Form_Confirmations() );
    }
    if ( class_exists( 'Arthur_AI_Action_Export_Form_Entries' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Export_Form_Entries() );
    }
    if ( class_exists( 'Arthur_AI_Action_Tag_Form_Leads' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Tag_Form_Leads() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Form_Webhooks' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Form_Webhooks() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Form_Crm_Mapping' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Form_Crm_Mapping() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Form_Payments' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Form_Payments() );
    }
    if ( class_exists( 'Arthur_AI_Action_Toggle_Form_Logging' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Toggle_Form_Logging() );
    }

    // Register events, bookings and calendar actions
    if ( class_exists( 'Arthur_AI_Action_Create_Event' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_Event() );
    }
    if ( class_exists( 'Arthur_AI_Action_Duplicate_Event' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Duplicate_Event() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Event_Details' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Event_Details() );
    }
    if ( class_exists( 'Arthur_AI_Action_Manage_Event_Tickets' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Manage_Event_Tickets() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Ticket_Caps' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Ticket_Caps() );
    }
    if ( class_exists( 'Arthur_AI_Action_Manage_Event_Attendees' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Manage_Event_Attendees() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Event_Booking_Rules' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Event_Booking_Rules() );
    }
    if ( class_exists( 'Arthur_AI_Action_Close_Event_Bookings' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Close_Event_Bookings() );
    }
    if ( class_exists( 'Arthur_AI_Action_Customise_Event_Views' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Customise_Event_Views() );
    }
    if ( class_exists( 'Arthur_AI_Action_Create_My_Bookings_Dashboard' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_My_Bookings_Dashboard() );
    }
    if ( class_exists( 'Arthur_AI_Action_Sync_Event_Tickets_With_Woo' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Sync_Event_Tickets_With_Woo() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_External_Calendar_Sync' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_External_Calendar_Sync() );
    }

    // Register membership, subscription and LMS actions
    if ( class_exists( 'Arthur_AI_Action_Create_Membership_Level' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_Membership_Level() );
    }
    if ( class_exists( 'Arthur_AI_Action_Protect_Content_By_Membership' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Protect_Content_By_Membership() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Membership_Signup_Flow' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Membership_Signup_Flow() );
    }
    if ( class_exists( 'Arthur_AI_Action_Create_Subscription_Plan' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_Subscription_Plan() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Subscription_Renewal_Flows' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Subscription_Renewal_Flows() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Course_Structure' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Course_Structure() );
    }
    if ( class_exists( 'Arthur_AI_Action_Manage_Student_Enrolment' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Manage_Student_Enrolment() );
    }
    if ( class_exists( 'Arthur_AI_Action_Create_My_Membership_Dashboard' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_My_Membership_Dashboard() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Member_Recommendations' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Member_Recommendations() );
    }
    if ( class_exists( 'Arthur_AI_Action_Map_Membership_To_Courses' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Map_Membership_To_Courses() );
    }
    // Register LMS actions (course/lesson/quiz)
    if ( class_exists( 'Arthur_AI_Action_Create_Or_Update_Course' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_Or_Update_Course() );
    }
    if ( class_exists( 'Arthur_AI_Action_Create_Or_Update_Lessons' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_Or_Update_Lessons() );
    }
    if ( class_exists( 'Arthur_AI_Action_Create_Or_Update_Quizzes' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_Or_Update_Quizzes() );
    }
    if ( class_exists( 'Arthur_AI_Action_Apply_Generated_Lesson_Content' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Apply_Generated_Lesson_Content() );
    }

    // Register meta/introspection actions
    if ( class_exists( 'Arthur_AI_Action_List_Orders' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_List_Orders() );
    }
    if ( class_exists( 'Arthur_AI_Action_List_Products' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_List_Products() );
    }
    if ( class_exists( 'Arthur_AI_Action_List_Events' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_List_Events() );
    }
    if ( class_exists( 'Arthur_AI_Action_List_Memberships' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_List_Memberships() );
    }

    // Register system planning and checkpoint actions
    if ( class_exists( 'Arthur_AI_Action_Simulate_Changes' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Simulate_Changes() );
    }
    if ( class_exists( 'Arthur_AI_Action_Execute_Change_Plan' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Execute_Change_Plan() );
    }
    if ( class_exists( 'Arthur_AI_Action_Create_Site_Checkpoint' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Create_Site_Checkpoint() );
    }
    if ( class_exists( 'Arthur_AI_Action_List_Site_Checkpoints' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_List_Site_Checkpoints() );
    }
    if ( class_exists( 'Arthur_AI_Action_Rollback_To_Checkpoint' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Rollback_To_Checkpoint() );
    }
    if ( class_exists( 'Arthur_AI_Action_List_Arthur_Action_Log' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_List_Arthur_Action_Log() );
    }

    // Register plugin lifecycle actions
    if ( class_exists( 'Arthur_AI_Action_Activate_Plugins' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Activate_Plugins() );
    }
    if ( class_exists( 'Arthur_AI_Action_Deactivate_Plugins' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Deactivate_Plugins() );
    }
    if ( class_exists( 'Arthur_AI_Action_Delete_Plugins' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Delete_Plugins() );
    }
    if ( class_exists( 'Arthur_AI_Action_Toggle_Plugin_Auto_Updates' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Toggle_Plugin_Auto_Updates() );
    }
    if ( class_exists( 'Arthur_AI_Action_List_Plugins_Status' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_List_Plugins_Status() );
    }

    // Register theme lifecycle actions
    if ( class_exists( 'Arthur_AI_Action_Install_Theme' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Install_Theme() );
    }
    if ( class_exists( 'Arthur_AI_Action_Activate_Theme' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Activate_Theme() );
    }
    if ( class_exists( 'Arthur_AI_Action_Delete_Theme' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Delete_Theme() );
    }
    if ( class_exists( 'Arthur_AI_Action_Toggle_Theme_Auto_Updates' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Toggle_Theme_Auto_Updates() );
    }

    // Register core update and translation actions
    if ( class_exists( 'Arthur_AI_Action_Update_Core' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Core() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Core_Auto_Update' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Core_Auto_Update() );
    }
    if ( class_exists( 'Arthur_AI_Action_Update_Translations' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Update_Translations() );
    }
    if ( class_exists( 'Arthur_AI_Action_Check_Filesystem_Health' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Check_Filesystem_Health() );
    }

    // Register general settings actions
    if ( class_exists( 'Arthur_AI_Action_Configure_General_Settings' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_General_Settings() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Writing_Settings' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Writing_Settings() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Reading_Settings' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Reading_Settings() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Media_Settings' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Media_Settings() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Permalink_Bases' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Permalink_Bases() );
    }
    if ( class_exists( 'Arthur_AI_Action_Flush_Rewrite_Rules_Safely' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Flush_Rewrite_Rules_Safely() );
    }

    // Register extended performance actions
    if ( class_exists( 'Arthur_AI_Action_Configure_Cdn' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Cdn() );
    }
    if ( class_exists( 'Arthur_AI_Action_Cdn_Purge_Cache' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Cdn_Purge_Cache() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Object_Cache' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Object_Cache() );
    }
    if ( class_exists( 'Arthur_AI_Action_Flush_Object_Cache' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Flush_Object_Cache() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Housekeeping_Profile' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Housekeeping_Profile() );
    }
    if ( class_exists( 'Arthur_AI_Action_Run_Housekeeping_Profile' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Run_Housekeeping_Profile() );
    }

    // Register advanced security actions
    if ( class_exists( 'Arthur_AI_Action_Manage_Security_Firewall' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Manage_Security_Firewall() );
    }
    if ( class_exists( 'Arthur_AI_Action_Run_Malware_Scan' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Run_Malware_Scan() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Password_Policy' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Password_Policy() );
    }
    if ( class_exists( 'Arthur_AI_Action_Generate_Security_Report' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Generate_Security_Report() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Region_Based_Cookie_Rules' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Region_Based_Cookie_Rules() );
    }

    // Register analytics actions
    if ( class_exists( 'Arthur_AI_Action_Query_Analytics_Metrics' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Query_Analytics_Metrics() );
    }
    if ( class_exists( 'Arthur_AI_Action_Query_Analytics_Funnels' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Query_Analytics_Funnels() );
    }
    if ( class_exists( 'Arthur_AI_Action_List_Tracking_Events' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_List_Tracking_Events() );
    }
    if ( class_exists( 'Arthur_AI_Action_Toggle_Tracking_Event' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Toggle_Tracking_Event() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Action_Logging' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Action_Logging() );
    }
    if ( class_exists( 'Arthur_AI_Action_Report_System_Errors' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Report_System_Errors() );
    }

    // Register multisite and environment actions
    if ( class_exists( 'Arthur_AI_Action_Manage_Subsites' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Manage_Subsites() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Environment_Profiles' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Environment_Profiles() );
    }
    if ( class_exists( 'Arthur_AI_Action_Get_Current_Environment' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Get_Current_Environment() );
    }

    // Register SSO & directory sync actions
    if ( class_exists( 'Arthur_AI_Action_Configure_Sso_Provider' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Sso_Provider() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Sso_Mapping' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Sso_Mapping() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Sso_Modes' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Sso_Modes() );
    }
    if ( class_exists( 'Arthur_AI_Action_Test_Sso_Connection' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Test_Sso_Connection() );
    }
    if ( class_exists( 'Arthur_AI_Action_Configure_Directory_Sync' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Configure_Directory_Sync() );
    }
    if ( class_exists( 'Arthur_AI_Action_Run_Directory_Sync' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Run_Directory_Sync() );
    }

    // Register developer tools actions
    if ( class_exists( 'Arthur_AI_Action_Manage_Code_Snippets' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Manage_Code_Snippets() );
    }
    if ( class_exists( 'Arthur_AI_Action_Rollback_Snippet_On_Error' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Rollback_Snippet_On_Error() );
    }
    if ( class_exists( 'Arthur_AI_Action_Edit_Theme_Template_File' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Edit_Theme_Template_File() );
    }
    if ( class_exists( 'Arthur_AI_Action_Rollback_Theme_Template_File' ) ) {
        Arthur_AI_Actions_Registry::register_action( new Arthur_AI_Action_Rollback_Theme_Template_File() );
    }

    // Register modules
    Arthur_AI_Modules::register_module( new Arthur_AI_Module_Content() );

    Arthur_AI_Rest::init();
    Arthur_AI_Admin_Page::init();
}
add_action( 'init', 'arthur_ai_content_assistant_init' );

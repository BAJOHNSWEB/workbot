<?php
/**
 * Bookings customiser for event booking rules, closures and dashboards.
 *
 * Enforces booking windows and closure policies by disabling ticket
 * purchase forms when events are closed or outside of booking windows.
 * Provides a shortcode to display a logged‑in user’s bookings and
 * tickets. Reads configuration saved via configure_event_booking_rules
 * and close_event_bookings actions.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Bookings_Customiser {
    /**
     * Initialise hooks.
     */
    public static function init() {
        // Block ticket forms if bookings are closed or outside booking window
        add_filter( 'tribe_tickets_tickets_enabled_for_event', array( __CLASS__, 'maybe_disable_ticket_form' ), 10, 2 );
        // Shortcode for My bookings dashboard
        add_shortcode( 'arthur_ai_my_bookings', array( __CLASS__, 'render_my_bookings' ) );
    }

    /**
     * Determine whether ticket forms should be shown for an event.
     *
     * @param bool $enabled Original enabled value.
     * @param int  $event_id Event post ID.
     * @return bool
     */
    public static function maybe_disable_ticket_form( $enabled, $event_id ) {
        // Retrieve booking rules and closure state
        $rules  = get_post_meta( $event_id, 'arthur_ai_booking_rules', true );
        $closed = get_post_meta( $event_id, 'arthur_ai_event_closed_state', true );
        // If event is closed and hide_tickets is true, disable form
        if ( ! empty( $closed ) && isset( $closed['hide_tickets'] ) && $closed['hide_tickets'] ) {
            return false;
        }
        // Check booking window if defined
        if ( ! empty( $rules['booking_window'] ) ) {
            $now        = current_time( 'Y-m-d H:i:s' );
            $open_time  = ! empty( $rules['booking_window']['open'] ) ? $rules['booking_window']['open'] : '';
            $close_time = ! empty( $rules['booking_window']['close'] ) ? $rules['booking_window']['close'] : '';
            if ( $open_time && $now < $open_time ) {
                return false;
            }
            if ( $close_time && $now > $close_time ) {
                return false;
            }
        }
        return $enabled;
    }

    /**
     * Render the My bookings dashboard for logged‑in users.
     *
     * Lists tickets purchased by the current user using Event Tickets
     * attendee data. Falls back to a message when no bookings exist.
     *
     * @return string
     */
    public static function render_my_bookings() {
        if ( ! class_exists( 'Tribe__Tickets__Tickets' ) ) {
            return '';
        }
        if ( ! is_user_logged_in() ) {
            return '<p>' . esc_html__( 'Please log in to view your bookings.', 'arthur-ai' ) . '</p>';
        }
        $user    = wp_get_current_user();
        $email   = $user->user_email;
        // Fetch attendee posts matching this email. We attempt to use known meta keys.
        $attendees = get_posts( array(
            'post_type'      => 'tribe_attendee',
            'posts_per_page' => -1,
            'meta_query'     => array(
                array(
                    'key'     => '_tribe_tickets_email',
                    'value'   => $email,
                    'compare' => '=',
                ),
            ),
        ) );
        if ( empty( $attendees ) ) {
            return '<p>' . esc_html__( 'You have no bookings.', 'arthur-ai' ) . '</p>';
        }
        $output = '<div class="arthur-ai-bookings-dashboard"><ul class="arthur-ai-bookings">';
        foreach ( $attendees as $att ) {
            $event_id  = get_post_meta( $att->ID, '_tribe_ticket_event', true );
            $ticket_id = get_post_meta( $att->ID, '_tribe_ticket_id', true );
            if ( $event_id ) {
                $event_title  = get_the_title( $event_id );
                $event_link   = get_permalink( $event_id );
                $ticket_title = $ticket_id ? get_the_title( $ticket_id ) : '';
                $output      .= '<li class="arthur-ai-booking-item">';
                $output      .= '<a href="' . esc_url( $event_link ) . '">' . esc_html( $event_title ) . '</a>';
                if ( $ticket_title ) {
                    $output  .= ' – ' . esc_html( $ticket_title );
                }
                $output      .= '</li>';
            }
        }
        $output .= '</ul></div>';
        return $output;
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Performance customisations applied at runtime.
 *
 * Handles features such as lazy loading images when no dedicated plugin
 * implements it, applying simple frontend optimisations based on AI
 * actions. Currently this class focuses on lazy loading; it could be
 * extended to include other performance tweaks.
 */
class Arthur_AI_Performance_Customiser {

    /**
     * Initialise hooks.
     */
    public static function init() {
        $settings = get_option( 'arthur_ai_lazy_loading', array() );
        $enabled  = isset( $settings['enabled'] ) ? (bool) $settings['enabled'] : false;
        if ( $enabled ) {
            add_filter( 'the_content', array( __CLASS__, 'filter_the_content_lazyload' ), 20 );
            add_filter( 'post_thumbnail_html', array( __CLASS__, 'filter_img_tag_lazyload' ), 20 );
            add_filter( 'wp_get_attachment_image_attributes', array( __CLASS__, 'filter_attachment_image_attributes' ), 20, 3 );
        }
    }

    /**
     * Lazy load images in post content.
     *
     * @param string $content
     * @return string
     */
    public static function filter_the_content_lazyload( $content ) {
        if ( empty( $content ) ) {
            return $content;
        }
        // Do not add loading attribute if browser already supports default lazy loading (WordPress does by default in recent versions).
        // We still enforce it for browsers that ignore WordPress default; this is simple string replacement.
        return preg_replace_callback( '/<img[^>]+>/', function ( $matches ) {
            $img = $matches[0];
            // Skip if already has loading attribute.
            if ( false !== stripos( $img, 'loading=' ) ) {
                return $img;
            }
            // Skip images with noscript fallback or special classes.
            if ( false !== stripos( $img, 'skip-lazy' ) ) {
                return $img;
            }
            // Insert loading="lazy" before closing tag.
            return preg_replace( '/<img([^>]+)\/>/', '<img$1 loading="lazy" />', $img );
        }, $content );
    }

    /**
     * Add loading="lazy" to post thumbnails.
     *
     * @param string $html
     * @return string
     */
    public static function filter_img_tag_lazyload( $html ) {
        if ( strpos( $html, 'loading=' ) === false ) {
            $html = preg_replace( '/<img([^>]+)\/>/', '<img$1 loading="lazy" />', $html );
        }
        return $html;
    }

    /**
     * Ensure attachment image attributes include loading="lazy".
     *
     * @param array  $attr Attributes.
     * @param object $attachment Attachment object.
     * @param string $size
     * @return array
     */
    public static function filter_attachment_image_attributes( $attr, $attachment, $size ) {
        if ( empty( $attr['loading'] ) ) {
            $attr['loading'] = 'lazy';
        }
        return $attr;
    }
}

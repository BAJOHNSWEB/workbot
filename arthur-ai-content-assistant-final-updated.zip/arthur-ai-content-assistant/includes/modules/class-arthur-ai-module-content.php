<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Module_Content implements Arthur_AI_Module_Interface {

    public function get_id() {
        return 'content';
    }

    public function get_title() {
        return __( 'Content Assistant', 'arthur-ai' );
    }

    public function get_prompt_context() {
        // Expand prompt context to mention that this module can manage user profiles,
        // security rules, general site settings, media handling, WooCommerce tweaks
        // and front‑end design/theme adjustments.
        return 'You are operating in the Content module. Focus on WordPress posts and pages and appearance changes such as the login and admin pages. You may create, rewrite and structurally edit content. You can insert blocks such as quotes, callouts, bullet lists, CTAs and summary sections using valid HTML. You may also update login page settings such as the logo, background colour or image, button colours, welcome message, footer text and custom CSS. In addition to content, you can manage user accounts and profile fields, enforce security settings like password strength, rename the login URL or restrict XML‑RPC and REST API access, update general site settings including the site title, tagline and permalink structure, insert analytics or custom HTML into the head and footer, control comments and cookie banners, optimise and rename media uploads, define new image sizes and convert to WebP, and perform basic WooCommerce customisation like altering buttons, tabs, checkout fields or order tagging.  You can also configure caching and performance settings, run database housekeeping tasks, inspect or adjust scheduled cron jobs, optimise database tables and configure lazy loading or asset optimisation. Security actions allow you to toggle file editing, XML‑RPC and version exposure, configure REST API restrictions, obfuscate the login URL, set login rate limiting and two‑factor authentication, audit roles and report inactive users, manage privacy pages and cookie banners, and process privacy requests. Integration and automation actions let you connect email marketing and CRM services, set up global webhooks, define automation rules and nurture sequences, configure tracking scripts and events, manage imports and exports, trigger backups and schedules, and store backup checklists.  On the design front, you can adjust the site logo and icon, set light and dark logo variants, define global colours and typography, customise button styles, edit header and footer templates, manage block templates and patterns, apply patterns across pages, duplicate and edit Elementor templates, tune Elementor responsive settings, add responsive CSS, standardise section spacing and apply a consistent layout grid. Prefer updating existing pages or posts in the site map when the user refers to them by name (e.g. About Us page, Contact page). Only create a new page or post if no suitable existing one exists.';
    }

    public function get_allowed_actions() {
        return array(
            // Content actions
            'create_post',
            'update_post_image_and_text',
            'rewrite_post_body',
            'append_note_to_post',
            'replace_snippet_in_post',
            'insert_after_heading_in_post',
            'insert_at_bottom_of_post',
            'bulk_create_posts',
            'generate_summary_post',
            'publish_post',
            'update_menu_add_items',
            'replace_frontend_snippet',
            'replace_in_elementor_data',
            'replace_in_block_template',

            // Login customisation actions
            'change_login_logo',
            'change_login_bg_color',
            'change_login_bg_image',
            'change_login_button_colors',
            'set_login_message',
            'toggle_login_links',
            'change_login_form_style',
            'toggle_login_form_alignment',
            'set_login_footer_text',
            'set_login_custom_css',
            'set_login_logo_link',

            // Admin customisation actions
            'change_admin_toolbar_colors',
            'change_admin_menu_colors',
            'set_admin_footer_text',
            'set_admin_custom_css',

            // Admin menu / sidebar customisation actions
            'hide_admin_menu_items',
            'rename_admin_menu_item',
            'reorder_admin_menu_items',
            'add_admin_menu_page',
            'add_admin_submenu_page',
            'hide_admin_menu_items_by_role',
            'move_admin_settings',
            'collapse_admin_menu',

            // Post/page editor customisation actions
            'disable_gutenberg',
            'enable_gutenberg_blocks',
            'disable_gutenberg_blocks',
            'set_auto_reusable_block',
            'disable_comments',
            'hide_featured_image_box',
            'hide_tags_categories_box',
            'add_custom_fields',
            'set_title_placeholder',
            'set_default_featured_image',
            'set_default_category',
            'duplicate_post',
            'bulk_duplicate_posts',
            'lock_pages',

            // Content creation & editing actions
            'duplicate_post_full',
            'convert_post_type',
            'update_headings_structure',
            'update_meta_fields_single',
            'bulk_update_meta_fields',
            'map_imported_data_to_meta',
            'update_post_taxonomies',
            'update_post_custom_taxonomies',
            'insert_blocks_in_post',
            'restructure_post_into_sections',
            'convert_classic_to_blocks',
            'wrap_content_in_pattern',
            'moderate_comments_by_rules',
            'reply_to_comment',
            'bulk_close_comments_on_old_posts',

            // Profile/user customisation actions
            'force_strong_passwords',
            'rename_user_roles',
            'create_user_role',
            'hide_profile_fields',
            'add_profile_fields',
            'redirect_on_login',
            'redirect_on_logout',
            'disable_admin_bar_for_non_admins',

            // Security customisation actions
            'rename_login_url',
            'disable_xml_rpc',
            'disable_file_editing',
            'limit_login_attempts',
            'auto_logout_inactive_users',
            'hide_wp_version',
            'disable_rest_api_for_guests',

            // Site settings / misc actions
            'change_site_title',
            'change_site_tagline',
            'change_permalink_structure',
            'add_google_analytics_snippet',
            'add_custom_head_html',
            'add_custom_footer_html',
            'toggle_comments_global',
            'add_cookie_banner_basic',
            'force_https_redirects',

            // Media customisation actions
            'auto_optimise_images',
            'auto_rename_uploads',
            'replace_media_file',
            'add_image_sizes',
            'convert_images_to_webp',
            'generate_image_alt_text_ai',
            'bulk_delete_unused_media',

            // New media library actions
            'upload_media_items',
            'regenerate_image_sizes',
            'bulk_update_media_meta',
            'update_media_taxonomies',
            'replace_brand_assets',
            'optimise_existing_images_batch',

            // WooCommerce customisation actions
            'woocommerce_change_add_to_cart_text',
            'woocommerce_add_product_tab',
            'woocommerce_change_checkout_fields',
            'woocommerce_require_phone',
            'woocommerce_postcode_validation',
            'woocommerce_auto_tag_orders',
            'woocommerce_custom_thankyou_message',
            'woocommerce_update_email_templates',

            // WooCommerce product management
            'create_product',
            'bulk_edit_products',
            'duplicate_product',
            'update_product_attributes',
            'update_product_categories',
            'reorganise_product_taxonomy',
            'update_product_tags',
            'rewrite_product_descriptions',
            'generate_product_usps',
            'assign_cross_sells',

            // WooCommerce checkout and account
            'customise_checkout_fields',
            'set_guest_checkout_mode',
            'add_checkout_instructions',

            // WooCommerce orders & fulfilment
            'edit_order_details',
            'bulk_update_order_statuses',
            'generate_order_response',

            // WooCommerce email customisation
            'customise_woo_emails',
            'adjust_email_triggers',

            // WooCommerce My Account
            'add_my_account_endpoint',
            'merge_my_account_dashboard',

            // WooCommerce coupons, shipping and tax
            'manage_coupons',
            'configure_shipping',
            'configure_tax_rates',

            // WooCommerce extensions
            'manage_subscriptions',
            'manage_bookings',
            'manage_memberships',

            // Theme/design customisation actions
            'change_site_logo',
            'change_site_icon',
            'set_header_logo_variants',
            'update_global_design_tokens',
            'update_global_button_styles',
            'edit_header_layout',
            'edit_footer_layout',
            'manage_block_template',
            'define_block_pattern',
            'apply_pattern_to_posts',
            'duplicate_elementor_template',
            'update_elementor_widget_content',
            'tune_elementor_responsive_layout',
            'add_frontend_responsive_css',
            'standardise_section_spacing',
            'apply_layout_grid',

            // Site structure & navigation actions
            'create_or_update_nav_menu',
            'update_nav_menu_items',
            'rename_nav_menu_labels',
            'set_role_based_menus',
            'create_core_pages',
            'reorganise_page_hierarchy',
            'assign_page_templates_bulk',
            'configure_widget_area',
            'update_sidebar_blocks',
            'insert_internal_links',
            'fix_broken_internal_links',
            'generate_index_page',
            'manage_sitemap_inclusion',

            // Forms & lead capture actions
            'create_form_from_brief',
            'update_form_fields',
            'create_multistep_form',
            'embed_form_on_pages',
            'set_form_style_preset',
            'configure_form_notifications',
            'configure_form_confirmations',
            'export_form_entries',
            'tag_form_leads',
            'configure_form_webhooks',
            'configure_form_crm_mapping',
            'configure_form_payments',
            'toggle_form_logging',

            // Events, bookings and calendars actions
            'create_event',
            'duplicate_event',
            'update_event_details',
            'manage_event_tickets',
            'update_ticket_caps',
            'manage_event_attendees',
            'configure_event_booking_rules',
            'close_event_bookings',
            'customise_event_views',
            'create_my_bookings_dashboard',
            'sync_event_tickets_with_woo',
            'configure_external_calendar_sync',

            // Membership, subscriptions and LMS actions
            'create_membership_level',
            'protect_content_by_membership',
            'configure_membership_signup_flow',
            'create_subscription_plan',
            'configure_subscription_renewal_flows',
            'configure_course_structure',
            'manage_student_enrolment',
            'create_my_membership_dashboard',
            'configure_member_recommendations',
            'map_membership_to_courses',
            // LMS content actions
            'create_or_update_course',
            'create_or_update_lessons',
            'create_or_update_quizzes',
            'apply_generated_lesson_content',

            // SEO, marketing and social sharing actions
            'update_seo_meta',
            'set_schema_markup',
            'apply_seo_optimised_content',
            'set_indexing_flags',
            'configure_sitemap_settings',
            'cleanup_redirected_or_orphaned_content',
            'manage_redirects',
            'configure_404_logging_and_redirects',
            'set_social_meta',
            'apply_social_share_snippets',
            'create_landing_page',
            'duplicate_landing_page_for_ab',

            // System/inspection/meta actions
            'list_entities',
            'scan_content_issues',
            'get_settings_snapshot',
            'inspect_options_bundle',
            'apply_options_bundle',
            'preview_change_plan',
            'export_change_plan',

            // Performance, caching & housekeeping actions
            'configure_page_cache',
            'clear_site_cache',
            'configure_asset_optimisation',
            'configure_lazy_loading',
            'run_db_housekeeping',
            'optimise_database_tables',
            'inspect_scheduled_tasks',
            'adjust_cron_tasks',

            // Security, privacy & compliance actions
            'toggle_file_editing',
            'toggle_xmlrpc',
            'toggle_wp_version_exposure',
            'configure_rest_api_restrictions',
            'configure_login_url_obfuscation',
            'configure_login_rate_limiting',
            'configure_two_factor_auth',
            'audit_roles_and_capabilities',
            'report_inactive_users',
            'update_privacy_and_terms_pages',
            'configure_cookie_banner',
            'process_privacy_requests',

            // Integrations, automation, analytics & backup actions
            'configure_email_marketing_integration',
            'configure_crm_integration',
            'configure_global_webhooks',
            'configure_automation_rules',
            'configure_nurture_sequences',
            'configure_tracking_scripts',
            'configure_tracking_events',
            'create_analytics_dashboard_page',
            'import_data_batch',
            'export_data_batch',
            'configure_import_field_mapping',
            'trigger_site_backup',
            'configure_backup_schedule',
            'store_backup_restore_checklist',

            // Global meta/introspection actions
            'site_inventory_map',
            'list_plugins_themes',
            'list_posts',
            'list_users',
            'list_orders',
            'list_products',
            'list_events',
            'list_memberships',

            // Planning, dry-run & checkpoints
            'simulate_changes',
            'execute_change_plan',
            'create_site_checkpoint',
            'list_site_checkpoints',
            'rollback_to_checkpoint',
            'list_arthur_action_log',

            // Plugin lifecycle actions
            'activate_plugins',
            'deactivate_plugins',
            'delete_plugins',
            'toggle_plugin_auto_updates',
            'list_plugins_status',

            // Theme lifecycle actions
            'install_theme',
            'activate_theme',
            'delete_theme',
            'toggle_theme_auto_updates',

            // Core and translation actions
            'update_core',
            'configure_core_auto_update',
            'update_translations',
            'check_filesystem_health',

            // Core settings actions
            'configure_general_settings',
            'configure_writing_settings',
            'configure_reading_settings',
            'configure_media_settings',
            'configure_permalink_bases',
            'flush_rewrite_rules_safely',

            // CDN and object cache actions
            'configure_cdn',
            'cdn_purge_cache',
            'configure_object_cache',
            'flush_object_cache',
            'configure_housekeeping_profile',
            'run_housekeeping_profile',

            // Advanced security actions
            'manage_security_firewall',
            'run_malware_scan',
            'configure_password_policy',
            'generate_security_report',
            'configure_region_based_cookie_rules',

            // Analytics & logging actions
            'query_analytics_metrics',
            'query_analytics_funnels',
            'list_tracking_events',
            'toggle_tracking_event',
            'configure_action_logging',
            'report_system_errors',

            // Multisite & environment actions
            'manage_subsites',
            'configure_environment_profiles',
            'get_current_environment',

            // SSO and directory sync actions
            'configure_sso_provider',
            'configure_sso_mapping',
            'configure_sso_modes',
            'test_sso_connection',
            'configure_directory_sync',
            'run_directory_sync',

            // Developer tools actions
            'manage_code_snippets',
            'rollback_snippet_on_error',
            'edit_theme_template_file',
            'rollback_theme_template_file',
        );
    }
}

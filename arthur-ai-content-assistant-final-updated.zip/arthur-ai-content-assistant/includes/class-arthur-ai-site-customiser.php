<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Applies site‑wide settings and miscellaneous customisations configured by AI actions.
 *
 * Handles Google Analytics insertion, custom head and footer HTML, global
 * comment disabling, a simple cookie consent banner, HTTPS enforcement and
 * other site configuration tasks. Options are stored by the corresponding
 * action classes and read on each request.
 */
class Arthur_AI_Site_Customiser {

    public static function init() {
        // Output snippets in head and footer.
        add_action( 'wp_head', array( __CLASS__, 'output_head_snippets' ) );
        add_action( 'wp_footer', array( __CLASS__, 'output_footer_snippets' ) );

        // Disable comments globally.
        add_filter( 'comments_open', array( __CLASS__, 'filter_comments_open' ), 99, 2 );
        add_filter( 'pings_open', array( __CLASS__, 'filter_comments_open' ), 99, 2 );
        add_filter( 'pre_option_default_comment_status', array( __CLASS__, 'filter_default_comment_status' ) );

        // Enforce HTTPS on the frontend.
        add_action( 'template_redirect', array( __CLASS__, 'maybe_force_https' ) );
    }

    /**
     * Output Google Analytics, custom head HTML or other code snippets in the head.
     */
    public static function output_head_snippets() {
        // GA snippet or tracking ID
        $ga = get_option( 'arthur_ai_google_analytics_snippet', '' );
        if ( $ga ) {
            // If only a tracking ID was provided (e.g. UA-XXXXX), wrap in GA script.
            if ( preg_match( '/^UA-\w+/', $ga ) || preg_match( '/^G-\w+/', $ga ) ) {
                $tracking_id = esc_js( $ga );
                echo "\n<!-- Arthur AI Google Analytics -->\n";
                echo "<script async src='https://www.googletagmanager.com/gtag/js?id={$tracking_id}'></script>\n";
                echo "<script>window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}gtag('js', new Date());gtag('config','{$tracking_id}');</script>\n";
            } else {
                // Assume full snippet provided – output as is.
                echo "\n<!-- Arthur AI Google Analytics Snippet -->\n";
                echo $ga;
                echo "\n";
            }
        }
        // Custom head HTML
        $html = get_option( 'arthur_ai_custom_head_html', '' );
        if ( $html ) {
            echo "\n<!-- Arthur AI Custom Head HTML -->\n";
            // Output raw as trusted admin input; no escaping.
            echo $html;
            echo "\n";
        }
    }

    /**
     * Output custom footer HTML and a basic cookie banner if configured.
     */
    public static function output_footer_snippets() {
        // Custom footer HTML
        $html = get_option( 'arthur_ai_custom_footer_html', '' );
        if ( $html ) {
            echo "\n<!-- Arthur AI Custom Footer HTML -->\n";
            echo $html;
            echo "\n";
        }
        // Cookie banner
        $banner = get_option( 'arthur_ai_cookie_banner_options', array() );
        if ( is_array( $banner ) && ! empty( $banner['text'] ) && ! empty( $banner['button_label'] ) ) {
            $cookie_name = 'arthur_ai_cookie_banner_accepted';
            if ( ! isset( $_COOKIE[ $cookie_name ] ) ) {
                $text   = wp_kses_post( $banner['text'] );
                $button = esc_html( $banner['button_label'] );
                $bg     = isset( $banner['background'] ) ? sanitize_hex_color( $banner['background'] ) : '#000';
                $colour = isset( $banner['color'] ) ? sanitize_hex_color( $banner['color'] ) : '#fff';
                ?>
                <div id="arthur-ai-cookie-banner" style="position:fixed;bottom:0;left:0;right:0;padding:15px;background:<?php echo esc_attr( $bg ); ?>;color:<?php echo esc_attr( $colour ); ?>;z-index:9999;text-align:center;">
                    <span><?php echo $text; ?></span>
                    <button id="arthur-ai-cookie-accept" style="margin-left:15px;padding:6px 12px;border:0;cursor:pointer;">
                        <?php echo $button; ?>
                    </button>
                </div>
                <script>
                (function(){
                    var btn = document.getElementById('arthur-ai-cookie-accept');
                    if(btn){
                        btn.addEventListener('click', function(){
                            var expiry = new Date();
                            expiry.setTime(expiry.getTime() + (365*24*60*60*1000));
                            document.cookie = '<?php echo $cookie_name; ?>=1; expires=' + expiry.toUTCString() + '; path=/';
                            var banner = document.getElementById('arthur-ai-cookie-banner');
                            if(banner){ banner.parentNode.removeChild(banner); }
                        });
                    }
                })();
                </script>
                <?php
            }
        }
    }

    /**
     * Disable comments and pings globally when the global toggle is off.
     *
     * @param bool       $open Current state.
     * @param int|WP_Post $post_id Post ID or WP_Post.
     * @return bool
     */
    public static function filter_comments_open( $open, $post_id ) {
        $enabled = (bool) get_option( 'arthur_ai_comments_global_enabled', true );
        if ( ! $enabled ) {
            return false;
        }
        return $open;
    }

    /**
     * Override the default comment status option.
     *
     * @return string 'open' or 'closed'
     */
    public static function filter_default_comment_status( $status ) {
        $enabled = (bool) get_option( 'arthur_ai_comments_global_enabled', true );
        return $enabled ? $status : 'closed';
    }

    /**
     * Redirect non‑HTTPS requests to HTTPS when the force HTTPS flag is enabled.
     */
    public static function maybe_force_https() {
        $flag = (bool) get_option( 'arthur_ai_force_https_redirects', false );
        if ( ! $flag ) {
            return;
        }
        if ( is_admin() || defined( 'WP_CLI' ) ) {
            return;
        }
        if ( ! is_ssl() ) {
            $redirect = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
            wp_safe_redirect( $redirect );
            exit;
        }
    }
}
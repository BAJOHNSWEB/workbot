<?php
/**
 * Action: List membership plans or user memberships.
 *
 * Provides a list of membership plans when WooCommerce Memberships is active. If other membership plugins
 * are installed, extend this action accordingly in the future. If no supported plugin is active, returns an
 * informative error. Currently only membership plan listing is implemented; user memberships could be added.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_List_Memberships implements Arthur_AI_Action_Interface {

    /**
     * Get action slug.
     *
     * @return string
     */
    public function get_type() {
        return 'list_memberships';
    }

    /**
     * Get human label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'List memberships', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        // Currently only Woo Memberships support.
        if ( ! class_exists( 'WC_Memberships' ) ) {
            return array(
                'error'   => true,
                'message' => 'No supported membership plugin is active. WooCommerce Memberships is required to list membership plans.',
            );
        }

        // Query membership plans (custom post type 'wc_membership_plan').
        $args = array(
            'post_type'      => 'wc_membership_plan',
            'posts_per_page' => -1,
            'post_status'    => array( 'publish', 'private' ),
        );
        $query = new WP_Query( $args );
        $plans = array();
        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                $id = get_the_ID();
                $access_length = get_post_meta( $id, '_access_length', true );
                $access_unit   = get_post_meta( $id, '_access_period', true );
                $plans[] = array(
                    'id'            => $id,
                    'name'          => get_the_title(),
                    'slug'          => get_post_field( 'post_name', $id ),
                    'description'   => get_post_field( 'post_excerpt', $id ),
                    'price'         => get_post_meta( $id, '_price', true ),
                    'access_length' => $access_length && $access_unit ? $access_length . ' ' . $access_unit : 'unlimited',
                );
            }
            wp_reset_postdata();
        }

        return array(
            'plans' => $plans,
        );
    }
}
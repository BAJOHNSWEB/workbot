<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Provide a snapshot of the site inventory: post types, taxonomies,
 * menus, widget areas, image sizes and theme information.
 *
 * This read‑only action collects structural information about the
 * current WordPress installation. It does not mutate any data and
 * can safely be used to understand the available content types and
 * layout areas. Useful for AI to plan actions or navigate the site.
 */
class Arthur_AI_Action_Site_Inventory_Map implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'site_inventory_map';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Site Inventory Map', 'arthur-ai' );
    }

    /**
     * Execute the inventory mapping.
     *
     * @param array $payload Unused.
     * @return array Inventory map.
     */
    public function execute( array $payload ) {
        $inventory = array();
        // Post types.
        $post_types = get_post_types( array( 'public' => true ), 'objects' );
        $inventory['post_types'] = array();
        foreach ( $post_types as $pt ) {
            $inventory['post_types'][] = array(
                'name'  => $pt->name,
                'label' => $pt->label,
                'public' => $pt->public,
            );
        }
        // Taxonomies.
        $taxes = get_taxonomies( array( 'public' => true ), 'objects' );
        $inventory['taxonomies'] = array();
        foreach ( $taxes as $tx ) {
            $inventory['taxonomies'][] = array(
                'name'  => $tx->name,
                'label' => $tx->label,
                'hierarchical' => $tx->hierarchical,
            );
        }
        // Menus and menu locations.
        $locations = get_registered_nav_menus();
        $inventory['menus'] = array(
            'locations' => $locations,
            'menus'     => array(),
        );
        $nav_menus = wp_get_nav_menus();
        foreach ( $nav_menus as $menu ) {
            $inventory['menus']['menus'][] = array(
                'term_id' => $menu->term_id,
                'name'    => $menu->name,
                'slug'    => $menu->slug,
            );
        }
        // Widget areas/sidebars.
        global $wp_registered_sidebars;
        $inventory['widget_areas'] = array();
        if ( is_array( $wp_registered_sidebars ) ) {
            foreach ( $wp_registered_sidebars as $id => $sidebar ) {
                $inventory['widget_areas'][] = array(
                    'id'    => $id,
                    'name'  => $sidebar['name'],
                    'description' => isset( $sidebar['description'] ) ? $sidebar['description'] : '',
                );
            }
        }
        // Image sizes.
        $inventory['image_sizes'] = array();
        $builtin = array(
            'thumbnail' => array( 'width' => get_option( 'thumbnail_size_w' ), 'height' => get_option( 'thumbnail_size_h' ), 'crop' => (bool) get_option( 'thumbnail_crop' ) ),
            'medium'    => array( 'width' => get_option( 'medium_size_w' ), 'height' => get_option( 'medium_size_h' ), 'crop' => false ),
            'large'     => array( 'width' => get_option( 'large_size_w' ), 'height' => get_option( 'large_size_h' ), 'crop' => false ),
        );
        foreach ( $builtin as $name => $details ) {
            $inventory['image_sizes'][] = array(
                'name'   => $name,
                'width'  => $details['width'],
                'height' => $details['height'],
                'crop'   => $details['crop'],
            );
        }
        $additional = wp_get_additional_image_sizes();
        if ( is_array( $additional ) ) {
            foreach ( $additional as $name => $size ) {
                $inventory['image_sizes'][] = array(
                    'name'   => $name,
                    'width'  => $size['width'],
                    'height' => $size['height'],
                    'crop'   => $size['crop'],
                );
            }
        }
        // Theme info.
        $theme          = wp_get_theme();
        $parent_theme   = $theme->parent();
        $inventory['theme'] = array(
            'name'        => $theme->get( 'Name' ),
            'version'     => $theme->get( 'Version' ),
            'stylesheet'  => $theme->get_stylesheet(),
            'template'    => $theme->get_template(),
            'is_child'    => $theme->is_child_theme(),
            'parent_name' => $parent_theme ? $parent_theme->get( 'Name' ) : null,
        );
        return array( 'success' => true, 'inventory' => $inventory );
    }
}
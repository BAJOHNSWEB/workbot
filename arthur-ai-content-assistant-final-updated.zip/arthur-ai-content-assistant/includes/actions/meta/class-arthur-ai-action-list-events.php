<?php
/**
 * Action: List Events (The Events Calendar).
 *
 * Returns a paginated list of events created via The Events Calendar plugin. If the plugin is not active,
 * returns an error. Supports basic filters like date range, category and status.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_List_Events implements Arthur_AI_Action_Interface {

    /**
     * Get the action slug.
     *
     * @return string
     */
    public function get_type() {
        return 'list_events';
    }

    /**
     * Get the human‑readable label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'List events', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'Tribe__Events__Main' ) ) {
            return array(
                'error'   => true,
                'message' => 'The Events Calendar is not active. Cannot list events.',
            );
        }

        // Set up query arguments.
        $paged = isset( $payload['page'] ) ? max( 1, intval( $payload['page'] ) ) : 1;
        $per_page = isset( $payload['limit'] ) ? max( 1, intval( $payload['limit'] ) ) : 20;

        $args = array(
            'post_type'      => Tribe__Events__Main::POSTTYPE,
            'post_status'    => isset( $payload['status'] ) ? (array) $payload['status'] : array( 'publish', 'draft', 'private' ),
            'posts_per_page' => $per_page,
            'paged'          => $paged,
            'orderby'        => 'event_date',
            'order'          => 'DESC',
        );

        // Filter by date range.
        $meta_query = array();
        if ( ! empty( $payload['date_from'] ) || ! empty( $payload['date_to'] ) ) {
            $date_query = array( 'relation' => 'AND' );
            if ( ! empty( $payload['date_from'] ) ) {
                $date_query[] = array(
                    'key'     => '_EventStartDate',
                    'value'   => sanitize_text_field( $payload['date_from'] ),
                    'compare' => '>=',
                    'type'    => 'DATETIME',
                );
            }
            if ( ! empty( $payload['date_to'] ) ) {
                $date_query[] = array(
                    'key'     => '_EventStartDate',
                    'value'   => sanitize_text_field( $payload['date_to'] ),
                    'compare' => '<=',
                    'type'    => 'DATETIME',
                );
            }
            $meta_query[] = $date_query;
        }

        // Filter by category (term slug or ID).
        if ( ! empty( $payload['category'] ) ) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'tribe_events_cat',
                    'field'    => is_numeric( $payload['category'] ) ? 'term_id' : 'slug',
                    'terms'    => $payload['category'],
                ),
            );
        }
        if ( ! empty( $meta_query ) ) {
            $args['meta_query'] = $meta_query;
        }

        $query = new WP_Query( $args );
        $events = array();
        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                $post_id = get_the_ID();
                $events[] = array(
                    'id'          => $post_id,
                    'title'       => get_the_title(),
                    'status'      => get_post_status( $post_id ),
                    'start_date'  => get_post_meta( $post_id, '_EventStartDate', true ),
                    'end_date'    => get_post_meta( $post_id, '_EventEndDate', true ),
                    'all_day'     => (bool) get_post_meta( $post_id, '_EventAllDay', true ),
                    'slug'        => get_post_field( 'post_name', $post_id ),
                );
            }
            wp_reset_postdata();
        }

        // Prepare pagination info.
        $total_posts = $query->found_posts;
        $total_pages = $query->max_num_pages;

        return array(
            'events'     => $events,
            'pagination' => array(
                'page'        => $paged,
                'per_page'    => $per_page,
                'total_pages' => $total_pages,
                'total_items' => $total_posts,
            ),
        );
    }
}
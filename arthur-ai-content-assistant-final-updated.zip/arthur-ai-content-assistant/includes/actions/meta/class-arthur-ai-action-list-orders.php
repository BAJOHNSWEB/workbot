<?php
/**
 * Action: List WooCommerce orders.
 *
 * This action returns a paginated list of WooCommerce orders with basic metadata. It is read‑only and
 * does not modify any data. The action will gracefully fail if WooCommerce is not active.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_List_Orders implements Arthur_AI_Action_Interface {

    /**
     * Get the action slug.
     *
     * @return string
     */
    public function get_type() {
        return 'list_orders';
    }

    /**
     * Get the human‑readable label for this action.
     *
     * @return string
     */
    public function get_label() {
        return __( 'List orders', 'arthur-ai' );
    }

    /**
     * Execute the action. Accepts filters for WooCommerce orders and returns a paginated list of orders.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        // Ensure WooCommerce is available.
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array(
                'error'   => true,
                'message' => 'WooCommerce is not active. Cannot list orders.',
            );
        }

        // Default query arguments.
        $args = array(
            'limit'   => isset( $payload['limit'] ) ? max( 1, intval( $payload['limit'] ) ) : 20,
            'page'    => isset( $payload['page'] ) ? max( 1, intval( $payload['page'] ) ) : 1,
            'status'  => isset( $payload['status'] ) ? $payload['status'] : array_keys( wc_get_order_statuses() ),
            'orderby' => 'date',
            'order'   => 'DESC',
        );

        // Optional filters.
        if ( ! empty( $payload['customer_id'] ) ) {
            $args['customer_id'] = intval( $payload['customer_id'] );
        }
        if ( ! empty( $payload['date_from'] ) || ! empty( $payload['date_to'] ) ) {
            $args['date_created'] = array();
            if ( ! empty( $payload['date_from'] ) ) {
                $args['date_created']['after'] = sanitize_text_field( $payload['date_from'] );
            }
            if ( ! empty( $payload['date_to'] ) ) {
                $args['date_created']['before'] = sanitize_text_field( $payload['date_to'] );
            }
        }

        // Query orders.
        $query   = new WC_Order_Query( $args );
        $results = $query->get_orders();

        // Format results.
        $orders   = array();
        $statuses = wc_get_order_statuses();
        foreach ( $results as $order ) {
            /** @var WC_Order $order */
            $orders[] = array(
                'id'            => $order->get_id(),
                'number'        => $order->get_order_number(),
                'status'        => isset( $statuses[ $order->get_status() ] ) ? $statuses[ $order->get_status() ] : $order->get_status(),
                'total'         => wc_format_localized_price( $order->get_total() ),
                'currency'      => $order->get_currency(),
                'date_created'  => $order->get_date_created() ? $order->get_date_created()->date( 'Y-m-d H:i:s' ) : '',
                'customer_id'   => $order->get_customer_id(),
                'billing_email' => $order->get_billing_email(),
            );
        }

        // Determine total count for pagination.
        $total_query = new WC_Order_Query( array_merge( $args, array( 'limit' => -1 ) ) );
        $total_count = count( $total_query->get_orders() );
        $total_pages = $args['limit'] > 0 ? (int) ceil( $total_count / $args['limit'] ) : 1;

        return array(
            'orders'      => $orders,
            'pagination'  => array(
                'page'        => $args['page'],
                'per_page'    => $args['limit'],
                'total_pages' => $total_pages,
                'total_items' => $total_count,
            ),
        );
    }
}
<?php
/**
 * Action: List WooCommerce products.
 *
 * Provides a paginated listing of products with basic metadata such as name, price and stock status. If WooCommerce
 * is not active the action returns an error.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_List_Products implements Arthur_AI_Action_Interface {

    /**
     * Get the action slug.
     *
     * @return string
     */
    public function get_type() {
        return 'list_products';
    }

    /**
     * Get the human‑readable label for this action.
     *
     * @return string
     */
    public function get_label() {
        return __( 'List products', 'arthur-ai' );
    }

    /**
     * Execute the action. Accepts filters to query WooCommerce products.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array(
                'error'   => true,
                'message' => 'WooCommerce is not active. Cannot list products.',
            );
        }

        // Default query args.
        $args = array(
            'limit'    => isset( $payload['limit'] ) ? max( 1, intval( $payload['limit'] ) ) : 20,
            'page'     => isset( $payload['page'] ) ? max( 1, intval( $payload['page'] ) ) : 1,
            'status'   => isset( $payload['status'] ) ? (array) $payload['status'] : array( 'publish', 'private' ),
            'orderby'  => 'date',
            'order'    => 'DESC',
        );

        // Additional filters.
        if ( ! empty( $payload['stock_status'] ) ) {
            $args['stock_status'] = (array) $payload['stock_status'];
        }
        if ( ! empty( $payload['category'] ) ) {
            $args['category'] = (array) $payload['category'];
        }
        if ( ! empty( $payload['tag'] ) ) {
            $args['tag'] = (array) $payload['tag'];
        }
        if ( ! empty( $payload['search'] ) ) {
            $args['search'] = sanitize_text_field( $payload['search'] );
        }

        // Query products.
        $query   = new WC_Product_Query( $args );
        $results = $query->get_products();

        $products = array();
        foreach ( $results as $product ) {
            /** @var WC_Product $product */
            $products[] = array(
                'id'          => $product->get_id(),
                'name'        => $product->get_name(),
                'sku'         => $product->get_sku(),
                'price'       => wc_get_price_to_display( $product ),
                'stock'       => $product->get_stock_quantity(),
                'stock_status'=> $product->get_stock_status(),
                'type'        => $product->get_type(),
                'date_created'=> $product->get_date_created() ? $product->get_date_created()->date( 'Y-m-d H:i:s' ) : '',
            );
        }

        // Total count for pagination. Reuse query to count.
        $args_count = $args;
        $args_count['limit'] = -1;
        $count_query = new WC_Product_Query( $args_count );
        $total_count = count( $count_query->get_products() );
        $total_pages = $args['limit'] > 0 ? (int) ceil( $total_count / $args['limit'] ) : 1;

        return array(
            'products'    => $products,
            'pagination'  => array(
                'page'        => $args['page'],
                'per_page'    => $args['limit'],
                'total_pages' => $total_pages,
                'total_items' => $total_count,
            ),
        );
    }
}
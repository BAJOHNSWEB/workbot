<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * List posts or custom post types with flexible filters.
 *
 * This action returns a paged list of posts based on provided
 * criteria. It supports filtering by post type, status, author,
 * taxonomy terms and date ranges. Results are read‑only and include
 * minimal fields. Use this to inspect content before performing
 * modifications.
 */
class Arthur_AI_Action_List_Posts implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'list_posts';
    }

    public function get_label() {
        return __( 'List Posts', 'arthur-ai' );
    }

    /**
     * Execute the post listing.
     *
     * @param array $payload {
     *     @type string       $post_type   Post type to list (default 'post').
     *     @type array|string $status      Post status or array of statuses (default 'publish').
     *     @type int          $author      Author ID.
     *     @type array        $tax_query   Taxonomy query (array of arrays as in WP_Query).
     *     @type string       $date_after  Date query after (Y-m-d).
     *     @type string       $date_before Date query before (Y-m-d).
     *     @type int          $paged       Page number (default 1).
     *     @type int          $per_page    Items per page (default 20).
     * }
     * @return array Result set.
     */
    public function execute( array $payload ) {
        $post_type = isset( $payload['post_type'] ) ? sanitize_key( $payload['post_type'] ) : 'post';
        $status    = isset( $payload['status'] ) ? $payload['status'] : 'publish';
        $author    = isset( $payload['author'] ) ? intval( $payload['author'] ) : 0;
        $tax_query = isset( $payload['tax_query'] ) && is_array( $payload['tax_query'] ) ? $payload['tax_query'] : array();
        $date_after  = isset( $payload['date_after'] ) ? $payload['date_after'] : '';
        $date_before = isset( $payload['date_before'] ) ? $payload['date_before'] : '';
        $paged     = isset( $payload['paged'] ) ? max( 1, intval( $payload['paged'] ) ) : 1;
        $per_page  = isset( $payload['per_page'] ) ? max( 1, intval( $payload['per_page'] ) ) : 20;

        $args = array(
            'post_type'      => $post_type,
            'post_status'    => $status,
            'author'         => $author,
            'posts_per_page' => $per_page,
            'paged'          => $paged,
        );
        if ( ! empty( $tax_query ) ) {
            $args['tax_query'] = $tax_query;
        }
        if ( $date_after || $date_before ) {
            $args['date_query'] = array();
            if ( $date_after ) {
                $args['date_query'][] = array( 'after' => $date_after );
            }
            if ( $date_before ) {
                $args['date_query'][] = array( 'before' => $date_before );
            }
        }
        $query = new WP_Query( $args );
        $items = array();
        foreach ( $query->posts as $post ) {
            $items[] = array(
                'ID'      => $post->ID,
                'title'   => $post->post_title,
                'status'  => $post->post_status,
                'author'  => $post->post_author,
                'date'    => $post->post_date,
                'type'    => $post->post_type,
                'slug'    => $post->post_name,
            );
        }
        return array(
            'success'     => true,
            'page'        => $paged,
            'per_page'    => $per_page,
            'total'       => intval( $query->found_posts ),
            'total_pages' => intval( $query->max_num_pages ),
            'items'       => $items,
        );
    }
}
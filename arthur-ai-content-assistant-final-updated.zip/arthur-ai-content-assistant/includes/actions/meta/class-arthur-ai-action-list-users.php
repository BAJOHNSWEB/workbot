<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * List users with optional filters for roles and search.
 *
 * This action returns a paginated list of users, allowing filtering
 * by roles and a search term across username, email and display
 * name. It is read‑only. Additional reporting such as inactivity
 * thresholds can be added via user meta if available.
 */
class Arthur_AI_Action_List_Users implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'list_users';
    }

    public function get_label() {
        return __( 'List Users', 'arthur-ai' );
    }

    /**
     * Execute user listing.
     *
     * @param array $payload {
     *     @type array  $roles      Roles to include (optional).
     *     @type string $search     Search term for username/email/display_name.
     *     @type int    $paged      Page number (default 1).
     *     @type int    $per_page   Users per page (default 20).
     * }
     * @return array Result with users.
     */
    public function execute( array $payload ) {
        $roles    = isset( $payload['roles'] ) ? (array) $payload['roles'] : array();
        $search   = isset( $payload['search'] ) ? sanitize_text_field( $payload['search'] ) : '';
        $paged    = isset( $payload['paged'] ) ? max( 1, (int) $payload['paged'] ) : 1;
        $per_page = isset( $payload['per_page'] ) ? max( 1, (int) $payload['per_page'] ) : 20;

        $args = array();
        if ( ! empty( $roles ) ) {
            $args['role__in'] = $roles;
        }
        if ( $search ) {
            $args['search'] = '*' . $search . '*';
            $args['search_columns'] = array( 'user_login', 'user_email', 'display_name' );
        }
        $args['number'] = $per_page;
        $args['offset'] = ( $paged - 1 ) * $per_page;
        $users = get_users( $args );
        $items = array();
        foreach ( $users as $user ) {
            $items[] = array(
                'ID'           => $user->ID,
                'user_login'   => $user->user_login,
                'display_name' => $user->display_name,
                'email'        => $user->user_email,
                'roles'        => $user->roles,
                'registered'   => $user->user_registered,
            );
        }
        // Total count for pagination.
        $total = count_users();
        $total_users = isset( $total['total_users'] ) ? (int) $total['total_users'] : 0;
        return array(
            'success'    => true,
            'page'       => $paged,
            'per_page'   => $per_page,
            'total'      => $total_users,
            'items'      => $items,
        );
    }
}
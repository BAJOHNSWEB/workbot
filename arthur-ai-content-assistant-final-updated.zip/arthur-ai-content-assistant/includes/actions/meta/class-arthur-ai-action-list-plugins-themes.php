<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * List installed plugins and themes with their status and update info.
 *
 * This read‑only action enumerates all plugins and themes on the site
 * using WordPress APIs. It returns details such as slug, name,
 * version, whether the plugin/theme is active or network active,
 * whether auto‑updates are enabled and whether an update is available.
 */
class Arthur_AI_Action_List_Plugins_Themes implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'list_plugins_themes';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'List Plugins and Themes', 'arthur-ai' );
    }

    /**
     * Execute the listing action.
     *
     * @param array $payload Not used.
     * @return array List of plugins and themes.
     */
    public function execute( array $payload ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/update.php';
        $plugins        = get_plugins();
        $plugin_updates = get_plugin_updates();
        $auto_updates   = (array) get_site_option( 'auto_update_plugins', array() );
        $plugins_list   = array();
        foreach ( $plugins as $file => $data ) {
            $slug = dirname( $file );
            $is_active = is_plugin_active( $file );
            $is_network_active = is_plugin_active_for_network( $file );
            $updates_available = isset( $plugin_updates[ $file ] );
            $plugins_list[] = array(
                'slug'            => $slug,
                'file'            => $file,
                'name'            => isset( $data['Name'] ) ? $data['Name'] : $slug,
                'version'         => isset( $data['Version'] ) ? $data['Version'] : '',
                'active'          => $is_active,
                'network_active'  => $is_network_active,
                'auto_update'     => in_array( $file, $auto_updates, true ),
                'update_available'=> $updates_available,
            );
        }
        // Themes
        $themes        = wp_get_themes();
        $theme_updates = get_theme_updates();
        $theme_auto    = (array) get_site_option( 'auto_update_themes', array() );
        $themes_list   = array();
        foreach ( $themes as $stylesheet => $theme ) {
            $parent  = $theme->parent();
            $updates_available = isset( $theme_updates[ $stylesheet ] );
            $themes_list[] = array(
                'slug'         => $stylesheet,
                'name'         => $theme->get( 'Name' ),
                'version'      => $theme->get( 'Version' ),
                'active'       => $theme->get_stylesheet() === get_stylesheet(),
                'auto_update'  => in_array( $stylesheet, $theme_auto, true ),
                'update_available' => $updates_available,
                'is_child'     => $theme->is_child_theme(),
                'parent'       => $parent ? $parent->get_stylesheet() : null,
            );
        }
        return array(
            'success' => true,
            'plugins' => $plugins_list,
            'themes'  => $themes_list,
        );
    }
}
<?php
/**
 * Action: Configure General Settings
 *
 * Allows adjusting core General Settings via a single action. Supports site title, tagline, language,
 * timezone, date/time formats and week start day. Optionally site URL and home URL can be changed,
 * but these changes should be confirmed separately due to potential site breakage.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Configure_General_Settings implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_general_settings';
    }

    public function get_label() {
        return __( 'Configure General Settings', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $changes = array();
        // Site title.
        if ( isset( $payload['site_title'] ) ) {
            $old = get_option( 'blogname' );
            $new = sanitize_text_field( $payload['site_title'] );
            if ( $new !== $old ) {
                update_option( 'blogname', $new );
                $changes['blogname'] = array( 'old' => $old, 'new' => $new );
            }
        }
        // Tagline.
        if ( isset( $payload['tagline'] ) ) {
            $old = get_option( 'blogdescription' );
            $new = sanitize_text_field( $payload['tagline'] );
            if ( $new !== $old ) {
                update_option( 'blogdescription', $new );
                $changes['blogdescription'] = array( 'old' => $old, 'new' => $new );
            }
        }
        // Language.
        if ( isset( $payload['language'] ) ) {
            $old = get_option( 'WPLANG' );
            $new = sanitize_text_field( $payload['language'] );
            if ( $new !== $old ) {
                update_option( 'WPLANG', $new );
                $changes['language'] = array( 'old' => $old, 'new' => $new );
            }
        }
        // Timezone.
        if ( isset( $payload['timezone'] ) ) {
            $old = get_option( 'timezone_string' );
            $new = sanitize_text_field( $payload['timezone'] );
            if ( $new !== $old ) {
                update_option( 'timezone_string', $new );
                $changes['timezone'] = array( 'old' => $old, 'new' => $new );
            }
        }
        // Date format.
        if ( isset( $payload['date_format'] ) ) {
            $old = get_option( 'date_format' );
            $new = sanitize_text_field( $payload['date_format'] );
            if ( $new !== $old ) {
                update_option( 'date_format', $new );
                $changes['date_format'] = array( 'old' => $old, 'new' => $new );
            }
        }
        // Time format.
        if ( isset( $payload['time_format'] ) ) {
            $old = get_option( 'time_format' );
            $new = sanitize_text_field( $payload['time_format'] );
            if ( $new !== $old ) {
                update_option( 'time_format', $new );
                $changes['time_format'] = array( 'old' => $old, 'new' => $new );
            }
        }
        // Week start day.
        if ( isset( $payload['start_of_week'] ) ) {
            $old = get_option( 'start_of_week' );
            $new = intval( $payload['start_of_week'] );
            if ( $new !== $old ) {
                update_option( 'start_of_week', $new );
                $changes['start_of_week'] = array( 'old' => $old, 'new' => $new );
            }
        }
        // Optionally update siteurl/home; warn about breakage.
        if ( isset( $payload['siteurl'] ) && isset( $payload['home'] ) ) {
            $siteurl = esc_url_raw( $payload['siteurl'] );
            $home    = esc_url_raw( $payload['home'] );
            if ( $siteurl !== get_option( 'siteurl' ) || $home !== get_option( 'home' ) ) {
                update_option( 'siteurl', $siteurl );
                update_option( 'home', $home );
                $changes['siteurl'] = array( 'old' => get_option( 'siteurl' ), 'new' => $siteurl );
                $changes['home']    = array( 'old' => get_option( 'home' ), 'new' => $home );
            }
        }

        return array(
            'success' => true,
            'changes' => $changes,
        );
    }
}
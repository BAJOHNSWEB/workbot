<?php
/**
 * Action: Configure Media Settings
 *
 * Adjusts the WordPress Media settings: thumbnail, medium and large image sizes and cropping behaviour, and
 * whether uploads are organized into month- and year-based folders.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Configure_Media_Settings implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_media_settings';
    }

    public function get_label() {
        return __( 'Configure Media Settings', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $changes = array();
        // Thumbnail size.
        if ( isset( $payload['thumbnail_size_w'] ) ) {
            $w = max( 0, intval( $payload['thumbnail_size_w'] ) );
            $old = get_option( 'thumbnail_size_w' );
            if ( $w !== $old ) {
                update_option( 'thumbnail_size_w', $w );
                $changes['thumbnail_size_w'] = array( 'old' => $old, 'new' => $w );
            }
        }
        if ( isset( $payload['thumbnail_size_h'] ) ) {
            $h  = max( 0, intval( $payload['thumbnail_size_h'] ) );
            $old = get_option( 'thumbnail_size_h' );
            if ( $h !== $old ) {
                update_option( 'thumbnail_size_h', $h );
                $changes['thumbnail_size_h'] = array( 'old' => $old, 'new' => $h );
            }
        }
        if ( isset( $payload['thumbnail_crop'] ) ) {
            $crop = (bool) $payload['thumbnail_crop'];
            $old  = get_option( 'thumbnail_crop' );
            if ( $crop !== $old ) {
                update_option( 'thumbnail_crop', $crop );
                $changes['thumbnail_crop'] = array( 'old' => $old, 'new' => $crop );
            }
        }
        // Medium size.
        foreach ( array( 'medium_size_w', 'medium_size_h', 'medium_crop' ) as $option ) {
            if ( isset( $payload[ $option ] ) ) {
                $value = $option === 'medium_crop' ? (bool) $payload[ $option ] : max( 0, intval( $payload[ $option ] ) );
                $old   = get_option( $option );
                if ( $value !== $old ) {
                    update_option( $option, $value );
                    $changes[ $option ] = array( 'old' => $old, 'new' => $value );
                }
            }
        }
        // Large size.
        foreach ( array( 'large_size_w', 'large_size_h', 'large_crop' ) as $option ) {
            if ( isset( $payload[ $option ] ) ) {
                $value = $option === 'large_crop' ? (bool) $payload[ $option ] : max( 0, intval( $payload[ $option ] ) );
                $old   = get_option( $option );
                if ( $value !== $old ) {
                    update_option( $option, $value );
                    $changes[ $option ] = array( 'old' => $old, 'new' => $value );
                }
            }
        }
        // Organize uploads by year/month.
        if ( isset( $payload['uploads_use_yearmonth_folders'] ) ) {
            $flag = (bool) $payload['uploads_use_yearmonth_folders'];
            $old  = get_option( 'uploads_use_yearmonth_folders' );
            if ( $flag !== $old ) {
                update_option( 'uploads_use_yearmonth_folders', $flag );
                $changes['uploads_use_yearmonth_folders'] = array( 'old' => $old, 'new' => $flag );
            }
        }
        return array(
            'success' => true,
            'changes' => $changes,
        );
    }
}
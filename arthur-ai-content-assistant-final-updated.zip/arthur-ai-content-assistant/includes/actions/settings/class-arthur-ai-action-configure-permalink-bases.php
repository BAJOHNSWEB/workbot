<?php
/**
 * Action: Configure Permalink Bases
 *
 * Updates the category and tag base structures. Optionally flushes rewrite rules. Custom post type bases
 * are not currently handled. After changing bases, you should flush rewrite rules to apply the changes.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Configure_Permalink_Bases implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_permalink_bases';
    }

    public function get_label() {
        return __( 'Configure Permalink Bases', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $changes = array();
        if ( isset( $payload['category_base'] ) ) {
            $new = trim( sanitize_title_with_dashes( $payload['category_base'] ), '/' );
            $old = get_option( 'category_base' );
            if ( $new !== $old ) {
                update_option( 'category_base', $new );
                $changes['category_base'] = array( 'old' => $old, 'new' => $new );
            }
        }
        if ( isset( $payload['tag_base'] ) ) {
            $new = trim( sanitize_title_with_dashes( $payload['tag_base'] ), '/' );
            $old = get_option( 'tag_base' );
            if ( $new !== $old ) {
                update_option( 'tag_base', $new );
                $changes['tag_base'] = array( 'old' => $old, 'new' => $new );
            }
        }
        // Optionally flush rewrite rules.
        if ( ! empty( $payload['flush'] ) ) {
            flush_rewrite_rules();
            $changes['rewrite_rules_flushed'] = true;
        }
        return array(
            'success' => true,
            'changes' => $changes,
        );
    }
}
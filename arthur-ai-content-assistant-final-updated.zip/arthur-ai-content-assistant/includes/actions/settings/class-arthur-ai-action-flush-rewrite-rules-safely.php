<?php
/**
 * Action: Flush Rewrite Rules Safely
 *
 * Flushes the WordPress rewrite rules. Because this can affect URL routing, a confirmation flag is
 * required. This action simply calls flush_rewrite_rules() and returns a success message.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Flush_Rewrite_Rules_Safely implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'flush_rewrite_rules_safely';
    }

    public function get_label() {
        return __( 'Flush Rewrite Rules Safely', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( empty( $payload['confirm'] ) ) {
            return array(
                'error'   => true,
                'message' => 'Flushing rewrite rules requires confirmation. Set confirm=true to proceed.',
            );
        }
        flush_rewrite_rules();
        return array(
            'success' => true,
            'message' => 'Rewrite rules flushed.',
        );
    }
}
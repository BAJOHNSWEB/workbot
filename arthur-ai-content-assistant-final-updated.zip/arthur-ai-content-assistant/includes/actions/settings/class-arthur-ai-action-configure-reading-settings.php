<?php
/**
 * Action: Configure Reading Settings
 *
 * Adjusts the WordPress Reading settings including the front page display, posts per page and feed length,
 * and search engine visibility. This action sanitizes inputs and applies only the provided settings.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Configure_Reading_Settings implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_reading_settings';
    }

    public function get_label() {
        return __( 'Configure Reading Settings', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $changes = array();
        // Show on front: 'posts' or 'page'.
        if ( isset( $payload['show_on_front'] ) ) {
            $value = in_array( $payload['show_on_front'], array( 'posts', 'page' ), true ) ? $payload['show_on_front'] : 'posts';
            $old   = get_option( 'show_on_front' );
            if ( $value !== $old ) {
                update_option( 'show_on_front', $value );
                $changes['show_on_front'] = array( 'old' => $old, 'new' => $value );
            }
        }
        // Page on front.
        if ( isset( $payload['page_on_front'] ) ) {
            $page_id = intval( $payload['page_on_front'] );
            $old     = get_option( 'page_on_front' );
            if ( $page_id !== $old ) {
                update_option( 'page_on_front', $page_id );
                $changes['page_on_front'] = array( 'old' => $old, 'new' => $page_id );
            }
        }
        // Page for posts.
        if ( isset( $payload['page_for_posts'] ) ) {
            $page_id = intval( $payload['page_for_posts'] );
            $old     = get_option( 'page_for_posts' );
            if ( $page_id !== $old ) {
                update_option( 'page_for_posts', $page_id );
                $changes['page_for_posts'] = array( 'old' => $old, 'new' => $page_id );
            }
        }
        // Posts per page.
        if ( isset( $payload['posts_per_page'] ) ) {
            $num = intval( $payload['posts_per_page'] );
            $num = max( 1, $num );
            $old = get_option( 'posts_per_page' );
            if ( $num !== $old ) {
                update_option( 'posts_per_page', $num );
                $changes['posts_per_page'] = array( 'old' => $old, 'new' => $num );
            }
        }
        // Posts per RSS.
        if ( isset( $payload['posts_per_rss'] ) ) {
            $num = intval( $payload['posts_per_rss'] );
            $num = max( 1, $num );
            $old = get_option( 'posts_per_rss' );
            if ( $num !== $old ) {
                update_option( 'posts_per_rss', $num );
                $changes['posts_per_rss'] = array( 'old' => $old, 'new' => $num );
            }
        }
        // Blog public (search engine visibility).
        if ( isset( $payload['blog_public'] ) ) {
            $public = (bool) $payload['blog_public'] ? 1 : 0;
            $old    = get_option( 'blog_public' );
            if ( $public !== $old ) {
                update_option( 'blog_public', $public );
                $changes['blog_public'] = array( 'old' => $old, 'new' => $public );
            }
        }
        return array(
            'success' => true,
            'changes' => $changes,
        );
    }
}
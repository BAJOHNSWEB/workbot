<?php
/**
 * Action: Configure Writing Settings
 *
 * Updates the WordPress Writing settings. Supports default category, post format, use of smilies, and ping
 * services. Additional writing options could be added here as needed.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Configure_Writing_Settings implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_writing_settings';
    }

    public function get_label() {
        return __( 'Configure Writing Settings', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $changes = array();
        // Default post category.
        if ( isset( $payload['default_category'] ) ) {
            $cat_id = intval( $payload['default_category'] );
            $old    = get_option( 'default_category' );
            if ( $cat_id && $cat_id !== $old ) {
                update_option( 'default_category', $cat_id );
                $changes['default_category'] = array( 'old' => $old, 'new' => $cat_id );
            }
        }
        // Default post format.
        if ( isset( $payload['default_post_format'] ) ) {
            $format = sanitize_text_field( $payload['default_post_format'] );
            $old    = get_option( 'default_post_format' );
            if ( $format !== $old ) {
                update_option( 'default_post_format', $format );
                $changes['default_post_format'] = array( 'old' => $old, 'new' => $format );
            }
        }
        // Smilies.
        if ( isset( $payload['use_smilies'] ) ) {
            $smilies = (bool) $payload['use_smilies'];
            $old     = get_option( 'use_smilies' );
            if ( $smilies !== $old ) {
                update_option( 'use_smilies', $smilies );
                $changes['use_smilies'] = array( 'old' => $old, 'new' => $smilies );
            }
        }
        // Ping sites (services).
        if ( isset( $payload['ping_sites'] ) ) {
            // Expect newline separated string or array.
            $sites = $payload['ping_sites'];
            if ( is_array( $sites ) ) {
                $sites = implode( "\n", array_map( 'esc_url_raw', $sites ) );
            } else {
                $sites = sanitize_textarea_field( $sites );
            }
            $old = get_option( 'ping_sites' );
            if ( $sites !== $old ) {
                update_option( 'ping_sites', $sites );
                $changes['ping_sites'] = array( 'old' => $old, 'new' => $sites );
            }
        }
        return array(
            'success' => true,
            'changes' => $changes,
        );
    }
}
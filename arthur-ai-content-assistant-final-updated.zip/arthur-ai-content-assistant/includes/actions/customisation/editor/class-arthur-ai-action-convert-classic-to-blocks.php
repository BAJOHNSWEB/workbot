<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Convert classic content to block markup by replacing content.
 */
class Arthur_AI_Action_Convert_Classic_To_Blocks implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'convert_classic_to_blocks';
    }

    public function get_label() {
        return __( 'Convert Classic To Blocks', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $post_id      = isset( $payload['post_id'] ) ? (int) $payload['post_id'] : 0;
        $post_content = isset( $payload['post_content'] ) ? (string) $payload['post_content'] : '';
        if ( ! $post_id || '' === $post_content ) {
            return array( 'success' => false, 'message' => __( 'post_id and post_content are required.', 'arthur-ai' ) );
        }
        $post_content = wp_kses_post( $post_content );
        $result       = wp_update_post( array( 'ID' => $post_id, 'post_content' => $post_content ), true );
        if ( is_wp_error( $result ) ) {
            return array( 'success' => false, 'message' => $result->get_error_message() );
        }
        return array( 'success' => true, 'post_id' => $post_id );
    }
}
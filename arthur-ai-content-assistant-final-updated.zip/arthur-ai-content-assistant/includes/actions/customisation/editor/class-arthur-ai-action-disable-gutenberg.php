<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to disable the WordPress block editor (Gutenberg) for specific post types.
 *
 * Usage: Provide a list of post types to disable the block editor for. When this action
 * executes it overwrites the existing option so you can re‑enable Gutenberg later by
 * calling the action again with an empty array.
 */
class Arthur_AI_Action_Disable_Gutenberg implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'disable_gutenberg';
    }

    public function get_label() {
        return __( 'Disable Gutenberg for Post Types', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * Expected payload:
     * {
     *   "post_types": [string]
     * }
     *
     * The list of post types is sanitised and stored in the arthur_ai_disable_gutenberg option.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $post_types = array();
        if ( isset( $payload['post_types'] ) && is_array( $payload['post_types'] ) ) {
            foreach ( $payload['post_types'] as $pt ) {
                $pt = sanitize_key( (string) $pt );
                if ( '' !== $pt ) {
                    $post_types[] = $pt;
                }
            }
        }
        update_option( 'arthur_ai_disable_gutenberg', $post_types );
        return array(
            'success' => true,
            'message' => sprintf( __( 'Block editor disabled for: %s', 'arthur-ai' ), implode( ', ', $post_types ) )
        );
    }
}
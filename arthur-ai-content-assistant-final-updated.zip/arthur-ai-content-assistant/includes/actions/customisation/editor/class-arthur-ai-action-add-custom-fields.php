<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to register custom fields on the post editor screen. Each custom field
 * definition should include a key, a label, a type (text or textarea) and an
 * optional array of post types to apply the field to. This action overwrites
 * the entire list of custom fields stored in arthur_ai_custom_fields.
 */
class Arthur_AI_Action_Add_Custom_Fields implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'add_custom_fields';
    }

    public function get_label() {
        return __( 'Add Custom Fields', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * Expected payload:
     * {
     *   "custom_fields": [ { "key": string, "label": string|null, "type": string|null, "post_types": [string]|null } ]
     * }
     *
     * Stores a sanitised array of field definitions in the arthur_ai_custom_fields option.
     * Only keys are required; labels default to the key, type defaults to 'text', post_types
     * may be omitted to apply to all types.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $fields = array();
        if ( isset( $payload['custom_fields'] ) && is_array( $payload['custom_fields'] ) ) {
            foreach ( $payload['custom_fields'] as $field ) {
                if ( ! is_array( $field ) || empty( $field['key'] ) ) {
                    continue;
                }
                $key = sanitize_key( (string) $field['key'] );
                if ( '' === $key ) {
                    continue;
                }
                $label = isset( $field['label'] ) && is_string( $field['label'] ) ? sanitize_text_field( $field['label'] ) : $key;
                $type  = isset( $field['type'] ) && is_string( $field['type'] ) ? sanitize_key( $field['type'] ) : 'text';
                $post_types = array();
                if ( isset( $field['post_types'] ) && is_array( $field['post_types'] ) ) {
                    foreach ( $field['post_types'] as $pt ) {
                        $pt = sanitize_key( (string) $pt );
                        if ( '' !== $pt ) {
                            $post_types[] = $pt;
                        }
                    }
                }
                $fields[] = array(
                    'key'        => $key,
                    'label'      => $label,
                    'type'       => $type,
                    'post_types' => $post_types,
                );
            }
        }
        update_option( 'arthur_ai_custom_fields', $fields );
        return array(
            'success' => true,
            'message' => __( 'Custom fields updated.', 'arthur-ai' )
        );
    }
}
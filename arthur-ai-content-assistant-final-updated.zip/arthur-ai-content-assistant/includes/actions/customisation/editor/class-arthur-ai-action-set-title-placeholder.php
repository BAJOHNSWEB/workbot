<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to change the default placeholder text shown in the title field of
 * the editor for a specific post type. Passing a blank placeholder will
 * remove the customisation for that post type.
 */
class Arthur_AI_Action_Set_Title_Placeholder implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'set_title_placeholder';
    }

    public function get_label() {
        return __( 'Set Title Placeholder', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * Expected payload:
     * {
     *   "post_type": string,
     *   "placeholder": string
     * }
     *
     * Updates the arthur_ai_title_placeholders option, replacing or removing
     * the entry for the given post_type.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! isset( $payload['post_type'] ) || ! is_string( $payload['post_type'] ) ) {
            return array( 'success' => false, 'message' => __( 'post_type is required.', 'arthur-ai' ) );
        }
        $pt = sanitize_key( (string) $payload['post_type'] );
        $placeholder = '';
        if ( isset( $payload['placeholder'] ) && is_string( $payload['placeholder'] ) ) {
            $placeholder = trim( $payload['placeholder'] );
        }
        $placeholders = get_option( 'arthur_ai_title_placeholders', array() );
        if ( ! is_array( $placeholders ) ) {
            $placeholders = array();
        }
        if ( '' === $placeholder ) {
            unset( $placeholders[ $pt ] );
        } else {
            $placeholders[ $pt ] = $placeholder;
        }
        update_option( 'arthur_ai_title_placeholders', $placeholders );
        return array(
            'success' => true,
            'message' => __( 'Title placeholder updated.', 'arthur-ai' )
        );
    }
}
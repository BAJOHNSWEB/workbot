<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Convert a post to another post type.
 */
class Arthur_AI_Action_Convert_Post_Type implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'convert_post_type';
    }

    public function get_label() {
        return __( 'Convert Post Type', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $post_id         = isset( $payload['post_id'] ) ? (int) $payload['post_id'] : 0;
        $target_type     = isset( $payload['target_post_type'] ) ? sanitize_key( $payload['target_post_type'] ) : '';
        $target_status   = isset( $payload['target_status'] ) ? $payload['target_status'] : null;
        $post            = get_post( $post_id );
        if ( ! $post ) {
            return array( 'success' => false, 'message' => __( 'Post not found.', 'arthur-ai' ) );
        }
        $post_types = get_post_types( array(), 'names' );
        if ( '' === $target_type || ! in_array( $target_type, $post_types, true ) ) {
            return array( 'success' => false, 'message' => __( 'Invalid target post type.', 'arthur-ai' ) );
        }
        $update = array(
            'ID'        => $post_id,
            'post_type' => $target_type,
        );
        if ( $target_status ) {
            $update['post_status'] = sanitize_key( $target_status );
        }
        $result = wp_update_post( $update, true );
        if ( is_wp_error( $result ) ) {
            return array( 'success' => false, 'message' => $result->get_error_message() );
        }
        return array( 'success' => true, 'post_id' => $post_id, 'post_type' => $target_type );
    }
}
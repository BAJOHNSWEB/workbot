<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to hide the featured image meta box for specific post types. Supply
 * one or more post type slugs and this box will be removed from the editor
 * screen. Setting an empty list will re‑enable the box for all post types.
 */
class Arthur_AI_Action_Hide_Featured_Image_Box implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'hide_featured_image_box';
    }

    public function get_label() {
        return __( 'Hide Featured Image Box', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * Expected payload:
     * {
     *   "post_types": [string]
     * }
     *
     * Stores the list of post types in arthur_ai_hide_featured_image_box.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $post_types = array();
        if ( isset( $payload['post_types'] ) && is_array( $payload['post_types'] ) ) {
            foreach ( $payload['post_types'] as $pt ) {
                $pt = sanitize_key( (string) $pt );
                if ( '' !== $pt ) {
                    $post_types[] = $pt;
                }
            }
        }
        update_option( 'arthur_ai_hide_featured_image_box', $post_types );
        return array(
            'success' => true,
            'message' => __( 'Featured image box visibility updated.', 'arthur-ai' )
        );
    }
}
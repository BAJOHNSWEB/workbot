<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to configure the automatic insertion of a reusable block (or custom
 * block content) into new pages when they are created. If a valid block ID
 * is provided it takes precedence; otherwise arbitrary HTML content may be
 * inserted. Supplying neither will clear the existing settings.
 */
class Arthur_AI_Action_Set_Auto_Reusable_Block implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'set_auto_reusable_block';
    }

    public function get_label() {
        return __( 'Set Auto Reusable Block', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * Expected payload:
     * {
     *   "block_id": number|null,
     *   "block_content": string|null
     * }
     *
     * When block_id is a positive integer it is stored as arthur_ai_auto_reusable_block_id and
     * block_content is cleared. When block_id is zero or not provided, block_content (if supplied)
     * is stored in arthur_ai_auto_reusable_block_content. Both options are cleared if neither
     * parameter is provided.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $block_id      = 0;
        $block_content = '';

        if ( isset( $payload['block_id'] ) && is_numeric( $payload['block_id'] ) ) {
            $block_id = intval( $payload['block_id'] );
        }
        if ( isset( $payload['block_content'] ) && is_string( $payload['block_content'] ) ) {
            $block_content = (string) $payload['block_content'];
        }

        if ( $block_id > 0 ) {
            update_option( 'arthur_ai_auto_reusable_block_id', $block_id );
            update_option( 'arthur_ai_auto_reusable_block_content', '' );
            return array(
                'success' => true,
                'message' => sprintf( __( 'Reusable block %d will be auto inserted into new pages.', 'arthur-ai' ), $block_id )
            );
        }

        // No block ID, so store custom content if provided
        if ( '' !== trim( $block_content ) ) {
            update_option( 'arthur_ai_auto_reusable_block_id', 0 );
            update_option( 'arthur_ai_auto_reusable_block_content', wp_kses_post( $block_content ) );
            return array(
                'success' => true,
                'message' => __( 'Custom block content will be auto inserted into new pages.', 'arthur-ai' )
            );
        }

        // Clear both options if nothing provided
        update_option( 'arthur_ai_auto_reusable_block_id', 0 );
        update_option( 'arthur_ai_auto_reusable_block_content', '' );
        return array(
            'success' => true,
            'message' => __( 'Auto reusable block settings cleared.', 'arthur-ai' )
        );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Close comments on posts older than a given date.
 */
class Arthur_AI_Action_Bulk_Close_Comments_On_Old_Posts implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'bulk_close_comments_on_old_posts';
    }

    public function get_label() {
        return __( 'Bulk Close Comments on Old Posts', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $before_date = isset( $payload['before_date'] ) ? strtotime( $payload['before_date'] ) : false;
        $post_types  = isset( $payload['post_types'] ) && is_array( $payload['post_types'] ) ? $payload['post_types'] : array( 'post' );
        if ( ! $before_date ) {
            return array( 'success' => false, 'message' => __( 'A valid before_date is required.', 'arthur-ai' ) );
        }
        $args = array(
            'post_type'      => $post_types,
            'post_status'    => 'publish',
            'date_query'     => array( array( 'before' => date_i18n( 'Y-m-d H:i:s', $before_date ) ) ),
            'posts_per_page' => -1,
            'fields'         => 'ids',
        );
        $posts = get_posts( $args );
        $count = 0;
        foreach ( $posts as $pid ) {
            update_post_meta( $pid, '_arthur_ai_previous_comment_status', get_post_field( 'comment_status', $pid ) );
            wp_update_post( array( 'ID' => $pid, 'comment_status' => 'closed', 'ping_status' => 'closed' ) );
            $count++;
        }
        return array( 'success' => true, 'closed_posts' => $count );
    }
}
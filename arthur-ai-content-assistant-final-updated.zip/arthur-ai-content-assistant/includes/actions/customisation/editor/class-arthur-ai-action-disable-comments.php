<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to globally disable or enable comments. When set to true comments
 * and pings will be closed for all post types and comment support removed.
 */
class Arthur_AI_Action_Disable_Comments implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'disable_comments';
    }

    public function get_label() {
        return __( 'Disable Comments Globally', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * Expected payload:
     * {
     *   "disable": boolean
     * }
     *
     * Stores the boolean flag in arthur_ai_disable_comments.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $disable = false;
        if ( isset( $payload['disable'] ) ) {
            $disable = (bool) $payload['disable'];
        }
        update_option( 'arthur_ai_disable_comments', $disable );
        return array(
            'success' => true,
            'message' => $disable ? __( 'Comments have been disabled.', 'arthur-ai' ) : __( 'Comments have been enabled.', 'arthur-ai' )
        );
    }
}
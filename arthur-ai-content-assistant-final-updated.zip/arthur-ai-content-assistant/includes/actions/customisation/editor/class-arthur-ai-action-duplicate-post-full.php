<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Duplicate a post including meta, taxonomies and featured image.
 */
class Arthur_AI_Action_Duplicate_Post_Full implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'duplicate_post_full';
    }

    public function get_label() {
        return __( 'Duplicate Post (Full)', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( empty( $payload['source_post_id'] ) ) {
            return array( 'success' => false, 'message' => __( 'source_post_id is required.', 'arthur-ai' ) );
        }
        $source_id = (int) $payload['source_post_id'];
        $post      = get_post( $source_id );
        if ( ! $post ) {
            return array( 'success' => false, 'message' => __( 'Source post not found.', 'arthur-ai' ) );
        }
        $new_post = array(
            'post_author'  => get_current_user_id(),
            'post_content' => $post->post_content,
            'post_excerpt' => $post->post_excerpt,
            'post_title'   => isset( $payload['new_post_title'] ) && $payload['new_post_title'] ? (string) $payload['new_post_title'] : $post->post_title,
            'post_status'  => isset( $payload['post_status'] ) && $payload['post_status'] ? (string) $payload['post_status'] : 'draft',
            'post_type'    => $post->post_type,
        );
        // Insert new post
        $new_id = wp_insert_post( $new_post );
        if ( is_wp_error( $new_id ) ) {
            return array( 'success' => false, 'message' => $new_id->get_error_message() );
        }
        // Copy non-protected meta
        $meta = get_post_meta( $source_id );
        foreach ( $meta as $key => $values ) {
            if ( is_protected_meta( $key, 'post' ) ) {
                continue;
            }
            foreach ( $values as $value ) {
                add_post_meta( $new_id, $key, maybe_unserialize( $value ) );
            }
        }
        // Copy taxonomies
        $taxes = get_object_taxonomies( $post->post_type, 'names' );
        foreach ( $taxes as $tax ) {
            $terms = wp_get_object_terms( $source_id, $tax, array( 'fields' => 'ids' ) );
            if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
                wp_set_object_terms( $new_id, $terms, $tax );
            }
        }
        // Copy featured image
        $thumb_id = get_post_thumbnail_id( $source_id );
        if ( $thumb_id ) {
            set_post_thumbnail( $new_id, $thumb_id );
        }
        return array( 'success' => true, 'new_post_id' => $new_id );
    }
}
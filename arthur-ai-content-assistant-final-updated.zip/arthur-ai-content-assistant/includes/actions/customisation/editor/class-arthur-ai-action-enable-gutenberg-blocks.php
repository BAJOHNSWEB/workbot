<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to specify an allow‑list of Gutenberg block names. When set, only the
 * blocks in this list will be available in the block editor. This action also
 * clears any disabled blocks list to avoid conflicting settings.
 */
class Arthur_AI_Action_Enable_Gutenberg_Blocks implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'enable_gutenberg_blocks';
    }

    public function get_label() {
        return __( 'Enable Gutenberg Blocks', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * Expected payload:
     * {
     *   "blocks": [string]
     * }
     *
     * Stores the allow‑list of block names in arthur_ai_enabled_blocks and clears
     * arthur_ai_disabled_blocks.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $blocks = array();
        if ( isset( $payload['blocks'] ) && is_array( $payload['blocks'] ) ) {
            foreach ( $payload['blocks'] as $blk ) {
                $blk = sanitize_text_field( (string) $blk );
                if ( '' !== $blk ) {
                    $blocks[] = $blk;
                }
            }
        }
        update_option( 'arthur_ai_enabled_blocks', $blocks );
        // Clear disabled blocks to avoid conflicts
        update_option( 'arthur_ai_disabled_blocks', array() );
        return array(
            'success' => true,
            'message' => __( 'Gutenberg block allow‑list updated.', 'arthur-ai' )
        );
    }
}
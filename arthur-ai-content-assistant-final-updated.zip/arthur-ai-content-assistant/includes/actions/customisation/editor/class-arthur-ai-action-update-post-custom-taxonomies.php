<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Assign terms in custom taxonomies for a post.
 */
class Arthur_AI_Action_Update_Post_Custom_Taxonomies implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'update_post_custom_taxonomies';
    }

    public function get_label() {
        return __( 'Update Custom Taxonomies', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $post_id    = isset( $payload['post_id'] ) ? (int) $payload['post_id'] : 0;
        $taxonomies = isset( $payload['taxonomies'] ) && is_array( $payload['taxonomies'] ) ? $payload['taxonomies'] : array();
        $create     = ! empty( $payload['create_terms'] );
        if ( ! $post_id || empty( $taxonomies ) ) {
            return array( 'success' => false, 'message' => __( 'post_id and taxonomies are required.', 'arthur-ai' ) );
        }
        $summary = array();
        foreach ( $taxonomies as $tax => $terms ) {
            $tax = sanitize_key( $tax );
            if ( ! taxonomy_exists( $tax ) ) {
                continue;
            }
            $term_ids = array();
            foreach ( (array) $terms as $term ) {
                if ( is_numeric( $term ) ) {
                    $term_ids[] = (int) $term;
                } elseif ( is_string( $term ) ) {
                    $t = get_term_by( 'name', $term, $tax );
                    if ( ! $t && $create ) {
                        $t = wp_insert_term( $term, $tax );
                        if ( is_wp_error( $t ) ) {
                            continue;
                        }
                        $t = get_term( $t['term_id'], $tax );
                    }
                    if ( $t ) {
                        $term_ids[] = (int) $t->term_id;
                    }
                }
            }
            if ( ! empty( $term_ids ) ) {
                wp_set_post_terms( $post_id, $term_ids, $tax );
            }
            $summary[ $tax ] = $term_ids;
        }
        return array( 'success' => true, 'taxonomies' => $summary );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to set the default featured image ID for posts and pages. When a post
 * is saved without a featured image and this setting is non‑zero the image
 * will automatically be assigned.
 */
class Arthur_AI_Action_Set_Default_Featured_Image implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'set_default_featured_image';
    }

    public function get_label() {
        return __( 'Set Default Featured Image', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * Expected payload:
     * {
     *   "image_id": number
     * }
     *
     * Stores the integer ID in arthur_ai_default_featured_image_id.
     * A zero or non‑numeric value clears the setting.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $image_id = 0;
        if ( isset( $payload['image_id'] ) && is_numeric( $payload['image_id'] ) ) {
            $image_id = intval( $payload['image_id'] );
        }
        update_option( 'arthur_ai_default_featured_image_id', $image_id );
        return array(
            'success' => true,
            'message' => __( 'Default featured image updated.', 'arthur-ai' )
        );
    }
}
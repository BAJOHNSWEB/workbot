<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Restructure a post into logical sections by replacing its content with provided block markup.
 */
class Arthur_AI_Action_Restructure_Post_Into_Sections implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'restructure_post_into_sections';
    }

    public function get_label() {
        return __( 'Restructure Post Into Sections', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $post_id      = isset( $payload['post_id'] ) ? (int) $payload['post_id'] : 0;
        $post_content = isset( $payload['post_content'] ) ? (string) $payload['post_content'] : '';
        if ( ! $post_id || '' === $post_content ) {
            return array( 'success' => false, 'message' => __( 'post_id and post_content are required.', 'arthur-ai' ) );
        }
        $post_content = wp_kses_post( $post_content );
        $result       = wp_update_post( array( 'ID' => $post_id, 'post_content' => $post_content ), true );
        if ( is_wp_error( $result ) ) {
            return array( 'success' => false, 'message' => $result->get_error_message() );
        }
        return array( 'success' => true, 'post_id' => $post_id );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to duplicate a single post or page. Creates a new draft copy of the
 * source post with the same title, content and excerpt. Author is set to the
 * current user and the post type is preserved.
 */
class Arthur_AI_Action_Duplicate_Post implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'duplicate_post';
    }

    public function get_label() {
        return __( 'Duplicate Post/Page', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * Expected payload:
     * {
     *   "source_post_id": number
     * }
     *
     * Returns the new post_id in the response on success.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $source_id = isset( $payload['source_post_id'] ) ? intval( $payload['source_post_id'] ) : 0;
        if ( $source_id <= 0 ) {
            return array( 'success' => false, 'message' => __( 'No source_post_id provided.', 'arthur-ai' ) );
        }
        $source = get_post( $source_id );
        if ( ! $source ) {
            return array( 'success' => false, 'message' => __( 'Source post not found.', 'arthur-ai' ) );
        }
        if ( ! current_user_can( 'edit_post', $source_id ) ) {
            return array( 'success' => false, 'message' => __( 'You do not have permission to duplicate this post.', 'arthur-ai' ) );
        }
        $new_post = array(
            'post_title'   => $source->post_title,
            'post_content' => $source->post_content,
            'post_excerpt' => $source->post_excerpt,
            'post_status'  => 'draft',
            'post_type'    => $source->post_type,
            'post_author'  => get_current_user_id(),
        );
        $new_post_id = wp_insert_post( $new_post, true );
        if ( is_wp_error( $new_post_id ) ) {
            return array( 'success' => false, 'message' => $new_post_id->get_error_message() );
        }
        return array(
            'success' => true,
            'post_id' => $new_post_id,
            'message' => __( 'Post duplicated.', 'arthur-ai' )
        );
    }
}
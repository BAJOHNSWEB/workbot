<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Moderate comments based on provided statuses.
 */
class Arthur_AI_Action_Moderate_Comments_By_Rules implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'moderate_comments_by_rules';
    }

    public function get_label() {
        return __( 'Moderate Comments by Rules', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $actions = isset( $payload['actions'] ) && is_array( $payload['actions'] ) ? $payload['actions'] : array();
        if ( empty( $actions ) ) {
            return array( 'success' => false, 'message' => __( 'actions array is required.', 'arthur-ai' ) );
        }
        $counts = array( 'approve' => 0, 'spam' => 0, 'trash' => 0, 'unapprove' => 0 );
        foreach ( $actions as $item ) {
            if ( ! isset( $item['comment_id'], $item['status'] ) ) {
                continue;
            }
            $comment_id = (int) $item['comment_id'];
            $status     = $item['status'];
            $allowed    = array( 'approve', 'spam', 'trash', 'unapprove' );
            if ( ! in_array( $status, $allowed, true ) ) {
                continue;
            }
            wp_set_comment_status( $comment_id, $status );
            $counts[ $status ]++;
        }
        return array( 'success' => true, 'counts' => $counts );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
/**
 * Update meta/ACF fields for a single post.
 */
class Arthur_AI_Action_Update_Meta_Fields_Single implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'update_meta_fields_single';
    }

    public function get_label() {
        return __( 'Update Meta Fields (Single)', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $post_id = isset( $payload['post_id'] ) ? (int) $payload['post_id'] : 0;
        $meta    = isset( $payload['meta'] ) && is_array( $payload['meta'] ) ? $payload['meta'] : array();
        if ( ! $post_id || empty( $meta ) ) {
            return array( 'success' => false, 'message' => __( 'post_id and meta data are required.', 'arthur-ai' ) );
        }
        $updated = array();
        foreach ( $meta as $key => $value ) {
            $key = sanitize_key( $key );
            update_post_meta( $post_id, $key, $value );
            $updated[] = $key;
        }
        return array( 'success' => true, 'updated_keys' => $updated );
    }
}
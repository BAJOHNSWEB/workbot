<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to duplicate multiple posts or pages in a single request. This will
 * iterate over the provided source_post_ids, duplicating each into a new
 * draft authored by the current user. Posts that cannot be duplicated due
 * to permissions or errors will be skipped.
 */
class Arthur_AI_Action_Bulk_Duplicate_Posts implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'bulk_duplicate_posts';
    }

    public function get_label() {
        return __( 'Bulk Duplicate Posts/Pages', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * Expected payload:
     * {
     *   "source_post_ids": [number]
     * }
     *
     * Returns an array of new_post_ids in the response.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! isset( $payload['source_post_ids'] ) || ! is_array( $payload['source_post_ids'] ) ) {
            return array( 'success' => false, 'message' => __( 'source_post_ids is required.', 'arthur-ai' ) );
        }
        $new_ids = array();
        foreach ( $payload['source_post_ids'] as $source_id ) {
            $source_id = intval( $source_id );
            if ( $source_id <= 0 ) {
                continue;
            }
            $source = get_post( $source_id );
            if ( ! $source ) {
                continue;
            }
            if ( ! current_user_can( 'edit_post', $source_id ) ) {
                continue;
            }
            $new_post = array(
                'post_title'   => $source->post_title,
                'post_content' => $source->post_content,
                'post_excerpt' => $source->post_excerpt,
                'post_status'  => 'draft',
                'post_type'    => $source->post_type,
                'post_author'  => get_current_user_id(),
            );
            $new_post_id = wp_insert_post( $new_post, true );
            if ( ! is_wp_error( $new_post_id ) ) {
                $new_ids[] = $new_post_id;
            }
        }
        return array(
            'success'  => true,
            'post_ids' => $new_ids,
            'message'  => __( 'Bulk duplication completed.', 'arthur-ai' )
        );
    }
}
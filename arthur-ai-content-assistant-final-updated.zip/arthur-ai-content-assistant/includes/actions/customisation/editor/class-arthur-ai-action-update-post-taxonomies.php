<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Assign or edit categories and tags for a post.
 */
class Arthur_AI_Action_Update_Post_Taxonomies implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'update_post_taxonomies';
    }

    public function get_label() {
        return __( 'Update Post Taxonomies', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $post_id      = isset( $payload['post_id'] ) ? (int) $payload['post_id'] : 0;
        $categories   = isset( $payload['categories'] ) && is_array( $payload['categories'] ) ? $payload['categories'] : array();
        $tags         = isset( $payload['tags'] ) && is_array( $payload['tags'] ) ? $payload['tags'] : array();
        $create_terms = ! empty( $payload['create_terms'] );
        if ( ! $post_id ) {
            return array( 'success' => false, 'message' => __( 'post_id is required.', 'arthur-ai' ) );
        }
        $cat_ids = array();
        $tag_ids = array();
        // Resolve categories
        foreach ( $categories as $cat ) {
            if ( is_numeric( $cat ) ) {
                $cat_ids[] = (int) $cat;
            } elseif ( is_string( $cat ) ) {
                $term = get_term_by( 'name', $cat, 'category' );
                if ( ! $term && $create_terms ) {
                    $term = wp_insert_term( $cat, 'category' );
                    if ( is_wp_error( $term ) ) {
                        continue;
                    }
                    $term = get_term( $term['term_id'], 'category' );
                }
                if ( $term ) {
                    $cat_ids[] = (int) $term->term_id;
                }
            }
        }
        // Resolve tags
        foreach ( $tags as $tag ) {
            if ( is_numeric( $tag ) ) {
                $tag_ids[] = (int) $tag;
            } elseif ( is_string( $tag ) ) {
                $term = get_term_by( 'name', $tag, 'post_tag' );
                if ( ! $term && $create_terms ) {
                    $term = wp_insert_term( $tag, 'post_tag' );
                    if ( is_wp_error( $term ) ) {
                        continue;
                    }
                    $term = get_term( $term['term_id'], 'post_tag' );
                }
                if ( $term ) {
                    $tag_ids[] = (int) $term->term_id;
                }
            }
        }
        if ( ! empty( $cat_ids ) ) {
            wp_set_post_terms( $post_id, $cat_ids, 'category' );
        }
        if ( ! empty( $tag_ids ) ) {
            wp_set_post_terms( $post_id, $tag_ids, 'post_tag' );
        }
        return array( 'success' => true, 'categories' => $cat_ids, 'tags' => $tag_ids );
    }
}
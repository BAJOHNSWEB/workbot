<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Generate a reply to an existing comment.
 */
class Arthur_AI_Action_Reply_To_Comment implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'reply_to_comment';
    }

    public function get_label() {
        return __( 'Reply to Comment', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $comment_id    = isset( $payload['comment_id'] ) ? (int) $payload['comment_id'] : 0;
        $reply_content = isset( $payload['reply_content'] ) ? (string) $payload['reply_content'] : '';
        $author_name   = isset( $payload['author_name'] ) ? (string) $payload['author_name'] : '';
        $author_email  = isset( $payload['author_email'] ) ? (string) $payload['author_email'] : '';
        if ( ! $comment_id || '' === $reply_content ) {
            return array( 'success' => false, 'message' => __( 'comment_id and reply_content are required.', 'arthur-ai' ) );
        }
        $parent = get_comment( $comment_id );
        if ( ! $parent ) {
            return array( 'success' => false, 'message' => __( 'Parent comment not found.', 'arthur-ai' ) );
        }
        $commentdata = array(
            'comment_post_ID'      => $parent->comment_post_ID,
            'comment_parent'       = $comment_id,
            'comment_content'      => wp_kses_post( $reply_content ),
            'comment_type'         => '',
            'comment_author'       => $author_name ? $author_name : 'Arthur AI',
            'comment_author_email' => $author_email ? $author_email : '',
            'comment_author_url'   => '',
            'user_id'             => get_current_user_id(),
        );
        $new_id = wp_insert_comment( $commentdata );
        return array( 'success' => true, 'comment_id' => $new_id );
    }
}
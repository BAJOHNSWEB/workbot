<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to hide the tags and/or categories meta boxes on the post editor
 * screen. When called the specified flags are stored, causing the boxes to
 * be removed via the Post Editor Customiser hooks.
 */
class Arthur_AI_Action_Hide_Tags_Categories_Box implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'hide_tags_categories_box';
    }

    public function get_label() {
        return __( 'Hide Tags/Categories Boxes', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * Expected payload:
     * {
     *   "hide_tags": boolean|null,
     *   "hide_categories": boolean|null
     * }
     *
     * Stores the booleans in arthur_ai_hide_tags_box and arthur_ai_hide_categories_box.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( isset( $payload['hide_tags'] ) ) {
            $hide_tags = (bool) $payload['hide_tags'];
            update_option( 'arthur_ai_hide_tags_box', $hide_tags );
        }
        if ( isset( $payload['hide_categories'] ) ) {
            $hide_categories = (bool) $payload['hide_categories'];
            update_option( 'arthur_ai_hide_categories_box', $hide_categories );
        }
        return array(
            'success' => true,
            'message' => __( 'Tags/categories box visibility updated.', 'arthur-ai' )
        );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Map imported data array into post meta based on mapping paths.
 */
class Arthur_AI_Action_Map_Imported_Data_To_Meta implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'map_imported_data_to_meta';
    }

    public function get_label() {
        return __( 'Map Imported Data to Meta', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $post_id   = isset( $payload['post_id'] ) ? (int) $payload['post_id'] : 0;
        $data      = isset( $payload['source_data'] ) && is_array( $payload['source_data'] ) ? $payload['source_data'] : array();
        $mapping   = isset( $payload['mapping'] ) && is_array( $payload['mapping'] ) ? $payload['mapping'] : array();
        if ( ! $post_id || empty( $mapping ) ) {
            return array( 'success' => false, 'message' => __( 'post_id and mapping are required.', 'arthur-ai' ) );
        }
        $summary = array();
        foreach ( $mapping as $meta_key => $path ) {
            $meta_key = sanitize_key( $meta_key );
            $value    = null;
            if ( is_string( $path ) && '' !== $path ) {
                $segments = explode( '.', $path );
                $current  = $data;
                foreach ( $segments as $segment ) {
                    if ( is_array( $current ) && array_key_exists( $segment, $current ) ) {
                        $current = $current[ $segment ];
                    } else {
                        $current = null;
                        break;
                    }
                }
                $value = $current;
            }
            update_post_meta( $post_id, $meta_key, $value );
            $summary[ $meta_key ] = $value;
        }
        return array( 'success' => true, 'mapping' => $summary );
    }
}
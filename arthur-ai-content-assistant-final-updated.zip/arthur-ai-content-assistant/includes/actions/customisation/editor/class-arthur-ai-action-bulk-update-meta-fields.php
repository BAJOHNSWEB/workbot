<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Bulk update meta fields across multiple posts.
 */
class Arthur_AI_Action_Bulk_Update_Meta_Fields implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'bulk_update_meta_fields';
    }

    public function get_label() {
        return __( 'Bulk Update Meta Fields', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $items = isset( $payload['items'] ) && is_array( $payload['items'] ) ? $payload['items'] : array();
        if ( empty( $items ) ) {
            return array( 'success' => false, 'message' => __( 'items array is required.', 'arthur-ai' ) );
        }
        $report = array();
        foreach ( $items as $item ) {
            if ( ! is_array( $item ) || ! isset( $item['post_id'] ) || ! isset( $item['meta'] ) || ! is_array( $item['meta'] ) ) {
                continue;
            }
            $post_id = (int) $item['post_id'];
            $updated = array();
            foreach ( $item['meta'] as $key => $value ) {
                $key = sanitize_key( $key );
                update_post_meta( $post_id, $key, $value );
                $updated[] = $key;
            }
            $report[] = array( 'post_id' => $post_id, 'updated_keys' => $updated );
        }
        return array( 'success' => true, 'report' => $report );
    }
}
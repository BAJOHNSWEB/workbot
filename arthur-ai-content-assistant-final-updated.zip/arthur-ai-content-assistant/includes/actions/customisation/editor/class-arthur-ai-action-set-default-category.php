<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to set the default category for new posts. Accepts either a term ID
 * or a category slug. When a new post is created without any categories,
 * this category will be assigned.
 */
class Arthur_AI_Action_Set_Default_Category implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'set_default_category';
    }

    public function get_label() {
        return __( 'Set Default Category', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * Expected payload:
     * {
     *   "category": string|number
     * }
     *
     * Stores the category identifier (slug or ID) in arthur_ai_default_category. An empty
     * string clears the setting.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $category = '';
        if ( isset( $payload['category'] ) ) {
            $value = $payload['category'];
            if ( is_numeric( $value ) ) {
                $category = intval( $value );
            } else {
                $category = sanitize_title( (string) $value );
            }
        }
        update_option( 'arthur_ai_default_category', $category );
        return array(
            'success' => true,
            'message' => __( 'Default category updated.', 'arthur-ai' )
        );
    }
}
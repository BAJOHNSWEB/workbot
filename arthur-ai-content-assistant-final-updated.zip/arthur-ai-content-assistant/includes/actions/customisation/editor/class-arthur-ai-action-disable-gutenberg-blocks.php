<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to disable specific Gutenberg block types. The provided block names
 * will be removed from the editor. Any existing allow‑list is cleared to
 * ensure the disabled list takes effect as a deny‑list.
 */
class Arthur_AI_Action_Disable_Gutenberg_Blocks implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'disable_gutenberg_blocks';
    }

    public function get_label() {
        return __( 'Disable Gutenberg Blocks', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * Expected payload:
     * {
     *   "blocks": [string]
     * }
     *
     * Stores the deny‑list of block names in arthur_ai_disabled_blocks and clears
     * arthur_ai_enabled_blocks.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $blocks = array();
        if ( isset( $payload['blocks'] ) && is_array( $payload['blocks'] ) ) {
            foreach ( $payload['blocks'] as $blk ) {
                $blk = sanitize_text_field( (string) $blk );
                if ( '' !== $blk ) {
                    $blocks[] = $blk;
                }
            }
        }
        update_option( 'arthur_ai_disabled_blocks', $blocks );
        // Clear enabled blocks so the disable list acts as a deny‑list
        update_option( 'arthur_ai_enabled_blocks', array() );
        return array(
            'success' => true,
            'message' => __( 'Gutenberg block deny‑list updated.', 'arthur-ai' )
        );
    }
}
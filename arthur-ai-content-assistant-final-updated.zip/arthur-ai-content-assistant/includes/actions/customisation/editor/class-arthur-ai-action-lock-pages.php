<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to lock or unlock specific pages for editing by non‑administrator users. When
 * locked, only administrators will be able to edit the pages. This action
 * updates the arthur_ai_locked_pages option to include or exclude the given
 * page IDs.
 */
class Arthur_AI_Action_Lock_Pages implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'lock_pages';
    }

    public function get_label() {
        return __( 'Lock/Unlock Pages for Non‑Admins', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * Expected payload:
     * {
     *   "page_ids": [number],
     *   "locked": boolean
     * }
     *
     * When locked = true, the provided pages are added to the locked list. When
     * locked = false, the provided pages are removed from the locked list.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! isset( $payload['page_ids'] ) || ! is_array( $payload['page_ids'] ) ) {
            return array( 'success' => false, 'message' => __( 'page_ids array is required.', 'arthur-ai' ) );
        }
        $lock   = isset( $payload['locked'] ) ? (bool) $payload['locked'] : true;
        $ids    = array();
        foreach ( $payload['page_ids'] as $id ) {
            $id = intval( $id );
            if ( $id > 0 ) {
                $ids[] = $id;
            }
        }
        $current = get_option( 'arthur_ai_locked_pages', array() );
        if ( ! is_array( $current ) ) {
            $current = array();
        }
        if ( $lock ) {
            $merged = array_unique( array_merge( $current, $ids ) );
            update_option( 'arthur_ai_locked_pages', $merged );
        } else {
            $remaining = array_diff( $current, $ids );
            update_option( 'arthur_ai_locked_pages', array_values( $remaining ) );
        }
        return array(
            'success' => true,
            'message' => $lock ? __( 'Pages locked for non‑admins.', 'arthur-ai' ) : __( 'Pages unlocked.', 'arthur-ai' )
        );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Duplicate an Elementor library template.
 */
class Arthur_AI_Action_Duplicate_Elementor_Template implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'duplicate_elementor_template';
    }

    public function get_label() {
        return __( 'Duplicate Elementor Template', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
            return array( 'success' => false, 'message' => __( 'Elementor is not active.', 'arthur-ai' ) );
        }
        $template_id = isset( $payload['template_id'] ) ? (int) $payload['template_id'] : 0;
        if ( ! $template_id ) {
            return array( 'success' => false, 'message' => __( 'template_id is required.', 'arthur-ai' ) );
        }
        $template = get_post( $template_id );
        if ( ! $template || 'elementor_library' !== $template->post_type ) {
            return array( 'success' => false, 'message' => __( 'Template not found.', 'arthur-ai' ) );
        }
        $new_title = isset( $payload['new_title'] ) && $payload['new_title'] ? sanitize_text_field( $payload['new_title'] ) : $template->post_title . ' Copy';
        $new_post  = array(
            'post_type'    => 'elementor_library',
            'post_status'  => 'draft',
            'post_title'   => $new_title,
            'post_content' => $template->post_content,
        );
        $new_id = wp_insert_post( $new_post );
        if ( is_wp_error( $new_id ) ) {
            return array( 'success' => false, 'message' => $new_id->get_error_message() );
        }
        // Copy Elementor metadata
        $meta = get_post_meta( $template_id );
        foreach ( $meta as $key => $values ) {
            foreach ( $values as $value ) {
                add_post_meta( $new_id, $key, maybe_unserialize( $value ) );
            }
        }
        return array( 'success' => true, 'template_id' => $new_id );
    }
}
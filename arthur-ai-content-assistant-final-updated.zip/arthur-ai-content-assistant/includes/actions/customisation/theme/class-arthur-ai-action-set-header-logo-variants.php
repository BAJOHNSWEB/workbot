<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Store header logo variants (light/dark) for front‑end.
 */
class Arthur_AI_Action_Set_Header_Logo_Variants implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'set_header_logo_variants';
    }

    public function get_label() {
        return __( 'Set Header Logo Variants', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $light = isset( $payload['light_logo_id'] ) ? (int) $payload['light_logo_id'] : 0;
        $dark  = isset( $payload['dark_logo_id'] ) ? (int) $payload['dark_logo_id'] : 0;
        $rules = isset( $payload['rules'] ) && is_array( $payload['rules'] ) ? $payload['rules'] : array();
        $config = array( 'light_logo_id' => $light, 'dark_logo_id' => $dark, 'rules' => $rules );
        update_option( 'arthur_ai_header_logo_variants', $config );
        return array( 'success' => true );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Define or update a reusable block pattern.
 */
class Arthur_AI_Action_Define_Block_Pattern implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'define_block_pattern';
    }

    public function get_label() {
        return __( 'Define Block Pattern', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $pattern_name  = isset( $payload['pattern_name'] ) ? sanitize_text_field( $payload['pattern_name'] ) : '';
        $pattern_slug  = isset( $payload['pattern_slug'] ) ? sanitize_key( $payload['pattern_slug'] ) : '';
        $categories    = isset( $payload['categories'] ) && is_array( $payload['categories'] ) ? array_map( 'sanitize_key', $payload['categories'] ) : array();
        $content       = isset( $payload['content'] ) ? (string) $payload['content'] : '';
        if ( '' === $pattern_slug || '' === $content ) {
            return array( 'success' => false, 'message' => __( 'pattern_slug and content are required.', 'arthur-ai' ) );
        }
        $args = array(
            'post_type'      => 'wp_block',
            'name'           => $pattern_slug,
            'posts_per_page' => 1,
        );
        $existing = get_posts( $args );
        $post_data = array(
            'post_content' => wp_kses_post( $content ),
            'post_title'   => $pattern_name ? $pattern_name : $pattern_slug,
            'post_name'    => $pattern_slug,
            'post_status'  => 'publish',
            'post_type'    => 'wp_block',
        );
        if ( ! empty( $existing ) ) {
            $post_data['ID'] = $existing[0]->ID;
            wp_update_post( $post_data );
            return array( 'success' => true, 'pattern_id' => $existing[0]->ID );
        }
        $pattern_id = wp_insert_post( $post_data );
        return is_wp_error( $pattern_id ) ? array( 'success' => false, 'message' => $pattern_id->get_error_message() ) : array( 'success' => true, 'pattern_id' => $pattern_id );
    }
}
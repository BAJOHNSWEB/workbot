<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Change the front-end site logo.
 */
class Arthur_AI_Action_Change_Site_Logo implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'change_site_logo';
    }

    public function get_label() {
        return __( 'Change Site Logo', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! empty( $payload['attachment_id'] ) ) {
            $attachment_id = (int) $payload['attachment_id'];
            set_theme_mod( 'custom_logo', $attachment_id );
        } elseif ( ! empty( $payload['url'] ) ) {
            // Store fallback URL in option
            update_option( 'arthur_ai_site_logo_url', esc_url_raw( $payload['url'] ) );
        } else {
            return array( 'success' => false, 'message' => __( 'attachment_id or url is required.', 'arthur-ai' ) );
        }
        return array( 'success' => true );
    }
}
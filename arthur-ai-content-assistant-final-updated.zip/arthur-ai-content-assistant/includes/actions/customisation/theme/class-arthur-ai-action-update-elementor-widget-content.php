<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Replace content in Elementor widgets using provided paths.
 */
class Arthur_AI_Action_Update_Elementor_Widget_Content implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'update_elementor_widget_content';
    }

    public function get_label() {
        return __( 'Update Elementor Widget Content', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
            return array( 'success' => false, 'message' => __( 'Elementor is not active.', 'arthur-ai' ) );
        }
        $post_id      = isset( $payload['post_id'] ) ? (int) $payload['post_id'] : 0;
        $template_id  = isset( $payload['template_id'] ) ? (int) $payload['template_id'] : 0;
        $replacements = isset( $payload['replacements'] ) && is_array( $payload['replacements'] ) ? $payload['replacements'] : array();
        $target_id    = $template_id ? $template_id : $post_id;
        if ( ! $target_id || empty( $replacements ) ) {
            return array( 'success' => false, 'message' => __( 'post_id/template_id and replacements are required.', 'arthur-ai' ) );
        }
        $data = get_post_meta( $target_id, '_elementor_data', true );
        if ( empty( $data ) ) {
            return array( 'success' => false, 'message' => __( 'Elementor data not found.', 'arthur-ai' ) );
        }
        $json = json_decode( $data, true );
        if ( ! is_array( $json ) ) {
            return array( 'success' => false, 'message' => __( 'Invalid Elementor data.', 'arthur-ai' ) );
        }
        // Apply replacements: expecting array of [ 'path' => [segments], 'value' => new value ]
        foreach ( $replacements as $rep ) {
            if ( ! isset( $rep['path'], $rep['value'] ) ) {
                continue;
            }
            $path  = $rep['path'];
            $value = $rep['value'];
            $ref   =& $json;
            foreach ( $path as $segment ) {
                if ( ! isset( $ref[ $segment ] ) ) {
                    $ref[ $segment ] = array();
                }
                $ref =& $ref[ $segment ];
            }
            $ref = $value;
        }
        update_post_meta( $target_id, '_elementor_data', wp_json_encode( $json ) );
        return array( 'success' => true );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Update global colour and typography tokens.
 */
class Arthur_AI_Action_Update_Global_Design_Tokens implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'update_global_design_tokens';
    }

    public function get_label() {
        return __( 'Update Global Design Tokens', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $colours    = isset( $payload['colours'] ) && is_array( $payload['colours'] ) ? $payload['colours'] : array();
        $typography = isset( $payload['typography'] ) && is_array( $payload['typography'] ) ? $payload['typography'] : array();
        $tokens     = array();
        if ( ! empty( $colours ) ) {
            $tokens['colours'] = $colours;
        }
        if ( ! empty( $typography ) ) {
            $tokens['typography'] = $typography;
        }
        update_option( 'arthur_ai_design_tokens', $tokens );
        return array( 'success' => true );
    }
}
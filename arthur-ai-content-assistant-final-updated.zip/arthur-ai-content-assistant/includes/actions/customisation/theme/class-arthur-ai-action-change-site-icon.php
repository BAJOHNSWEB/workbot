<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Update the site icon (favicon).
 */
class Arthur_AI_Action_Change_Site_Icon implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'change_site_icon';
    }

    public function get_label() {
        return __( 'Change Site Icon', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( empty( $payload['attachment_id'] ) ) {
            return array( 'success' => false, 'message' => __( 'attachment_id is required.', 'arthur-ai' ) );
        }
        update_option( 'site_icon', (int) $payload['attachment_id'] );
        return array( 'success' => true );
    }
}
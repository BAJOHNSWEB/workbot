<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Create or update a block template.
 */
class Arthur_AI_Action_Manage_Block_Template implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'manage_block_template';
    }

    public function get_label() {
        return __( 'Manage Block Template', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $template_type = isset( $payload['template_type'] ) ? sanitize_key( $payload['template_type'] ) : '';
        $slug          = isset( $payload['slug'] ) ? sanitize_key( $payload['slug'] ) : '';
        $post_content  = isset( $payload['post_content'] ) ? (string) $payload['post_content'] : '';
        if ( '' === $template_type || '' === $slug || '' === $post_content ) {
            return array( 'success' => false, 'message' => __( 'template_type, slug and post_content are required.', 'arthur-ai' ) );
        }
        $post_content = wp_kses_post( $post_content );
        $args = array(
            'post_type'   => 'wp_template',
            'name'        => $slug,
            'post_status' => 'publish',
            'posts_per_page' => 1,
        );
        $existing = get_posts( $args );
        if ( ! empty( $existing ) ) {
            $template_id = $existing[0]->ID;
            wp_update_post( array( 'ID' => $template_id, 'post_content' => $post_content, 'post_title' => $slug ) );
            return array( 'success' => true, 'template_id' => $template_id );
        }
        $insert = array(
            'post_type'    => 'wp_template',
            'post_status'  => 'publish',
            'post_name'    => $slug,
            'post_title'   => $slug,
            'post_content' => $post_content,
            'meta_input'   => array( 'wp_template_type' => $template_type ),
        );
        $template_id = wp_insert_post( $insert );
        return is_wp_error( $template_id ) ? array( 'success' => false, 'message' => $template_id->get_error_message() ) : array( 'success' => true, 'template_id' => $template_id );
    }
}
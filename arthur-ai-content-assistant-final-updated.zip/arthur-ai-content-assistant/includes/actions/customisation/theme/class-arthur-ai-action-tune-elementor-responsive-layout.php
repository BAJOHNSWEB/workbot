<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Adjust Elementor widget settings for responsive layout.
 */
class Arthur_AI_Action_Tune_Elementor_Responsive_Layout implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'tune_elementor_responsive_layout';
    }

    public function get_label() {
        return __( 'Tune Elementor Responsive Layout', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
            return array( 'success' => false, 'message' => __( 'Elementor is not active.', 'arthur-ai' ) );
        }
        $post_id   = isset( $payload['post_id'] ) ? (int) $payload['post_id'] : 0;
        $template  = isset( $payload['template_id'] ) ? (int) $payload['template_id'] : 0;
        $settings  = isset( $payload['settings'] ) && is_array( $payload['settings'] ) ? $payload['settings'] : array();
        $target_id = $template ? $template : $post_id;
        if ( ! $target_id || empty( $settings ) ) {
            return array( 'success' => false, 'message' => __( 'post_id/template_id and settings are required.', 'arthur-ai' ) );
        }
        $data = get_post_meta( $target_id, '_elementor_data', true );
        $json = json_decode( $data, true );
        if ( ! is_array( $json ) ) {
            return array( 'success' => false, 'message' => __( 'Invalid Elementor data.', 'arthur-ai' ) );
        }
        // For simplicity, we expect settings as path/value pairs similar to replacements.
        foreach ( $settings as $item ) {
            if ( ! isset( $item['path'], $item['value'] ) ) {
                continue;
            }
            $path  = $item['path'];
            $value = $item['value'];
            $ref   =& $json;
            foreach ( $path as $segment ) {
                if ( ! isset( $ref[ $segment ] ) ) {
                    $ref[ $segment ] = array();
                }
                $ref =& $ref[ $segment ];
            }
            $ref = $value;
        }
        update_post_meta( $target_id, '_elementor_data', wp_json_encode( $json ) );
        return array( 'success' => true );
    }
}
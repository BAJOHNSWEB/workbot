<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Apply a block pattern's content across selected posts.
 */
class Arthur_AI_Action_Apply_Pattern_To_Posts implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'apply_pattern_to_posts';
    }

    public function get_label() {
        return __( 'Apply Pattern to Posts', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $pattern_content = isset( $payload['pattern_content'] ) ? (string) $payload['pattern_content'] : '';
        $post_ids        = isset( $payload['post_ids'] ) && is_array( $payload['post_ids'] ) ? $payload['post_ids'] : array();
        $mode            = isset( $payload['mode'] ) ? $payload['mode'] : 'append';
        if ( '' === $pattern_content || empty( $post_ids ) ) {
            return array( 'success' => false, 'message' => __( 'pattern_content and post_ids are required.', 'arthur-ai' ) );
        }
        $pattern_content = wp_kses_post( $pattern_content );
        $result_ids      = array();
        foreach ( $post_ids as $pid ) {
            $pid = (int) $pid;
            $post = get_post( $pid );
            if ( ! $post ) {
                continue;
            }
            $content = $post->post_content;
            if ( 'prepend' === $mode ) {
                $content = $pattern_content . '\n' . $content;
            } elseif ( 'append' === $mode ) {
                $content = $content . '\n' . $pattern_content;
            } elseif ( 'replace_section' === $mode ) {
                $content = $pattern_content;
            }
            wp_update_post( array( 'ID' => $pid, 'post_content' => $content ) );
            $result_ids[] = $pid;
        }
        return array( 'success' => true, 'updated_posts' => $result_ids );
    }
}
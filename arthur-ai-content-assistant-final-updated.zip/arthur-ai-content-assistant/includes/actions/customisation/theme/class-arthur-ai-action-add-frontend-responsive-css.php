<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Add responsive CSS for front‑end layout issues.
 */
class Arthur_AI_Action_Add_Frontend_Responsive_Css implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'add_frontend_responsive_css';
    }

    public function get_label() {
        return __( 'Add Frontend Responsive CSS', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $css   = isset( $payload['css'] ) ? (string) $payload['css'] : '';
        $scope = isset( $payload['scope'] ) ? $payload['scope'] : 'global';
        if ( '' === trim( $css ) ) {
            return array( 'success' => false, 'message' => __( 'css is required.', 'arthur-ai' ) );
        }
        if ( 'per_post' === $scope ) {
            $post_id = isset( $payload['post_id'] ) ? (int) $payload['post_id'] : 0;
            if ( ! $post_id ) {
                return array( 'success' => false, 'message' => __( 'post_id is required for per_post scope.', 'arthur-ai' ) );
            }
            update_option( 'arthur_ai_frontend_responsive_css_post_' . $post_id, $css );
        } else {
            // Append to global
            $existing = get_option( 'arthur_ai_frontend_responsive_css', '' );
            $existing .= '\n' . $css;
            update_option( 'arthur_ai_frontend_responsive_css', $existing );
        }
        return array( 'success' => true );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Edit the header layout for block themes by updating the corresponding template part.
 */
class Arthur_AI_Action_Edit_Header_Layout implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'edit_header_layout';
    }

    public function get_label() {
        return __( 'Edit Header Layout', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $slug         = isset( $payload['template_slug'] ) ? sanitize_key( $payload['template_slug'] ) : '';
        $post_content = isset( $payload['post_content'] ) ? (string) $payload['post_content'] : '';
        if ( '' === $slug || '' === $post_content ) {
            return array( 'success' => false, 'message' => __( 'template_slug and post_content are required.', 'arthur-ai' ) );
        }
        $post_content = wp_kses_post( $post_content );
        $updated      = false;
        // Search for header template parts with this slug
        $args = array(
            'post_type'      => array( 'wp_template', 'wp_template_part' ),
            'name'           => $slug,
            'posts_per_page' => -1,
        );
        $templates = get_posts( $args );
        foreach ( $templates as $t ) {
            wp_update_post( array( 'ID' => $t->ID, 'post_content' => $post_content ) );
            $updated = true;
        }
        return $updated ? array( 'success' => true ) : array( 'success' => false, 'message' => __( 'No matching header template found.', 'arthur-ai' ) );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Edit the footer layout for block themes.
 */
class Arthur_AI_Action_Edit_Footer_Layout implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'edit_footer_layout';
    }

    public function get_label() {
        return __( 'Edit Footer Layout', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $slug         = isset( $payload['template_slug'] ) ? sanitize_key( $payload['template_slug'] ) : '';
        $post_content = isset( $payload['post_content'] ) ? (string) $payload['post_content'] : '';
        if ( '' === $slug || '' === $post_content ) {
            return array( 'success' => false, 'message' => __( 'template_slug and post_content are required.', 'arthur-ai' ) );
        }
        $post_content = wp_kses_post( $post_content );
        $updated      = false;
        $args = array(
            'post_type'      => array( 'wp_template', 'wp_template_part' ),
            'name'           => $slug,
            'posts_per_page' => -1,
        );
        $templates = get_posts( $args );
        foreach ( $templates as $t ) {
            wp_update_post( array( 'ID' => $t->ID, 'post_content' => $post_content ) );
            $updated = true;
        }
        return $updated ? array( 'success' => true ) : array( 'success' => false, 'message' => __( 'No matching footer template found.', 'arthur-ai' ) );
    }
}
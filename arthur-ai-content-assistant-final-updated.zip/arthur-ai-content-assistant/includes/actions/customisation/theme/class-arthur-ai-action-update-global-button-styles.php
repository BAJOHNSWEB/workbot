<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Update global button styles (border radius, padding etc.).
 */
class Arthur_AI_Action_Update_Global_Button_Styles implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'update_global_button_styles';
    }

    public function get_label() {
        return __( 'Update Global Button Styles', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $styles = array();
        foreach ( array( 'border-radius', 'padding', 'font-weight', 'background-color', 'color' ) as $prop ) {
            if ( isset( $payload[ $prop ] ) ) {
                $styles[ $prop ] = sanitize_text_field( $payload[ $prop ] );
            }
        }
        update_option( 'arthur_ai_button_styles', $styles );
        return array( 'success' => true );
    }
}
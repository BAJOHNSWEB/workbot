<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Apply a consistent layout grid system across the site.
 */
class Arthur_AI_Action_Apply_Layout_Grid implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'apply_layout_grid';
    }

    public function get_label() {
        return __( 'Apply Layout Grid', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $settings = isset( $payload['grid'] ) && is_array( $payload['grid'] ) ? $payload['grid'] : array();
        if ( empty( $settings ) ) {
            return array( 'success' => false, 'message' => __( 'grid settings are required.', 'arthur-ai' ) );
        }
        update_option( 'arthur_ai_layout_grid', $settings );
        return array( 'success' => true );
    }
}
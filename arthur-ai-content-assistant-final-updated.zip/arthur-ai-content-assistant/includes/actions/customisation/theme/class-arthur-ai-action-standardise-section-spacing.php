<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Standardise section spacing across the site by storing configuration.
 */
class Arthur_AI_Action_Standardise_Section_Spacing implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'standardise_section_spacing';
    }

    public function get_label() {
        return __( 'Standardise Section Spacing', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $spacing   = isset( $payload['spacing'] ) && is_array( $payload['spacing'] ) ? $payload['spacing'] : array();
        $selectors = isset( $payload['selectors'] ) && is_array( $payload['selectors'] ) ? $payload['selectors'] : array();
        if ( empty( $spacing ) || empty( $selectors ) ) {
            return array( 'success' => false, 'message' => __( 'spacing and selectors are required.', 'arthur-ai' ) );
        }
        update_option( 'arthur_ai_section_spacing', array( 'spacing' => $spacing, 'selectors' => $selectors ) );
        return array( 'success' => true );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Define styling presets for forms.
 */
class Arthur_AI_Action_Set_Form_Style_Preset implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'set_form_style_preset';
    }

    public function get_label() {
        return __( 'Set Form Style Preset', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? strtolower( trim( $payload['provider'] ) ) : '';
        $target   = isset( $payload['target'] ) ? $payload['target'] : 'global';
        $styles   = isset( $payload['styles'] ) && is_array( $payload['styles'] ) ? $payload['styles'] : array();
        if ( ! $provider || empty( $styles ) ) {
            return array( 'error' => 'Provider and styles are required.' );
        }
        $presets = get_option( 'arthur_ai_form_styles', array() );
        if ( ! is_array( $presets ) ) {
            $presets = array();
        }
        // Append new preset
        $presets[] = array_merge( array(
            'provider' => $provider,
            'target'   => $target,
        ), $styles );
        update_option( 'arthur_ai_form_styles', $presets, false );
        return array( 'success' => true );
    }
}
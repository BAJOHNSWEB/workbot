<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Embed a form shortcode on specific pages or sections.
 */
class Arthur_AI_Action_Embed_Form_On_Pages implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'embed_form_on_pages';
    }

    public function get_label() {
        return __( 'Embed Form on Pages', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $provider  = isset( $payload['provider'] ) ? strtolower( trim( $payload['provider'] ) ) : '';
        $form_id   = isset( $payload['form_id'] ) ? intval( $payload['form_id'] ) : 0;
        $shortcode = isset( $payload['shortcode'] ) ? $payload['shortcode'] : '';
        $placements = isset( $payload['placements'] ) && is_array( $payload['placements'] ) ? $payload['placements'] : array();
        if ( ! $provider || ! $form_id || empty( $placements ) ) {
            return array( 'error' => 'Provider, form_id and placements are required.' );
        }

        // Derive default shortcode
        if ( ! $shortcode ) {
            switch ( $provider ) {
                case 'cf7':
                case 'contactform7':
                case 'contact-form-7':
                    $shortcode = sprintf( '[contact-form-7 id="%d"]', $form_id );
                    break;
                case 'gravityforms':
                case 'gf':
                case 'gravity':
                    $shortcode = sprintf( '[gravityform id="%d" title="false" description="false"]', $form_id );
                    break;
                case 'wpforms':
                    $shortcode = sprintf( '[wpforms id="%d"]', $form_id );
                    break;
                default:
                    return array( 'error' => 'Unsupported provider.' );
            }
        }
        $updated_posts = array();
        foreach ( $placements as $placement ) {
            if ( ! is_array( $placement ) ) {
                continue;
            }
            $post_id = isset( $placement['post_id'] ) ? intval( $placement['post_id'] ) : 0;
            $location = isset( $placement['location'] ) ? $placement['location'] : 'append';
            if ( ! $post_id ) {
                continue;
            }
            $post = get_post( $post_id );
            if ( ! $post ) {
                continue;
            }
            $content = $post->post_content;
            $new_content = '';
            switch ( $location ) {
                case 'replace_content':
                    $new_content = $shortcode;
                    break;
                case 'prepend':
                    $new_content = $shortcode . "\n\n" . $content;
                    break;
                case 'append':
                    $new_content = $content . "\n\n" . $shortcode;
                    break;
                case 'after_heading':
                    // Insert after first H1/H2 tag
                    $pattern = '/(<h[12][^>]*>.*?<\/h[12]>)/i';
                    if ( preg_match( $pattern, $content, $matches ) ) {
                        $pos = strpos( $content, $matches[0] ) + strlen( $matches[0] );
                        $new_content = substr_replace( $content, "\n\n" . $shortcode . "\n\n", $pos, 0 );
                    } else {
                        $new_content = $content . "\n\n" . $shortcode;
                    }
                    break;
                default:
                    $new_content = $content . "\n\n" . $shortcode;
                    break;
            }
            // Update the post if content changed
            if ( $new_content !== $content ) {
                wp_update_post( array( 'ID' => $post_id, 'post_content' => $new_content ) );
                $updated_posts[] = $post_id;
            }
        }
        return array( 'updated_posts' => $updated_posts );
    }
}
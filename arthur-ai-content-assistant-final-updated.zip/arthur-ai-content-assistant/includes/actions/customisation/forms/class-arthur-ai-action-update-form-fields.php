<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Add, update or remove fields and validation rules on an existing form.
 */
class Arthur_AI_Action_Update_Form_Fields implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'update_form_fields';
    }

    public function get_label() {
        return __( 'Update Form Fields', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? strtolower( trim( $payload['provider'] ) ) : '';
        $form_id  = isset( $payload['form_id'] ) ? intval( $payload['form_id'] ) : 0;
        $changes  = isset( $payload['changes'] ) && is_array( $payload['changes'] ) ? $payload['changes'] : array();
        if ( ! $provider || ! $form_id ) {
            return array( 'error' => 'Provider and form_id are required.' );
        }

        // CF7 updates are not supported via API in this implementation
        if ( in_array( $provider, array( 'cf7', 'contactform7', 'contact-form-7' ), true ) ) {
            return array( 'error' => 'Updating Contact Form 7 fields programmatically is not supported.' );
        }

        // Gravity Forms
        if ( in_array( $provider, array( 'gravityforms', 'gf', 'gravity' ), true ) ) {
            if ( ! class_exists( 'GFAPI' ) ) {
                return array( 'error' => 'Gravity Forms plugin is not active.' );
            }
            $form = GFAPI::get_form( $form_id );
            if ( is_wp_error( $form ) || empty( $form ) ) {
                return array( 'error' => 'Form not found.' );
            }
            // Create a map of fields by id for easier access
            $fields_by_id = array();
            foreach ( $form['fields'] as $index => $field ) {
                $fields_by_id[ intval( $field->id ) ] = array( 'index' => $index, 'field' => $field );
            }
            $summary = array( 'added' => array(), 'updated' => array(), 'removed' => array() );
            foreach ( $changes as $change ) {
                if ( ! is_array( $change ) || empty( $change['action'] ) ) {
                    continue;
                }
                $action   = $change['action'];
                $field_id = isset( $change['field_id'] ) ? intval( $change['field_id'] ) : 0;
                if ( 'add' === $action ) {
                    $def = isset( $change['field'] ) && is_array( $change['field'] ) ? $change['field'] : array();
                    $type  = isset( $def['type'] ) ? strtolower( $def['type'] ) : 'text';
                    $label = isset( $def['label'] ) ? $def['label'] : 'New field';
                    $required = isset( $def['required'] ) && $def['required'];
                    $choices  = isset( $def['choices'] ) && is_array( $def['choices'] ) ? $def['choices'] : array();
                    // Determine next id: max existing id + 1
                    $new_id = 1;
                    foreach ( $form['fields'] as $existing ) {
                        if ( intval( $existing->id ) >= $new_id ) {
                            $new_id = intval( $existing->id ) + 1;
                        }
                    }
                    $props = array(
                        'id'         => $new_id,
                        'type'       => $type,
                        'label'      => $label,
                        'isRequired' => $required,
                    );
                    if ( in_array( $type, array( 'select', 'radio', 'checkbox' ), true ) ) {
                        $choices_array = array();
                        foreach ( $choices as $choice ) {
                            $choices_array[] = array( 'text' => $choice, 'value' => $choice, 'isSelected' => false );
                        }
                        $props['choices'] = $choices_array;
                        if ( 'checkbox' === $type ) {
                            $props['type'] = 'checkbox';
                            $props['inputs'] = array();
                            $sub_id = 1;
                            foreach ( $choices_array as $choice ) {
                                $props['inputs'][] = array( 'id' => $new_id . '.' . $sub_id, 'label' => $choice['text'] );
                                $sub_id++;
                            }
                        }
                    }
                    $new_field = GF_Fields::create( $props );
                    $form['fields'][] = $new_field;
                    $summary['added'][] = $new_id;
                } elseif ( 'update' === $action && $field_id && isset( $fields_by_id[ $field_id ] ) ) {
                    $def = isset( $change['field'] ) && is_array( $change['field'] ) ? $change['field'] : array();
                    $field_index = $fields_by_id[ $field_id ]['index'];
                    $field_obj   = $fields_by_id[ $field_id ]['field'];
                    if ( isset( $def['label'] ) ) {
                        $field_obj->label = $def['label'];
                    }
                    if ( isset( $def['required'] ) ) {
                        $field_obj->isRequired = (bool) $def['required'];
                    }
                    if ( isset( $def['choices'] ) && is_array( $def['choices'] ) ) {
                        $choices_array = array();
                        foreach ( $def['choices'] as $choice ) {
                            $choices_array[] = array( 'text' => $choice, 'value' => $choice, 'isSelected' => false );
                        }
                        $field_obj->choices = $choices_array;
                    }
                    // Update the field object back into form fields
                    $form['fields'][ $field_index ] = $field_obj;
                    $summary['updated'][] = $field_id;
                } elseif ( 'remove' === $action && $field_id && isset( $fields_by_id[ $field_id ] ) ) {
                    $field_index = $fields_by_id[ $field_id ]['index'];
                    array_splice( $form['fields'], $field_index, 1 );
                    $summary['removed'][] = $field_id;
                }
            }
            $result = GFAPI::update_form( $form );
            if ( is_wp_error( $result ) ) {
                return array( 'error' => 'Failed to update form.' );
            }
            return $summary;
        }

        // WPForms provider
        if ( 'wpforms' === $provider ) {
            if ( ! function_exists( 'wpforms' ) || ! is_object( wpforms() ) ) {
                return array( 'error' => 'WPForms plugin is not active.' );
            }
            $form = wpforms()->form->get( $form_id );
            if ( empty( $form ) || ! is_array( $form ) ) {
                return array( 'error' => 'Form not found.' );
            }
            if ( ! isset( $form['fields'] ) || ! is_array( $form['fields'] ) ) {
                $form['fields'] = array();
            }
            // Map fields by id for convenience
            $fields_by_id = array();
            foreach ( $form['fields'] as $index => $field ) {
                if ( isset( $field['id'] ) ) {
                    $fields_by_id[ $field['id'] ] = $index;
                }
            }
            $summary = array( 'added' => array(), 'updated' => array(), 'removed' => array() );
            foreach ( $changes as $change ) {
                if ( ! is_array( $change ) || empty( $change['action'] ) ) {
                    continue;
                }
                $action   = $change['action'];
                $field_id = isset( $change['field_id'] ) ? (string) $change['field_id'] : '';
                if ( 'add' === $action ) {
                    $def = isset( $change['field'] ) && is_array( $change['field'] ) ? $change['field'] : array();
                    $type     = isset( $def['type'] ) ? strtolower( $def['type'] ) : 'text';
                    $label    = isset( $def['label'] ) ? $def['label'] : 'New field';
                    $required = isset( $def['required'] ) && $def['required'];
                    $choices  = isset( $def['choices'] ) && is_array( $def['choices'] ) ? $def['choices'] : array();
                    // Determine next id as string highest +1
                    $max_id = 0;
                    foreach ( $form['fields'] as $field ) {
                        $fid = isset( $field['id'] ) ? intval( $field['id'] ) : 0;
                        if ( $fid > $max_id ) {
                            $max_id = $fid;
                        }
                    }
                    $new_id = (string) ( $max_id + 1 );
                    $wpfield = array(
                        'id'       => $new_id,
                        'type'     => $type,
                        'label'    => $label,
                        'required' => $required,
                    );
                    if ( in_array( $type, array( 'select', 'radio', 'checkbox' ), true ) ) {
                        $options = array();
                        $sub_id  = 1;
                        foreach ( $choices as $choice ) {
                            $options[] = array(
                                'choice' => $choice,
                                'value'  => $choice,
                                'label'  => $choice,
                                'id'     => (string) $sub_id,
                            );
                            $sub_id++;
                        }
                        $wpfield['choices'] = $options;
                    }
                    $form['fields'][] = $wpfield;
                    $summary['added'][] = $new_id;
                } elseif ( 'update' === $action && $field_id && isset( $fields_by_id[ $field_id ] ) ) {
                    $def = isset( $change['field'] ) && is_array( $change['field'] ) ? $change['field'] : array();
                    $index = $fields_by_id[ $field_id ];
                    $field = $form['fields'][ $index ];
                    if ( isset( $def['label'] ) ) {
                        $field['label'] = $def['label'];
                    }
                    if ( isset( $def['required'] ) ) {
                        $field['required'] = (bool) $def['required'];
                    }
                    if ( isset( $def['choices'] ) && is_array( $def['choices'] ) ) {
                        $options = array();
                        $sub_id  = 1;
                        foreach ( $def['choices'] as $choice ) {
                            $options[] = array(
                                'choice' => $choice,
                                'value'  => $choice,
                                'label'  => $choice,
                                'id'     => (string) $sub_id,
                            );
                            $sub_id++;
                        }
                        $field['choices'] = $options;
                    }
                    $form['fields'][ $index ] = $field;
                    $summary['updated'][] = $field_id;
                } elseif ( 'remove' === $action && $field_id && isset( $fields_by_id[ $field_id ] ) ) {
                    $index = $fields_by_id[ $field_id ];
                    array_splice( $form['fields'], $index, 1 );
                    $summary['removed'][] = $field_id;
                }
            }
            // Save the form
            wpforms()->form->update( $form_id, $form );
            return $summary;
        }

        return array( 'error' => 'Unsupported provider.' );
    }
}
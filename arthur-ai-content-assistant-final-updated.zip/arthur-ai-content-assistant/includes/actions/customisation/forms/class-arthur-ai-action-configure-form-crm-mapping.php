<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure CRM mapping for form submissions.
 */
class Arthur_AI_Action_Configure_Form_Crm_Mapping implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_form_crm_mapping';
    }

    public function get_label() {
        return __( 'Configure Form CRM Mapping', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? strtolower( trim( $payload['provider'] ) ) : '';
        $form_id  = isset( $payload['form_id'] ) ? intval( $payload['form_id'] ) : 0;
        $service  = isset( $payload['service'] ) ? strtolower( trim( $payload['service'] ) ) : 'generic_webhook';
        $field_mapping = isset( $payload['field_mapping'] ) && is_array( $payload['field_mapping'] ) ? $payload['field_mapping'] : array();
        $endpoint = isset( $payload['endpoint'] ) ? $payload['endpoint'] : '';
        if ( ! $provider || ! $form_id || empty( $field_mapping ) ) {
            return array( 'error' => 'Provider, form_id and field_mapping are required.' );
        }
        $mappings = get_option( 'arthur_ai_form_crm_mappings', array() );
        if ( ! is_array( $mappings ) ) {
            $mappings = array();
        }
        $mappings[] = array(
            'provider' => $provider,
            'form_id'  => $form_id,
            'service'  => $service,
            'field_mapping' => $field_mapping,
            'endpoint' => $endpoint,
        );
        update_option( 'arthur_ai_form_crm_mappings', $mappings, false );
        return array( 'success' => true );
    }
}
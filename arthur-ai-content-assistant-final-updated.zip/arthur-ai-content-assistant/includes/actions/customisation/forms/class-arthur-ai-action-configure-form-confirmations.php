<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure form confirmations (messages or redirects).
 */
class Arthur_AI_Action_Configure_Form_Confirmations implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_form_confirmations';
    }

    public function get_label() {
        return __( 'Configure Form Confirmations', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $provider      = isset( $payload['provider'] ) ? strtolower( trim( $payload['provider'] ) ) : '';
        $form_id       = isset( $payload['form_id'] ) ? intval( $payload['form_id'] ) : 0;
        $confirmations = isset( $payload['confirmations'] ) && is_array( $payload['confirmations'] ) ? $payload['confirmations'] : array();
        if ( ! $provider || ! $form_id || empty( $confirmations ) ) {
            return array( 'error' => 'Provider, form_id and confirmations are required.' );
        }
        // CF7
        if ( in_array( $provider, array( 'cf7', 'contactform7', 'contact-form-7' ), true ) ) {
            if ( ! class_exists( 'WPCF7_ContactForm' ) ) {
                return array( 'error' => 'Contact Form 7 plugin is not active.' );
            }
            $post = get_post( $form_id );
            if ( ! $post || 'wpcf7_contact_form' !== $post->post_type ) {
                return array( 'error' => 'Contact form not found.' );
            }
            // CF7 stores messages in _messages meta
            $messages = get_post_meta( $form_id, '_messages', true );
            if ( ! is_array( $messages ) ) {
                $messages = array();
            }
            $additional_settings = get_post_meta( $form_id, '_additional_settings', true );
            foreach ( $confirmations as $conf ) {
                if ( ! is_array( $conf ) ) {
                    continue;
                }
                $type = isset( $conf['type'] ) ? strtolower( $conf['type'] ) : 'message';
                if ( 'message' === $type ) {
                    $msg = isset( $conf['message_html'] ) ? $conf['message_html'] : '';
                    $messages['mail_sent_ok'] = $msg;
                } elseif ( 'redirect' === $type ) {
                    $url = isset( $conf['redirect_url'] ) ? $conf['redirect_url'] : '';
                    if ( $url ) {
                        $additional_settings = "on_sent_ok: \"location = '" . esc_url_raw( $url ) . "' ;\"";
                    }
                }
            }
            update_post_meta( $form_id, '_messages', $messages );
            if ( $additional_settings ) {
                update_post_meta( $form_id, '_additional_settings', $additional_settings );
            }
            return array( 'success' => true );
        }
        // Gravity Forms
        if ( in_array( $provider, array( 'gravityforms', 'gf', 'gravity' ), true ) ) {
            if ( ! class_exists( 'GFAPI' ) ) {
                return array( 'error' => 'Gravity Forms plugin is not active.' );
            }
            $form = GFAPI::get_form( $form_id );
            if ( is_wp_error( $form ) || empty( $form ) ) {
                return array( 'error' => 'Form not found.' );
            }
            if ( ! isset( $form['confirmations'] ) || ! is_array( $form['confirmations'] ) ) {
                $form['confirmations'] = array();
            }
            foreach ( $confirmations as $conf ) {
                if ( ! is_array( $conf ) ) {
                    continue;
                }
                $type = isset( $conf['type'] ) ? strtolower( $conf['type'] ) : 'message';
                $confirmation_id = uniqid( 'conf_' );
                $confirmation = array(
                    'id'      => $confirmation_id,
                    'name'    => $confirmation_id,
                    'isDefault' => empty( $form['confirmations'] ),
                    'type'    => $type,
                    'message' => '',
                    'url'     => '',
                    'pageId'  => '',
                    'queryString' => '',
                    'conditionalLogic' => '',
                    'isActive' => true,
                );
                if ( 'message' === $type ) {
                    $confirmation['message'] = isset( $conf['message_html'] ) ? $conf['message_html'] : 'Thank you.';
                } elseif ( 'redirect' === $type ) {
                    $confirmation['url'] = isset( $conf['redirect_url'] ) ? $conf['redirect_url'] : site_url();
                }
                $form['confirmations'][ $confirmation_id ] = $confirmation;
            }
            $result = GFAPI::update_form( $form );
            if ( is_wp_error( $result ) ) {
                return array( 'error' => 'Failed to update Gravity Form confirmations.' );
            }
            return array( 'success' => true );
        }
        // WPForms
        if ( 'wpforms' === $provider ) {
            if ( ! function_exists( 'wpforms' ) || ! is_object( wpforms() ) ) {
                return array( 'error' => 'WPForms plugin is not active.' );
            }
            $form = wpforms()->form->get( $form_id );
            if ( empty( $form ) || ! is_array( $form ) ) {
                return array( 'error' => 'Form not found.' );
            }
            foreach ( $confirmations as $conf ) {
                if ( ! is_array( $conf ) ) {
                    continue;
                }
                $type = isset( $conf['type'] ) ? strtolower( $conf['type'] ) : 'message';
                if ( 'message' === $type ) {
                    $form['settings']['confirmation_type'] = 'message';
                    $form['settings']['confirmation_message'] = isset( $conf['message_html'] ) ? $conf['message_html'] : 'Thank you.';
                    $form['settings']['confirmation_redirect'] = '';
                } elseif ( 'redirect' === $type ) {
                    $form['settings']['confirmation_type'] = 'url';
                    $form['settings']['confirmation_redirect'] = isset( $conf['redirect_url'] ) ? $conf['redirect_url'] : site_url();
                    $form['settings']['confirmation_message'] = '';
                }
                // Only one confirmation supported in WPForms; break after first
                break;
            }
            wpforms()->form->update( $form_id, $form );
            return array( 'success' => true );
        }
        return array( 'error' => 'Unsupported provider.' );
    }
}
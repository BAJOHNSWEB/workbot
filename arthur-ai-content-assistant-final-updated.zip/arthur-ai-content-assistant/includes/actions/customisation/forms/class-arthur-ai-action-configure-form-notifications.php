<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure form notifications for admin, user or additional recipients.
 */
class Arthur_AI_Action_Configure_Form_Notifications implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_form_notifications';
    }

    public function get_label() {
        return __( 'Configure Form Notifications', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $provider     = isset( $payload['provider'] ) ? strtolower( trim( $payload['provider'] ) ) : '';
        $form_id      = isset( $payload['form_id'] ) ? intval( $payload['form_id'] ) : 0;
        $notifications = isset( $payload['notifications'] ) && is_array( $payload['notifications'] ) ? $payload['notifications'] : array();
        if ( ! $provider || ! $form_id || empty( $notifications ) ) {
            return array( 'error' => 'Provider, form_id and notifications are required.' );
        }
        $configured_ids = array();
        // CF7
        if ( in_array( $provider, array( 'cf7', 'contactform7', 'contact-form-7' ), true ) ) {
            if ( ! class_exists( 'WPCF7_ContactForm' ) ) {
                return array( 'error' => 'Contact Form 7 plugin is not active.' );
            }
            $post = get_post( $form_id );
            if ( ! $post || 'wpcf7_contact_form' !== $post->post_type ) {
                return array( 'error' => 'Contact form not found.' );
            }
            // Retrieve existing mail settings
            $mail    = get_post_meta( $form_id, '_mail', true );
            $mail_2  = get_post_meta( $form_id, '_mail_2', true );
            if ( ! is_array( $mail ) ) {
                $mail = array();
            }
            if ( ! is_array( $mail_2 ) ) {
                $mail_2 = array();
            }
            foreach ( $notifications as $note ) {
                if ( ! is_array( $note ) ) {
                    continue;
                }
                $type    = isset( $note['type'] ) ? strtolower( $note['type'] ) : 'admin';
                $to      = isset( $note['to'] ) ? $note['to'] : ''; // string
                $subject = isset( $note['subject'] ) ? $note['subject'] : ''; // string
                $message = isset( $note['message_html'] ) ? $note['message_html'] : ''; // string
                $from_name  = isset( $note['from_name'] ) ? $note['from_name'] : '';
                $from_email = isset( $note['from_email'] ) ? $note['from_email'] : '';
                $reply_to   = isset( $note['reply_to'] ) ? $note['reply_to'] : '';
                $enabled    = isset( $note['enabled'] ) ? (bool) $note['enabled'] : true;
                // Build sender string
                $sender = '';
                if ( $from_name || $from_email ) {
                    $sender = trim( $from_name . ' <' . $from_email . '>' );
                }
                $mail_entry = array(
                    'recipient' => $to ? $to : get_option( 'admin_email' ),
                    'subject'   => $subject ?: $post->post_title,
                    'sender'    => $sender ?: get_option( 'admin_email' ),
                    'body'      => $message ?: 'New form submission',
                    'additional_headers' => $reply_to ? 'Reply-To: ' . $reply_to : '',
                    'use_html'  => true,
                    'active'    => $enabled,
                );
                if ( 'user' === $type ) {
                    $mail_2 = $mail_entry;
                    $configured_ids[] = 'user';
                } else {
                    // admin or additional all map to mail
                    $mail = $mail_entry;
                    $configured_ids[] = 'admin';
                }
            }
            update_post_meta( $form_id, '_mail', $mail );
            update_post_meta( $form_id, '_mail_2', $mail_2 );
            return array( 'configured' => $configured_ids );
        }

        // Gravity Forms
        if ( in_array( $provider, array( 'gravityforms', 'gf', 'gravity' ), true ) ) {
            if ( ! class_exists( 'GFAPI' ) ) {
                return array( 'error' => 'Gravity Forms plugin is not active.' );
            }
            $form = GFAPI::get_form( $form_id );
            if ( is_wp_error( $form ) || empty( $form ) ) {
                return array( 'error' => 'Form not found.' );
            }
            if ( ! isset( $form['notifications'] ) || ! is_array( $form['notifications'] ) ) {
                $form['notifications'] = array();
            }
            foreach ( $notifications as $note ) {
                if ( ! is_array( $note ) ) {
                    continue;
                }
                $id  = isset( $note['id'] ) ? $note['id'] : '';
                $type = isset( $note['type'] ) ? strtolower( $note['type'] ) : 'admin';
                $to   = isset( $note['to'] ) ? $note['to'] : get_option( 'admin_email' );
                $subject = isset( $note['subject'] ) ? $note['subject'] : $form['title'];
                $message = isset( $note['message_html'] ) ? $note['message_html'] : 'New form submission';
                $from_name  = isset( $note['from_name'] ) ? $note['from_name'] : '';
                $from_email = isset( $note['from_email'] ) ? $note['from_email'] : '';
                $reply_to   = isset( $note['reply_to'] ) ? $note['reply_to'] : '';
                $enabled    = isset( $note['enabled'] ) ? (bool) $note['enabled'] : true;
                // Determine toType for Gravity Forms: if to contains merge tag, set type=field
                $to_type = strpos( $to, '{' ) !== false ? 'field' : 'email';
                $notification = array(
                    'id'          => $id ? $id : uniqid( 'notif_' ),
                    'event'       => 'form_submission',
                    'toType'      => $to_type,
                    'to'          => $to,
                    'subject'     => $subject,
                    'message'     => $message,
                    'from'        => $from_email ?: get_option( 'admin_email' ),
                    'fromName'    => $from_name ?: get_option( 'blogname' ),
                    'replyTo'     => $reply_to ?: get_option( 'admin_email' ),
                    'isActive'    => $enabled,
                );
                $form['notifications'][ $notification['id'] ] = $notification;
                $configured_ids[] = $notification['id'];
            }
            $result = GFAPI::update_form( $form );
            if ( is_wp_error( $result ) ) {
                return array( 'error' => 'Failed to update Gravity Form notifications.' );
            }
            return array( 'configured' => $configured_ids );
        }

        // WPForms
        if ( 'wpforms' === $provider ) {
            if ( ! function_exists( 'wpforms' ) || ! is_object( wpforms() ) ) {
                return array( 'error' => 'WPForms plugin is not active.' );
            }
            $form = wpforms()->form->get( $form_id );
            if ( empty( $form ) || ! is_array( $form ) ) {
                return array( 'error' => 'Form not found.' );
            }
            if ( ! isset( $form['settings'] ) || ! is_array( $form['settings'] ) ) {
                $form['settings'] = array();
            }
            if ( ! isset( $form['settings']['notifications'] ) || ! is_array( $form['settings']['notifications'] ) ) {
                $form['settings']['notifications'] = array();
            }
            $notif_index = 1;
            foreach ( $notifications as $note ) {
                if ( ! is_array( $note ) ) {
                    continue;
                }
                $to      = isset( $note['to'] ) ? $note['to'] : get_option( 'admin_email' );
                $subject = isset( $note['subject'] ) ? $note['subject'] : $form['meta']['form_title'];
                $message = isset( $note['message_html'] ) ? $note['message_html'] : 'New form submission';
                $from_name  = isset( $note['from_name'] ) ? $note['from_name'] : '';
                $from_email = isset( $note['from_email'] ) ? $note['from_email'] : '';
                $reply_to   = isset( $note['reply_to'] ) ? $note['reply_to'] : '';
                $enabled    = isset( $note['enabled'] ) ? (bool) $note['enabled'] : true;
                $slug = 'email_' . $notif_index;
                $form['settings']['notifications'][ $slug ] = array(
                    'email'   => $to,
                    'subject' => $subject,
                    'sender_name'  => $from_name,
                    'sender_address' => $from_email ?: get_option( 'admin_email' ),
                    'reply_to' => $reply_to ?: '',
                    'message' => $message,
                    'active'  => $enabled,
                );
                $configured_ids[] = $slug;
                $notif_index++;
            }
            wpforms()->form->update( $form_id, $form );
            return array( 'configured' => $configured_ids );
        }
        return array( 'error' => 'Unsupported provider.' );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure webhook endpoints for form submissions.
 */
class Arthur_AI_Action_Configure_Form_Webhooks implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_form_webhooks';
    }

    public function get_label() {
        return __( 'Configure Form Webhooks', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $provider  = isset( $payload['provider'] ) ? strtolower( trim( $payload['provider'] ) ) : '';
        $form_id   = isset( $payload['form_id'] ) ? intval( $payload['form_id'] ) : 0;
        $endpoints = isset( $payload['endpoints'] ) && is_array( $payload['endpoints'] ) ? $payload['endpoints'] : array();
        if ( ! $provider || ! $form_id || empty( $endpoints ) ) {
            return array( 'error' => 'Provider, form_id and endpoints are required.' );
        }
        $existing = get_option( 'arthur_ai_form_webhooks', array() );
        if ( ! is_array( $existing ) ) {
            $existing = array();
        }
        foreach ( $endpoints as $endpoint ) {
            if ( ! is_array( $endpoint ) || empty( $endpoint['url'] ) ) {
                continue;
            }
            $config = array(
                'provider' => $provider,
                'form_id'  => $form_id,
                'url'      => $endpoint['url'],
                'method'   => isset( $endpoint['method'] ) ? strtoupper( $endpoint['method'] ) : 'POST',
                'headers'  => isset( $endpoint['headers'] ) && is_array( $endpoint['headers'] ) ? $endpoint['headers'] : array(),
                'body_template' => isset( $endpoint['body_template'] ) && is_array( $endpoint['body_template'] ) ? $endpoint['body_template'] : array(),
                'enabled'  => isset( $endpoint['enabled'] ) ? (bool) $endpoint['enabled'] : true,
            );
            $existing[] = $config;
        }
        update_option( 'arthur_ai_form_webhooks', $existing, false );
        return array( 'success' => true );
    }
}
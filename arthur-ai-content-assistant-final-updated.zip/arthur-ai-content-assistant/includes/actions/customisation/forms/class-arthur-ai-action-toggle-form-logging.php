<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Enable or disable logging of form submissions and webhooks.
 */
class Arthur_AI_Action_Toggle_Form_Logging implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'toggle_form_logging';
    }

    public function get_label() {
        return __( 'Toggle Form Logging', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $enabled = isset( $payload['enabled'] ) ? (bool) $payload['enabled'] : false;
        update_option( 'arthur_ai_form_logging_enabled', $enabled, false );
        return array( 'enabled' => $enabled );
    }
}
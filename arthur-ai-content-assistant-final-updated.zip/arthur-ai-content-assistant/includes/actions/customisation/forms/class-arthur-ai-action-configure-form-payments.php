<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure payment integration on a form.
 */
class Arthur_AI_Action_Configure_Form_Payments implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_form_payments';
    }

    public function get_label() {
        return __( 'Configure Form Payments', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? strtolower( trim( $payload['provider'] ) ) : '';
        $form_id  = isset( $payload['form_id'] ) ? intval( $payload['form_id'] ) : 0;
        $mode     = isset( $payload['mode'] ) ? strtolower( $payload['mode'] ) : 'disabled';
        $gateway  = isset( $payload['gateway'] ) ? strtolower( $payload['gateway'] ) : '';
        $amount_type = isset( $payload['amount_type'] ) ? strtolower( $payload['amount_type'] ) : 'fixed';
        $amount   = isset( $payload['amount'] ) ? $payload['amount'] : '';
        $amount_field = isset( $payload['amount_field'] ) ? $payload['amount_field'] : '';
        $currency = isset( $payload['currency'] ) ? strtoupper( $payload['currency'] ) : '';
        if ( ! $provider || ! $form_id ) {
            return array( 'error' => 'Provider and form_id are required.' );
        }
        // Check plugin is active where payments can be configured; fallback to storing config
        $config_store = get_option( 'arthur_ai_form_payments', array() );
        if ( ! is_array( $config_store ) ) {
            $config_store = array();
        }
        $config_store[] = array(
            'provider'    => $provider,
            'form_id'     => $form_id,
            'mode'        => $mode,
            'gateway'     => $gateway,
            'amount_type' => $amount_type,
            'amount'      => $amount,
            'amount_field'=> $amount_field,
            'currency'    => $currency,
        );
        update_option( 'arthur_ai_form_payments', $config_store, false );
        return array( 'success' => true );
    }
}
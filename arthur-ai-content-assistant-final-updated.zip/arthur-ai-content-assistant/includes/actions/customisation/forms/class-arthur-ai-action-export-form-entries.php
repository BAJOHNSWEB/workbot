<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Export form entries in CSV or JSON format.
 */
class Arthur_AI_Action_Export_Form_Entries implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'export_form_entries';
    }

    public function get_label() {
        return __( 'Export Form Entries', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? strtolower( trim( $payload['provider'] ) ) : '';
        $form_id  = isset( $payload['form_id'] ) ? intval( $payload['form_id'] ) : 0;
        $format   = isset( $payload['format'] ) ? strtolower( $payload['format'] ) : 'json';
        $filters  = isset( $payload['filters'] ) && is_array( $payload['filters'] ) ? $payload['filters'] : array();
        if ( ! $provider || ! $form_id ) {
            return array( 'error' => 'Provider and form_id are required.' );
        }
        // Collect entries
        $entries = array();
        // CF7 does not store entries natively
        if ( in_array( $provider, array( 'cf7', 'contactform7', 'contact-form-7' ), true ) ) {
            return array( 'error' => 'Contact Form 7 does not support exporting entries unless a compatible storage plugin is used.' );
        }
        // Gravity Forms
        if ( in_array( $provider, array( 'gravityforms', 'gf', 'gravity' ), true ) ) {
            if ( ! class_exists( 'GFAPI' ) ) {
                return array( 'error' => 'Gravity Forms plugin is not active.' );
            }
            $search_criteria = array();
            if ( isset( $filters['start_date'] ) ) {
                $search_criteria['start_date'] = $filters['start_date'];
            }
            if ( isset( $filters['end_date'] ) ) {
                $search_criteria['end_date'] = $filters['end_date'];
            }
            $paging = array( 'offset' => 0, 'page_size' => 1000 );
            $entries = GFAPI::get_entries( $form_id, $search_criteria, null, $paging );
            if ( is_wp_error( $entries ) ) {
                return array( 'error' => 'Failed to fetch Gravity Forms entries.' );
            }
            // Convert GF entries to simple arrays keyed by field id
            $converted = array();
            foreach ( $entries as $entry ) {
                $row = array();
                foreach ( $entry as $key => $value ) {
                    if ( is_numeric( $key ) ) {
                        $row[ 'field_' . $key ] = $value;
                    }
                }
                $converted[] = $row;
            }
            $entries = $converted;
        }
        // WPForms
        if ( 'wpforms' === $provider ) {
            if ( ! function_exists( 'wpforms' ) || ! is_object( wpforms() ) ) {
                return array( 'error' => 'WPForms plugin is not active.' );
            }
            $args = array( 'form_id' => $form_id );
            // Note: WPForms API may not support filters; ignoring filters
            $raw_entries = wpforms()->entry->get_entries( $args );
            if ( is_wp_error( $raw_entries ) ) {
                return array( 'error' => 'Failed to fetch WPForms entries.' );
            }
            foreach ( $raw_entries as $entry ) {
                $row = array();
                if ( isset( $entry['fields'] ) && is_array( $entry['fields'] ) ) {
                    foreach ( $entry['fields'] as $field ) {
                        if ( isset( $field['name'] ) ) {
                            $row[ $field['name'] ] = isset( $field['value'] ) ? $field['value'] : '';
                        }
                    }
                }
                $entries[] = $row;
            }
        }
        if ( empty( $entries ) ) {
            return array( 'message' => 'No entries found.' );
        }
        // Export format
        if ( 'csv' === $format ) {
            $header = array();
            // Determine all columns
            foreach ( $entries as $row ) {
                foreach ( array_keys( $row ) as $col ) {
                    if ( ! in_array( $col, $header, true ) ) {
                        $header[] = $col;
                    }
                }
            }
            // Build CSV
            $csv_lines = array();
            $csv_lines[] = implode( ',', array_map( 'esc_html', $header ) );
            foreach ( $entries as $row ) {
                $line = array();
                foreach ( $header as $col ) {
                    $line[] = isset( $row[ $col ] ) ? str_replace( ',', ' ', $row[ $col ] ) : '';
                }
                $csv_lines[] = implode( ',', $line );
            }
            $csv_content = implode( "\n", $csv_lines );
            // Save file in uploads
            $upload_dir = wp_upload_dir();
            $filename   = 'form-' . $form_id . '-entries-' . time() . '.csv';
            $file_path  = trailingslashit( $upload_dir['path'] ) . $filename;
            file_put_contents( $file_path, $csv_content );
            $url = trailingslashit( $upload_dir['url'] ) . $filename;
            return array( 'format' => 'csv', 'url' => $url );
        }
        // Default to JSON
        return array( 'format' => 'json', 'data' => $entries );
    }
}
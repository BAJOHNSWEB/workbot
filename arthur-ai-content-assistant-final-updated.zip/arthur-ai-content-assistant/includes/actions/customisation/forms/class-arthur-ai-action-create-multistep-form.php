<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Create a multi-step form. Supported for Gravity Forms and WPForms.
 */
class Arthur_AI_Action_Create_Multistep_Form implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'create_multistep_form';
    }

    public function get_label() {
        return __( 'Create Multistep Form', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? strtolower( trim( $payload['provider'] ) ) : '';
        $form_name = isset( $payload['form_name'] ) ? sanitize_text_field( $payload['form_name'] ) : 'Multi-step Form';
        $steps     = isset( $payload['steps'] ) && is_array( $payload['steps'] ) ? $payload['steps'] : array();
        if ( ! $provider || empty( $steps ) ) {
            return array( 'error' => 'Provider and steps are required.' );
        }

        // CF7: multi-step forms not supported directly
        if ( in_array( $provider, array( 'cf7', 'contactform7', 'contact-form-7' ), true ) ) {
            return array( 'error' => 'Contact Form 7 does not support multi-step forms in this implementation.' );
        }

        // Gravity Forms multi-step
        if ( in_array( $provider, array( 'gravityforms', 'gf', 'gravity' ), true ) ) {
            if ( ! class_exists( 'GFAPI' ) ) {
                return array( 'error' => 'Gravity Forms plugin is not active.' );
            }
            $form = array(
                'title'         => $form_name,
                'description'   => '',
                'labelPlacement' => 'top_label',
                'fields'        => array(),
                'notifications' => array(),
                'confirmations' => array(),
                'is_active'     => true,
            );
            $field_id = 1;
            $step_count = count( $steps );
            $current_step = 1;
            foreach ( $steps as $step ) {
                // Add page break before all steps except the first
                if ( $current_step > 1 ) {
                    $page_field = GF_Fields::create( array(
                        'id'    => $field_id,
                        'type'  => 'page',
                        'title' => isset( $step['title'] ) ? $step['title'] : 'Step ' . $current_step,
                        'nextButton' => array( 'text' => __( 'Next', 'arthur-ai' ) ),
                        'previousButton' => array( 'text' => __( 'Previous', 'arthur-ai' ) ),
                    ) );
                    $form['fields'][] = $page_field;
                    $field_id++;
                }
                $fields = isset( $step['fields'] ) && is_array( $step['fields'] ) ? $step['fields'] : array();
                foreach ( $fields as $field ) {
                    if ( ! is_array( $field ) ) {
                        continue;
                    }
                    $type     = isset( $field['type'] ) ? strtolower( $field['type'] ) : 'text';
                    $label    = isset( $field['label'] ) ? $field['label'] : 'Field';
                    $required = isset( $field['required'] ) && $field['required'];
                    $choices  = isset( $field['choices'] ) && is_array( $field['choices'] ) ? $field['choices'] : array();
                    $props = array(
                        'id'         => $field_id,
                        'type'       => $type,
                        'label'      => $label,
                        'isRequired' => $required,
                    );
                    if ( in_array( $type, array( 'select', 'radio', 'checkbox' ), true ) ) {
                        $choices_array = array();
                        foreach ( $choices as $choice ) {
                            $choices_array[] = array( 'text' => $choice, 'value' => $choice, 'isSelected' => false );
                        }
                        $props['choices'] = $choices_array;
                        if ( 'checkbox' === $type ) {
                            $props['type'] = 'checkbox';
                            $props['inputs'] = array();
                            $sub_id = 1;
                            foreach ( $choices_array as $choice ) {
                                $props['inputs'][] = array( 'id' => $field_id . '.' . $sub_id, 'label' => $choice['text'] );
                                $sub_id++;
                            }
                        }
                    }
                    $gf_field = GF_Fields::create( $props );
                    $form['fields'][] = $gf_field;
                    $field_id++;
                }
                $current_step++;
            }
            $form_id = GFAPI::add_form( $form );
            if ( is_wp_error( $form_id ) ) {
                return array( 'error' => 'Failed to create multi-step Gravity Form.' );
            }
            return array( 'provider' => 'gravityforms', 'form_id' => $form_id );
        }

        // WPForms multi-step
        if ( 'wpforms' === $provider ) {
            if ( ! function_exists( 'wpforms' ) || ! is_object( wpforms() ) ) {
                return array( 'error' => 'WPForms plugin is not active.' );
            }
            $form_data = array(
                'meta'    => array(
                    'form_title' => $form_name,
                    'form_desc'  => '',
                ),
                'fields'  => array(),
                'settings' => array(
                    'notifications'       => array(),
                    'notification_enable' => true,
                    'confirmation_type'   => 'message',
                    'confirmation_message' => __( 'Thank you for submitting.', 'arthur-ai' ),
                    'confirmation_redirect' => '',
                ),
            );
            $field_id = 1;
            $step_count = count( $steps );
            $current_step = 1;
            foreach ( $steps as $step ) {
                if ( $current_step > 1 ) {
                    // Page break field
                    $form_data['fields'][] = array(
                        'id'   => (string) $field_id,
                        'type' => 'pagebreak',
                        'label' => isset( $step['title'] ) ? $step['title'] : 'Step ' . $current_step,
                    );
                    $field_id++;
                }
                $fields = isset( $step['fields'] ) && is_array( $step['fields'] ) ? $step['fields'] : array();
                foreach ( $fields as $field ) {
                    if ( ! is_array( $field ) ) {
                        continue;
                    }
                    $type     = isset( $field['type'] ) ? strtolower( $field['type'] ) : 'text';
                    $label    = isset( $field['label'] ) ? $field['label'] : 'Field';
                    $required = isset( $field['required'] ) && $field['required'];
                    $choices  = isset( $field['choices'] ) && is_array( $field['choices'] ) ? $field['choices'] : array();
                    $wpfield = array(
                        'id'       => (string) $field_id,
                        'type'     => $type,
                        'label'    => $label,
                        'required' => $required,
                    );
                    if ( in_array( $type, array( 'select', 'radio', 'checkbox' ), true ) ) {
                        $options = array();
                        $sub_id = 1;
                        foreach ( $choices as $choice ) {
                            $options[] = array(
                                'choice' => $choice,
                                'value'  => $choice,
                                'label'  => $choice,
                                'id'     => (string) $sub_id,
                            );
                            $sub_id++;
                        }
                        $wpfield['choices'] = $options;
                    }
                    $form_data['fields'][] = $wpfield;
                    $field_id++;
                }
                $current_step++;
            }
            $form_id = wpforms()->form->add( $form_data );
            if ( empty( $form_id ) ) {
                return array( 'error' => 'Failed to create multi-step WPForms form.' );
            }
            return array( 'provider' => 'wpforms', 'form_id' => $form_id );
        }
        return array( 'error' => 'Unsupported provider.' );
    }
}
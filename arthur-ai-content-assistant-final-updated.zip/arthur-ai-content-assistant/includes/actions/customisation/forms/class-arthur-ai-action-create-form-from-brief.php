<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Create a new form from a simple brief. Supports multiple form providers.
 */
class Arthur_AI_Action_Create_Form_From_Brief implements Arthur_AI_Action_Interface {

    /**
     * Get the action slug.
     *
     * @return string
     */
    public function get_type() {
        return 'create_form_from_brief';
    }

    /**
     * Get the human readable label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'Create Form from Brief', 'arthur-ai' );
    }

    /**
     * Execute the action: create a form using the specified provider.
     *
     * @param array $payload Request payload containing provider and form details.
     * @return array Result with form ID or error.
     */
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? strtolower( trim( $payload['provider'] ) ) : '';
        if ( ! $provider ) {
            return array( 'error' => 'Provider is required.' );
        }

        $form_name = isset( $payload['form_name'] ) ? sanitize_text_field( $payload['form_name'] ) : 'New Form';
        $form_type = isset( $payload['form_type'] ) ? sanitize_title( $payload['form_type'] ) : '';
        $fields    = isset( $payload['fields'] ) && is_array( $payload['fields'] ) ? $payload['fields'] : array();
        $payment   = isset( $payload['payment'] ) && is_array( $payload['payment'] ) ? $payload['payment'] : array();

        // Contact Form 7 provider
        if ( in_array( $provider, array( 'cf7', 'contactform7', 'contact-form-7' ), true ) ) {
            if ( ! class_exists( 'WPCF7_ContactForm' ) ) {
                return array( 'error' => 'Contact Form 7 plugin is not active.' );
            }
            // Build CF7 form markup from fields
            $form_lines = array();
            $field_index = 1;
            foreach ( $fields as $field ) {
                if ( ! is_array( $field ) ) {
                    continue;
                }
                $type     = isset( $field['type'] ) ? strtolower( $field['type'] ) : 'text';
                $label    = isset( $field['label'] ) ? $field['label'] : 'Field ' . $field_index;
                $required = isset( $field['required'] ) && $field['required'];
                $choices  = isset( $field['choices'] ) && is_array( $field['choices'] ) ? $field['choices'] : array();
                // Generate a name for the field
                $name = 'field_' . $field_index;
                $tag  = '';
                switch ( $type ) {
                    case 'email':
                        $tag = sprintf( '[email%s %s]', $required ? '*' : '', $name );
                        break;
                    case 'phone':
                        $tag = sprintf( '[tel%s %s]', $required ? '*' : '', $name );
                        break;
                    case 'textarea':
                        $tag = sprintf( '[textarea%s %s]', $required ? '*' : '', $name );
                        break;
                    case 'select':
                        $options = '';
                        foreach ( $choices as $choice ) {
                            $options .= '"' . esc_attr( $choice ) . '" ';
                        }
                        $tag = sprintf( '[select%s %s %s]', $required ? '*' : '', $name, trim( $options ) );
                        break;
                    case 'checkbox':
                        $options = '';
                        foreach ( $choices as $choice ) {
                            $options .= '"' . esc_attr( $choice ) . '" ';
                        }
                        $tag = sprintf( '[checkbox %s use_label_element %s]', $name, trim( $options ) );
                        break;
                    case 'radio':
                        $options = '';
                        foreach ( $choices as $choice ) {
                            $options .= '"' . esc_attr( $choice ) . '" ';
                        }
                        $tag = sprintf( '[radio %s %s]', $name, trim( $options ) );
                        break;
                    case 'date':
                        $tag = sprintf( '[date%s %s]', $required ? '*' : '', $name );
                        break;
                    case 'file':
                        $tag = sprintf( '[file%s %s]', $required ? '*' : '', $name );
                        break;
                    default:
                        // Default to text field
                        $tag = sprintf( '[text%s %s]', $required ? '*' : '', $name );
                        break;
                }
                $form_lines[] = '<label>' . esc_html( $label ) . ' ' . $tag . '</label>';
                $field_index++;
            }
            // Append submit button
            $form_lines[] = '[submit "Send"]';
            $form_markup = implode( "\n\n", $form_lines );
            // Create the form post
            $post_id = wp_insert_post( array(
                'post_title'  => $form_name,
                'post_type'   => 'wpcf7_contact_form',
                'post_status' => 'publish',
            ) );
            if ( is_wp_error( $post_id ) || ! $post_id ) {
                return array( 'error' => 'Failed to create Contact Form 7 form.' );
            }
            // Save form markup and a basic mail template
            update_post_meta( $post_id, '_form', $form_markup );
            $mail = array(
                'subject'   => sprintf( 'New submission: %s', $form_name ),
                'sender'    => '{your-email}',
                'body'      => 'New form submission',
                'recipient' => get_option( 'admin_email' ),
            );
            update_post_meta( $post_id, '_mail', $mail );
            return array( 'provider' => 'cf7', 'form_id' => $post_id );
        }

        // Gravity Forms provider
        if ( in_array( $provider, array( 'gravityforms', 'gf', 'gravity' ), true ) ) {
            if ( ! class_exists( 'GFAPI' ) ) {
                return array( 'error' => 'Gravity Forms plugin is not active.' );
            }
            $form = array(
                'title'         => $form_name,
                'description'   => '',
                'labelPlacement' => 'top_label',
                'fields'        => array(),
                'notifications' => array(),
                'confirmations' => array(),
                'is_active'     => true,
            );
            $field_id = 1;
            foreach ( $fields as $field ) {
                if ( ! is_array( $field ) ) {
                    continue;
                }
                $type     = isset( $field['type'] ) ? strtolower( $field['type'] ) : 'text';
                $label    = isset( $field['label'] ) ? $field['label'] : 'Field ' . $field_id;
                $required = isset( $field['required'] ) && $field['required'];
                $choices  = isset( $field['choices'] ) && is_array( $field['choices'] ) ? $field['choices'] : array();
                $field_props = array(
                    'id'         => $field_id,
                    'type'       => $type,
                    'label'      => $label,
                    'isRequired' => $required,
                );
                if ( in_array( $type, array( 'select', 'radio', 'checkbox' ), true ) ) {
                    $choices_array = array();
                    foreach ( $choices as $choice ) {
                        $choices_array[] = array( 'text' => $choice, 'value' => $choice, 'isSelected' => false );
                    }
                    $field_props['choices'] = $choices_array;
                    if ( 'checkbox' === $type ) {
                        $field_props['type'] = 'checkbox';
                        $field_props['inputs'] = array();
                        $sub_id = 1;
                        foreach ( $choices_array as $choice ) {
                            $field_props['inputs'][] = array( 'id' => $field_id . '.' . $sub_id, 'label' => $choice['text'] );
                            $sub_id++;
                        }
                    }
                }
                $gf_field = GF_Fields::create( $field_props );
                $form['fields'][] = $gf_field;
                $field_id++;
            }
            $form_id = GFAPI::add_form( $form );
            if ( is_wp_error( $form_id ) ) {
                return array( 'error' => 'Failed to create Gravity Form.' );
            }
            return array( 'provider' => 'gravityforms', 'form_id' => $form_id );
        }

        // WPForms provider
        if ( 'wpforms' === $provider ) {
            if ( ! function_exists( 'wpforms' ) || ! is_object( wpforms() ) ) {
                return array( 'error' => 'WPForms plugin is not active.' );
            }
            $form_data = array(
                'meta'     => array(
                    'form_title' => $form_name,
                    'form_desc'  => '',
                ),
                'fields'   => array(),
                'settings' => array(
                    'notifications'       => array(),
                    'notification_enable' => true,
                    'confirmation_type'   => 'message',
                    'confirmation_message' => __( 'Thank you for contacting us.', 'arthur-ai' ),
                    'confirmation_redirect' => '',
                ),
            );
            $field_id = 1;
            foreach ( $fields as $field ) {
                if ( ! is_array( $field ) ) {
                    continue;
                }
                $type     = isset( $field['type'] ) ? strtolower( $field['type'] ) : 'text';
                $label    = isset( $field['label'] ) ? $field['label'] : 'Field ' . $field_id;
                $required = isset( $field['required'] ) && $field['required'];
                $choices  = isset( $field['choices'] ) && is_array( $field['choices'] ) ? $field['choices'] : array();
                $wpfield  = array(
                    'id'       => (string) $field_id,
                    'type'     => $type,
                    'label'    => $label,
                    'required' => $required,
                );
                if ( in_array( $type, array( 'select', 'radio', 'checkbox' ), true ) ) {
                    $options = array();
                    $sub_id  = 1;
                    foreach ( $choices as $choice ) {
                        $options[] = array(
                            'choice' => $choice,
                            'value'  => $choice,
                            'label'  => $choice,
                            'id'     => (string) $sub_id,
                        );
                        $sub_id++;
                    }
                    $wpfield['choices'] = $options;
                }
                $form_data['fields'][] = $wpfield;
                $field_id++;
            }
            $form_id = wpforms()->form->add( $form_data );
            if ( empty( $form_id ) ) {
                return array( 'error' => 'Failed to create WPForms form.' );
            }
            return array( 'provider' => 'wpforms', 'form_id' => $form_id );
        }

        return array( 'error' => 'Unsupported provider.' );
    }
}
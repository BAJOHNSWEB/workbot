<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure tagging rules for form submissions based on responses.
 */
class Arthur_AI_Action_Tag_Form_Leads implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'tag_form_leads';
    }

    public function get_label() {
        return __( 'Tag Form Leads', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? strtolower( trim( $payload['provider'] ) ) : '';
        $form_id  = isset( $payload['form_id'] ) ? intval( $payload['form_id'] ) : 0;
        $rules    = isset( $payload['rules'] ) && is_array( $payload['rules'] ) ? $payload['rules'] : array();
        if ( ! $provider || ! $form_id || empty( $rules ) ) {
            return array( 'error' => 'Provider, form_id and rules are required.' );
        }
        $existing = get_option( 'arthur_ai_form_lead_tags', array() );
        if ( ! is_array( $existing ) ) {
            $existing = array();
        }
        foreach ( $rules as $rule ) {
            if ( ! is_array( $rule ) ) {
                continue;
            }
            $field_key   = isset( $rule['field_key'] ) ? $rule['field_key'] : ( isset( $rule['field_id'] ) ? $rule['field_id'] : '' );
            $match_type  = isset( $rule['match_type'] ) ? $rule['match_type'] : 'equals';
            $match_value = isset( $rule['match_value'] ) ? $rule['match_value'] : '';
            $tags_to_add = isset( $rule['tags_to_add'] ) && is_array( $rule['tags_to_add'] ) ? $rule['tags_to_add'] : array();
            if ( ! $field_key || empty( $tags_to_add ) ) {
                continue;
            }
            $existing[] = array(
                'provider'    => $provider,
                'form_id'     => $form_id,
                'field_key'   => $field_key,
                'match_type'  => $match_type,
                'match_value' => $match_value,
                'tags_to_add' => $tags_to_add,
            );
        }
        update_option( 'arthur_ai_form_lead_tags', $existing, false );
        return array( 'success' => true );
    }
}
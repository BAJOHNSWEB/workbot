<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Create or update an index page listing posts or other content.
 */
class Arthur_AI_Action_Generate_Index_Page implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'generate_index_page';
    }

    public function get_label() {
        return __( 'Generate Index Page', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $page_title = isset( $payload['page_title'] ) ? trim( (string) $payload['page_title'] ) : '';
        if ( '' === $page_title ) {
            return array( 'success' => false, 'message' => __( 'page_title is required.', 'arthur-ai' ) );
        }
        $slug     = isset( $payload['slug'] ) && $payload['slug'] ? sanitize_title( (string) $payload['slug'] ) : sanitize_title( $page_title );
        $content  = isset( $payload['content'] ) ? (string) $payload['content'] : '';
        $template = isset( $payload['template'] ) ? (string) $payload['template'] : '';
        // Try to find existing page
        $existing = get_page_by_path( $slug );
        if ( ! $existing ) {
            $existing = get_page_by_title( $page_title, OBJECT, 'page' );
        }
        $created  = false;
        if ( $existing ) {
            $post_id = (int) $existing->ID;
            $update_data = array( 'ID' => $post_id );
            if ( '' !== $content ) {
                $update_data['post_content'] = wp_kses_post( $content );
            }
            if ( '' !== $template ) {
                update_post_meta( $post_id, '_wp_page_template', $template );
            }
            wp_update_post( $update_data );
        } else {
            $new_data = array(
                'post_title'   => $page_title,
                'post_name'    => $slug,
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_content' => wp_kses_post( $content ),
            );
            $post_id = wp_insert_post( $new_data );
            $created = true;
            if ( ! is_wp_error( $post_id ) ) {
                if ( '' !== $template ) {
                    update_post_meta( $post_id, '_wp_page_template', $template );
                }
            }
        }
        return array(
            'success' => true,
            'page_id' => (int) $post_id,
            'created' => $created,
        );
    }
}
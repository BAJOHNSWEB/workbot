<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Replace or remove broken internal links in post content.
 */
class Arthur_AI_Action_Fix_Broken_Internal_Links implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'fix_broken_internal_links';
    }

    public function get_label() {
        return __( 'Fix Broken Internal Links', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $replacements = isset( $payload['replacements'] ) && is_array( $payload['replacements'] ) ? $payload['replacements'] : array();
        $summary      = array();
        foreach ( $replacements as $rep ) {
            if ( ! is_array( $rep ) || empty( $rep['old_url'] ) ) {
                continue;
            }
            $old_url = (string) $rep['old_url'];
            $new_url = isset( $rep['new_url'] ) ? (string) $rep['new_url'] : null;
            // Determine posts to update
            $target_posts = array();
            if ( ! empty( $rep['post_id'] ) ) {
                $target_posts[] = (int) $rep['post_id'];
            } else {
                // Apply to all posts/pages
                $all = get_posts( array( 'post_type' => 'any', 'posts_per_page' => -1, 'post_status' => array( 'publish', 'draft', 'private', 'pending', 'future' ) ) );
                foreach ( $all as $p ) {
                    $target_posts[] = (int) $p->ID;
                }
            }
            foreach ( $target_posts as $pid ) {
                $content = get_post_field( 'post_content', $pid );
                if ( false === strpos( $content, $old_url ) ) {
                    continue;
                }
                $count = 0;
                if ( null !== $new_url && '' !== $new_url ) {
                    // Replace href="old_url" with href="new_url"
                    $pattern = '#(<a[^>]*href=\"?)' . preg_quote( $old_url, '#' ) . '(\"[^>]*>)#i';
                    $replacement = '$1' . esc_url_raw( $new_url ) . '$2';
                    $new_content = preg_replace( $pattern, $replacement, $content, -1, $count );
                    if ( null !== $new_content ) {
                        $content = $new_content;
                    }
                } else {
                    // Remove entire anchor but keep inner text
                    $pattern     = '#<a[^>]*href=\"' . preg_quote( $old_url, '#' ) . '\"[^>]*>(.*?)</a>#is';
                    $new_content = preg_replace( $pattern, '$1', $content, -1, $count );
                    if ( null !== $new_content ) {
                        $content = $new_content;
                    }
                }
                if ( $count > 0 ) {
                    wp_update_post( array( 'ID' => $pid, 'post_content' => wp_kses_post( $content ) ) );
                    if ( ! isset( $summary[ $pid ] ) ) {
                        $summary[ $pid ] = 0;
                    }
                    $summary[ $pid ] += $count;
                }
            }
        }
        return array( 'success' => true, 'replacements' => $summary );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Create standard core pages such as About, Contact or Privacy Policy.
 */
class Arthur_AI_Action_Create_Core_Pages implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'create_core_pages';
    }

    public function get_label() {
        return __( 'Create Core Pages', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $pages = isset( $payload['pages'] ) && is_array( $payload['pages'] ) ? $payload['pages'] : array();
        $results = array();
        foreach ( $pages as $page ) {
            if ( ! is_array( $page ) ) {
                continue;
            }
            $title = isset( $page['title'] ) ? (string) $page['title'] : '';
            if ( '' === $title ) {
                continue;
            }
            $slug     = isset( $page['slug'] ) && $page['slug'] ? sanitize_title( (string) $page['slug'] ) : sanitize_title( $title );
            $content  = isset( $page['content'] ) ? (string) $page['content'] : '';
            $template = isset( $page['template'] ) ? (string) $page['template'] : '';

            // Try to find existing page by slug.
            $existing = get_page_by_path( $slug );
            if ( ! $existing ) {
                // Try by exact title
                $existing = get_page_by_title( $title, OBJECT, 'page' );
            }
            if ( $existing ) {
                $post_id = (int) $existing->ID;
                // Optionally update content/template if provided
                $update_data = array( 'ID' => $post_id );
                $need_update = false;
                if ( '' !== $content ) {
                    $update_data['post_content'] = wp_kses_post( $content );
                    $need_update = true;
                }
                if ( '' !== $template ) {
                    update_post_meta( $post_id, '_wp_page_template', $template );
                }
                if ( $need_update ) {
                    wp_update_post( $update_data );
                }
                $results[] = $post_id;
            } else {
                $post_data = array(
                    'post_title'   => $title,
                    'post_name'    => $slug,
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                    'post_content' => wp_kses_post( $content ),
                );
                $new_id = wp_insert_post( $post_data );
                if ( ! is_wp_error( $new_id ) ) {
                    if ( '' !== $template ) {
                        update_post_meta( $new_id, '_wp_page_template', $template );
                    }
                    $results[] = (int) $new_id;
                }
            }
        }
        return array( 'success' => true, 'pages' => $results );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Create or update a navigation menu and optionally assign it to a theme location.
 */
class Arthur_AI_Action_Create_Or_Update_Nav_Menu implements Arthur_AI_Action_Interface {

    /**
     * Get the action type (slug).
     *
     * @return string
     */
    public function get_type() {
        return 'create_or_update_nav_menu';
    }

    /**
     * Get a human‑readable label for this action.
     *
     * @return string
     */
    public function get_label() {
        return __( 'Create or Update Navigation Menu', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * @param array $payload Payload data.
     * @return array Result data.
     */
    public function execute( array $payload ) {
        $menu_name = isset( $payload['menu_name'] ) ? trim( (string) $payload['menu_name'] ) : '';
        if ( '' === $menu_name ) {
            return array( 'success' => false, 'message' => __( 'menu_name is required.', 'arthur-ai' ) );
        }

        // Check if menu exists by name.
        $menu_obj = wp_get_nav_menu_object( $menu_name );
        $menu_id  = 0;
        if ( $menu_obj ) {
            $menu_id = (int) $menu_obj->term_id;
            // Update description if provided.
            if ( isset( $payload['description'] ) && '' !== (string) $payload['description'] ) {
                wp_update_nav_menu_object( $menu_id, array( 'description' => (string) $payload['description'] ) );
            }
        } else {
            // Create new menu.
            $args = array();
            if ( isset( $payload['description'] ) && '' !== (string) $payload['description'] ) {
                $args['description'] = (string) $payload['description'];
            }
            $menu_id = wp_create_nav_menu( $menu_name, $args );
            if ( is_wp_error( $menu_id ) ) {
                return array( 'success' => false, 'message' => $menu_id->get_error_message() );
            }
        }

        $assigned_locations = array();
        // Assign menu to a location if provided and location exists.
        if ( isset( $payload['location'] ) && $payload['location'] ) {
            $location = (string) $payload['location'];
            $registered_locations = get_registered_nav_menus();
            if ( array_key_exists( $location, $registered_locations ) ) {
                $locations = get_theme_mod( 'nav_menu_locations', array() );
                $locations[ $location ] = $menu_id;
                set_theme_mod( 'nav_menu_locations', $locations );
                $assigned_locations[] = $location;
            }
        }

        return array(
            'success'   => true,
            'menu_id'   => $menu_id,
            'locations' => $assigned_locations,
        );
    }
}
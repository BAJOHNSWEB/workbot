<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Update post content with internal links already inserted by the AI.
 */
class Arthur_AI_Action_Insert_Internal_Links implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'insert_internal_links';
    }

    public function get_label() {
        return __( 'Insert Internal Links', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $items   = isset( $payload['items'] ) && is_array( $payload['items'] ) ? $payload['items'] : array();
        $updated = array();
        foreach ( $items as $item ) {
            if ( ! is_array( $item ) || empty( $item['post_id'] ) || ! isset( $item['post_content'] ) ) {
                continue;
            }
            $post_id     = (int) $item['post_id'];
            $post_content = wp_kses_post( (string) $item['post_content'] );
            wp_update_post( array( 'ID' => $post_id, 'post_content' => $post_content ) );
            $updated[] = $post_id;
        }
        return array( 'success' => true, 'updated' => $updated );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Add, update or remove items in a navigation menu.
 */
class Arthur_AI_Action_Update_Nav_Menu_Items implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'update_nav_menu_items';
    }

    public function get_label() {
        return __( 'Update Navigation Menu Items', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        // Determine menu ID
        $menu_id = 0;
        if ( ! empty( $payload['menu_id'] ) ) {
            $menu_id = (int) $payload['menu_id'];
        } elseif ( ! empty( $payload['menu_name'] ) ) {
            $menu_obj = wp_get_nav_menu_object( (string) $payload['menu_name'] );
            if ( ! $menu_obj ) {
                return array( 'success' => false, 'message' => __( 'Menu not found.', 'arthur-ai' ) );
            }
            $menu_id = (int) $menu_obj->term_id;
        } else {
            return array( 'success' => false, 'message' => __( 'menu_id or menu_name is required.', 'arthur-ai' ) );
        }

        $items   = isset( $payload['items'] ) && is_array( $payload['items'] ) ? $payload['items'] : array();
        $added   = array();
        $updated = array();
        $removed = array();

        foreach ( $items as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }
            $action = isset( $item['action'] ) ? $item['action'] : '';
            switch ( $action ) {
                case 'add':
                    $args = array(
                        'menu-item-title'  => isset( $item['title'] ) ? (string) $item['title'] : '',
                        'menu-item-status' => 'publish',
                    );
                    if ( ! empty( $item['url'] ) ) {
                        $args['menu-item-url']  = (string) $item['url'];
                        $args['menu-item-type'] = 'custom';
                    } else {
                        if ( ! empty( $item['object_id'] ) ) {
                            $args['menu-item-object-id'] = (int) $item['object_id'];
                        }
                        if ( ! empty( $item['object'] ) ) {
                            $args['menu-item-object'] = (string) $item['object'];
                        }
                        if ( ! empty( $item['type'] ) ) {
                            $args['menu-item-type'] = (string) $item['type'];
                        }
                    }
                    if ( isset( $item['parent_id'] ) ) {
                        $args['menu-item-parent-id'] = (int) $item['parent_id'];
                    }
                    if ( isset( $item['position'] ) ) {
                        $args['menu-item-position'] = (int) $item['position'];
                    }
                    $new_id = wp_update_nav_menu_item( $menu_id, 0, $args );
                    if ( ! is_wp_error( $new_id ) ) {
                        $added[] = (int) $new_id;
                    }
                    break;
                case 'update':
                    if ( empty( $item['item_id'] ) ) {
                        break;
                    }
                    $iid  = (int) $item['item_id'];
                    $args = array();
                    if ( isset( $item['title'] ) ) {
                        $args['menu-item-title'] = (string) $item['title'];
                    }
                    if ( ! empty( $item['url'] ) ) {
                        $args['menu-item-url']  = (string) $item['url'];
                        $args['menu-item-type'] = 'custom';
                    } else {
                        if ( ! empty( $item['object_id'] ) ) {
                            $args['menu-item-object-id'] = (int) $item['object_id'];
                        }
                        if ( ! empty( $item['object'] ) ) {
                            $args['menu-item-object'] = (string) $item['object'];
                        }
                        if ( ! empty( $item['type'] ) ) {
                            $args['menu-item-type'] = (string) $item['type'];
                        }
                    }
                    if ( isset( $item['parent_id'] ) ) {
                        $args['menu-item-parent-id'] = (int) $item['parent_id'];
                    }
                    if ( isset( $item['position'] ) ) {
                        $args['menu-item-position'] = (int) $item['position'];
                    }
                    $res = wp_update_nav_menu_item( $menu_id, $iid, $args );
                    if ( ! is_wp_error( $res ) ) {
                        $updated[] = $iid;
                    }
                    break;
                case 'remove':
                    if ( empty( $item['item_id'] ) ) {
                        break;
                    }
                    $iid = (int) $item['item_id'];
                    $deleted = wp_delete_post( $iid, true );
                    if ( $deleted ) {
                        $removed[] = $iid;
                    }
                    break;
            }
        }

        // Return summary of changes
        return array(
            'success' => true,
            'added'   => $added,
            'updated' => $updated,
            'removed' => $removed,
        );
    }
}
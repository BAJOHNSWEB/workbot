<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure role‑based menus per theme location.
 */
class Arthur_AI_Action_Set_Role_Based_Menus implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'set_role_based_menus';
    }

    public function get_label() {
        return __( 'Set Role‑Based Menus', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( empty( $payload['rules'] ) || ! is_array( $payload['rules'] ) ) {
            return array( 'success' => false, 'message' => __( 'rules parameter is required.', 'arthur-ai' ) );
        }

        $out_rules = array();
        foreach ( $payload['rules'] as $location => $rules ) {
            if ( ! is_array( $rules ) ) {
                continue;
            }
            $location_rules = array();
            foreach ( $rules as $rule ) {
                if ( ! is_array( $rule ) || empty( $rule['role'] ) ) {
                    continue;
                }
                $role = (string) $rule['role'];
                // Determine menu_id
                $menu_id = 0;
                if ( ! empty( $rule['menu_id'] ) ) {
                    $menu_id = (int) $rule['menu_id'];
                } elseif ( ! empty( $rule['menu_name'] ) ) {
                    $menu_obj = wp_get_nav_menu_object( (string) $rule['menu_name'] );
                    if ( ! $menu_obj ) {
                        // If menu does not exist, attempt to create it
                        $new_id = wp_create_nav_menu( (string) $rule['menu_name'] );
                        if ( is_wp_error( $new_id ) ) {
                            continue;
                        }
                        $menu_id = (int) $new_id;
                    } else {
                        $menu_id = (int) $menu_obj->term_id;
                    }
                }
                if ( $menu_id > 0 ) {
                    $location_rules[] = array(
                        'role'    => $role,
                        'menu_id' => $menu_id,
                    );
                }
            }
            if ( ! empty( $location_rules ) ) {
                $out_rules[ (string) $location ] = $location_rules;
            }
        }

        update_option( 'arthur_ai_role_based_menus', $out_rules );

        return array(
            'success' => true,
            'rules'   => $out_rules,
        );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Update or replace blocks within a sidebar (block-based widgets).
 */
class Arthur_AI_Action_Update_Sidebar_Blocks implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'update_sidebar_blocks';
    }

    public function get_label() {
        return __( 'Update Sidebar Blocks', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $sidebar_id    = isset( $payload['sidebar_id'] ) ? (string) $payload['sidebar_id'] : '';
        $blocks_content = isset( $payload['blocks_content'] ) ? (string) $payload['blocks_content'] : '';
        if ( '' === $sidebar_id ) {
            return array( 'success' => false, 'message' => __( 'sidebar_id is required.', 'arthur-ai' ) );
        }
        $sidebars      = get_option( 'sidebars_widgets', array() );
        $widget_blocks = get_option( 'widget_block', array() );
        if ( ! isset( $sidebars[ $sidebar_id ] ) ) {
            $sidebars[ $sidebar_id ] = array();
        }
        $found = false;
        // Try to find existing block instance in this sidebar
        foreach ( $sidebars[ $sidebar_id ] as $slot_id ) {
            if ( strpos( $slot_id, 'block-' ) === 0 ) {
                $idx = (int) substr( $slot_id, strlen( 'block-' ) );
                if ( isset( $widget_blocks[ $idx ] ) ) {
                    $widget_blocks[ $idx ]['content']          = $blocks_content;
                    $widget_blocks[ $idx ]['content_raw']      = $blocks_content;
                    $widget_blocks[ $idx ]['content_filtered'] = wp_kses_post( $blocks_content );
                    $found = true;
                    break;
                }
            }
        }
        if ( ! $found ) {
            // Create a new block widget instance
            $max_index = 0;
            foreach ( array_keys( $widget_blocks ) as $idx ) {
                if ( is_numeric( $idx ) && $idx > $max_index ) {
                    $max_index = $idx;
                }
            }
            $new_index = $max_index + 1;
            $widget_blocks[ $new_index ] = array(
                'content'          => $blocks_content,
                'title'            => '',
                'content_raw'      => $blocks_content,
                'content_filtered' => wp_kses_post( $blocks_content ),
            );
            $sidebars[ $sidebar_id ] = array( 'block-' . $new_index );
        }
        update_option( 'widget_block', $widget_blocks );
        update_option( 'sidebars_widgets', $sidebars );
        return array( 'success' => true, 'sidebar' => $sidebar_id );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Manage inclusion or exclusion of posts in the XML sitemap.
 */
class Arthur_AI_Action_Manage_Sitemap_Inclusion implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'manage_sitemap_inclusion';
    }

    public function get_label() {
        return __( 'Manage Sitemap Inclusion', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $include = isset( $payload['include'] ) && is_array( $payload['include'] ) ? $payload['include'] : array();
        $exclude = isset( $payload['exclude'] ) && is_array( $payload['exclude'] ) ? $payload['exclude'] : array();
        $rules   = array(
            'include' => array(
                'post_types' => array(),
                'post_ids'   => array(),
            ),
            'exclude' => array(
                'post_types' => array(),
                'post_ids'   => array(),
            ),
        );
        // Normalise include rules
        if ( ! empty( $include['post_types'] ) && is_array( $include['post_types'] ) ) {
            $rules['include']['post_types'] = array_values( array_unique( array_map( 'sanitize_key', $include['post_types'] ) ) );
        }
        if ( ! empty( $include['post_ids'] ) && is_array( $include['post_ids'] ) ) {
            $rules['include']['post_ids'] = array_values( array_unique( array_map( 'intval', $include['post_ids'] ) ) );
        }
        // Normalise exclude rules
        if ( ! empty( $exclude['post_types'] ) && is_array( $exclude['post_types'] ) ) {
            $rules['exclude']['post_types'] = array_values( array_unique( array_map( 'sanitize_key', $exclude['post_types'] ) ) );
        }
        if ( ! empty( $exclude['post_ids'] ) && is_array( $exclude['post_ids'] ) ) {
            $rules['exclude']['post_ids'] = array_values( array_unique( array_map( 'intval', $exclude['post_ids'] ) ) );
        }
        update_option( 'arthur_ai_sitemap_rules', $rules );
        return array( 'success' => true, 'rules' => $rules );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure a widget area for classic or block widgets.
 */
class Arthur_AI_Action_Configure_Widget_Area implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_widget_area';
    }

    public function get_label() {
        return __( 'Configure Widget Area', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $sidebar_id = isset( $payload['sidebar_id'] ) ? (string) $payload['sidebar_id'] : '';
        if ( '' === $sidebar_id ) {
            return array( 'success' => false, 'message' => __( 'sidebar_id is required.', 'arthur-ai' ) );
        }
        $mode = isset( $payload['mode'] ) && 'block' === $payload['mode'] ? 'block' : 'classic';
        $result = array();
        if ( 'classic' === $mode ) {
            $widgets = isset( $payload['widgets'] ) && is_array( $payload['widgets'] ) ? $payload['widgets'] : array();
            $sidebars = get_option( 'sidebars_widgets', array() );
            if ( ! isset( $sidebars[ $sidebar_id ] ) ) {
                $sidebars[ $sidebar_id ] = array();
            }
            // Clear current widgets for this sidebar
            $sidebars[ $sidebar_id ] = array();
            foreach ( $widgets as $w ) {
                if ( ! is_array( $w ) || empty( $w['id_base'] ) ) {
                    continue;
                }
                $id_base  = (string) $w['id_base'];
                $settings = isset( $w['settings'] ) && is_array( $w['settings'] ) ? $w['settings'] : array();
                $opt_key  = 'widget_' . $id_base;
                $instances = get_option( $opt_key, array() );
                // Find next numeric index
                $max_index = 0;
                foreach ( array_keys( $instances ) as $idx ) {
                    if ( is_numeric( $idx ) && $idx > $max_index ) {
                        $max_index = $idx;
                    }
                }
                $new_index = $max_index + 1;
                $instances[ $new_index ] = $settings;
                update_option( $opt_key, $instances );
                $sidebars[ $sidebar_id ][] = $id_base . '-' . $new_index;
            }
            update_option( 'sidebars_widgets', $sidebars );
            $result['widgets'] = $sidebars[ $sidebar_id ];
        } else {
            // Block mode
            $blocks_content = isset( $payload['blocks_content'] ) ? (string) $payload['blocks_content'] : '';
            $sidebars      = get_option( 'sidebars_widgets', array() );
            $widget_blocks = get_option( 'widget_block', array() );
            if ( ! isset( $sidebars[ $sidebar_id ] ) ) {
                $sidebars[ $sidebar_id ] = array();
            }
            // Remove existing block instances in this sidebar
            foreach ( $sidebars[ $sidebar_id ] as $slot_id ) {
                if ( strpos( $slot_id, 'block-' ) === 0 ) {
                    $idx = (int) substr( $slot_id, strlen( 'block-' ) );
                    if ( isset( $widget_blocks[ $idx ] ) ) {
                        unset( $widget_blocks[ $idx ] );
                    }
                }
            }
            // Determine new index for block widget
            $max_index = 0;
            foreach ( array_keys( $widget_blocks ) as $idx ) {
                if ( is_numeric( $idx ) && $idx > $max_index ) {
                    $max_index = $idx;
                }
            }
            $new_index = $max_index + 1;
            $widget_blocks[ $new_index ] = array(
                'content'          => $blocks_content,
                'title'            => '',
                'content_raw'      => $blocks_content,
                'content_filtered' => wp_kses_post( $blocks_content ),
            );
            update_option( 'widget_block', $widget_blocks );
            $sidebars[ $sidebar_id ] = array( 'block-' . $new_index );
            update_option( 'sidebars_widgets', $sidebars );
            $result['block_instance'] = 'block-' . $new_index;
        }
        return array( 'success' => true ) + $result;
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Rename navigation menu item labels while preserving their URLs and object references.
 */
class Arthur_AI_Action_Rename_Nav_Menu_Labels implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'rename_nav_menu_labels';
    }

    public function get_label() {
        return __( 'Rename Navigation Menu Labels', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        // Determine menu ID
        $menu_id = 0;
        if ( ! empty( $payload['menu_id'] ) ) {
            $menu_id = (int) $payload['menu_id'];
        } elseif ( ! empty( $payload['menu_name'] ) ) {
            $menu_obj = wp_get_nav_menu_object( (string) $payload['menu_name'] );
            if ( ! $menu_obj ) {
                return array( 'success' => false, 'message' => __( 'Menu not found.', 'arthur-ai' ) );
            }
            $menu_id = (int) $menu_obj->term_id;
        } else {
            return array( 'success' => false, 'message' => __( 'menu_id or menu_name is required.', 'arthur-ai' ) );
        }

        $label_map = isset( $payload['label_map'] ) && is_array( $payload['label_map'] ) ? $payload['label_map'] : array();
        if ( empty( $label_map ) ) {
            return array( 'success' => false, 'message' => __( 'label_map is required.', 'arthur-ai' ) );
        }

        $menu_items = wp_get_nav_menu_items( $menu_id );
        if ( ! is_array( $menu_items ) ) {
            $menu_items = array();
        }

        $renamed = array();
        foreach ( $label_map as $map ) {
            if ( ! is_array( $map ) ) {
                continue;
            }
            $new_title = isset( $map['new_title'] ) ? (string) $map['new_title'] : '';
            if ( '' === $new_title ) {
                continue;
            }
            $target_item_id = 0;
            if ( ! empty( $map['item_id'] ) ) {
                $target_item_id = (int) $map['item_id'];
            } elseif ( ! empty( $map['old_title'] ) ) {
                $old_title = (string) $map['old_title'];
                foreach ( $menu_items as $mi ) {
                    if ( isset( $mi->title ) && $mi->title === $old_title ) {
                        $target_item_id = (int) $mi->ID;
                        break;
                    }
                }
            }
            if ( $target_item_id > 0 ) {
                $res = wp_update_nav_menu_item( $menu_id, $target_item_id, array( 'menu-item-title' => $new_title ) );
                if ( ! is_wp_error( $res ) ) {
                    $renamed[] = $target_item_id;
                }
            }
        }

        return array(
            'success' => true,
            'renamed' => $renamed,
        );
    }
}
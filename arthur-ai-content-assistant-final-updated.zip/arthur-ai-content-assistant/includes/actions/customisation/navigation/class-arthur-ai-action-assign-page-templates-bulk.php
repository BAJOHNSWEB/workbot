<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Assign a page template to a list of pages in bulk.
 */
class Arthur_AI_Action_Assign_Page_Templates_Bulk implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'assign_page_templates_bulk';
    }

    public function get_label() {
        return __( 'Assign Page Templates (Bulk)', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $template = isset( $payload['template'] ) ? (string) $payload['template'] : '';
        $post_ids = isset( $payload['post_ids'] ) && is_array( $payload['post_ids'] ) ? $payload['post_ids'] : array();
        $updated  = array();
        if ( '' === $template || empty( $post_ids ) ) {
            return array( 'success' => false, 'message' => __( 'template and post_ids are required.', 'arthur-ai' ) );
        }
        foreach ( $post_ids as $pid ) {
            $pid = (int) $pid;
            update_post_meta( $pid, '_wp_page_template', $template );
            $updated[] = $pid;
        }
        return array(
            'success'  => true,
            'template' => $template,
            'posts'    => $updated,
        );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Reorganise page hierarchy by changing parent relationships and slugs.
 */
class Arthur_AI_Action_Reorganise_Page_Hierarchy implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'reorganise_page_hierarchy';
    }

    public function get_label() {
        return __( 'Reorganise Page Hierarchy', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $items = isset( $payload['items'] ) && is_array( $payload['items'] ) ? $payload['items'] : array();
        $updated = array();
        foreach ( $items as $item ) {
            if ( ! is_array( $item ) || empty( $item['post_id'] ) ) {
                continue;
            }
            $post_id   = (int) $item['post_id'];
            $parent_id = isset( $item['parent_id'] ) && $item['parent_id'] ? (int) $item['parent_id'] : 0;
            $post_name = isset( $item['post_name'] ) && $item['post_name'] ? sanitize_title( (string) $item['post_name'] ) : null;
            $update    = array( 'ID' => $post_id );
            $update['post_parent'] = $parent_id;
            if ( null !== $post_name ) {
                $update['post_name'] = $post_name;
            }
            wp_update_post( $update );
            $updated[] = array(
                'post_id'   => $post_id,
                'parent_id' => $parent_id,
                'post_name' => $post_name,
            );
        }
        // Flush rewrite rules once to apply new structure.
        flush_rewrite_rules();
        return array(
            'success' => true,
            'updated' => $updated,
        );
    }
}
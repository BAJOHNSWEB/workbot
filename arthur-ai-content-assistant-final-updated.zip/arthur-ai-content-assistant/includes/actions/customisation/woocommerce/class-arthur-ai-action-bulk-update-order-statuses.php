<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Bulk update WooCommerce order statuses.
 *
 * This action changes the status of multiple orders at once. The
 * payload must include an array of order IDs and the target
 * status. Orders that do not exist or for which the status is
 * invalid are ignored. Returns a list of updated orders.
 */
class Arthur_AI_Action_Bulk_Update_Order_Statuses implements Arthur_AI_Action_Interface {

    /**
     * Get type slug.
     *
     * @return string
     */
    public function get_type() {
        return 'bulk_update_order_statuses';
    }

    /**
     * Get label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Bulk Update Order Statuses', 'arthur-ai' );
    }

    /**
     * Execute action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['order_ids'] ) || ! is_array( $payload['order_ids'] ) ) {
            return array( 'success' => false, 'message' => __( 'order_ids array is required.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['status'] ) ) {
            return array( 'success' => false, 'message' => __( 'status is required.', 'arthur-ai' ) );
        }
        $status = sanitize_key( (string) $payload['status'] );
        $valid  = wc_get_order_statuses();
        if ( ! isset( $valid[ 'wc-' . $status ] ) ) {
            return array( 'success' => false, 'message' => __( 'Invalid order status.', 'arthur-ai' ) );
        }
        $updated = array();
        foreach ( $payload['order_ids'] as $id ) {
            $order = wc_get_order( intval( $id ) );
            if ( ! $order ) {
                continue;
            }
            $order->update_status( $status, __( 'Status updated by AI action', 'arthur-ai' ), true );
            $order->save();
            $updated[] = $order->get_id();
        }
        return array( 'success' => true, 'updated_order_ids' => $updated );
    }
}
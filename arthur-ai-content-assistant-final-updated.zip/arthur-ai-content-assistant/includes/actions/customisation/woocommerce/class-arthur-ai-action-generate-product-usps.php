<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Store product USPs or comparison tables in product meta.
 *
 * The AI can generate a block of markup (USP block) representing
 * unique selling points, features, or comparison tables. This
 * action saves that markup to a meta field for later display
 * by theme or template modifications. It does not attempt to
 * render the block itself.
 */
class Arthur_AI_Action_Generate_Product_USPs implements Arthur_AI_Action_Interface {

    /**
     * Get type slug.
     *
     * @return string
     */
    public function get_type() {
        return 'generate_product_usps';
    }

    /**
     * Get human label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Generate Product USPs', 'arthur-ai' );
    }

    /**
     * Execute action to save USP block.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['product_id'] ) || ! isset( $payload['usp_block'] ) ) {
            return array( 'success' => false, 'message' => __( 'product_id and usp_block are required.', 'arthur-ai' ) );
        }
        $product_id = intval( $payload['product_id'] );
        $product    = wc_get_product( $product_id );
        if ( ! $product ) {
            return array( 'success' => false, 'message' => __( 'Invalid product ID.', 'arthur-ai' ) );
        }
        $content = wp_kses_post( (string) $payload['usp_block'] );
        update_post_meta( $product_id, '_arthur_ai_usp_block', $content );
        return array( 'success' => true, 'message' => __( 'USP block saved.', 'arthur-ai' ), 'product_id' => $product_id );
    }
}
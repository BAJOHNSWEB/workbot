<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Duplicate a WooCommerce product, optionally including variations.
 *
 * This action copies the core product fields, description, pricing,
 * images, categories, tags and meta. For variable products, variations
 * can also be duplicated when include_variations is true.
 */
class Arthur_AI_Action_Duplicate_Product implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'duplicate_product';
    }
    public function get_label() {
        return __( 'Duplicate Product', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['product_id'] ) ) {
            return array( 'success' => false, 'message' => __( 'product_id is required.', 'arthur-ai' ) );
        }
        $product_id        = intval( $payload['product_id'] );
        $include_variations = isset( $payload['include_variations'] ) ? (bool) $payload['include_variations'] : false;
        $product           = wc_get_product( $product_id );
        if ( ! $product ) {
            return array( 'success' => false, 'message' => __( 'Product not found.', 'arthur-ai' ) );
        }
        $type = $product->get_type();
        // Create new product of same type
        if ( 'variable' === $type ) {
            $new = new WC_Product_Variable();
        } elseif ( 'grouped' === $type ) {
            $new = new WC_Product_Grouped();
        } elseif ( 'external' === $type ) {
            $new = new WC_Product_External();
        } elseif ( 'simple' === $type ) {
            $new = new WC_Product_Simple();
        } else {
            // Fallback to simple
            $new = new WC_Product_Simple();
        }
        // Copy basic fields
        $new->set_name( $product->get_name() . ' (Copy)' );
        $new->set_description( $product->get_description() );
        $new->set_short_description( $product->get_short_description() );
        $new->set_regular_price( $product->get_regular_price() );
        $new->set_sale_price( $product->get_sale_price() );
        // Copy stock
        if ( $product->get_manage_stock() ) {
            $new->set_manage_stock( true );
            $new->set_stock_quantity( $product->get_stock_quantity() );
        }
        // Copy SKU (append random suffix)
        $sku = $product->get_sku();
        if ( $sku ) {
            $new->set_sku( $sku . '-' . wp_generate_password( 4, false ) );
        }
        // Copy featured image
        $image_id = $product->get_image_id();
        if ( $image_id ) {
            $new->set_image_id( $image_id );
        }
        // Copy gallery
        $gallery_ids = $product->get_gallery_image_ids();
        if ( $gallery_ids ) {
            $new->set_gallery_image_ids( $gallery_ids );
        }
        // Copy attributes
        $new->set_attributes( $product->get_attributes() );
        // Save to get ID
        $new_product_id = $new->save();
        // Copy taxonomy terms (categories/tags)
        $taxonomies = array( 'product_cat', 'product_tag' );
        foreach ( $taxonomies as $tax ) {
            $terms = wp_get_object_terms( $product_id, $tax, array( 'fields' => 'ids' ) );
            if ( $terms && ! is_wp_error( $terms ) ) {
                wp_set_object_terms( $new_product_id, $terms, $tax );
            }
        }
        // Copy post meta (excluding some keys)
        $exclude_meta = array( '_edit_lock', '_edit_last', '_price', '_stock', '_stock_status', '_regular_price', '_sale_price', '_thumbnail_id' );
        $meta        = get_post_meta( $product_id );
        foreach ( $meta as $key => $vals ) {
            if ( in_array( $key, $exclude_meta, true ) ) {
                continue;
            }
            foreach ( $vals as $val ) {
                add_post_meta( $new_product_id, $key, maybe_unserialize( $val ) );
            }
        }
        // Duplicate variations if requested
        if ( $include_variations && 'variable' === $type ) {
            $variation_ids = $product->get_children();
            foreach ( $variation_ids as $var_id ) {
                $var_product = wc_get_product( $var_id );
                if ( ! $var_product ) {
                    continue;
                }
                $new_var = new WC_Product_Variation();
                $new_var->set_parent_id( $new_product_id );
                $new_var->set_attributes( $var_product->get_attributes() );
                $new_var->set_regular_price( $var_product->get_regular_price() );
                $new_var->set_sale_price( $var_product->get_sale_price() );
                $new_var->set_sku( $var_product->get_sku() ? $var_product->get_sku() . '-' . wp_generate_password( 4, false ) : '' );
                if ( $var_product->get_manage_stock() ) {
                    $new_var->set_manage_stock( true );
                    $new_var->set_stock_quantity( $var_product->get_stock_quantity() );
                }
                $new_var->save();
            }
        }
        return array( 'success' => true, 'product_id' => $new_product_id, 'message' => __( 'Product duplicated.', 'arthur-ai' ) );
    }
}
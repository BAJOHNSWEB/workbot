<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Reorganise the WooCommerce product taxonomy hierarchy.
 *
 * This action accepts an array of term items with new parent and slug.
 * It uses wp_update_term to apply the changes. Only term_id and
 * parent_id are required; slug is optional.
 */
class Arthur_AI_Action_Reorganise_Product_Taxonomy implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'reorganise_product_taxonomy';
    }
    public function get_label() {
        return __( 'Reorganise Product Taxonomy', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        $items = isset( $payload['items'] ) && is_array( $payload['items'] ) ? $payload['items'] : array();
        if ( empty( $items ) ) {
            return array( 'success' => false, 'message' => __( 'No items provided.', 'arthur-ai' ) );
        }
        $updated = array();
        foreach ( $items as $item ) {
            if ( ! is_array( $item ) || ! isset( $item['term_id'] ) ) {
                continue;
            }
            $term_id  = intval( $item['term_id'] );
            $parent   = isset( $item['parent_id'] ) ? intval( $item['parent_id'] ) : 0;
            $slug     = isset( $item['slug'] ) ? sanitize_title( (string) $item['slug'] ) : '';
            $args     = array();
            $args['parent'] = $parent;
            if ( $slug ) {
                $args['slug'] = $slug;
            }
            $term = wp_update_term( $term_id, 'product_cat', $args );
            if ( ! is_wp_error( $term ) ) {
                $updated[] = $term_id;
            }
        }
        return array( 'success' => true, 'updated' => $updated, 'message' => __( 'Product taxonomy reorganised.', 'arthur-ai' ) );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Update product attributes and regenerate variations.
 *
 * This action updates the attribute definitions on a product and
 * optionally regenerates variations based on provided definitions.
 */
class Arthur_AI_Action_Update_Product_Attributes implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'update_product_attributes';
    }
    public function get_label() {
        return __( 'Update Product Attributes', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['product_id'] ) ) {
            return array( 'success' => false, 'message' => __( 'product_id is required.', 'arthur-ai' ) );
        }
        $product = wc_get_product( intval( $payload['product_id'] ) );
        if ( ! $product ) {
            return array( 'success' => false, 'message' => __( 'Product not found.', 'arthur-ai' ) );
        }
        $attributes = isset( $payload['attributes'] ) && is_array( $payload['attributes'] ) ? $payload['attributes'] : array();
        $variations = isset( $payload['variations'] ) && is_array( $payload['variations'] ) ? $payload['variations'] : array();
        // Update attributes on product
        $attr_objects = array();
        foreach ( $attributes as $name => $values ) {
            $taxonomy = wc_sanitize_taxonomy_name( $name );
            $values   = is_array( $values ) ? $values : array( $values );
            $options  = array();
            if ( taxonomy_exists( $taxonomy ) ) {
                foreach ( $values as $val ) {
                    if ( is_numeric( $val ) ) {
                        $options[] = intval( $val );
                    } else {
                        $term = term_exists( $val, $taxonomy );
                        if ( $term ) {
                            $options[] = is_array( $term ) ? $term['term_id'] : intval( $term );
                        } else {
                            $new = wp_insert_term( $val, $taxonomy );
                            if ( ! is_wp_error( $new ) && isset( $new['term_id'] ) ) {
                                $options[] = $new['term_id'];
                            }
                        }
                    }
                }
            } else {
                $options = array_map( 'wc_clean', $values );
            }
            $attr = new WC_Product_Attribute();
            $attr->set_name( $taxonomy );
            $attr->set_options( $options );
            $attr->set_visible( true );
            // For variable products, mark as variation attribute
            $attr->set_variation( $product->is_type( 'variable' ) );
            $attr_objects[] = $attr;
        }
        if ( $attr_objects ) {
            $product->set_attributes( $attr_objects );
            $product->save();
        }
        // Regenerate variations if requested
        $created_variations = array();
        if ( $variations && $product->is_type( 'variable' ) ) {
            // Remove existing variations
            $existing_variations = $product->get_children();
            foreach ( $existing_variations as $child_id ) {
                wp_delete_post( $child_id, true );
            }
            foreach ( $variations as $var_def ) {
                if ( ! is_array( $var_def ) ) {
                    continue;
                }
                $variation = new WC_Product_Variation();
                $variation->set_parent_id( $product->get_id() );
                // Attributes mapping
                if ( isset( $var_def['attributes'] ) && is_array( $var_def['attributes'] ) ) {
                    $attrs = array();
                    foreach ( $var_def['attributes'] as $attr_name => $attr_value ) {
                        $attrs[ wc_sanitize_taxonomy_name( $attr_name ) ] = $attr_value;
                    }
                    $variation->set_attributes( $attrs );
                }
                if ( isset( $var_def['regular_price'] ) ) {
                    $variation->set_regular_price( (string) $var_def['regular_price'] );
                }
                if ( isset( $var_def['sale_price'] ) ) {
                    $variation->set_sale_price( (string) $var_def['sale_price'] );
                }
                if ( isset( $var_def['sku'] ) ) {
                    $variation->set_sku( sanitize_text_field( (string) $var_def['sku'] ) );
                }
                if ( isset( $var_def['stock_quantity'] ) ) {
                    $variation->set_manage_stock( true );
                    $variation->set_stock_quantity( intval( $var_def['stock_quantity'] ) );
                }
                $var_id = $variation->save();
                if ( $var_id ) {
                    $created_variations[] = $var_id;
                }
            }
        }
        return array( 'success' => true, 'created_variations' => $created_variations, 'message' => __( 'Attributes and variations updated.', 'arthur-ai' ) );
    }
}
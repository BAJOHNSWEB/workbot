<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Modify WooCommerce checkout fields.
 *
 * Accepts a configuration array keyed by checkout section (billing, shipping,
 * account) with field subarrays specifying 'label', 'required' and/or
 * 'enabled' values. The configuration is stored in
 * arthur_ai_woo_checkout_fields_config and applied by the Woo customiser.
 */
class Arthur_AI_Action_Woocommerce_Change_Checkout_Fields implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'woocommerce_change_checkout_fields';
    }
    public function get_label() {
        return __( 'WooCommerce: Change Checkout Fields', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['config'] ) || ! is_array( $payload['config'] ) ) {
            return array( 'success' => false, 'message' => __( 'config array is required.', 'arthur-ai' ) );
        }
        $config = array();
        foreach ( $payload['config'] as $section => $fields ) {
            if ( ! is_array( $fields ) ) {
                continue;
            }
            $section_key = sanitize_key( (string) $section );
            foreach ( $fields as $field_key => $settings ) {
                if ( ! is_array( $settings ) ) {
                    continue;
                }
                $key = sanitize_key( (string) $field_key );
                $cfg = array();
                if ( isset( $settings['label'] ) ) {
                    $cfg['label'] = sanitize_text_field( (string) $settings['label'] );
                }
                if ( isset( $settings['required'] ) ) {
                    $cfg['required'] = (bool) $settings['required'];
                }
                if ( isset( $settings['enabled'] ) ) {
                    $cfg['enabled'] = (bool) $settings['enabled'];
                }
                if ( ! isset( $config[ $section_key ] ) ) {
                    $config[ $section_key ] = array();
                }
                $config[ $section_key ][ $key ] = $cfg;
            }
        }
        update_option( 'arthur_ai_woo_checkout_fields_config', $config );
        return array( 'success' => true, 'message' => __( 'Checkout fields configuration updated.', 'arthur-ai' ) );
    }
}
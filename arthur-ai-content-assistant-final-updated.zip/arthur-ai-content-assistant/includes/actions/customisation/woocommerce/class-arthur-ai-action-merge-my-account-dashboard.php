<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Merge WooCommerce My Account dashboard with custom content.
 *
 * This action stores block/HTML content that will be output at the top
 * of the My Account dashboard via the account customiser helper. It
 * overwrites any previously merged content.
 */
class Arthur_AI_Action_Merge_My_Account_Dashboard implements Arthur_AI_Action_Interface {

    /**
     * Get slug.
     *
     * @return string
     */
    public function get_type() {
        return 'merge_my_account_dashboard';
    }

    /**
     * Get label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Merge My Account Dashboard', 'arthur-ai' );
    }

    /**
     * Execute action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['content'] ) ) {
            return array( 'success' => false, 'message' => __( 'content is required.', 'arthur-ai' ) );
        }
        $content = wp_kses_post( (string) $payload['content'] );
        update_option( 'arthur_ai_my_account_merge_dashboard', $content );
        return array( 'success' => true, 'message' => __( 'Dashboard content saved.', 'arthur-ai' ) );
    }
}
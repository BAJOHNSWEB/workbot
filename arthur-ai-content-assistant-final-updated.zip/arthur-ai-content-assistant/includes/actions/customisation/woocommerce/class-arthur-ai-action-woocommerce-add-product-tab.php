<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Add a custom tab to WooCommerce product pages.
 *
 * The payload should include 'title' and 'content' strings. Optional
 * 'priority' sets the order. These values are stored in
 * arthur_ai_woo_product_tab and used by the Woo customiser filter.
 */
class Arthur_AI_Action_Woocommerce_Add_Product_Tab implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'woocommerce_add_product_tab';
    }
    public function get_label() {
        return __( 'WooCommerce: Add Product Tab', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['title'] ) || ! isset( $payload['content'] ) ) {
            return array( 'success' => false, 'message' => __( 'title and content are required.', 'arthur-ai' ) );
        }
        $tab = array(
            'title'   => (string) $payload['title'],
            'content' => (string) $payload['content'],
        );
        if ( isset( $payload['priority'] ) && is_numeric( $payload['priority'] ) ) {
            $tab['priority'] = (int) $payload['priority'];
        }
        update_option( 'arthur_ai_woo_product_tab', $tab );
        return array( 'success' => true, 'message' => __( 'Product tab settings updated.', 'arthur-ai' ) );
    }
}
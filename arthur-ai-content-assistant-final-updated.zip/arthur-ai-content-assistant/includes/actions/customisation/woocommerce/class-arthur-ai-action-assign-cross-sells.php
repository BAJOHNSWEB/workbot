<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Assign cross‑sells and up‑sells to a product.
 *
 * This action updates the cross‑sell and up‑sell associations for a
 * specified product. The payload must include the product ID and
 * optionally arrays of related product IDs for cross sells and
 * up sells. Existing associations will be replaced. Invalid IDs
 * are ignored. Returns the product ID and final assigned lists.
 */
class Arthur_AI_Action_Assign_Cross_Sells implements Arthur_AI_Action_Interface {

    /**
     * Get slug.
     *
     * @return string
     */
    public function get_type() {
        return 'assign_cross_sells';
    }

    /**
     * Get label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Assign Cross Sells / Up Sells', 'arthur-ai' );
    }

    /**
     * Execute action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['product_id'] ) ) {
            return array( 'success' => false, 'message' => __( 'product_id is required.', 'arthur-ai' ) );
        }
        $product = wc_get_product( intval( $payload['product_id'] ) );
        if ( ! $product ) {
            return array( 'success' => false, 'message' => __( 'Invalid product ID.', 'arthur-ai' ) );
        }
        $cross_ids = array();
        if ( isset( $payload['cross_sells'] ) && is_array( $payload['cross_sells'] ) ) {
            foreach ( $payload['cross_sells'] as $id ) {
                $id = intval( $id );
                if ( wc_get_product( $id ) ) {
                    $cross_ids[] = $id;
                }
            }
        }
        $up_ids = array();
        if ( isset( $payload['up_sells'] ) && is_array( $payload['up_sells'] ) ) {
            foreach ( $payload['up_sells'] as $id ) {
                $id = intval( $id );
                if ( wc_get_product( $id ) ) {
                    $up_ids[] = $id;
                }
            }
        }
        $product->set_cross_sell_ids( $cross_ids );
        $product->set_upsell_ids( $up_ids );
        $product->save();
        return array(
            'success'        => true,
            'product_id'     => $product->get_id(),
            'cross_sells'    => $cross_ids,
            'up_sells'       => $up_ids,
        );
    }
}
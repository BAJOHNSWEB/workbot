<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Toggle WooCommerce guest checkout mode.
 *
 * This action sets whether guest checkout is allowed. It stores the
 * preference in the option 'arthur_ai_allow_guest_checkout'. The
 * WooCommerce customiser helper reads this option and overrides
 * WooCommerce’s own guest checkout setting via a filter.
 */
class Arthur_AI_Action_Set_Guest_Checkout_Mode implements Arthur_AI_Action_Interface {

    /**
     * Get the slug.
     *
     * @return string
     */
    public function get_type() {
        return 'set_guest_checkout_mode';
    }

    /**
     * Get label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Set Guest Checkout Mode', 'arthur-ai' );
    }

    /**
     * Execute the action to set guest checkout mode.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['allow_guest_checkout'] ) ) {
            return array( 'success' => false, 'message' => __( 'allow_guest_checkout is required.', 'arthur-ai' ) );
        }
        $allow = (bool) $payload['allow_guest_checkout'];
        update_option( 'arthur_ai_allow_guest_checkout', $allow );
        return array( 'success' => true, 'allow_guest_checkout' => $allow );
    }
}
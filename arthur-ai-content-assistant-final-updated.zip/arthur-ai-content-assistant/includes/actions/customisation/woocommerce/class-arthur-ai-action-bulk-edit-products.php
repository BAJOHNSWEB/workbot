<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Bulk edit WooCommerce products.
 *
 * This action accepts a list of products and updates selected fields
 * such as regular price, sale price, SKU and stock quantity. It uses
 * the WooCommerce product CRUD API. On completion it returns a
 * summary of updated product IDs.
 */
class Arthur_AI_Action_Bulk_Edit_Products implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'bulk_edit_products';
    }
    public function get_label() {
        return __( 'Bulk Edit Products', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['items'] ) || ! is_array( $payload['items'] ) || empty( $payload['items'] ) ) {
            return array( 'success' => false, 'message' => __( 'No products provided.', 'arthur-ai' ) );
        }
        $updated = array();
        foreach ( $payload['items'] as $item ) {
            if ( ! is_array( $item ) || ! isset( $item['product_id'] ) ) {
                continue;
            }
            $product_id = intval( $item['product_id'] );
            $product    = wc_get_product( $product_id );
            if ( ! $product ) {
                continue;
            }
            $changed = false;
            if ( isset( $item['regular_price'] ) ) {
                $product->set_regular_price( (string) $item['regular_price'] );
                $changed = true;
            }
            if ( isset( $item['sale_price'] ) ) {
                $product->set_sale_price( (string) $item['sale_price'] );
                $changed = true;
            }
            if ( isset( $item['sku'] ) ) {
                $product->set_sku( sanitize_text_field( (string) $item['sku'] ) );
                $changed = true;
            }
            if ( isset( $item['stock_quantity'] ) ) {
                $product->set_manage_stock( true );
                $product->set_stock_quantity( intval( $item['stock_quantity'] ) );
                $changed = true;
            }
            if ( $changed ) {
                $product->save();
                $updated[] = $product_id;
            }
        }
        return array( 'success' => true, 'updated' => $updated, 'message' => __( 'Products updated.', 'arthur-ai' ) );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Generate a templated response to a customer order query.
 *
 * This action inserts a private note on the order containing the
 * AI‑generated response. Optionally, the note can be designated as
 * visible to the customer. This does not send an email directly but
 * stores the response in order notes for reference. Returns the ID of
 * the new note.
 */
class Arthur_AI_Action_Generate_Order_Response implements Arthur_AI_Action_Interface {

    /**
     * Get slug.
     *
     * @return string
     */
    public function get_type() {
        return 'generate_order_response';
    }

    /**
     * Get human label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Generate Order Response', 'arthur-ai' );
    }

    /**
     * Execute action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['order_id'] ) || ! isset( $payload['response_content'] ) ) {
            return array( 'success' => false, 'message' => __( 'order_id and response_content are required.', 'arthur-ai' ) );
        }
        $order = wc_get_order( intval( $payload['order_id'] ) );
        if ( ! $order ) {
            return array( 'success' => false, 'message' => __( 'Invalid order ID.', 'arthur-ai' ) );
        }
        $content    = wp_kses_post( (string) $payload['response_content'] );
        $is_private = true;
        if ( isset( $payload['private'] ) ) {
            $is_private = (bool) $payload['private'];
        }
        // Add as order note
        $note_id = $order->add_order_note( $content, ! $is_private );
        $order->save();
        return array( 'success' => true, 'order_id' => $order->get_id(), 'note_id' => $note_id );
    }
}
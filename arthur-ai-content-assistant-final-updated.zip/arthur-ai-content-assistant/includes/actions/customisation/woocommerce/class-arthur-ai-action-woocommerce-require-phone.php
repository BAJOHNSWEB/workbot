<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Require the billing phone field during WooCommerce checkout.
 *
 * Stores a boolean flag in arthur_ai_woo_require_phone. When enabled,
 * the Woo customiser ensures billing phone is marked required.
 */
class Arthur_AI_Action_Woocommerce_Require_Phone implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'woocommerce_require_phone';
    }
    public function get_label() {
        return __( 'WooCommerce: Require Phone', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $enabled = false;
        if ( isset( $payload['enabled'] ) ) {
            $enabled = (bool) $payload['enabled'];
        }
        update_option( 'arthur_ai_woo_require_phone', $enabled );
        return array( 'success' => true, 'message' => __( 'Phone requirement setting updated.', 'arthur-ai' ) );
    }
}
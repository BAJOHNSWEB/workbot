<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure WooCommerce shipping zones and methods.
 *
 * Stores a simplified configuration of shipping zones. Each zone may
 * include a name and an array of methods with settings. The actual
 * creation and updating of zones and methods is handled by the
 * WooCommerce customiser helper during runtime. This action merely
 * sanitises and saves the configuration.
 */
class Arthur_AI_Action_Configure_Shipping implements Arthur_AI_Action_Interface {

    /**
     * Get slug.
     *
     * @return string
     */
    public function get_type() {
        return 'configure_shipping';
    }

    /**
     * Get label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Configure Shipping', 'arthur-ai' );
    }

    /**
     * Execute action to save shipping configuration.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['zones'] ) || ! is_array( $payload['zones'] ) ) {
            return array( 'success' => false, 'message' => __( 'zones array is required.', 'arthur-ai' ) );
        }
        $config = array();
        foreach ( $payload['zones'] as $zone ) {
            if ( ! is_array( $zone ) || ! isset( $zone['name'] ) ) {
                continue;
            }
            $zone_entry = array( 'name' => sanitize_text_field( (string) $zone['name'] ) );
            if ( isset( $zone['methods'] ) && is_array( $zone['methods'] ) ) {
                $zone_entry['methods'] = array();
                foreach ( $zone['methods'] as $method ) {
                    if ( ! is_array( $method ) || ! isset( $method['method_id'] ) ) {
                        continue;
                    }
                    $method_id = sanitize_key( (string) $method['method_id'] );
                    $settings  = array();
                    if ( isset( $method['settings'] ) && is_array( $method['settings'] ) ) {
                        foreach ( $method['settings'] as $k => $v ) {
                            $settings[ sanitize_key( (string) $k ) ] = is_scalar( $v ) ? sanitize_text_field( (string) $v ) : $v;
                        }
                    }
                    $zone_entry['methods'][] = array(
                        'method_id' => $method_id,
                        'settings'  => $settings,
                    );
                }
            }
            $config[] = $zone_entry;
        }
        update_option( 'arthur_ai_shipping_config', $config );
        return array( 'success' => true, 'config' => $config );
    }
}
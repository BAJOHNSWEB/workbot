<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Automatically tag new WooCommerce orders with custom metadata.
 *
 * The payload should provide a 'tags' array of strings. These tags are
 * stored in arthur_ai_woo_auto_order_tags and saved as order meta when
 * new orders are created. This is a simple metadata attachment; it does
 * not create a taxonomy.
 */
class Arthur_AI_Action_Woocommerce_Auto_Tag_Orders implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'woocommerce_auto_tag_orders';
    }
    public function get_label() {
        return __( 'WooCommerce: Auto Tag Orders', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['tags'] ) || ! is_array( $payload['tags'] ) ) {
            return array( 'success' => false, 'message' => __( 'tags array is required.', 'arthur-ai' ) );
        }
        $tags = array();
        foreach ( $payload['tags'] as $tag ) {
            $tag = sanitize_text_field( (string) $tag );
            if ( '' !== $tag ) {
                $tags[] = $tag;
            }
        }
        update_option( 'arthur_ai_woo_auto_order_tags', $tags );
        return array( 'success' => true, 'message' => __( 'Order tagging rules updated.', 'arthur-ai' ) );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure WooCommerce tax classes and rates.
 *
 * This action accepts definitions for tax classes and tax rates and
 * stores them in the option 'arthur_ai_tax_config'. The WooCommerce
 * customiser helper reads this configuration and applies it using
 * WooCommerce APIs. Each rate definition should include
 * `tax_rate_country`, `tax_rate_state`, `tax_rate`, `tax_rate_name`,
 * `tax_rate_class`, `tax_rate_priority`, `tax_rate_compound` and
 * `tax_rate_shipping`.
 */
class Arthur_AI_Action_Configure_Tax_Rates implements Arthur_AI_Action_Interface {

    /**
     * Get slug.
     *
     * @return string
     */
    public function get_type() {
        return 'configure_tax_rates';
    }

    /**
     * Get label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Configure Tax Rates', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        $config = array();
        // Tax classes
        $classes = array();
        if ( isset( $payload['tax_classes'] ) && is_array( $payload['tax_classes'] ) ) {
            foreach ( $payload['tax_classes'] as $class ) {
                $classes[] = sanitize_text_field( (string) $class );
            }
        }
        $config['classes'] = $classes;
        // Rates
        $rates = array();
        if ( isset( $payload['rates'] ) && is_array( $payload['rates'] ) ) {
            foreach ( $payload['rates'] as $rate ) {
                if ( ! is_array( $rate ) ) {
                    continue;
                }
                $rate_def = array();
                // Accept keys as provided; sanitise individually
                foreach ( $rate as $k => $v ) {
                    $key = sanitize_key( (string) $k );
                    if ( in_array( $key, array( 'tax_rate_country', 'tax_rate_state', 'tax_rate_name', 'tax_rate_class' ), true ) ) {
                        $rate_def[ $key ] = sanitize_text_field( (string) $v );
                    } elseif ( 'tax_rate' === $key ) {
                        $rate_def[ $key ] = number_format( floatval( $v ), 4, '.', '' );
                    } elseif ( in_array( $key, array( 'tax_rate_priority', 'tax_rate_compound', 'tax_rate_shipping' ), true ) ) {
                        $rate_def[ $key ] = (int) $v;
                    }
                }
                if ( ! empty( $rate_def ) ) {
                    $rates[] = $rate_def;
                }
            }
        }
        $config['rates'] = $rates;
        update_option( 'arthur_ai_tax_config', $config );
        return array( 'success' => true, 'config' => $config );
    }
}
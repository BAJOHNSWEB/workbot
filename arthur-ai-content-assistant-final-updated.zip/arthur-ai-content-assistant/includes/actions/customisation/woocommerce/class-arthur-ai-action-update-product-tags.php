<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Create or update product tags.
 *
 * Allows the AI to create new product tags or update existing ones. The
 * payload must include a `tags` array containing either term IDs or
 * tag names. Optional fields `description` and `slug` apply when
 * creating or updating tags by name. When a numeric ID is provided,
 * only the description and slug will be updated if present. Returns
 * an array of term IDs for the processed tags.
 */
class Arthur_AI_Action_Update_Product_Tags implements Arthur_AI_Action_Interface {

    /**
     * Get the action type slug.
     *
     * @return string
     */
    public function get_type() {
        return 'update_product_tags';
    }

    /**
     * Get a human‑readable label for this action.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Update Product Tags', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['tags'] ) || ! is_array( $payload['tags'] ) ) {
            return array( 'success' => false, 'message' => __( 'tags array is required.', 'arthur-ai' ) );
        }
        $description = isset( $payload['description'] ) ? sanitize_textarea_field( (string) $payload['description'] ) : '';
        $slug        = isset( $payload['slug'] ) ? sanitize_title( (string) $payload['slug'] ) : '';
        $term_ids    = array();
        foreach ( $payload['tags'] as $tag ) {
            $term_id = 0;
            if ( is_numeric( $tag ) ) {
                $term_id = intval( $tag );
                $term    = get_term( $term_id, 'product_tag' );
                if ( $term instanceof WP_Term ) {
                    $args = array();
                    if ( '' !== $description ) {
                        $args['description'] = $description;
                    }
                    if ( '' !== $slug ) {
                        $args['slug'] = $slug;
                    }
                    if ( ! empty( $args ) ) {
                        wp_update_term( $term_id, 'product_tag', $args );
                    }
                } else {
                    // Invalid ID, skip.
                    continue;
                }
            } else {
                $name     = sanitize_text_field( (string) $tag );
                $existing = get_term_by( 'name', $name, 'product_tag' );
                if ( $existing ) {
                    $term_id = $existing->term_id;
                    $args    = array();
                    if ( '' !== $description ) {
                        $args['description'] = $description;
                    }
                    if ( '' !== $slug ) {
                        $args['slug'] = $slug;
                    }
                    if ( ! empty( $args ) ) {
                        wp_update_term( $term_id, 'product_tag', $args );
                    }
                } else {
                    $args = array();
                    if ( '' !== $description ) {
                        $args['description'] = $description;
                    }
                    if ( '' !== $slug ) {
                        $args['slug'] = $slug;
                    }
                    $result = wp_insert_term( $name, 'product_tag', $args );
                    if ( ! is_wp_error( $result ) && isset( $result['term_id'] ) ) {
                        $term_id = $result['term_id'];
                    }
                }
            }
            if ( $term_id ) {
                $term_ids[] = $term_id;
            }
        }
        return array( 'success' => true, 'tag_ids' => $term_ids );
    }
}
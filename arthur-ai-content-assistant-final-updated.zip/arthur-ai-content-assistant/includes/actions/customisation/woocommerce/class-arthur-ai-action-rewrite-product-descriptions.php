<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Rewrite WooCommerce product descriptions and short descriptions.
 *
 * This action allows the AI to update the long and short descriptions
 * for one or more products. It sanitises and applies the new
 * descriptions using WooCommerce CRUD. The payload must contain an
 * array of items, each with a `product_id` and the new description
 * fields. Returns an array summarising which products were updated.
 */
class Arthur_AI_Action_Rewrite_Product_Descriptions implements Arthur_AI_Action_Interface {

    /**
     * Get the action type.
     *
     * @return string
     */
    public function get_type() {
        return 'rewrite_product_descriptions';
    }

    /**
     * Get a human label for this action.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Rewrite Product Descriptions', 'arthur-ai' );
    }

    /**
     * Execute the action to rewrite product descriptions.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['items'] ) || ! is_array( $payload['items'] ) ) {
            return array( 'success' => false, 'message' => __( 'items array is required.', 'arthur-ai' ) );
        }
        $results = array();
        foreach ( $payload['items'] as $item ) {
            if ( ! isset( $item['product_id'] ) ) {
                continue;
            }
            $product = wc_get_product( intval( $item['product_id'] ) );
            if ( ! $product ) {
                continue;
            }
            $updated = false;
            if ( isset( $item['new_description'] ) ) {
                $desc = wp_kses_post( (string) $item['new_description'] );
                $product->set_description( $desc );
                $updated = true;
            }
            if ( isset( $item['new_short_description'] ) ) {
                $short = wp_kses_post( (string) $item['new_short_description'] );
                $product->set_short_description( $short );
                $updated = true;
            }
            if ( $updated ) {
                $product->save();
                $results[] = $product->get_id();
            }
        }
        return array( 'success' => true, 'updated_product_ids' => $results );
    }
}
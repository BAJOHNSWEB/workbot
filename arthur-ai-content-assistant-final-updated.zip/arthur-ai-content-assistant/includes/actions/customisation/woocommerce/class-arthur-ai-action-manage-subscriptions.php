<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Manage WooCommerce Subscriptions plans and settings.
 *
 * This action allows creation, updating and deletion of subscription
 * products when WooCommerce Subscriptions is active. It can also
 * store custom renewal email content for later use. For creation
 * and updates, pricing and schedule details must be provided. If
 * the subscription plugin is not active, an error is returned.
 */
class Arthur_AI_Action_Manage_Subscriptions implements Arthur_AI_Action_Interface {

    /**
     * Get slug.
     *
     * @return string
     */
    public function get_type() {
        return 'manage_subscriptions';
    }

    /**
     * Get human label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Manage Subscriptions', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        // Ensure the Subscriptions plugin is active
        if ( ! class_exists( 'WC_Subscriptions' ) && ! class_exists( 'WC_Subscriptions_Product' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce Subscriptions is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['operation'] ) ) {
            return array( 'success' => false, 'message' => __( 'operation is required.', 'arthur-ai' ) );
        }
        $operation = strtolower( sanitize_key( (string) $payload['operation'] ) );
        if ( ! in_array( $operation, array( 'create', 'update', 'delete' ), true ) ) {
            return array( 'success' => false, 'message' => __( 'Invalid operation.', 'arthur-ai' ) );
        }
        // Optional email content override
        if ( isset( $payload['email_content'] ) ) {
            update_option( 'arthur_ai_subscription_email_content', wp_kses_post( (string) $payload['email_content'] ) );
        }
        // Handle product operations
        if ( 'create' === $operation ) {
            // Required: title, price, billing_period, interval
            if ( ! isset( $payload['title'], $payload['price'], $payload['billing_period'], $payload['interval'] ) ) {
                return array( 'success' => false, 'message' => __( 'title, price, billing_period and interval are required.', 'arthur-ai' ) );
            }
            $product = new WC_Product_Subscription();
            $product->set_name( sanitize_text_field( (string) $payload['title'] ) );
            $product->set_regular_price( floatval( $payload['price'] ) );
            $product->set_sku( isset( $payload['sku'] ) ? sanitize_text_field( (string) $payload['sku'] ) : '' );
            // Set subscription details
            $product->set_subscriptions_price( floatval( $payload['price'] ) );
            $product->set_subscriptions_period( sanitize_text_field( (string) $payload['billing_period'] ) );
            $product->set_subscriptions_period_interval( intval( $payload['interval'] ) );
            if ( isset( $payload['length'] ) ) {
                $product->set_subscriptions_subscription_length( intval( $payload['length'] ) );
            }
            $product->save();
            return array( 'success' => true, 'product_id' => $product->get_id() );
        }
        // Load existing subscription product
        $product = null;
        if ( isset( $payload['product_id'] ) ) {
            $product = wc_get_product( intval( $payload['product_id'] ) );
        }
        if ( ! $product || ! $product->get_id() || ! $product->is_type( 'subscription' ) ) {
            return array( 'success' => false, 'message' => __( 'Subscription product not found.', 'arthur-ai' ) );
        }
        if ( 'delete' === $operation ) {
            wp_delete_post( $product->get_id(), true );
            return array( 'success' => true, 'deleted' => $product->get_id() );
        }
        // Update existing subscription product
        if ( isset( $payload['title'] ) ) {
            $product->set_name( sanitize_text_field( (string) $payload['title'] ) );
        }
        if ( isset( $payload['price'] ) ) {
            $product->set_regular_price( floatval( $payload['price'] ) );
            $product->set_subscriptions_price( floatval( $payload['price'] ) );
        }
        if ( isset( $payload['billing_period'] ) ) {
            $product->set_subscriptions_period( sanitize_text_field( (string) $payload['billing_period'] ) );
        }
        if ( isset( $payload['interval'] ) ) {
            $product->set_subscriptions_period_interval( intval( $payload['interval'] ) );
        }
        if ( isset( $payload['length'] ) ) {
            $product->set_subscriptions_subscription_length( intval( $payload['length'] ) );
        }
        $product->save();
        return array( 'success' => true, 'product_id' => $product->get_id() );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Manage WooCommerce Bookings products (basic operations).
 *
 * This action provides minimal CRUD for booking products when the
 * WooCommerce Bookings extension is active. It supports creating,
 * updating and deleting booking products with basic fields. It does
 * not implement advanced booking rules or availability settings.
 */
class Arthur_AI_Action_Manage_Bookings implements Arthur_AI_Action_Interface {

    /**
     * Get slug.
     *
     * @return string
     */
    public function get_type() {
        return 'manage_bookings';
    }

    /**
     * Get label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Manage Bookings', 'arthur-ai' );
    }

    /**
     * Execute action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WC_Bookings' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce Bookings is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['operation'] ) ) {
            return array( 'success' => false, 'message' => __( 'operation is required.', 'arthur-ai' ) );
        }
        $operation = strtolower( sanitize_key( (string) $payload['operation'] ) );
        if ( ! in_array( $operation, array( 'create', 'update', 'delete' ), true ) ) {
            return array( 'success' => false, 'message' => __( 'Invalid operation.', 'arthur-ai' ) );
        }
        // Create booking product
        if ( 'create' === $operation ) {
            if ( ! isset( $payload['title'], $payload['price'] ) ) {
                return array( 'success' => false, 'message' => __( 'title and price are required.', 'arthur-ai' ) );
            }
            $product = new WC_Product_Booking();
            $product->set_name( sanitize_text_field( (string) $payload['title'] ) );
            $product->set_regular_price( floatval( $payload['price'] ) );
            $product->save();
            return array( 'success' => true, 'product_id' => $product->get_id() );
        }
        // Load existing booking product
        $product = null;
        if ( isset( $payload['product_id'] ) ) {
            $product = wc_get_product( intval( $payload['product_id'] ) );
        }
        if ( ! $product || ! $product->get_id() || ! $product->is_type( 'booking' ) ) {
            return array( 'success' => false, 'message' => __( 'Booking product not found.', 'arthur-ai' ) );
        }
        if ( 'delete' === $operation ) {
            wp_delete_post( $product->get_id(), true );
            return array( 'success' => true, 'deleted' => $product->get_id() );
        }
        // Update
        if ( isset( $payload['title'] ) ) {
            $product->set_name( sanitize_text_field( (string) $payload['title'] ) );
        }
        if ( isset( $payload['price'] ) ) {
            $product->set_regular_price( floatval( $payload['price'] ) );
        }
        $product->save();
        return array( 'success' => true, 'product_id' => $product->get_id() );
    }
}
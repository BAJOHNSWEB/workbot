<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Manage WooCommerce Memberships plans.
 *
 * This action allows creation, updating and deletion of membership
 * plans when the WooCommerce Memberships extension is active. Basic
 * fields such as plan name, slug and access rules may be provided.
 */
class Arthur_AI_Action_Manage_Memberships implements Arthur_AI_Action_Interface {

    /**
     * Get slug.
     *
     * @return string
     */
    public function get_type() {
        return 'manage_memberships';
    }

    /**
     * Get human label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Manage Memberships', 'arthur-ai' );
    }

    /**
     * Execute action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WC_Memberships' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce Memberships is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['operation'] ) ) {
            return array( 'success' => false, 'message' => __( 'operation is required.', 'arthur-ai' ) );
        }
        $operation = strtolower( sanitize_key( (string) $payload['operation'] ) );
        if ( ! in_array( $operation, array( 'create', 'update', 'delete' ), true ) ) {
            return array( 'success' => false, 'message' => __( 'Invalid operation.', 'arthur-ai' ) );
        }
        // Plan creation
        if ( 'create' === $operation ) {
            if ( ! isset( $payload['name'] ) ) {
                return array( 'success' => false, 'message' => __( 'name is required.', 'arthur-ai' ) );
            }
            $args = array(
                'name'  => sanitize_text_field( (string) $payload['name'] ),
                'slug'  => isset( $payload['slug'] ) ? sanitize_title( (string) $payload['slug'] ) : '',
                'rules' => isset( $payload['rules'] ) && is_array( $payload['rules'] ) ? $payload['rules'] : array(),
            );
            $plan_id = wc_memberships_create_membership_plan( $args );
            return array( 'success' => true, 'plan_id' => $plan_id );
        }
        // For update or delete, need plan ID
        if ( ! isset( $payload['plan_id'] ) ) {
            return array( 'success' => false, 'message' => __( 'plan_id is required.', 'arthur-ai' ) );
        }
        $plan_id = intval( $payload['plan_id'] );
        if ( 'delete' === $operation ) {
            wc_memberships_delete_membership_plan( $plan_id );
            return array( 'success' => true, 'deleted' => $plan_id );
        }
        // Update existing
        $args = array();
        if ( isset( $payload['name'] ) ) {
            $args['name'] = sanitize_text_field( (string) $payload['name'] );
        }
        if ( isset( $payload['slug'] ) ) {
            $args['slug'] = sanitize_title( (string) $payload['slug'] );
        }
        if ( isset( $payload['rules'] ) && is_array( $payload['rules'] ) ) {
            $args['rules'] = $payload['rules'];
        }
        wc_memberships_update_membership_plan( $plan_id, $args );
        return array( 'success' => true, 'plan_id' => $plan_id );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Create or edit WooCommerce product categories.
 *
 * This action accepts an array of categories to create or update. If a
 * category entry is numeric, it is treated as a term ID to update with
 * provided description, parent or slug. If it is a string, a category
 * with that name will be created or updated. Returns a list of term
 * IDs that were created or updated.
 */
class Arthur_AI_Action_Update_Product_Categories implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'update_product_categories';
    }
    public function get_label() {
        return __( 'Update Product Categories', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        $cats  = isset( $payload['categories'] ) && is_array( $payload['categories'] ) ? $payload['categories'] : array();
        $desc  = isset( $payload['description'] ) ? wp_kses_post( (string) $payload['description'] ) : '';
        $parent = isset( $payload['parent'] ) ? intval( $payload['parent'] ) : 0;
        $slug   = isset( $payload['slug'] ) ? sanitize_title( (string) $payload['slug'] ) : '';
        $updated_terms = array();
        foreach ( $cats as $cat ) {
            if ( is_numeric( $cat ) ) {
                $term_id = intval( $cat );
                $args    = array();
                if ( $desc ) {
                    $args['description'] = $desc;
                }
                if ( $parent > 0 ) {
                    $args['parent'] = $parent;
                }
                if ( $slug ) {
                    $args['slug'] = $slug;
                }
                if ( ! empty( $args ) ) {
                    $term = wp_update_term( $term_id, 'product_cat', $args );
                    if ( ! is_wp_error( $term ) ) {
                        $updated_terms[] = $term_id;
                    }
                }
            } elseif ( is_string( $cat ) && '' !== $cat ) {
                $name = sanitize_text_field( $cat );
                $existing = term_exists( $name, 'product_cat' );
                if ( $existing ) {
                    $term_id = is_array( $existing ) ? $existing['term_id'] : intval( $existing );
                    $args    = array();
                    if ( $desc ) {
                        $args['description'] = $desc;
                    }
                    if ( $parent > 0 ) {
                        $args['parent'] = $parent;
                    }
                    if ( $slug ) {
                        $args['slug'] = $slug;
                    }
                    if ( ! empty( $args ) ) {
                        $term = wp_update_term( $term_id, 'product_cat', $args );
                        if ( ! is_wp_error( $term ) ) {
                            $updated_terms[] = $term_id;
                        }
                    }
                } else {
                    $args = array( 'description' => $desc );
                    if ( $parent > 0 ) {
                        $args['parent'] = $parent;
                    }
                    if ( $slug ) {
                        $args['slug'] = $slug;
                    }
                    $term = wp_insert_term( $name, 'product_cat', $args );
                    if ( ! is_wp_error( $term ) && isset( $term['term_id'] ) ) {
                        $updated_terms[] = $term['term_id'];
                    }
                }
            }
        }
        return array( 'success' => true, 'term_ids' => $updated_terms, 'message' => __( 'Categories processed.', 'arthur-ai' ) );
    }
}
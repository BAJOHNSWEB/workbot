<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Add instructions/notes to the WooCommerce checkout page.
 *
 * This action stores arbitrary HTML or block markup to be displayed
 * above the checkout form. The WooCommerce customiser helper
 * outputs the saved content via the `woocommerce_before_checkout_form`
 * action.
 */
class Arthur_AI_Action_Add_Checkout_Instructions implements Arthur_AI_Action_Interface {

    /**
     * Get the slug.
     *
     * @return string
     */
    public function get_type() {
        return 'add_checkout_instructions';
    }

    /**
     * Get label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Add Checkout Instructions', 'arthur-ai' );
    }

    /**
     * Execute the action to save checkout instructions.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['content'] ) ) {
            return array( 'success' => false, 'message' => __( 'content is required.', 'arthur-ai' ) );
        }
        $content = wp_kses_post( (string) $payload['content'] );
        update_option( 'arthur_ai_checkout_instructions', $content );
        return array( 'success' => true, 'message' => __( 'Checkout instructions saved.', 'arthur-ai' ) );
    }
}
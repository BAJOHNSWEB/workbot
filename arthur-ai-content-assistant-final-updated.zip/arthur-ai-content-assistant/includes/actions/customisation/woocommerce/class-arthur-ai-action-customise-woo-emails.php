<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Customise WooCommerce transactional email templates.
 *
 * This action allows the AI to override the subject, heading and body
 * HTML for specific WooCommerce email IDs. The settings are stored
 * in the option 'arthur_ai_woo_email_customisations' and applied by
 * the email customiser helper.
 */
class Arthur_AI_Action_Customise_Woo_Emails implements Arthur_AI_Action_Interface {

    /**
     * Get slug.
     *
     * @return string
     */
    public function get_type() {
        return 'customise_woo_emails';
    }

    /**
     * Get human label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Customise Email Templates', 'arthur-ai' );
    }

    /**
     * Execute action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['email_id'] ) ) {
            return array( 'success' => false, 'message' => __( 'email_id is required.', 'arthur-ai' ) );
        }
        $email_id = sanitize_key( (string) $payload['email_id'] );
        $customisations = get_option( 'arthur_ai_woo_email_customisations', array() );
        if ( ! is_array( $customisations ) ) {
            $customisations = array();
        }
        $entry = isset( $customisations[ $email_id ] ) && is_array( $customisations[ $email_id ] ) ? $customisations[ $email_id ] : array();
        if ( isset( $payload['subject'] ) ) {
            $entry['subject'] = sanitize_text_field( (string) $payload['subject'] );
        }
        if ( isset( $payload['heading'] ) ) {
            $entry['heading'] = sanitize_text_field( (string) $payload['heading'] );
        }
        if ( isset( $payload['body_html'] ) ) {
            $entry['body_html'] = wp_kses_post( (string) $payload['body_html'] );
        }
        $customisations[ $email_id ] = $entry;
        update_option( 'arthur_ai_woo_email_customisations', $customisations );
        return array( 'success' => true, 'email_id' => $email_id, 'settings' => $entry );
    }
}
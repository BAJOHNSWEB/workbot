<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Adjust WooCommerce email triggers.
 *
 * This action allows the AI to enable or disable specific WooCommerce
 * transactional emails. The payload should contain a `rules`
 * associative array keyed by email ID, each specifying an `enabled`
 * boolean. The configuration is stored in the option
 * 'arthur_ai_email_triggers' and applied by the email customiser.
 */
class Arthur_AI_Action_Adjust_Email_Triggers implements Arthur_AI_Action_Interface {

    /**
     * Get type slug.
     *
     * @return string
     */
    public function get_type() {
        return 'adjust_email_triggers';
    }

    /**
     * Get human label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Adjust Email Triggers', 'arthur-ai' );
    }

    /**
     * Execute action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['rules'] ) || ! is_array( $payload['rules'] ) ) {
            return array( 'success' => false, 'message' => __( 'rules array is required.', 'arthur-ai' ) );
        }
        $rules = array();
        foreach ( $payload['rules'] as $email_id => $settings ) {
            $key = sanitize_key( (string) $email_id );
            if ( ! is_array( $settings ) ) {
                continue;
            }
            $entry = array();
            if ( isset( $settings['enabled'] ) ) {
                $entry['enabled'] = (bool) $settings['enabled'];
            }
            if ( ! empty( $entry ) ) {
                $rules[ $key ] = $entry;
            }
        }
        update_option( 'arthur_ai_email_triggers', $rules );
        return array( 'success' => true, 'rules' => $rules );
    }
}
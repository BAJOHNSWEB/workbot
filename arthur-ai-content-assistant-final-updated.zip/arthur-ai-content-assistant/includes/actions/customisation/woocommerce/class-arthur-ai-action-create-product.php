<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Create a new WooCommerce product (simple or variable).
 *
 * This action accepts product details such as title, descriptions,
 * pricing, stock, images and attributes. For variable products it
 * also accepts variation definitions. It returns the new product ID
 * on success. If WooCommerce is not active, it returns an error.
 */
class Arthur_AI_Action_Create_Product implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'create_product';
    }

    public function get_label() {
        return __( 'Create Product', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        $type = isset( $payload['product_type'] ) && 'variable' === $payload['product_type'] ? 'variable' : 'simple';
        $title = isset( $payload['title'] ) ? sanitize_text_field( (string) $payload['title'] ) : '';
        if ( '' === $title ) {
            return array( 'success' => false, 'message' => __( 'Product title is required.', 'arthur-ai' ) );
        }
        $description       = isset( $payload['description'] ) ? wp_kses_post( (string) $payload['description'] ) : '';
        $short_description = isset( $payload['short_description'] ) ? wp_kses_post( (string) $payload['short_description'] ) : '';
        $regular_price     = isset( $payload['regular_price'] ) ? (string) $payload['regular_price'] : '';
        $sale_price        = isset( $payload['sale_price'] ) ? (string) $payload['sale_price'] : '';
        $sku               = isset( $payload['sku'] ) ? sanitize_text_field( (string) $payload['sku'] ) : '';
        $stock_qty         = isset( $payload['stock_quantity'] ) ? intval( $payload['stock_quantity'] ) : null;
        $images            = isset( $payload['images'] ) && is_array( $payload['images'] ) ? $payload['images'] : array();
        $attributes        = isset( $payload['attributes'] ) && is_array( $payload['attributes'] ) ? $payload['attributes'] : array();
        $variations        = isset( $payload['variations'] ) && is_array( $payload['variations'] ) ? $payload['variations'] : array();

        // Prepare gallery images and feature image
        $image_ids   = array();
        $first_image = 0;
        foreach ( $images as $img ) {
            if ( is_numeric( $img ) ) {
                $image_ids[] = intval( $img );
            } elseif ( is_string( $img ) && filter_var( $img, FILTER_VALIDATE_URL ) ) {
                // Sideload remote image
                $tmp = download_url( $img );
                if ( ! is_wp_error( $tmp ) ) {
                    $file_array = array();
                    $file_array['name']     = basename( parse_url( $img, PHP_URL_PATH ) );
                    $file_array['tmp_name'] = $tmp;
                    $id = media_handle_sideload( $file_array, 0 );
                    @unlink( $tmp );
                    if ( ! is_wp_error( $id ) ) {
                        $image_ids[] = $id;
                    }
                }
            }
        }
        if ( $image_ids ) {
            $first_image = array_shift( $image_ids );
        }

        if ( 'variable' === $type ) {
            $product = new WC_Product_Variable();
        } else {
            $product = new WC_Product_Simple();
        }
        $product->set_name( $title );
        $product->set_description( $description );
        $product->set_short_description( $short_description );
        if ( '' !== $regular_price ) {
            $product->set_regular_price( $regular_price );
        }
        if ( '' !== $sale_price ) {
            $product->set_sale_price( $sale_price );
        }
        if ( '' !== $sku ) {
            $product->set_sku( $sku );
        }
        if ( null !== $stock_qty ) {
            $product->set_manage_stock( true );
            $product->set_stock_quantity( $stock_qty );
        }
        if ( $first_image ) {
            $product->set_image_id( $first_image );
        }
        if ( $image_ids ) {
            $product->set_gallery_image_ids( $image_ids );
        }

        // Prepare attributes for product
        $attr_objects = array();
        foreach ( $attributes as $name => $values ) {
            $taxonomy = wc_sanitize_taxonomy_name( $name );
            $values   = is_array( $values ) ? $values : array( $values );
            $options  = array();
            // If taxonomy exists, ensure terms exist
            if ( taxonomy_exists( $taxonomy ) ) {
                foreach ( $values as $val ) {
                    if ( is_numeric( $val ) ) {
                        $options[] = intval( $val );
                    } else {
                        $term = term_exists( $val, $taxonomy );
                        if ( $term ) {
                            $options[] = is_array( $term ) ? $term['term_id'] : intval( $term );
                        } else {
                            $new = wp_insert_term( $val, $taxonomy );
                            if ( ! is_wp_error( $new ) && isset( $new['term_id'] ) ) {
                                $options[] = $new['term_id'];
                            }
                        }
                    }
                }
            } else {
                // Custom attribute
                $options = array_map( 'wc_clean', $values );
            }
            $attr = new WC_Product_Attribute();
            $attr->set_name( $taxonomy );
            $attr->set_options( $options );
            $attr->set_visible( true );
            $attr->set_variation( 'variable' === $type );
            $attr_objects[] = $attr;
        }
        if ( $attr_objects ) {
            $product->set_attributes( $attr_objects );
        }
        // Save product first to get an ID
        $product_id = $product->save();

        // Create variations if needed
        if ( 'variable' === $type && $variations ) {
            foreach ( $variations as $var_def ) {
                if ( ! is_array( $var_def ) ) {
                    continue;
                }
                $variation = new WC_Product_Variation();
                $variation->set_parent_id( $product_id );
                // Attributes
                $var_attrs = array();
                if ( isset( $var_def['attributes'] ) && is_array( $var_def['attributes'] ) ) {
                    foreach ( $var_def['attributes'] as $attr_name => $attr_value ) {
                        $var_attrs[ wc_sanitize_taxonomy_name( $attr_name ) ] = $attr_value;
                    }
                }
                if ( $var_attrs ) {
                    $variation->set_attributes( $var_attrs );
                }
                // Pricing
                if ( isset( $var_def['regular_price'] ) ) {
                    $variation->set_regular_price( (string) $var_def['regular_price'] );
                }
                if ( isset( $var_def['sale_price'] ) ) {
                    $variation->set_sale_price( (string) $var_def['sale_price'] );
                }
                if ( isset( $var_def['sku'] ) ) {
                    $variation->set_sku( sanitize_text_field( (string) $var_def['sku'] ) );
                }
                if ( isset( $var_def['stock_quantity'] ) ) {
                    $variation->set_manage_stock( true );
                    $variation->set_stock_quantity( intval( $var_def['stock_quantity'] ) );
                }
                // Image
                if ( isset( $var_def['image_id'] ) && is_numeric( $var_def['image_id'] ) ) {
                    $variation->set_image_id( intval( $var_def['image_id'] ) );
                }
                $variation->save();
            }
        }
        return array( 'success' => true, 'product_id' => $product_id, 'message' => __( 'Product created.', 'arthur-ai' ) );
    }
}
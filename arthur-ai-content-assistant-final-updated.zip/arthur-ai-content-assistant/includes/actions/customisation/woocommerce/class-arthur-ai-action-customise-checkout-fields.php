<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Customise WooCommerce checkout fields.
 *
 * This action accepts a structured definition of checkout field
 * modifications. For each checkout section (billing, shipping,
 * additional), the AI can specify fields to add, update or remove.
 * The configuration is stored in the option
 * 'arthur_ai_checkout_fields_customisation' and applied at runtime
 * by the WooCommerce customiser helper.
 */
class Arthur_AI_Action_Customise_Checkout_Fields implements Arthur_AI_Action_Interface {

    /**
     * Get the action slug.
     *
     * @return string
     */
    public function get_type() {
        return 'customise_checkout_fields';
    }

    /**
     * Get human label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Customise Checkout Fields', 'arthur-ai' );
    }

    /**
     * Execute the action to store checkout field customisation.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['fields'] ) || ! is_array( $payload['fields'] ) ) {
            return array( 'success' => false, 'message' => __( 'fields array is required.', 'arthur-ai' ) );
        }
        $sanitised = array();
        foreach ( array( 'billing', 'shipping', 'additional' ) as $section ) {
            if ( ! isset( $payload['fields'][ $section ] ) || ! is_array( $payload['fields'][ $section ] ) ) {
                continue;
            }
            $sec_cfg = $payload['fields'][ $section ];
            $out     = array();
            // Handle removals
            if ( isset( $sec_cfg['remove'] ) && is_array( $sec_cfg['remove'] ) ) {
                $out['remove'] = array();
                foreach ( $sec_cfg['remove'] as $key ) {
                    $out['remove'][] = sanitize_key( (string) $key );
                }
            }
            // Handle updates
            if ( isset( $sec_cfg['update'] ) && is_array( $sec_cfg['update'] ) ) {
                $out['update'] = array();
                foreach ( $sec_cfg['update'] as $field_key => $settings ) {
                    $field_key = sanitize_key( (string) $field_key );
                    if ( ! is_array( $settings ) ) {
                        continue;
                    }
                    $cfg = array();
                    foreach ( $settings as $k => $v ) {
                        $cfg[ sanitize_key( (string) $k ) ] = is_scalar( $v ) ? sanitize_text_field( (string) $v ) : $v;
                    }
                    $out['update'][ $field_key ] = $cfg;
                }
            }
            // Handle additions
            if ( isset( $sec_cfg['add'] ) && is_array( $sec_cfg['add'] ) ) {
                $out['add'] = array();
                foreach ( $sec_cfg['add'] as $field_key => $settings ) {
                    $field_key = sanitize_key( (string) $field_key );
                    if ( ! is_array( $settings ) ) {
                        continue;
                    }
                    $cfg = array();
                    foreach ( $settings as $k => $v ) {
                        // Allow complex structures such as options arrays
                        if ( is_scalar( $v ) ) {
                            $cfg[ sanitize_key( (string) $k ) ] = sanitize_text_field( (string) $v );
                        } else {
                            $cfg[ sanitize_key( (string) $k ) ] = $v;
                        }
                    }
                    $out['add'][ $field_key ] = $cfg;
                }
            }
            if ( ! empty( $out ) ) {
                $sanitised[ $section ] = $out;
            }
        }
        update_option( 'arthur_ai_checkout_fields_customisation', $sanitised );
        return array( 'success' => true, 'message' => __( 'Checkout fields customisation saved.', 'arthur-ai' ), 'config' => $sanitised );
    }
}
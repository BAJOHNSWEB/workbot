<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Create, update or delete WooCommerce coupons.
 *
 * This action provides basic CRUD functionality for WooCommerce coupons.
 * The payload must include an `operation` key specifying `create`,
 * `update` or `delete`. For create and update, relevant coupon
 * properties can be provided such as code, discount type, amount,
 * expiry date and usage limits. For delete, either a coupon ID or
 * code must be provided. Returns details of the created/updated
 * coupon or a success flag on deletion.
 */
class Arthur_AI_Action_Manage_Coupons implements Arthur_AI_Action_Interface {

    /**
     * Get slug.
     *
     * @return string
     */
    public function get_type() {
        return 'manage_coupons';
    }

    /**
     * Get human label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Manage Coupons', 'arthur-ai' );
    }

    /**
     * Execute the coupon management action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['operation'] ) ) {
            return array( 'success' => false, 'message' => __( 'operation is required.', 'arthur-ai' ) );
        }
        $operation = strtolower( sanitize_key( (string) $payload['operation'] ) );
        if ( ! in_array( $operation, array( 'create', 'update', 'delete' ), true ) ) {
            return array( 'success' => false, 'message' => __( 'Invalid operation.', 'arthur-ai' ) );
        }
        // Create a coupon
        if ( 'create' === $operation ) {
            if ( ! isset( $payload['code'] ) ) {
                return array( 'success' => false, 'message' => __( 'code is required for creation.', 'arthur-ai' ) );
            }
            $code = sanitize_text_field( (string) $payload['code'] );
            // Check if coupon code exists
            $existing = wc_get_coupon_id_by_code( $code );
            if ( $existing ) {
                return array( 'success' => false, 'message' => __( 'Coupon code already exists.', 'arthur-ai' ) );
            }
            $coupon = new WC_Coupon();
            $coupon->set_code( $code );
            // Set discount type and amount
            if ( isset( $payload['discount_type'] ) ) {
                $coupon->set_discount_type( sanitize_text_field( (string) $payload['discount_type'] ) );
            }
            if ( isset( $payload['amount'] ) ) {
                $coupon->set_amount( floatval( $payload['amount'] ) );
            }
            // Usage limit
            if ( isset( $payload['usage_limit'] ) ) {
                $coupon->set_usage_limit( intval( $payload['usage_limit'] ) );
            }
            // Expiry date (Y-m-d)
            if ( isset( $payload['expiry'] ) && ! empty( $payload['expiry'] ) ) {
                $expiry = sanitize_text_field( (string) $payload['expiry'] );
                // Convert to timestamp and set date
                $date = strtotime( $expiry );
                if ( $date ) {
                    $coupon->set_date_expires( $date );
                }
            }
            $coupon->save();
            return array( 'success' => true, 'coupon_id' => $coupon->get_id(), 'code' => $coupon->get_code() );
        }
        // Determine coupon for update or delete
        $coupon = null;
        if ( isset( $payload['coupon_id'] ) ) {
            $coupon = new WC_Coupon( intval( $payload['coupon_id'] ) );
        } elseif ( isset( $payload['code'] ) ) {
            $cid = wc_get_coupon_id_by_code( sanitize_text_field( (string) $payload['code'] ) );
            if ( $cid ) {
                $coupon = new WC_Coupon( $cid );
            }
        }
        if ( ! $coupon || ! $coupon->get_id() ) {
            return array( 'success' => false, 'message' => __( 'Coupon not found.', 'arthur-ai' ) );
        }
        if ( 'delete' === $operation ) {
            wp_delete_post( $coupon->get_id(), true );
            return array( 'success' => true, 'deleted' => $coupon->get_id() );
        }
        // Update existing coupon
        if ( isset( $payload['discount_type'] ) ) {
            $coupon->set_discount_type( sanitize_text_field( (string) $payload['discount_type'] ) );
        }
        if ( isset( $payload['amount'] ) ) {
            $coupon->set_amount( floatval( $payload['amount'] ) );
        }
        if ( isset( $payload['usage_limit'] ) ) {
            $coupon->set_usage_limit( intval( $payload['usage_limit'] ) );
        }
        if ( isset( $payload['expiry'] ) && ! empty( $payload['expiry'] ) ) {
            $date = strtotime( sanitize_text_field( (string) $payload['expiry'] ) );
            if ( $date ) {
                $coupon->set_date_expires( $date );
            }
        }
        $coupon->save();
        return array( 'success' => true, 'coupon_id' => $coupon->get_id(), 'code' => $coupon->get_code() );
    }
}
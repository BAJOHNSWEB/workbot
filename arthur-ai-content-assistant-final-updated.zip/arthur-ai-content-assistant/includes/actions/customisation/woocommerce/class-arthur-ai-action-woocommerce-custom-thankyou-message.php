<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Set a custom thank you message for WooCommerce order completion.
 *
 * The payload should include a 'message' string. The value is stored in
 * arthur_ai_woo_thankyou_message and displayed by the Woo customiser on
 * the thank you page. Message may contain basic HTML and is output via
 * wp_kses_post().
 */
class Arthur_AI_Action_Woocommerce_Custom_Thankyou_Message implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'woocommerce_custom_thankyou_message';
    }
    public function get_label() {
        return __( 'WooCommerce: Custom Thank You Message', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['message'] ) ) {
            return array( 'success' => false, 'message' => __( 'message is required.', 'arthur-ai' ) );
        }
        $msg = (string) $payload['message'];
        update_option( 'arthur_ai_woo_thankyou_message', $msg );
        return array( 'success' => true, 'message' => __( 'Thank you message updated.', 'arthur-ai' ) );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Update simple text snippets in WooCommerce email templates.
 *
 * Accepts an associative array in 'templates' with keys 'intro' and/or
 * 'outro'. These strings will be prepended/appended to the email
 * content via the Woo customiser. Values are stored in
 * arthur_ai_woo_email_templates.
 */
class Arthur_AI_Action_Woocommerce_Update_Email_Templates implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'woocommerce_update_email_templates';
    }
    public function get_label() {
        return __( 'WooCommerce: Update Email Templates', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['templates'] ) || ! is_array( $payload['templates'] ) ) {
            return array( 'success' => false, 'message' => __( 'templates array is required.', 'arthur-ai' ) );
        }
        $templates = array();
        if ( isset( $payload['templates']['intro'] ) ) {
            $templates['intro'] = (string) $payload['templates']['intro'];
        }
        if ( isset( $payload['templates']['outro'] ) ) {
            $templates['outro'] = (string) $payload['templates']['outro'];
        }
        update_option( 'arthur_ai_woo_email_templates', $templates );
        return array( 'success' => true, 'message' => __( 'Email template text updated.', 'arthur-ai' ) );
    }
}
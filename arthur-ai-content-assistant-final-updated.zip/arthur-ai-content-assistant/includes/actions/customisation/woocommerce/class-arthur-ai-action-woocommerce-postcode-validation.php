<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Validate checkout postcode according to pattern or country.
 *
 * The payload may include a 'pattern' regex or a 'country' code. A simple
 * pattern is looked up for common countries (US, GB, CA, DE, AU) when a
 * country code is provided. The configuration is stored in
 * arthur_ai_woo_postcode_validation and checked by the Woo customiser.
 */
class Arthur_AI_Action_Woocommerce_Postcode_Validation implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'woocommerce_postcode_validation';
    }
    public function get_label() {
        return __( 'WooCommerce: Postcode Validation', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $config = array();
        if ( isset( $payload['pattern'] ) && '' !== (string) $payload['pattern'] ) {
            $config['pattern'] = (string) $payload['pattern'];
        }
        if ( isset( $payload['country'] ) && '' !== (string) $payload['country'] ) {
            $config['country'] = (string) $payload['country'];
        }
        update_option( 'arthur_ai_woo_postcode_validation', $config );
        return array( 'success' => true, 'message' => __( 'Postcode validation settings updated.', 'arthur-ai' ) );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Add a custom endpoint/tab to the WooCommerce My Account area.
 *
 * This action registers a new endpoint slug, menu label and content
 * for the My Account page. The configuration is stored in the
 * 'arthur_ai_my_account_endpoints' option and applied by the account
 * customiser helper. When new endpoints are added, a flush of
 * rewrite rules is triggered on the next request.
 */
class Arthur_AI_Action_Add_My_Account_Endpoint implements Arthur_AI_Action_Interface {

    /**
     * Get slug.
     *
     * @return string
     */
    public function get_type() {
        return 'add_my_account_endpoint';
    }

    /**
     * Get label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Add My Account Endpoint', 'arthur-ai' );
    }

    /**
     * Execute action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['endpoint'] ) || ! isset( $payload['label'] ) || ! isset( $payload['content'] ) ) {
            return array( 'success' => false, 'message' => __( 'endpoint, label and content are required.', 'arthur-ai' ) );
        }
        $endpoint = sanitize_key( (string) $payload['endpoint'] );
        $label    = sanitize_text_field( (string) $payload['label'] );
        $content  = wp_kses_post( (string) $payload['content'] );
        $endpoints = get_option( 'arthur_ai_my_account_endpoints', array() );
        if ( ! is_array( $endpoints ) ) {
            $endpoints = array();
        }
        $endpoints[ $endpoint ] = array(
            'label'   => $label,
            'content' => $content,
        );
        update_option( 'arthur_ai_my_account_endpoints', $endpoints );
        // Flag to flush rewrite rules on next request
        update_option( 'arthur_ai_my_account_flush_needed', true );
        return array( 'success' => true, 'endpoint' => $endpoint, 'label' => $label );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Change the "Add to Basket" button text on WooCommerce product pages.
 *
 * Accepts 'single' and/or 'archive' strings to override the button label
 * on single product pages and archive/loop pages respectively. Values are
 * stored in arthur_ai_woo_add_to_cart_text and output by the Woo
 * customiser filters.
 */
class Arthur_AI_Action_Woocommerce_Change_Add_To_Cart_Text implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'woocommerce_change_add_to_cart_text';
    }
    public function get_label() {
        return __( 'WooCommerce: Change Add To Cart Text', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $settings = get_option( 'arthur_ai_woo_add_to_cart_text', array() );
        if ( ! is_array( $settings ) ) {
            $settings = array();
        }
        if ( isset( $payload['single'] ) ) {
            $settings['single'] = (string) $payload['single'];
        }
        if ( isset( $payload['archive'] ) ) {
            $settings['archive'] = (string) $payload['archive'];
        }
        update_option( 'arthur_ai_woo_add_to_cart_text', $settings );
        return array( 'success' => true, 'message' => __( 'Add to cart text updated.', 'arthur-ai' ) );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Edit WooCommerce order details, notes and custom meta.
 *
 * Allows the AI to update order meta, change the order status and add
 * a customer note. Accepts an order ID and optional arrays for meta
 * updates and note content. The order’s status can be changed to a
 * valid WooCommerce status. Returns a summary of what was modified.
 */
class Arthur_AI_Action_Edit_Order_Details implements Arthur_AI_Action_Interface {

    /**
     * Get slug.
     *
     * @return string
     */
    public function get_type() {
        return 'edit_order_details';
    }

    /**
     * Get human label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'WooCommerce: Edit Order Details', 'arthur-ai' );
    }

    /**
     * Execute action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        if ( ! isset( $payload['order_id'] ) ) {
            return array( 'success' => false, 'message' => __( 'order_id is required.', 'arthur-ai' ) );
        }
        $order_id = intval( $payload['order_id'] );
        $order    = wc_get_order( $order_id );
        if ( ! $order ) {
            return array( 'success' => false, 'message' => __( 'Invalid order ID.', 'arthur-ai' ) );
        }
        $changes = array();
        // Update meta
        if ( isset( $payload['meta'] ) && is_array( $payload['meta'] ) ) {
            foreach ( $payload['meta'] as $key => $value ) {
                $key = sanitize_text_field( (string) $key );
                $order->update_meta_data( $key, $value );
                $changes['meta'][ $key ] = $value;
            }
        }
        // Customer note
        if ( isset( $payload['customer_note'] ) ) {
            $note = sanitize_textarea_field( (string) $payload['customer_note'] );
            $order->add_order_note( $note, true );
            $changes['customer_note'] = $note;
        }
        // Status
        if ( isset( $payload['status'] ) ) {
            $new_status = sanitize_key( (string) $payload['status'] );
            $valid      = wc_get_order_statuses();
            if ( isset( $valid[ 'wc-' . $new_status ] ) ) {
                $order->update_status( $new_status, __( 'Status updated by AI action', 'arthur-ai' ), true );
                $changes['status'] = $new_status;
            }
        }
        $order->save();
        return array( 'success' => true, 'order_id' => $order_id, 'changes' => $changes );
    }
}
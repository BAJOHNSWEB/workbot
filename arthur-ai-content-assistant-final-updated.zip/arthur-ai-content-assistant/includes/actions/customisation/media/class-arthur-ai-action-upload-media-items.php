<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Upload new media items from external URLs or local file paths.
 *
 * Each item may specify a URL to download or a server-side file path to import.
 * Optional fields allow attaching the media to a parent post and setting
 * basic metadata such as the title, alt text and description. The action
 * returns an array of inserted attachment IDs along with their final URLs.
 */
class Arthur_AI_Action_Upload_Media_Items implements Arthur_AI_Action_Interface {

    /**
     * {@inheritdoc}
     */
    public function get_type() {
        return 'upload_media_items';
    }

    /**
     * {@inheritdoc}
     */
    public function get_label() {
        return __( 'Upload Media Items', 'arthur-ai' );
    }

    /**
     * {@inheritdoc}
     */
    public function execute( array $payload ) {
        if ( ! isset( $payload['items'] ) || ! is_array( $payload['items'] ) || empty( $payload['items'] ) ) {
            return array(
                'success' => false,
                'message' => __( 'items array is required.', 'arthur-ai' ),
            );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $results = array();

        foreach ( $payload['items'] as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }
            $attachment_id = 0;
            $parent_id     = isset( $item['post_id'] ) ? intval( $item['post_id'] ) : 0;
            $title         = isset( $item['title'] ) ? sanitize_text_field( (string) $item['title'] ) : '';
            $alt           = isset( $item['alt'] ) ? sanitize_text_field( (string) $item['alt'] ) : '';
            $description   = isset( $item['description'] ) ? wp_kses_post( (string) $item['description'] ) : '';

            // Determine source: URL or local file path.
            $source_url  = isset( $item['url'] ) && ! empty( $item['url'] ) ? esc_url_raw( $item['url'] ) : '';
            $file_path   = isset( $item['file_path'] ) ? (string) $item['file_path'] : '';
            $mime_type   = isset( $item['mime_type'] ) ? sanitize_text_field( (string) $item['mime_type'] ) : '';

            // Prepare a file array for media_handle_sideload().
            $file_array = array();
            $tmp_path   = '';

            if ( $source_url ) {
                // Download remote file to a temporary location.
                $tmp = download_url( $source_url );
                if ( is_wp_error( $tmp ) ) {
                    // Skip this item on failure.
                    continue;
                }
                $file_array['name']     = basename( parse_url( $source_url, PHP_URL_PATH ) );
                $file_array['tmp_name'] = $tmp;
                $tmp_path               = $tmp;
            } elseif ( $file_path && @is_readable( $file_path ) ) {
                // Copy local file into a temporary file for sideload handling.
                $file_array['name']     = basename( $file_path );
                $tmp                    = wp_tempnam( $file_array['name'] );
                if ( ! $tmp ) {
                    continue;
                }
                if ( ! @copy( $file_path, $tmp ) ) {
                    @unlink( $tmp );
                    continue;
                }
                $file_array['tmp_name'] = $tmp;
                $tmp_path               = $tmp;
            } else {
                // No valid source provided.
                continue;
            }

            // Assign a mime type if provided. Otherwise it will be detected.
            if ( $mime_type ) {
                $file_array['type'] = $mime_type;
            }

            // Use media_handle_sideload to properly move the file into the uploads directory.
            $attachment_id = media_handle_sideload( $file_array, $parent_id, $description );

            // Clean up temporary file if created by us.
            if ( $tmp_path && file_exists( $tmp_path ) ) {
                @unlink( $tmp_path );
            }

            if ( is_wp_error( $attachment_id ) || ! $attachment_id ) {
                continue;
            }

            // Update attachment post title if provided.
            if ( $title ) {
                wp_update_post( array( 'ID' => $attachment_id, 'post_title' => $title ) );
            }

            // Update alt text, description and caption.
            if ( $alt ) {
                update_post_meta( $attachment_id, '_wp_attachment_image_alt', $alt );
            }
            if ( $description ) {
                // Store description in post_content and caption in post_excerpt.
                wp_update_post( array( 'ID' => $attachment_id, 'post_content' => $description, 'post_excerpt' => $description ) );
            }

            $url = wp_get_attachment_url( $attachment_id );
            $results[] = array(
                'attachment_id' => $attachment_id,
                'url'           => $url,
            );
        }

        return array(
            'success'   => true,
            'uploads'   => $results,
            'message'   => __( 'Media items processed.', 'arthur-ai' ),
        );
    }
}
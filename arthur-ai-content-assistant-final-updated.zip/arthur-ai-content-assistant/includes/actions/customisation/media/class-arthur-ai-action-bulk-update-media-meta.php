<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Bulk update attachment metadata such as alt text, title, caption and description.
 *
 * This action accepts an array of items where each item specifies an
 * attachment ID and any combination of fields to update. Title updates
 * modify the post_title field, caption updates modify post_excerpt,
 * description updates modify post_content, and alt text updates modify
 * the _wp_attachment_image_alt meta. Fields not provided are left
 * unchanged. A summary of updated fields per attachment is returned.
 */
class Arthur_AI_Action_Bulk_Update_Media_Meta implements Arthur_AI_Action_Interface {

    /**
     * {@inheritdoc}
     */
    public function get_type() {
        return 'bulk_update_media_meta';
    }

    /**
     * {@inheritdoc}
     */
    public function get_label() {
        return __( 'Bulk Update Media Meta', 'arthur-ai' );
    }

    /**
     * {@inheritdoc}
     */
    public function execute( array $payload ) {
        if ( ! isset( $payload['items'] ) || ! is_array( $payload['items'] ) || empty( $payload['items'] ) ) {
            return array(
                'success' => false,
                'message' => __( 'items array is required.', 'arthur-ai' ),
            );
        }
        $summary = array();
        foreach ( $payload['items'] as $item ) {
            if ( ! is_array( $item ) || ! isset( $item['attachment_id'] ) ) {
                continue;
            }
            $attachment_id = intval( $item['attachment_id'] );
            if ( $attachment_id <= 0 ) {
                continue;
            }
            $updated_fields = array();
            // Update title
            if ( isset( $item['title'] ) ) {
                $title = sanitize_text_field( (string) $item['title'] );
                wp_update_post( array( 'ID' => $attachment_id, 'post_title' => $title ) );
                $updated_fields[] = 'title';
            }
            // Update caption
            if ( isset( $item['caption'] ) ) {
                $caption = wp_kses_post( (string) $item['caption'] );
                wp_update_post( array( 'ID' => $attachment_id, 'post_excerpt' => $caption ) );
                $updated_fields[] = 'caption';
            }
            // Update description
            if ( isset( $item['description'] ) ) {
                $description = wp_kses_post( (string) $item['description'] );
                wp_update_post( array( 'ID' => $attachment_id, 'post_content' => $description ) );
                $updated_fields[] = 'description';
            }
            // Update alt text
            if ( isset( $item['alt_text'] ) ) {
                $alt = sanitize_text_field( (string) $item['alt_text'] );
                update_post_meta( $attachment_id, '_wp_attachment_image_alt', $alt );
                $updated_fields[] = 'alt_text';
            }
            if ( $updated_fields ) {
                $summary[ $attachment_id ] = $updated_fields;
            }
        }
        return array(
            'success' => true,
            'updated' => $summary,
            'message' => __( 'Media metadata updated.', 'arthur-ai' ),
        );
    }
}
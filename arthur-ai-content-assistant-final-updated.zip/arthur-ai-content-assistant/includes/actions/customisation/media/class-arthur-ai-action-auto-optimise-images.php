<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure automatic image optimisation for uploads.
 *
 * This action allows the caller to enable or disable optimisation and
 * specify separate quality settings for JPEG and PNG files. When
 * optimisation is enabled, the media customiser will recompress JPEG
 * and PNG images on upload according to the configured qualities. JPEG
 * quality should be an integer between 1 and 100 (higher values mean
 * better quality and larger file size). PNG quality may be provided
 * either as a scale of 0–9 (where 9 is the lowest compression) or as
 * 0–100; values above 9 will be converted into the 0–9 range.
 */
class Arthur_AI_Action_Auto_Optimise_Images implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'auto_optimise_images';
    }
    public function get_label() {
        return __( 'Auto Optimise Images', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $enabled      = false;
        $quality_jpeg = 82;
        // Default PNG quality: 7 (0–9 scale).
        $quality_png  = 7;
        if ( isset( $payload['enabled'] ) ) {
            $enabled = (bool) $payload['enabled'];
        }
        // Accept legacy 'quality' to set JPEG quality if JPEG-specific not provided.
        if ( isset( $payload['quality_jpeg'] ) && is_numeric( $payload['quality_jpeg'] ) ) {
            $qj         = intval( $payload['quality_jpeg'] );
            $quality_jpeg = max( 1, min( 100, $qj ) );
        } elseif ( isset( $payload['quality'] ) && is_numeric( $payload['quality'] ) ) {
            $qj           = intval( $payload['quality'] );
            $quality_jpeg = max( 1, min( 100, $qj ) );
        }
        // Process PNG quality. Accept either 0–9 or 0–100 scale.
        if ( isset( $payload['quality_png'] ) && is_numeric( $payload['quality_png'] ) ) {
            $qp = intval( $payload['quality_png'] );
            if ( $qp >= 0 && $qp <= 9 ) {
                $quality_png = $qp;
            } elseif ( $qp >= 10 && $qp <= 100 ) {
                // Convert 0–100 scale to 0–9. Round to nearest integer.
                $quality_png = max( 0, min( 9, round( $qp / 100 * 9 ) ) );
            }
        } elseif ( isset( $payload['quality'] ) && is_numeric( $payload['quality'] ) ) {
            // Use legacy quality for PNG as well.
            $qp = intval( $payload['quality'] );
            if ( $qp >= 0 && $qp <= 9 ) {
                $quality_png = $qp;
            } elseif ( $qp >= 10 && $qp <= 100 ) {
                $quality_png = max( 0, min( 9, round( $qp / 100 * 9 ) ) );
            }
        }
        update_option( 'arthur_ai_auto_optimise_images_enabled', $enabled );
        update_option( 'arthur_ai_auto_optimise_images_quality_jpeg', $quality_jpeg );
        update_option( 'arthur_ai_auto_optimise_images_quality_png', $quality_png );
        return array( 'success' => true, 'message' => __( 'Image optimisation settings updated.', 'arthur-ai' ) );
    }
}
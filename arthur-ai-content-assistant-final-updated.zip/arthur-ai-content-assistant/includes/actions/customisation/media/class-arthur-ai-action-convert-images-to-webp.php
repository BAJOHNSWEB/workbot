<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure conversion of uploaded images to WebP format.
 *
 * This action accepts an enabled flag and an optional quality setting. When
 * enabled and supported by the server (GD or Imagick with WebP support),
 * the media customiser will generate WebP copies of JPEG and PNG uploads.
 * The quality value (1–100) controls compression for WebP images; a
 * sensible default of 80 is used when not provided.
 */
class Arthur_AI_Action_Convert_Images_To_Webp implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'convert_images_to_webp';
    }
    public function get_label() {
        return __( 'Convert Images To WebP', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $enabled = false;
        $quality = 80;
        if ( isset( $payload['enabled'] ) ) {
            $enabled = (bool) $payload['enabled'];
        }
        if ( isset( $payload['quality'] ) && is_numeric( $payload['quality'] ) ) {
            $q = intval( $payload['quality'] );
            $quality = max( 1, min( 100, $q ) );
        }
        update_option( 'arthur_ai_convert_images_to_webp_enabled', $enabled );
        update_option( 'arthur_ai_convert_images_to_webp_quality', $quality );
        return array( 'success' => true, 'message' => __( 'WebP conversion settings updated.', 'arthur-ai' ) );
    }
}
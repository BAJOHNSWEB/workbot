<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Replace an existing media file everywhere it appears.
 *
 * This action updates the underlying file of an existing attachment. The
 * caller must provide the attachment_id and either a URL or a local
 * file_path for the replacement. The old file is replaced within the
 * uploads directory, metadata is regenerated, and references to the
 * old URL in post content and selected meta fields are replaced with
 * the new URL. Optionally, thumbnails and custom sizes can be
 * regenerated. A report summarises the operation.
 */
class Arthur_AI_Action_Replace_Media_File implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'replace_media_file';
    }
    public function get_label() {
        return __( 'Replace Media File', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['attachment_id'] ) ) {
            return array( 'success' => false, 'message' => __( 'attachment_id is required.', 'arthur-ai' ) );
        }
        $attachment_id = (int) $payload['attachment_id'];
        if ( $attachment_id <= 0 ) {
            return array( 'success' => false, 'message' => __( 'Invalid attachment ID.', 'arthur-ai' ) );
        }
        // Determine source: url or file_path.
        $source_url  = isset( $payload['url'] ) ? esc_url_raw( $payload['url'] ) : '';
        $file_path   = isset( $payload['file_path'] ) ? (string) $payload['file_path'] : '';
        $regen_sizes = false;
        if ( isset( $payload['regenerate_sizes'] ) ) {
            $regen_sizes = (bool) $payload['regenerate_sizes'];
        }
        if ( ! $source_url && ! $file_path ) {
            return array( 'success' => false, 'message' => __( 'Either url or file_path must be provided.', 'arthur-ai' ) );
        }
        // Download remote file if needed.
        $temp_file = '';
        if ( $source_url ) {
            $tmp = download_url( $source_url );
            if ( is_wp_error( $tmp ) ) {
                return array( 'success' => false, 'message' => __( 'Failed to download replacement file.', 'arthur-ai' ) );
            }
            $temp_file = $tmp;
            $new_file_path = $tmp;
        } else {
            $real = realpath( $file_path );
            if ( ! $real || ! file_exists( $real ) ) {
                return array( 'success' => false, 'message' => __( 'Replacement file not found.', 'arthur-ai' ) );
            }
            $new_file_path = $real;
        }
        // Determine destination in uploads directory.
        $uploads    = wp_upload_dir();
        $filename   = wp_unique_filename( $uploads['path'], basename( $new_file_path ) );
        $dest_path  = trailingslashit( $uploads['path'] ) . $filename;
        // Copy the new file into uploads.
        if ( ! @copy( $new_file_path, $dest_path ) ) {
            if ( $temp_file ) {
                @unlink( $temp_file );
            }
            return array( 'success' => false, 'message' => __( 'Failed to copy new file into uploads.', 'arthur-ai' ) );
        }
        // Clean up temp file if downloaded.
        if ( $temp_file ) {
            @unlink( $temp_file );
        }
        // Capture old URL before updating.
        $old_url  = wp_get_attachment_url( $attachment_id );
        // Update attachment to point to new file.
        update_attached_file( $attachment_id, $dest_path );
        // Regenerate metadata.
        $metadata = wp_generate_attachment_metadata( $attachment_id, $dest_path );
        if ( $metadata && ! is_wp_error( $metadata ) ) {
            wp_update_attachment_metadata( $attachment_id, $metadata );
        }
        // Optionally regenerate thumbnails and custom sizes again (already done by generate_attachment_metadata).
        // Determine new URL.
        $new_url = wp_get_attachment_url( $attachment_id );
        // Replace occurrences in posts/pages meta and content.
        $post_count  = 0;
        $meta_count  = 0;
        if ( $old_url && $new_url && $old_url !== $new_url ) {
            global $wpdb;
            // Find posts containing old URL in content.
            $like   = '%' . $wpdb->esc_like( $old_url ) . '%';
            $posts  = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_content LIKE %s", $like ) );
            if ( $posts ) {
                foreach ( $posts as $pid ) {
                    $content = get_post_field( 'post_content', $pid );
                    $updated = str_replace( $old_url, $new_url, $content );
                    if ( $updated !== $content ) {
                        wp_update_post( array( 'ID' => $pid, 'post_content' => $updated ) );
                        $post_count++;
                    }
                }
            }
            // Update meta values that exactly match the old URL or attachment ID.
            // Replace URL values.
            $meta_rows = $wpdb->get_results( $wpdb->prepare( "SELECT meta_id, post_id, meta_key, meta_value FROM {$wpdb->postmeta} WHERE meta_value = %s", $old_url ) );
            if ( $meta_rows ) {
                foreach ( $meta_rows as $row ) {
                    update_post_meta( $row->post_id, $row->meta_key, $new_url );
                    $meta_count++;
                }
            }
            // Replace attachment ID references in meta.
            if ( $old_url && $old_url !== $new_url ) {
                $rows = $wpdb->get_results( $wpdb->prepare( "SELECT meta_id, post_id, meta_key FROM {$wpdb->postmeta} WHERE meta_value = %d", $attachment_id ) );
                foreach ( $rows as $row ) {
                    // No change in ID; we do not replace the ID itself because the attachment remains the same.
                    // However, if meta stores URL or path, we replaced above.
                }
            }
        }
        return array(
            'success'         => true,
            'attachment_id'   => $attachment_id,
            'old_url'         => $old_url,
            'new_url'         => $new_url,
            'posts_updated'   => $post_count,
            'meta_updated'    => $meta_count,
            'message'         => __( 'Media file replaced.', 'arthur-ai' ),
        );
    }
}
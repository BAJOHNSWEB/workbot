<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Replace outdated brand assets across the site.
 *
 * This action scans posts, widgets and menus for occurrences of an old
 * image URL or attachment ID and replaces them with a new URL or
 * attachment. It can operate on posts/pages, widget data, nav menu
 * item URLs or all three scopes. The caller must supply an array of
 * mappings defining old and new assets. A report is returned detailing
 * how many replacements were made for each mapping and scope.
 */
class Arthur_AI_Action_Replace_Brand_Assets implements Arthur_AI_Action_Interface {

    /**
     * {@inheritdoc}
     */
    public function get_type() {
        return 'replace_brand_assets';
    }

    /**
     * {@inheritdoc}
     */
    public function get_label() {
        return __( 'Replace Brand Assets', 'arthur-ai' );
    }

    /**
     * {@inheritdoc}
     */
    public function execute( array $payload ) {
        if ( ! isset( $payload['mappings'] ) || ! is_array( $payload['mappings'] ) || empty( $payload['mappings'] ) ) {
            return array(
                'success' => false,
                'message' => __( 'mappings array is required.', 'arthur-ai' ),
            );
        }
        $scope = isset( $payload['scope'] ) ? $payload['scope'] : 'posts';
        if ( ! in_array( $scope, array( 'posts', 'widgets', 'menus', 'all' ), true ) ) {
            $scope = 'posts';
        }
        $report = array();
        foreach ( $payload['mappings'] as $mapping ) {
            if ( ! is_array( $mapping ) ) {
                continue;
            }
            // Resolve old and new URLs.
            $old_url = '';
            $new_url = '';
            $old_id  = 0;
            $new_id  = 0;
            if ( isset( $mapping['old_attachment_id'] ) && $mapping['old_attachment_id'] ) {
                $old_id  = intval( $mapping['old_attachment_id'] );
                $old_url = wp_get_attachment_url( $old_id );
            }
            if ( isset( $mapping['old_url'] ) && $mapping['old_url'] ) {
                $old_url = esc_url_raw( $mapping['old_url'] );
            }
            if ( isset( $mapping['new_attachment_id'] ) && $mapping['new_attachment_id'] ) {
                $new_id  = intval( $mapping['new_attachment_id'] );
                $new_url = wp_get_attachment_url( $new_id );
            }
            if ( isset( $mapping['new_url'] ) && $mapping['new_url'] ) {
                $new_url = esc_url_raw( $mapping['new_url'] );
            }
            if ( ! $old_url || ! $new_url ) {
                continue;
            }
            $rep = array( 'posts' => 0, 'widgets' => 0, 'menus' => 0 );
            // Posts/pages/CPTs
            if ( 'posts' === $scope || 'all' === $scope ) {
                $query_args = array(
                    'post_type'      => array( 'post', 'page' ),
                    'post_status'    => 'publish',
                    'posts_per_page' => -1,
                    'fields'         => 'ids',
                );
                $posts = get_posts( $query_args );
                foreach ( $posts as $post_id ) {
                    $content = get_post_field( 'post_content', $post_id );
                    if ( false !== strpos( $content, $old_url ) ) {
                        $updated_content = str_replace( $old_url, $new_url, $content );
                        wp_update_post( array( 'ID' => $post_id, 'post_content' => $updated_content ) );
                        $rep['posts']++;
                    }
                    // Update featured image references by attachment ID.
                    $thumb_id = get_post_meta( $post_id, '_thumbnail_id', true );
                    if ( $old_id && $thumb_id && intval( $thumb_id ) === $old_id ) {
                        update_post_meta( $post_id, '_thumbnail_id', $new_id );
                    }
                }
            }
            // Widgets
            if ( 'widgets' === $scope || 'all' === $scope ) {
                // Known widget option names that may contain HTML/content.
                $widget_options = array( 'widget_text', 'widget_block', 'widget_media_image' );
                foreach ( $widget_options as $opt_name ) {
                    $opt = get_option( $opt_name );
                    if ( ! $opt || ! is_array( $opt ) ) {
                        continue;
                    }
                    $updated = false;
                    foreach ( $opt as $k => $instance ) {
                        if ( is_array( $instance ) ) {
                            $changed = false;
                            foreach ( $instance as $field_key => $value ) {
                                if ( is_string( $value ) && false !== strpos( $value, $old_url ) ) {
                                    $opt[ $k ][ $field_key ] = str_replace( $old_url, $new_url, $value );
                                    $changed                = true;
                                }
                            }
                            if ( $changed ) {
                                $updated = true;
                            }
                        }
                    }
                    if ( $updated ) {
                        update_option( $opt_name, $opt );
                        $rep['widgets']++;
                    }
                }
            }
            // Menus
            if ( 'menus' === $scope || 'all' === $scope ) {
                $menu_items = get_posts( array(
                    'post_type'      => 'nav_menu_item',
                    'post_status'    => 'publish',
                    'posts_per_page' => -1,
                ) );
                foreach ( $menu_items as $menu_item ) {
                    $item_id = $menu_item->ID;
                    $url     = get_post_meta( $item_id, '_menu_item_url', true );
                    if ( $url && $url === $old_url ) {
                        update_post_meta( $item_id, '_menu_item_url', $new_url );
                        $rep['menus']++;
                    }
                }
            }
            $report[] = array(
                'old_url'   => $old_url,
                'new_url'   => $new_url,
                'replaced'  => $rep,
            );
        }
        return array(
            'success' => true,
            'report'  => $report,
            'message' => __( 'Brand assets replaced where referenced.', 'arthur-ai' ),
        );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Automatically rename uploaded files based on a pattern.
 *
 * The payload should supply a 'pattern' string containing tokens such
 * as {post_slug}, {date} and {random}. This pattern is stored in
 * arthur_ai_auto_rename_uploads_pattern and used by the media customiser
 * on the sanitize_file_name filter to rename files at upload time.
 */
class Arthur_AI_Action_Auto_Rename_Uploads implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'auto_rename_uploads';
    }
    public function get_label() {
        return __( 'Auto Rename Uploads', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['pattern'] ) || '' === trim( (string) $payload['pattern'] ) ) {
            return array( 'success' => false, 'message' => __( 'pattern is required.', 'arthur-ai' ) );
        }
        $pattern = (string) $payload['pattern'];
        update_option( 'arthur_ai_auto_rename_uploads_pattern', $pattern );
        return array( 'success' => true, 'message' => __( 'Upload renaming pattern updated.', 'arthur-ai' ) );
    }
}
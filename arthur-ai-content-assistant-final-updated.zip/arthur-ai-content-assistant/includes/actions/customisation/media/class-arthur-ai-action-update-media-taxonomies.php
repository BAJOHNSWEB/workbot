<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Assign taxonomies to media attachments.
 *
 * This action accepts an array of items, each specifying an attachment ID
 * and a map of taxonomy names to term IDs or term names. It will create
 * missing terms when instructed and then assign the terms to the
 * attachment using wp_set_object_terms(). A summary of assigned term IDs
 * per taxonomy per attachment is returned.
 */
class Arthur_AI_Action_Update_Media_Taxonomies implements Arthur_AI_Action_Interface {

    /**
     * {@inheritdoc}
     */
    public function get_type() {
        return 'update_media_taxonomies';
    }

    /**
     * {@inheritdoc}
     */
    public function get_label() {
        return __( 'Update Media Taxonomies', 'arthur-ai' );
    }

    /**
     * {@inheritdoc}
     */
    public function execute( array $payload ) {
        if ( ! isset( $payload['items'] ) || ! is_array( $payload['items'] ) || empty( $payload['items'] ) ) {
            return array(
                'success' => false,
                'message' => __( 'items array is required.', 'arthur-ai' ),
            );
        }
        $create_terms = false;
        if ( isset( $payload['create_terms'] ) ) {
            $create_terms = (bool) $payload['create_terms'];
        }
        $result = array();
        foreach ( $payload['items'] as $item ) {
            if ( ! is_array( $item ) || ! isset( $item['attachment_id'] ) || ! isset( $item['taxonomies'] ) || ! is_array( $item['taxonomies'] ) ) {
                continue;
            }
            $attachment_id = intval( $item['attachment_id'] );
            if ( $attachment_id <= 0 ) {
                continue;
            }
            $assigned = array();
            foreach ( $item['taxonomies'] as $taxonomy => $terms ) {
                $taxonomy = sanitize_key( $taxonomy );
                if ( ! taxonomy_exists( $taxonomy ) ) {
                    continue;
                }
                // Normalise term IDs or names into IDs.
                $term_ids = array();
                if ( is_array( $terms ) ) {
                    foreach ( $terms as $term ) {
                        if ( is_numeric( $term ) ) {
                            $term_ids[] = intval( $term );
                        } else {
                            $term = (string) $term;
                            $existing = term_exists( $term, $taxonomy );
                            if ( $existing ) {
                                if ( is_array( $existing ) && isset( $existing['term_id'] ) ) {
                                    $term_ids[] = intval( $existing['term_id'] );
                                } else {
                                    $term_ids[] = intval( $existing );
                                }
                            } elseif ( $create_terms ) {
                                $created = wp_insert_term( $term, $taxonomy );
                                if ( ! is_wp_error( $created ) && isset( $created['term_id'] ) ) {
                                    $term_ids[] = intval( $created['term_id'] );
                                }
                            }
                        }
                    }
                }
                if ( $term_ids ) {
                    $assigned_ids = wp_set_object_terms( $attachment_id, $term_ids, $taxonomy, false );
                    if ( ! is_wp_error( $assigned_ids ) ) {
                        $assigned[ $taxonomy ] = $assigned_ids;
                    }
                }
            }
            if ( $assigned ) {
                $result[ $attachment_id ] = $assigned;
            }
        }
        return array(
            'success' => true,
            'assigned' => $result,
            'message' => __( 'Media taxonomies updated.', 'arthur-ai' ),
        );
    }
}
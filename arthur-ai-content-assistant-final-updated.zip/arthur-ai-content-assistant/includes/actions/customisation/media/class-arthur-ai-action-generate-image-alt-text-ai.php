<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Set or update alt text on one or more image attachments.
 *
 * This action accepts either a single attachment_id/alt pair or an array
 * of items. For each item, it stores the provided alt text in the
 * _wp_attachment_image_alt meta field. No external AI call is made here –
 * the caller must provide the alt text to persist.
 */
class Arthur_AI_Action_Generate_Image_Alt_Text_Ai implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'generate_image_alt_text_ai';
    }
    public function get_label() {
        return __( 'Generate Image Alt Text (AI)', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $items = array();
        // Support single pair as a convenience.
        if ( isset( $payload['attachment_id'] ) && isset( $payload['alt'] ) ) {
            $items[] = array(
                'attachment_id' => $payload['attachment_id'],
                'alt_text'      => $payload['alt'],
            );
        } elseif ( isset( $payload['items'] ) && is_array( $payload['items'] ) ) {
            $items = $payload['items'];
        } else {
            return array( 'success' => false, 'message' => __( 'No items provided.', 'arthur-ai' ) );
        }
        $updated = array();
        foreach ( $items as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }
            if ( ! isset( $item['attachment_id'] ) || ! isset( $item['alt_text'] ) ) {
                continue;
            }
            $attachment_id = (int) $item['attachment_id'];
            $alt           = (string) $item['alt_text'];
            if ( $attachment_id <= 0 || '' === $alt ) {
                continue;
            }
            update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );
            $updated[] = $attachment_id;
        }
        return array( 'success' => true, 'updated' => $updated, 'message' => __( 'Image alt text updated.', 'arthur-ai' ) );
    }
}
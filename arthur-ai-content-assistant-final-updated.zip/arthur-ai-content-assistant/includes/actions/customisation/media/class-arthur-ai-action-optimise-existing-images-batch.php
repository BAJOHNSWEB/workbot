<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Apply optimisation to existing image attachments in batch.
 *
 * This action allows a one-off pass over existing media to apply the
 * same compression and WebP conversion logic used for new uploads. The
 * caller can specify a list of attachment IDs or process all images up
 * to a limit. The optimisation routine respects the configuration
 * options set via auto_optimise_images and convert_images_to_webp. A
 * report is returned with counts of attachments optimised and any
 * failures.
 */
class Arthur_AI_Action_Optimise_Existing_Images_Batch implements Arthur_AI_Action_Interface {

    /**
     * {@inheritdoc}
     */
    public function get_type() {
        return 'optimise_existing_images_batch';
    }

    /**
     * {@inheritdoc}
     */
    public function get_label() {
        return __( 'Optimise Existing Images Batch', 'arthur-ai' );
    }

    /**
     * {@inheritdoc}
     */
    public function execute( array $payload ) {
        $limit          = 0;
        $attachment_ids = array();
        if ( isset( $payload['limit'] ) && is_numeric( $payload['limit'] ) ) {
            $limit = max( 0, intval( $payload['limit'] ) );
        }
        if ( isset( $payload['attachment_ids'] ) && is_array( $payload['attachment_ids'] ) ) {
            $attachment_ids = array_filter( array_map( 'intval', $payload['attachment_ids'] ) );
        }
        // If no IDs provided, fetch up to limit or all image attachments.
        if ( empty( $attachment_ids ) ) {
            $query_args = array(
                'post_type'      => 'attachment',
                'post_mime_type' => 'image',
                'post_status'    => 'inherit',
                'posts_per_page' => $limit > 0 ? $limit : -1,
                'fields'         => 'ids',
            );
            $attachment_ids = get_posts( $query_args );
        }
        if ( ! $attachment_ids ) {
            return array(
                'success' => false,
                'message' => __( 'No attachments to optimise.', 'arthur-ai' ),
            );
        }
        $optimised = 0;
        $failed    = array();
        foreach ( $attachment_ids as $attachment_id ) {
            $attachment_id = intval( $attachment_id );
            if ( $attachment_id <= 0 ) {
                continue;
            }
            $ok = false;
            if ( method_exists( 'Arthur_AI_Media_Customiser', 'optimise_existing_attachment' ) ) {
                $ok = (bool) Arthur_AI_Media_Customiser::optimise_existing_attachment( $attachment_id );
            }
            if ( $ok ) {
                $optimised++;
            } else {
                $failed[] = $attachment_id;
            }
        }
        return array(
            'success'    => true,
            'optimised'  => $optimised,
            'failed'     => $failed,
            'message'    => __( 'Optimisation pass completed.', 'arthur-ai' ),
        );
    }
}
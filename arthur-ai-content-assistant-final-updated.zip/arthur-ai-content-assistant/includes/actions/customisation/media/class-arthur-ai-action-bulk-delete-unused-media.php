<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Bulk delete unused media attachments.
 *
 * This action scans for media attachments that are likely unused based on
 * several simple heuristics: the attachment has no parent post, its URL
 * does not appear in the post_content of any published posts or pages, and
 * it is not referenced as a featured image via the _thumbnail_id meta.
 * The caller may limit how many attachments to inspect and choose
 * dry-run mode to see candidates without deleting them. When dry_run
 * is false, unused attachments are permanently deleted using
 * wp_delete_attachment(). A report of candidate or deleted IDs is
 * returned.
 */
class Arthur_AI_Action_Bulk_Delete_Unused_Media implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'bulk_delete_unused_media';
    }
    public function get_label() {
        return __( 'Bulk Delete Unused Media', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        // Determine limit and dry run mode.
        $limit   = 0;
        $dry_run = false;
        if ( isset( $payload['limit'] ) && is_numeric( $payload['limit'] ) ) {
            $limit = max( 0, intval( $payload['limit'] ) );
        }
        if ( isset( $payload['dry_run'] ) ) {
            $dry_run = (bool) $payload['dry_run'];
        }
        // Fetch candidate attachments: unparented image attachments.
        $query_args = array(
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'post_parent'    => 0,
            'post_mime_type' => 'image',
            'posts_per_page' => $limit > 0 ? $limit : -1,
            'fields'         => 'ids',
        );
        $attachments = get_posts( $query_args );
        if ( ! $attachments ) {
            return array(
                'success' => true,
                'candidates' => array(),
                'deleted' => array(),
                'message' => __( 'No candidate attachments found.', 'arthur-ai' ),
            );
        }
        $candidates = array();
        $deleted    = array();
        global $wpdb;
        foreach ( $attachments as $attachment_id ) {
            $attachment_id = (int) $attachment_id;
            if ( $attachment_id <= 0 ) {
                continue;
            }
            $file_url = wp_get_attachment_url( $attachment_id );
            // Check if attachment is referenced in any post content.
            $in_use = false;
            if ( $file_url ) {
                $like  = '%' . $wpdb->esc_like( $file_url ) . '%';
                $found = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_content LIKE %s AND post_status = 'publish' LIMIT 1", $like ) );
                if ( $found ) {
                    $in_use = true;
                }
            }
            // Check if used as featured image via _thumbnail_id.
            if ( ! $in_use ) {
                $meta_query = $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id' AND meta_value = %d LIMIT 1", $attachment_id ) );
                if ( $meta_query ) {
                    $in_use = true;
                }
            }
            if ( $in_use ) {
                continue;
            }
            if ( $dry_run ) {
                $candidates[] = $attachment_id;
            } else {
                $res = wp_delete_attachment( $attachment_id, true );
                if ( $res ) {
                    $deleted[] = $attachment_id;
                }
            }
        }
        return array(
            'success'    => true,
            'candidates' => $dry_run ? $candidates : array(),
            'deleted'    => $dry_run ? array() : $deleted,
            'message'    => $dry_run ? __( 'Dry run completed.', 'arthur-ai' ) : __( 'Unused media deleted.', 'arthur-ai' ),
        );
    }
}
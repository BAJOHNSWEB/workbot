<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Register additional image sizes for WordPress.
 *
 * The payload should contain a 'sizes' array of definitions. Each definition
 * should include 'name', 'width', 'height' and optional 'crop' boolean.
 * Sizes are stored in arthur_ai_custom_image_sizes and registered by
 * the media customiser on init. Existing definitions are merged.
 */
class Arthur_AI_Action_Add_Image_Sizes implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'add_image_sizes';
    }
    public function get_label() {
        return __( 'Add Image Sizes', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['sizes'] ) || ! is_array( $payload['sizes'] ) ) {
            return array( 'success' => false, 'message' => __( 'sizes array is required.', 'arthur-ai' ) );
        }
        $existing = get_option( 'arthur_ai_custom_image_sizes', array() );
        if ( ! is_array( $existing ) ) {
            $existing = array();
        }
        foreach ( $payload['sizes'] as $def ) {
            if ( ! is_array( $def ) || ! isset( $def['name'], $def['width'], $def['height'] ) ) {
                continue;
            }
            $name   = sanitize_key( (string) $def['name'] );
            $width  = (int) $def['width'];
            $height = (int) $def['height'];
            $crop   = false;
            if ( isset( $def['crop'] ) ) {
                $crop = (bool) $def['crop'];
            }
            if ( '' === $name || $width <= 0 || $height <= 0 ) {
                continue;
            }
            $existing[ $name ] = array( 'width' => $width, 'height' => $height, 'crop' => $crop );
        }
        update_option( 'arthur_ai_custom_image_sizes', $existing );
        return array( 'success' => true, 'message' => __( 'Image sizes updated.', 'arthur-ai' ) );
    }
}
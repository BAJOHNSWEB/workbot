<?php
/**
 * Edit a theme template file with backup.
 *
 * This action writes new content to a theme file after creating a backup in
 * the uploads directory. It requires confirmation to proceed.
 */
class Arthur_AI_Action_Edit_Theme_Template_File implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'edit_theme_template_file';
    }
    public function get_label() {
        return __( 'Edit Theme Template File', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $file_path = isset( $payload['file_path'] ) ? $payload['file_path'] : '';
        $new_content = isset( $payload['new_content'] ) ? $payload['new_content'] : '';
        $confirm = isset( $payload['confirm'] ) ? (bool) $payload['confirm'] : false;
        if ( ! $confirm ) {
            return array( 'success' => false, 'error' => __( 'Confirmation required.', 'arthur-ai-content-assistant' ) );
        }
        $theme_dir = get_stylesheet_directory();
        $abs_path  = realpath( $file_path );
        if ( false === $abs_path || strpos( $abs_path, $theme_dir ) !== 0 ) {
            return array( 'success' => false, 'error' => __( 'Invalid file path.', 'arthur-ai-content-assistant' ) );
        }
        // Create backup
        $backup_dir = WP_CONTENT_DIR . '/arthur-ai-backups';
        if ( ! is_dir( $backup_dir ) ) {
            wp_mkdir_p( $backup_dir );
        }
        $backup_file = $backup_dir . '/' . basename( $abs_path ) . '.' . time() . '.bak';
        if ( ! copy( $abs_path, $backup_file ) ) {
            return array( 'success' => false, 'error' => __( 'Failed to create backup.', 'arthur-ai-content-assistant' ) );
        }
        // Write new content
        $result = file_put_contents( $abs_path, $new_content );
        if ( false === $result ) {
            return array( 'success' => false, 'error' => __( 'Failed to write file.', 'arthur-ai-content-assistant' ) );
        }
        return array( 'success' => true, 'message' => __( 'File updated. Backup created.', 'arthur-ai-content-assistant' ), 'backup_file' => $backup_file );
    }
}
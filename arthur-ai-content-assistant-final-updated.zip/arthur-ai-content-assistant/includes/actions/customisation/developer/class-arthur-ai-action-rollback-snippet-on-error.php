<?php
/**
 * Roll back a code snippet in case of errors.
 *
 * Disables the given snippet so that it stops running. Previous versions are
 * not stored; this just turns off the snippet to restore site stability.
 */
class Arthur_AI_Action_Rollback_Snippet_On_Error implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'rollback_snippet_on_error';
    }
    public function get_label() {
        return __( 'Rollback Snippet on Error', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $snippet_id = isset( $payload['snippet_id'] ) ? sanitize_key( $payload['snippet_id'] ) : '';
        $snippets   = get_option( 'arthur_ai_code_snippets', array() );
        if ( isset( $snippets[ $snippet_id ] ) ) {
            $snippets[ $snippet_id ]['enabled'] = false;
            update_option( 'arthur_ai_code_snippets', $snippets );
            $mu_dir = WP_CONTENT_DIR . '/mu-plugins';
            $file   = $mu_dir . '/arthur-ai-snippet-' . $snippet_id . '.php';
            if ( file_exists( $file ) ) {
                unlink( $file );
            }
            return array( 'success' => true, 'message' => __( 'Snippet disabled.', 'arthur-ai-content-assistant' ) );
        }
        return array( 'success' => false, 'error' => __( 'Snippet not found.', 'arthur-ai-content-assistant' ) );
    }
}
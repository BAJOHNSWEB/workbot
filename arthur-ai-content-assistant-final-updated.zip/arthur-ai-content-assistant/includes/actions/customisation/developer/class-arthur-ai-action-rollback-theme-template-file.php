<?php
/**
 * Roll back a theme template file from a backup.
 *
 * Restores a file from a backup created by the edit action. The backup file
 * path must be supplied and exist within the backups directory.
 */
class Arthur_AI_Action_Rollback_Theme_Template_File implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'rollback_theme_template_file';
    }
    public function get_label() {
        return __( 'Rollback Theme Template File', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $backup_file = isset( $payload['backup_file'] ) ? $payload['backup_file'] : '';
        $target_file = isset( $payload['target_file'] ) ? $payload['target_file'] : '';
        $confirm     = isset( $payload['confirm'] ) ? (bool) $payload['confirm'] : false;
        if ( ! $confirm ) {
            return array( 'success' => false, 'error' => __( 'Confirmation required.', 'arthur-ai-content-assistant' ) );
        }
        $backup_dir = WP_CONTENT_DIR . '/arthur-ai-backups';
        $abs_backup = realpath( $backup_file );
        if ( false === $abs_backup || strpos( $abs_backup, $backup_dir ) !== 0 ) {
            return array( 'success' => false, 'error' => __( 'Invalid backup file.', 'arthur-ai-content-assistant' ) );
        }
        $abs_target = realpath( $target_file );
        if ( false === $abs_target ) {
            return array( 'success' => false, 'error' => __( 'Target file does not exist.', 'arthur-ai-content-assistant' ) );
        }
        if ( ! copy( $abs_backup, $abs_target ) ) {
            return array( 'success' => false, 'error' => __( 'Failed to restore file.', 'arthur-ai-content-assistant' ) );
        }
        return array( 'success' => true, 'message' => __( 'File restored from backup.', 'arthur-ai-content-assistant' ) );
    }
}
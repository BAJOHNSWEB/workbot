<?php
/**
 * Manage code snippets.
 *
 * Allows creation, update, deletion and toggling of code snippets stored in
 * a dedicated option and optionally written to the mu-plugins directory.
 */
class Arthur_AI_Action_Manage_Code_Snippets implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'manage_code_snippets';
    }
    public function get_label() {
        return __( 'Manage Code Snippets', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $action     = isset( $payload['action'] ) ? sanitize_key( $payload['action'] ) : '';
        $snippet_id = isset( $payload['snippet_id'] ) ? sanitize_key( $payload['snippet_id'] ) : '';
        $code       = isset( $payload['code'] ) ? $payload['code'] : '';
        $title      = isset( $payload['title'] ) ? sanitize_text_field( $payload['title'] ) : '';
        $snippets   = get_option( 'arthur_ai_code_snippets', array() );
        switch ( $action ) {
            case 'create':
                $id = uniqid( 'snippet_' );
                $snippets[ $id ] = array(
                    'title'   => $title,
                    'code'    => $code,
                    'enabled' => false,
                );
                update_option( 'arthur_ai_code_snippets', $snippets );
                return array( 'success' => true, 'snippet_id' => $id );
            case 'update':
                if ( isset( $snippets[ $snippet_id ] ) ) {
                    if ( ! empty( $title ) ) {
                        $snippets[ $snippet_id ]['title'] = $title;
                    }
                    if ( ! empty( $code ) ) {
                        $snippets[ $snippet_id ]['code'] = $code;
                    }
                    update_option( 'arthur_ai_code_snippets', $snippets );
                    return array( 'success' => true, 'snippet_id' => $snippet_id );
                }
                return array( 'success' => false, 'error' => __( 'Snippet not found.', 'arthur-ai-content-assistant' ) );
            case 'delete':
                if ( isset( $snippets[ $snippet_id ] ) ) {
                    unset( $snippets[ $snippet_id ] );
                    update_option( 'arthur_ai_code_snippets', $snippets );
                    return array( 'success' => true );
                }
                return array( 'success' => false, 'error' => __( 'Snippet not found.', 'arthur-ai-content-assistant' ) );
            case 'enable':
            case 'disable':
                if ( isset( $snippets[ $snippet_id ] ) ) {
                    $snippets[ $snippet_id ]['enabled'] = ( 'enable' === $action );
                    update_option( 'arthur_ai_code_snippets', $snippets );
                    // Write or remove from MU-plugins directory
                    $mu_dir = WP_CONTENT_DIR . '/mu-plugins';
                    if ( ! is_dir( $mu_dir ) ) {
                        wp_mkdir_p( $mu_dir );
                    }
                    $file = $mu_dir . '/arthur-ai-snippet-' . $snippet_id . '.php';
                    if ( $snippets[ $snippet_id ]['enabled'] ) {
                        // Prepend PHP opening tag if missing
                        $php_code = trim( $snippets[ $snippet_id ]['code'] );
                        if ( substr( $php_code, 0, 5 ) !== '<?php' ) {
                            $php_code = "<?php\n" . $php_code;
                        }
                        file_put_contents( $file, $php_code );
                    } else {
                        if ( file_exists( $file ) ) {
                            unlink( $file );
                        }
                    }
                    return array( 'success' => true, 'enabled' => $snippets[ $snippet_id ]['enabled'] );
                }
                return array( 'success' => false, 'error' => __( 'Snippet not found.', 'arthur-ai-content-assistant' ) );
            default:
                return array( 'success' => false, 'error' => __( 'Unknown action.', 'arthur-ai-content-assistant' ) );
        }
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure CRM integration settings.
 *
 * Stores authentication details and base URL for services like Salesforce,
 * HubSpot, Zoho or generic webhooks. Credentials are saved in plain
 * text; production use should encrypt or obfuscate sensitive data. The
 * integrations customiser will later use these settings when mapping
 * leads or contacts.
 */
class Arthur_AI_Action_Configure_Crm_Integration implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'configure_crm_integration';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Configure CRM Integration', 'arthur-ai' );
    }

    /**
     * Save CRM integration settings.
     *
     * @param array $payload {
     *     @type string $service   CRM provider slug.
     *     @type array  $auth      Auth credentials (e.g. tokens, client_id/secret).
     *     @type string $base_url  Base API URL or endpoint.
     * }
     * @return array Saved configuration with sensitive fields masked.
     */
    public function execute( array $payload ) {
        $service  = isset( $payload['service'] ) ? sanitize_key( (string) $payload['service'] ) : 'generic_webhook';
        $auth     = isset( $payload['auth'] ) && is_array( $payload['auth'] ) ? $payload['auth'] : array();
        $base_url = isset( $payload['base_url'] ) ? esc_url_raw( (string) $payload['base_url'] ) : '';
        $crms     = get_option( 'arthur_ai_crm_integrations', array() );
        if ( ! is_array( $crms ) ) {
            $crms = array();
        }
        $crms[ $service ] = array(
            'auth'     => $auth,
            'base_url' => $base_url,
        );
        update_option( 'arthur_ai_crm_integrations', $crms );
        // Mask sensitive fields for the response.
        $masked_auth = array();
        foreach ( $auth as $key => $value ) {
            $masked_auth[ $key ] = $value ? '********' : '';
        }
        return array(
            'success' => true,
            'service' => $service,
            'base_url' => $base_url,
            'auth_saved' => ! empty( $auth ),
        );
    }
}

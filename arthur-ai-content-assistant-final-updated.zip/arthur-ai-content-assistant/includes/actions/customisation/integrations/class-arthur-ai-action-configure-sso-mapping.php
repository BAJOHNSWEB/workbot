<?php
/**
 * Configure SSO role/attribute mapping.
 *
 * Maps identity provider claims or groups to WordPress roles. These mappings
 * are applied during SSO login to assign appropriate permissions.
 */
class Arthur_AI_Action_Configure_Sso_Mapping implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'configure_sso_mapping';
    }
    public function get_label() {
        return __( 'Configure SSO Mapping', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        $mapping  = isset( $payload['mapping'] ) && is_array( $payload['mapping'] ) ? $payload['mapping'] : array();
        $maps     = get_option( 'arthur_ai_sso_mappings', array() );
        $maps[ $provider ] = $mapping;
        update_option( 'arthur_ai_sso_mappings', $maps );
        return array(
            'success'  => true,
            'message'  => __( 'SSO mapping saved.', 'arthur-ai-content-assistant' ),
            'provider' => $provider,
            'mapping'  => $mapping,
        );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure field mappings for import operations.
 *
 * This action stores a mapping between source data fields and WordPress
 * fields/meta. It is used by the import_data_batch action to know how
 * to populate entities from imported data. Mappings are saved per
 * entity type (post, product, user, etc.).
 */
class Arthur_AI_Action_Configure_Import_Field_Mapping implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'configure_import_field_mapping';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Configure Import Field Mapping', 'arthur-ai' );
    }

    /**
     * Save field mapping for an entity type.
     *
     * @param array $payload {
     *     @type string $entity_type
     *     @type array  $mapping Source field => target field mapping.
     * }
     * @return array Result.
     */
    public function execute( array $payload ) {
        $entity_type = isset( $payload['entity_type'] ) ? sanitize_key( (string) $payload['entity_type'] ) : 'post';
        $mapping     = isset( $payload['mapping'] ) && is_array( $payload['mapping'] ) ? $payload['mapping'] : array();
        $mappings    = get_option( 'arthur_ai_import_mappings', array() );
        if ( ! is_array( $mappings ) ) {
            $mappings = array();
        }
        $mappings[ $entity_type ] = $mapping;
        update_option( 'arthur_ai_import_mappings', $mappings );
        return array(
            'success' => true,
            'entity_type' => $entity_type,
            'field_count' => count( $mapping ),
        );
    }
}

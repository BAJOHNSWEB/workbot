<?php
/**
 * Configure Single Sign-On (SSO) provider settings.
 *
 * Stores the identity provider details such as endpoints, client IDs and
 * secrets. This configuration is used by Arthur for later login flows.
 */
class Arthur_AI_Action_Configure_Sso_Provider implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'configure_sso_provider';
    }
    public function get_label() {
        return __( 'Configure SSO Provider', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        $settings = isset( $payload['settings'] ) && is_array( $payload['settings'] ) ? $payload['settings'] : array();
        $configs  = get_option( 'arthur_ai_sso_providers', array() );
        $configs[ $provider ] = $settings;
        update_option( 'arthur_ai_sso_providers', $configs );
        return array(
            'success' => true,
            'message' => __( 'SSO provider configuration saved.', 'arthur-ai-content-assistant' ),
            'provider' => $provider,
        );
    }
}
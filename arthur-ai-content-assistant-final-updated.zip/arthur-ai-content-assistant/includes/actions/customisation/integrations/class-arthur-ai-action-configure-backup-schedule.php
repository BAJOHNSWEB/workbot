<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure backup schedules and retention.
 *
 * This action attempts to update the schedule and retention settings of
 * supported backup plugins. If automatic configuration is not
 * available, it stores preferences in an option for administrative
 * reference. It does not guarantee that schedules are applied when
 * plugins lack programmatic APIs.
 */
class Arthur_AI_Action_Configure_Backup_Schedule implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'configure_backup_schedule';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Configure Backup Schedule', 'arthur-ai' );
    }

    /**
     * Configure backup schedules.
     *
     * @param array $payload {
     *     @type string $plugin
     *     @type string $schedule
     *     @type int    $retention_count
     * }
     * @return array Result summarising the applied schedule.
     */
    public function execute( array $payload ) {
        $plugin   = isset( $payload['plugin'] ) ? sanitize_key( (string) $payload['plugin'] ) : '';
        $schedule = isset( $payload['schedule'] ) ? sanitize_key( (string) $payload['schedule'] ) : 'weekly';
        $retain   = isset( $payload['retention_count'] ) ? max( 1, (int) $payload['retention_count'] ) : 5;
        $applied  = false;
        switch ( $plugin ) {
            case 'updraftplus':
                if ( class_exists( 'UpdraftPlus' ) ) {
                    $options = get_option( 'updraft_options', array() );
                    $options['backup_schedule'] = $schedule;
                    $options['file_retention'] = $retain;
                    $options['db_retention']   = $retain;
                    update_option( 'updraft_options', $options );
                    $applied = true;
                }
                break;
            case 'backwpup':
                if ( class_exists( 'BackWPup' ) ) {
                    // BackWPup job settings would need direct job config edits; skip automatic update.
                    $applied = false;
                }
                break;
            default:
                break;
        }
        // Persist preferences regardless, for reference.
        update_option( 'arthur_ai_backup_prefs', array(
            'plugin'  => $plugin,
            'schedule'=> $schedule,
            'retention_count' => $retain,
        ) );
        return array(
            'success' => true,
            'plugin'  => $plugin,
            'applied' => $applied,
            'schedule' => $schedule,
            'retention_count' => $retain,
        );
    }
}

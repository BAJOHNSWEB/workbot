<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Export a set of entities for analysis or backup.
 *
 * Exports posts, products or users to CSV or JSON. The result can be
 * returned as raw data or saved to a file under the uploads directory
 * with a link provided. Filters can limit which entities are exported.
 */
class Arthur_AI_Action_Export_Data_Batch implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'export_data_batch';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Export Data Batch', 'arthur-ai' );
    }

    /**
     * Export data based on entity type.
     *
     * @param array $payload {
     *     @type string $entity_type Type of entity (post, product, user).
     *     @type string $format      Format (csv or json).
     *     @type array  $filters     Optional filters (e.g. post_type, date_range).
     * }
     * @return array Result with data or file URL.
     */
    public function execute( array $payload ) {
        $entity_type = isset( $payload['entity_type'] ) ? sanitize_key( (string) $payload['entity_type'] ) : 'post';
        $format      = isset( $payload['format'] ) ? strtolower( (string) $payload['format'] ) : 'json';
        $filters     = isset( $payload['filters'] ) && is_array( $payload['filters'] ) ? $payload['filters'] : array();
        $data        = array();
        switch ( $entity_type ) {
            case 'product':
                if ( ! class_exists( 'WC_Product' ) ) {
                    return array( 'success' => false, 'error' => __( 'WooCommerce not active.', 'arthur-ai' ) );
                }
                $args = array( 'limit' => -1 );
                // Additional filters can be applied.
                $products = wc_get_products( $args );
                foreach ( $products as $product ) {
                    $data[] = array(
                        'ID'          => $product->get_id(),
                        'name'        => $product->get_name(),
                        'sku'         => $product->get_sku(),
                        'price'       => $product->get_price(),
                        'status'      => $product->get_status(),
                        'description' => $product->get_description(),
                    );
                }
                break;
            case 'user':
                $args = array( 'fields' => array( 'ID', 'user_login', 'user_email', 'user_registered' ) );
                $users = get_users( $args );
                foreach ( $users as $user ) {
                    $data[] = array(
                        'ID'             => $user->ID,
                        'user_login'     => $user->user_login,
                        'user_email'     => $user->user_email,
                        'user_registered'=> $user->user_registered,
                    );
                }
                break;
            default:
                // Posts: allow filtering by post_type or date range.
                $args = array(
                    'post_type'      => isset( $filters['post_type'] ) ? $filters['post_type'] : 'post',
                    'posts_per_page' => -1,
                    'post_status'    => 'any',
                );
                if ( isset( $filters['date_after'] ) ) {
                    $args['date_query'][] = array( 'after' => $filters['date_after'] );
                }
                if ( isset( $filters['date_before'] ) ) {
                    $args['date_query'][] = array( 'before' => $filters['date_before'] );
                }
                $query = new WP_Query( $args );
                foreach ( $query->posts as $post ) {
                    $data[] = array(
                        'ID'           => $post->ID,
                        'post_title'   => $post->post_title,
                        'post_type'    => $post->post_type,
                        'post_status'  => $post->post_status,
                        'post_date'    => $post->post_date,
                    );
                }
                break;
        }
        if ( 'csv' === $format ) {
            // Generate CSV content.
            $headers = array();
            if ( ! empty( $data ) ) {
                $headers = array_keys( $data[0] );
            }
            $csv_content = '';
            if ( ! empty( $headers ) ) {
                $csv_content .= implode( ',', $headers ) . "\n";
                foreach ( $data as $row ) {
                    $row_values = array();
                    foreach ( $headers as $header ) {
                        $row_values[] = isset( $row[ $header ] ) ? str_replace( ',', ' ', (string) $row[ $header ] ) : '';
                    }
                    $csv_content .= implode( ',', $row_values ) . "\n";
                }
            }
            // Save file to uploads.
            $upload_dir = wp_upload_dir();
            $file_name  = 'arthur_ai_export_' . time() . '.csv';
            $file_path  = trailingslashit( $upload_dir['path'] ) . $file_name;
            file_put_contents( $file_path, $csv_content );
            return array(
                'success' => true,
                'file_url' => $upload_dir['url'] . '/' . $file_name,
            );
        }
        // Return raw data for JSON.
        return array(
            'success' => true,
            'data'    => $data,
        );
    }
}

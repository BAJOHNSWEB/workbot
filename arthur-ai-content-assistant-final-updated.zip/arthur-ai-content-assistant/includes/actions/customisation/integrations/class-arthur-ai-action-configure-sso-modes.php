<?php
/**
 * Configure SSO modes (enforce SSO or mixed auth).
 */
class Arthur_AI_Action_Configure_Sso_Modes implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'configure_sso_modes';
    }
    public function get_label() {
        return __( 'Configure SSO Modes', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $mode          = isset( $payload['mode'] ) ? sanitize_key( $payload['mode'] ) : 'allow_both';
        $login_redirect = isset( $payload['login_redirect'] ) ? esc_url_raw( $payload['login_redirect'] ) : '';
        $settings      = array(
            'mode'           => $mode,
            'login_redirect' => $login_redirect,
        );
        update_option( 'arthur_ai_sso_modes', $settings );
        return array(
            'success' => true,
            'settings' => $settings,
        );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure tracking scripts like GA4, Meta Pixel and generic snippets.
 *
 * Each script definition contains a type, identifier/configuration,
 * location (head or body_end) and an enabled flag. Scripts are saved
 * in an option and the analytics customiser outputs them accordingly.
 */
class Arthur_AI_Action_Configure_Tracking_Scripts implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'configure_tracking_scripts';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Configure Tracking Scripts', 'arthur-ai' );
    }

    /**
     * Save tracking script definitions.
     *
     * @param array $payload {
     *     @type array $scripts List of script configs (type, id/config, location, enabled).
     * }
     * @return array Result summarising saved scripts.
     */
    public function execute( array $payload ) {
        if ( ! isset( $payload['scripts'] ) || ! is_array( $payload['scripts'] ) ) {
            return array( 'success' => false, 'message' => __( 'No scripts provided.', 'arthur-ai' ) );
        }
        $scripts_to_store = array();
        foreach ( $payload['scripts'] as $script ) {
            if ( ! isset( $script['type'] ) ) {
                continue;
            }
            $type     = sanitize_key( (string) $script['type'] );
            $id_config = isset( $script['id'] ) ? $script['id'] : ( isset( $script['config'] ) ? $script['config'] : '' );
            $location = isset( $script['location'] ) ? sanitize_key( (string) $script['location'] ) : 'head';
            $enabled  = isset( $script['enabled'] ) ? (bool) $script['enabled'] : true;
            $scripts_to_store[ $type ] = array(
                'id_config' => $id_config,
                'location'  => $location,
                'enabled'   => $enabled,
            );
        }
        update_option( 'arthur_ai_tracking_scripts', $scripts_to_store );
        return array(
            'success' => true,
            'scripts' => array_keys( $scripts_to_store ),
        );
    }
}

<?php
/**
 * Configure directory sync settings.
 *
 * Stores connection details for syncing user accounts from an external
 * directory (LDAP, Azure AD, etc.). No actual sync is performed here.
 */
class Arthur_AI_Action_Configure_Directory_Sync implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'configure_directory_sync';
    }
    public function get_label() {
        return __( 'Configure Directory Sync', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        $auth     = isset( $payload['auth'] ) ? $payload['auth'] : array();
        $rules    = isset( $payload['sync_rules'] ) ? $payload['sync_rules'] : array();
        $configs  = get_option( 'arthur_ai_directory_sync', array() );
        $configs[ $provider ] = array(
            'auth'      => $auth,
            'sync_rules' => $rules,
        );
        update_option( 'arthur_ai_directory_sync', $configs );
        return array(
            'success'  => true,
            'provider' => $provider,
            'message'  => __( 'Directory sync settings saved.', 'arthur-ai-content-assistant' ),
        );
    }
}
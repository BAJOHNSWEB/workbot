<?php
/**
 * Test the SSO connection.
 *
 * Attempts a simple connection to the configured identity provider. Without
 * provider-specific APIs this action only verifies that configuration exists.
 */
class Arthur_AI_Action_Test_Sso_Connection implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'test_sso_connection';
    }
    public function get_label() {
        return __( 'Test SSO Connection', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        $configs  = get_option( 'arthur_ai_sso_providers', array() );
        if ( empty( $configs[ $provider ] ) ) {
            return array( 'success' => false, 'error' => __( 'No configuration found for this provider.', 'arthur-ai-content-assistant' ) );
        }
        // Without external libraries we cannot perform a real handshake, so we return success if config exists.
        return array(
            'success'  => true,
            'provider' => $provider,
            'message'  => __( 'Configuration found. Real connection testing requires provider SDK.', 'arthur-ai-content-assistant' ),
        );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Store a backup/restore checklist for administrators.
 *
 * This action saves informational content for restoring from backups. It
 * creates or updates an admin notice page under Tools or stores the
 * content in an option. Administrators can refer to this checklist
 * during disaster recovery; the plugin does not perform any restore
 * operations automatically.
 */
class Arthur_AI_Action_Store_Backup_Restore_Checklist implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'store_backup_restore_checklist';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Store Backup Restore Checklist', 'arthur-ai' );
    }

    /**
     * Save checklist content.
     *
     * @param array $payload {
     *     @type string $content Text or HTML content of the checklist.
     * }
     * @return array Result.
     */
    public function execute( array $payload ) {
        $content = isset( $payload['content'] ) ? wp_kses_post( (string) $payload['content'] ) : '';
        update_option( 'arthur_ai_backup_restore_checklist', $content );
        return array(
            'success' => true,
            'saved'   => ! empty( $content ),
        );
    }
}

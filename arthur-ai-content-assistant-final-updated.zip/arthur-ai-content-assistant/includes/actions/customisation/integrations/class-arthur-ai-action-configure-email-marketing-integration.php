<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure connection to an email marketing platform.
 *
 * Stores API credentials and endpoint details for services like Mailchimp,
 * Klaviyo or generic webhooks. Sensitive values should be stored in a
 * secure manner; this action stores them in options for demonstration
 * purposes only. The integrations customiser will use these details
 * when pushing contacts via automation rules.
 */
class Arthur_AI_Action_Configure_Email_Marketing_Integration implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'configure_email_marketing_integration';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Configure Email Marketing Integration', 'arthur-ai' );
    }

    /**
     * Save integration details.
     *
     * @param array $payload {
     *     @type string $service   Service slug (mailchimp, klaviyo, generic_webhook).
     *     @type string $api_key   API key or token.
     *     @type string $endpoint  Endpoint or list/audience ID.
     * }
     * @return array Saved configuration (sensitive values masked).
     */
    public function execute( array $payload ) {
        $service  = isset( $payload['service'] ) ? sanitize_key( (string) $payload['service'] ) : 'generic_webhook';
        $api_key  = isset( $payload['api_key'] ) ? trim( (string) $payload['api_key'] ) : '';
        $endpoint = isset( $payload['endpoint'] ) ? sanitize_text_field( (string) $payload['endpoint'] ) : '';
        // Persist. In a real implementation, consider encrypting the API key.
        $integrations = get_option( 'arthur_ai_email_integrations', array() );
        if ( ! is_array( $integrations ) ) {
            $integrations = array();
        }
        $integrations[ $service ] = array(
            'api_key'  => $api_key,
            'endpoint' => $endpoint,
        );
        update_option( 'arthur_ai_email_integrations', $integrations );
        return array(
            'success' => true,
            'service' => $service,
            'endpoint' => $endpoint,
            'api_key_saved' => $api_key ? true : false,
        );
    }
}

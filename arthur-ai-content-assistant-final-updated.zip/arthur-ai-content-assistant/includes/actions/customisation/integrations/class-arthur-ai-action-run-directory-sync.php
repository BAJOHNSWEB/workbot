<?php
/**
 * Run a directory sync.
 *
 * Attempts to synchronise users from an external directory according to
 * previously configured rules. As there is no direct integration here,
 * this action returns a not implemented result.
 */
class Arthur_AI_Action_Run_Directory_Sync implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'run_directory_sync';
    }
    public function get_label() {
        return __( 'Run Directory Sync', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        $configs  = get_option( 'arthur_ai_directory_sync', array() );
        if ( empty( $configs[ $provider ] ) ) {
            return array( 'success' => false, 'error' => __( 'No sync configuration for this provider.', 'arthur-ai-content-assistant' ) );
        }
        return array(
            'success'  => false,
            'provider' => $provider,
            'message'  => __( 'Directory sync execution not implemented. Please implement a provider integration.', 'arthur-ai-content-assistant' ),
        );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure site‑wide webhooks.
 *
 * Stores generic webhook definitions that can be used across automation
 * rules. Each webhook has a name, URL, HTTP method, headers and a
 * body template. Body placeholders will be replaced at runtime via the
 * integrations customiser.
 */
class Arthur_AI_Action_Configure_Global_Webhooks implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'configure_global_webhooks';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Configure Global Webhooks', 'arthur-ai' );
    }

    /**
     * Save webhook definitions.
     *
     * @param array $payload {
     *     @type array $webhooks List of webhook configurations.
     * }
     * @return array Result summarising saved hooks.
     */
    public function execute( array $payload ) {
        if ( ! isset( $payload['webhooks'] ) || ! is_array( $payload['webhooks'] ) ) {
            return array( 'success' => false, 'message' => __( 'No webhooks provided.', 'arthur-ai' ) );
        }
        $existing = get_option( 'arthur_ai_global_webhooks', array() );
        if ( ! is_array( $existing ) ) {
            $existing = array();
        }
        foreach ( $payload['webhooks'] as $hook ) {
            if ( ! isset( $hook['name'] ) || ! isset( $hook['url'] ) ) {
                continue;
            }
            $name    = sanitize_key( (string) $hook['name'] );
            $url     = esc_url_raw( (string) $hook['url'] );
            $method  = isset( $hook['method'] ) ? strtoupper( sanitize_text_field( (string) $hook['method'] ) ) : 'POST';
            $headers = isset( $hook['headers'] ) && is_array( $hook['headers'] ) ? $hook['headers'] : array();
            $body    = isset( $hook['body_template'] ) ? $hook['body_template'] : array();
            $existing[ $name ] = array(
                'url'     => $url,
                'method'  => $method,
                'headers' => $headers,
                'body_template' => $body,
            );
        }
        update_option( 'arthur_ai_global_webhooks', $existing );
        return array(
            'success' => true,
            'webhooks' => array_keys( $existing ),
        );
    }
}

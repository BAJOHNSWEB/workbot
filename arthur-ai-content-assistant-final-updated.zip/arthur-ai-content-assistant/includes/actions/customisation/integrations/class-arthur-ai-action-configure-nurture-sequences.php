<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure nurture sequences for email marketing.
 *
 * Stores definitions of email sequences to be sent via an email marketing
 * service. Each sequence contains multiple steps with delays, subjects
 * and bodies. The integrations customiser may invoke appropriate API
 * calls if supported, otherwise the definitions serve as documentation.
 */
class Arthur_AI_Action_Configure_Nurture_Sequences implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'configure_nurture_sequences';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Configure Nurture Sequences', 'arthur-ai' );
    }

    /**
     * Save nurture sequence definitions.
     *
     * @param array $payload {
     *     @type string $service  Email service slug.
     *     @type array  $sequence Sequence definition with name and steps.
     * }
     * @return array Result summarising saved sequence.
     */
    public function execute( array $payload ) {
        $service  = isset( $payload['service'] ) ? sanitize_key( (string) $payload['service'] ) : 'generic';
        $sequence = isset( $payload['sequence'] ) && is_array( $payload['sequence'] ) ? $payload['sequence'] : array();
        $sequences = get_option( 'arthur_ai_nurture_sequences', array() );
        if ( ! is_array( $sequences ) ) {
            $sequences = array();
        }
        if ( isset( $sequence['name'] ) ) {
            $name = sanitize_title( (string) $sequence['name'] );
            $sequences[ $service . ':' . $name ] = $sequence;
        }
        update_option( 'arthur_ai_nurture_sequences', $sequences );
        return array(
            'success' => true,
            'service' => $service,
            'saved_sequences' => count( $sequences ),
        );
    }
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Create or update an analytics dashboard page.
 *
 * This action creates a WordPress page containing the provided layout,
 * intended for internal analytics dashboards. External dashboards can
 * be embedded via iframes or other markup. The page ID is stored in
 * an option for later reference. It does not attempt to generate
 * analytics data itself.
 */
class Arthur_AI_Action_Create_Analytics_Dashboard_Page implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'create_analytics_dashboard_page';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Create Analytics Dashboard Page', 'arthur-ai' );
    }

    /**
     * Create or update a dashboard page.
     *
     * @param array $payload {
     *     @type string $page_title
     *     @type string $layout
     * }
     * @return array Page information.
     */
    public function execute( array $payload ) {
        $title  = isset( $payload['page_title'] ) ? sanitize_text_field( (string) $payload['page_title'] ) : __( 'Analytics Dashboard', 'arthur-ai' );
        $layout = isset( $payload['layout'] ) ? (string) $payload['layout'] : '';
        // See if a dashboard page already exists.
        $page_id = (int) get_option( 'arthur_ai_analytics_dashboard_page_id', 0 );
        if ( $page_id > 0 && get_post( $page_id ) ) {
            // Update existing page.
            $post_id = wp_update_post( array(
                'ID'           => $page_id,
                'post_title'   => $title,
                'post_content' => wp_kses_post( $layout ),
            ), true );
            if ( is_wp_error( $post_id ) ) {
                return array( 'success' => false, 'error' => $post_id->get_error_message() );
            }
            $page_id = $post_id;
        } else {
            // Create a new page.
            $page_id = wp_insert_post( array(
                'post_title'   => $title,
                'post_name'    => sanitize_title( $title ),
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_content' => wp_kses_post( $layout ),
            ), true );
            if ( is_wp_error( $page_id ) ) {
                return array( 'success' => false, 'error' => $page_id->get_error_message() );
            }
            update_option( 'arthur_ai_analytics_dashboard_page_id', $page_id );
        }
        return array(
            'success' => true,
            'page_id' => $page_id,
            'url'     => get_permalink( $page_id ),
        );
    }
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Trigger a backup job via supported backup plugins.
 *
 * This action invokes the backup process in plugins like UpdraftPlus,
 * BackWPup or Jetpack Backup when possible. If no recognised plugin is
 * active, it returns an error. The result includes job ID or status
 * information if provided by the plugin API.
 */
class Arthur_AI_Action_Trigger_Site_Backup implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'trigger_site_backup';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Trigger Site Backup', 'arthur-ai' );
    }

    /**
     * Trigger a backup job.
     *
     * @param array $payload {
     *     @type string $plugin      Backup plugin identifier (updraftplus, backwpup, jetpack_backup).
     *     @type string $backup_type Optional backup type (full, db_only, files_only).
     * }
     * @return array Result with status or error.
     */
    public function execute( array $payload ) {
        $plugin      = isset( $payload['plugin'] ) ? sanitize_key( (string) $payload['plugin'] ) : '';
        $backup_type = isset( $payload['backup_type'] ) ? sanitize_key( (string) $payload['backup_type'] ) : 'full';
        switch ( $plugin ) {
            case 'updraftplus':
                if ( class_exists( 'UpdraftPlus' ) ) {
                    // Trigger UpdraftPlus backup via its commands.
                    do_action( 'updraftplus_backupnow', array( 'onlyfiles' => ( 'db_only' === $backup_type ) ? false : true, 'onlydb' => ( 'files_only' === $backup_type ) ? false : true ) );
                    return array( 'success' => true, 'message' => __( 'UpdraftPlus backup triggered.', 'arthur-ai' ) );
                }
                break;
            case 'backwpup':
                if ( class_exists( 'BackWPup' ) ) {
                    // BackWPup stores jobs; we can trigger the default job.
                    do_action( 'backwpup_run_schedule', null );
                    return array( 'success' => true, 'message' => __( 'BackWPup backup triggered.', 'arthur-ai' ) );
                }
                break;
            case 'jetpack_backup':
                if ( class_exists( 'Automattic\Jetpack\Constants' ) ) {
                    // Jetpack Backup triggers automatically; manual trigger not exposed.
                    return array( 'success' => false, 'error' => __( 'Jetpack Backup does not support manual triggering via API.', 'arthur-ai' ) );
                }
                break;
            default:
                break;
        }
        return array( 'success' => false, 'error' => __( 'No supported backup plugin found.', 'arthur-ai' ) );
    }
}

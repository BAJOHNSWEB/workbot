<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Import a batch of data into WordPress.
 *
 * This action imports posts, products or users from an array of parsed
 * data. It assumes that the data is already parsed from CSV/XML. A
 * mapping array defines how source fields map to WordPress fields or
 * meta. For products, WooCommerce must be active. For users, the
 * mapping should include at least username and email. This action
 * returns lists of created or updated IDs.
 */
class Arthur_AI_Action_Import_Data_Batch implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'import_data_batch';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Import Data Batch', 'arthur-ai' );
    }

    /**
     * Import data into WordPress.
     *
     * @param array $payload {
     *     @type string $source_type  Type of source (csv, xml, array).
     *     @type string $entity_type  Entity type (post, product, user).
     *     @type array  $mapping      Field mapping from source keys to WP fields.
     *     @type array  $batch        Array of parsed data rows.
     * }
     * @return array Summary of imported entities.
     */
    public function execute( array $payload ) {
        $entity_type = isset( $payload['entity_type'] ) ? sanitize_key( (string) $payload['entity_type'] ) : 'post';
        $mapping     = isset( $payload['mapping'] ) && is_array( $payload['mapping'] ) ? $payload['mapping'] : array();
        $batch       = isset( $payload['batch'] ) && is_array( $payload['batch'] ) ? $payload['batch'] : array();
        $created     = array();
        $updated     = array();
        foreach ( $batch as $row ) {
            // Prepare data according to mapping.
            $data = array();
            foreach ( $mapping as $src => $target ) {
                if ( ! isset( $row[ $src ] ) ) {
                    continue;
                }
                $value = $row[ $src ];
                // Target can be e.g. title, post_content, meta:_sku
                if ( 0 === strpos( $target, 'meta:' ) ) {
                    $meta_key = substr( $target, 5 );
                    $data['meta'][ $meta_key ] = $value;
                } else {
                    $data[ $target ] = $value;
                }
            }
            switch ( $entity_type ) {
                case 'product':
                    if ( ! class_exists( 'WC_Product' ) ) {
                        continue 2;
                    }
                    $product = null;
                    if ( isset( $data['id'] ) && $data['id'] ) {
                        $product = wc_get_product( (int) $data['id'] );
                    }
                    if ( $product ) {
                        // Update product fields.
                        if ( isset( $data['title'] ) ) {
                            $product->set_name( $data['title'] );
                        }
                        if ( isset( $data['regular_price'] ) ) {
                            $product->set_regular_price( $data['regular_price'] );
                        }
                        if ( isset( $data['description'] ) ) {
                            $product->set_description( $data['description'] );
                        }
                        $product->save();
                        if ( isset( $data['meta'] ) ) {
                            foreach ( $data['meta'] as $meta_key => $meta_value ) {
                                update_post_meta( $product->get_id(), $meta_key, $meta_value );
                            }
                        }
                        $updated[] = $product->get_id();
                    } else {
                        $product = new WC_Product_Simple();
                        if ( isset( $data['title'] ) ) {
                            $product->set_name( $data['title'] );
                        }
                        if ( isset( $data['regular_price'] ) ) {
                            $product->set_regular_price( $data['regular_price'] );
                        }
                        if ( isset( $data['description'] ) ) {
                            $product->set_description( $data['description'] );
                        }
                        $product->save();
                        $post_id = $product->get_id();
                        if ( isset( $data['meta'] ) ) {
                            foreach ( $data['meta'] as $meta_key => $meta_value ) {
                                update_post_meta( $post_id, $meta_key, $meta_value );
                            }
                        }
                        $created[] = $post_id;
                    }
                    break;
                case 'user':
                    // Ensure required fields exist: user_login and user_email.
                    if ( ! isset( $data['user_login'] ) || ! isset( $data['user_email'] ) ) {
                        continue 2;
                    }
                    $user_id = username_exists( $data['user_login'] );
                    if ( $user_id ) {
                        // Update user.
                        wp_update_user( array_merge( $data, array( 'ID' => $user_id ) ) );
                        if ( isset( $data['meta'] ) ) {
                            foreach ( $data['meta'] as $meta_key => $meta_value ) {
                                update_user_meta( $user_id, $meta_key, $meta_value );
                            }
                        }
                        $updated[] = $user_id;
                    } else {
                        $user_id = wp_insert_user( $data );
                        if ( ! is_wp_error( $user_id ) ) {
                            if ( isset( $data['meta'] ) ) {
                                foreach ( $data['meta'] as $meta_key => $meta_value ) {
                                    update_user_meta( $user_id, $meta_key, $meta_value );
                                }
                            }
                            $created[] = $user_id;
                        }
                    }
                    break;
                default:
                    // Post (default): insert or update.
                    $postarr = array(
                        'post_type'   => isset( $data['post_type'] ) ? $data['post_type'] : 'post',
                        'post_status' => isset( $data['post_status'] ) ? $data['post_status'] : 'publish',
                    );
                    if ( isset( $data['ID'] ) ) {
                        $postarr['ID'] = (int) $data['ID'];
                    }
                    if ( isset( $data['title'] ) ) {
                        $postarr['post_title'] = $data['title'];
                    }
                    if ( isset( $data['post_content'] ) ) {
                        $postarr['post_content'] = $data['post_content'];
                    }
                    $post_id = wp_insert_post( $postarr, true );
                    if ( is_wp_error( $post_id ) ) {
                        continue 2;
                    }
                    if ( isset( $data['meta'] ) ) {
                        foreach ( $data['meta'] as $meta_key => $meta_value ) {
                            update_post_meta( $post_id, $meta_key, $meta_value );
                        }
                    }
                    if ( isset( $row['ID'] ) ) {
                        $updated[] = $post_id;
                    } else {
                        $created[] = $post_id;
                    }
                    break;
            }
        }
        return array(
            'success' => true,
            'created' => $created,
            'updated' => $updated,
        );
    }
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure automation rules for triggers and actions.
 *
 * Each rule defines a trigger (e.g. new order, new user, form submission)
 * with optional conditions, and a set of actions to run when the trigger
 * occurs. Actions may include adding tags, calling webhooks, adding
 * contacts to CRM or email lists, etc. The integrations customiser
 * executes these rules at runtime.
 */
class Arthur_AI_Action_Configure_Automation_Rules implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'configure_automation_rules';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Configure Automation Rules', 'arthur-ai' );
    }

    /**
     * Save automation rules.
     *
     * @param array $payload {
     *     @type array $rules List of rule definitions with triggers and actions.
     * }
     * @return array Result summarising stored rules.
     */
    public function execute( array $payload ) {
        if ( ! isset( $payload['rules'] ) || ! is_array( $payload['rules'] ) ) {
            return array( 'success' => false, 'message' => __( 'No rules provided.', 'arthur-ai' ) );
        }
        // Basic validation: ensure each rule has trigger and actions.
        $rules_to_store = array();
        foreach ( $payload['rules'] as $index => $rule ) {
            if ( ! isset( $rule['trigger'] ) || ! isset( $rule['actions'] ) ) {
                continue;
            }
            $rules_to_store[] = $rule;
        }
        update_option( 'arthur_ai_automation_rules', $rules_to_store );
        return array(
            'success' => true,
            'rule_count' => count( $rules_to_store ),
        );
    }
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure tracking events to trigger on user actions.
 *
 * This action stores definitions of events such as purchases, form
 * submissions, or custom element clicks. Each event includes a name,
 * trigger and payload mapping for sending data to analytics systems. The
 * analytics customiser executes these when the triggers fire.
 */
class Arthur_AI_Action_Configure_Tracking_Events implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'configure_tracking_events';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Configure Tracking Events', 'arthur-ai' );
    }

    /**
     * Save tracking event definitions.
     *
     * @param array $payload {
     *     @type array $events List of event definitions (name, trigger, payload_mapping).
     * }
     * @return array Result summarising saved events.
     */
    public function execute( array $payload ) {
        if ( ! isset( $payload['events'] ) || ! is_array( $payload['events'] ) ) {
            return array( 'success' => false, 'message' => __( 'No events provided.', 'arthur-ai' ) );
        }
        $events_to_store = array();
        foreach ( $payload['events'] as $event ) {
            if ( ! isset( $event['name'] ) || ! isset( $event['trigger'] ) ) {
                continue;
            }
            $name = sanitize_key( (string) $event['name'] );
            $events_to_store[ $name ] = array(
                'trigger' => $event['trigger'],
                'payload_mapping' => isset( $event['payload_mapping'] ) ? $event['payload_mapping'] : array(),
            );
        }
        update_option( 'arthur_ai_tracking_events', $events_to_store );
        return array(
            'success' => true,
            'events'  => array_keys( $events_to_store ),
        );
    }
}

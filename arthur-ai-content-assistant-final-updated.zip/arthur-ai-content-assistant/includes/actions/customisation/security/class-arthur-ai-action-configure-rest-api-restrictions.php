<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure restrictions on the REST API for unauthenticated access.
 *
 * This action allows administrators to require authentication for all REST
 * requests or to allow unauthenticated access to specific route prefixes.
 * The security customiser applies these settings via the
 * rest_authentication_errors filter. Existing restrictions for guests may
 * remain; this action supersedes the simpler disable_rest_api_for_guests
 * flag when set.
 */
class Arthur_AI_Action_Configure_Rest_Api_Restrictions implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'configure_rest_api_restrictions';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Configure REST API Restrictions', 'arthur-ai' );
    }

    /**
     * Save REST API restriction settings.
     *
     * @param array $payload {
     *     @type string $mode         Either 'authenticated_only' or 'allow_public_for_routes'.
     *     @type array  $allowed_routes Route prefixes allowed when mode is allow_public_for_routes.
     * }
     * @return array Result.
     */
    public function execute( array $payload ) {
        $mode          = isset( $payload['mode'] ) ? sanitize_text_field( (string) $payload['mode'] ) : 'authenticated_only';
        $allowed_routes = array();
        if ( isset( $payload['allowed_routes'] ) && is_array( $payload['allowed_routes'] ) ) {
            foreach ( $payload['allowed_routes'] as $route ) {
                $route = trim( sanitize_text_field( (string) $route ) );
                if ( '' !== $route ) {
                    $allowed_routes[] = $route;
                }
            }
        }
        update_option( 'arthur_ai_rest_api_restrictions', array(
            'mode'          => $mode,
            'allowed_routes' => $allowed_routes,
        ) );
        return array(
            'success' => true,
            'mode'    => $mode,
            'allowed_routes' => $allowed_routes,
        );
    }
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Process user privacy requests (export or erase).
 *
 * This action interfaces with WordPress’s built‑in privacy request system.
 * It can create new export/erasure requests or update existing ones to
 * reflect confirmation/completion. For export requests, it triggers
 * processing of personal data and returns the request ID and current
 * status.
 */
class Arthur_AI_Action_Process_Privacy_Requests implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'process_privacy_requests';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Process Privacy Requests', 'arthur-ai' );
    }

    /**
     * Handle privacy requests.
     *
     * @param array $payload {
     *     @type array $requests Each item with email, type (export|erase), and action.
     * }
     * @return array Summary of processed requests.
     */
    public function execute( array $payload ) {
        $results = array();
        if ( ! isset( $payload['requests'] ) || ! is_array( $payload['requests'] ) ) {
            return array( 'success' => false, 'message' => __( 'No requests provided.', 'arthur-ai' ) );
        }
        foreach ( $payload['requests'] as $req ) {
            $email  = isset( $req['email'] ) ? sanitize_email( (string) $req['email'] ) : '';
            $type   = isset( $req['type'] ) ? sanitize_key( (string) $req['type'] ) : 'export';
            $action = isset( $req['action'] ) ? sanitize_key( (string) $req['action'] ) : 'create_request';
            if ( ! in_array( $type, array( 'export', 'erase' ), true ) || '' === $email ) {
                continue;
            }
            switch ( $action ) {
                case 'create_request':
                    $request_id = wp_create_user_request( $email, $type );
                    if ( is_wp_error( $request_id ) ) {
                        $results[] = array( 'email' => $email, 'error' => $request_id->get_error_message() );
                    } else {
                        $results[] = array( 'email' => $email, 'request_id' => $request_id, 'status' => 'created' );
                    }
                    break;
                case 'mark_confirmed':
                    // Mark as confirmed if the request exists and is pending confirmation.
                    $req_obj = wp_get_user_request( $req['request_id'] );
                    if ( $req_obj && 'request-pending' === $req_obj->status ) {
                        update_user_request( $req['request_id'], array( 'status' => 'request-confirmed' ) );
                        $results[] = array( 'request_id' => $req['request_id'], 'status' => 'confirmed' );
                    }
                    break;
                case 'mark_complete':
                    $req_obj = wp_get_user_request( $req['request_id'] );
                    if ( $req_obj ) {
                        update_user_request( $req['request_id'], array( 'status' => 'request-completed' ) );
                        $results[] = array( 'request_id' => $req['request_id'], 'status' => 'completed' );
                    }
                    break;
                default:
                    $results[] = array( 'email' => $email, 'error' => __( 'Unknown action.', 'arthur-ai' ) );
                    break;
            }
        }
        return array(
            'success' => true,
            'results' => $results,
        );
    }
}

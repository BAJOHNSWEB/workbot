<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Limit the number of allowed login attempts within a lockout window.
 *
 * Stores the maximum attempts and lockout duration (in minutes) in
 * arthur_ai_limit_login_attempts. The security customiser uses this to
 * track attempts via transients and block authentication when the limit is
 * exceeded. A simple heuristic is used – this is not intended to
 * replace a full security plugin.
 */
class Arthur_AI_Action_Limit_Login_Attempts implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'limit_login_attempts';
    }

    public function get_label() {
        return __( 'Limit Login Attempts', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $max  = 5;
        $mins = 60;
        if ( isset( $payload['max_attempts'] ) && is_numeric( $payload['max_attempts'] ) ) {
            $max = max( 1, intval( $payload['max_attempts'] ) );
        }
        if ( isset( $payload['lockout_duration'] ) && is_numeric( $payload['lockout_duration'] ) ) {
            $mins = max( 1, intval( $payload['lockout_duration'] ) );
        }
        update_option( 'arthur_ai_limit_login_attempts', array( 'max' => $max, 'duration' => $mins ) );
        return array( 'success' => true, 'message' => __( 'Login attempt limits updated.', 'arthur-ai' ) );
    }
}
<?php
/**
 * Manage security firewall settings.
 *
 * This action enables or configures firewall rules via supported security
 * plugins (e.g. Wordfence, Sucuri). If no supported plugin is active, it
 * stores the desired configuration for reference and notifies the user that
 * further setup is required.
 */
class Arthur_AI_Action_Manage_Security_Firewall implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'manage_security_firewall';
    }
    public function get_label() {
        return __( 'Manage Security Firewall', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_text_field( $payload['provider'] ) : '';
        $settings = isset( $payload['settings'] ) && is_array( $payload['settings'] ) ? $payload['settings'] : array();
        $message  = '';
        $applied  = false;

        switch ( $provider ) {
            case 'wordfence':
                if ( class_exists( 'wordfence' ) ) {
                    // Wordfence options are stored in the wfConfig table; update as needed.
                    foreach ( $settings as $key => $value ) {
                        wfConfig::set( $key, $value );
                    }
                    $applied = true;
                    $message = __( 'Wordfence firewall settings updated.', 'arthur-ai-content-assistant' );
                } else {
                    $message = __( 'Wordfence plugin not detected. Settings saved for reference.', 'arthur-ai-content-assistant' );
                }
                break;
            case 'sucuri':
                if ( defined( 'SUCURI_PHP_VERSION' ) ) {
                    // Sucuri has limited API via constants; store settings anyway.
                    $message = __( 'Sucuri plugin detected. Advanced configuration requires manual setup.', 'arthur-ai-content-assistant' );
                    $applied = true;
                } else {
                    $message = __( 'Sucuri plugin not detected. Settings saved for reference.', 'arthur-ai-content-assistant' );
                }
                break;
            default:
                $message = __( 'Settings stored. No firewall plugin integration available.', 'arthur-ai-content-assistant' );
                break;
        }

        update_option( 'arthur_ai_firewall_settings', array(
            'provider' => $provider,
            'settings' => $settings,
        ) );

        return array(
            'success' => true,
            'applied' => $applied,
            'message' => $message,
            'settings' => array(
                'provider' => $provider,
                'settings' => $settings,
            ),
        );
    }
}
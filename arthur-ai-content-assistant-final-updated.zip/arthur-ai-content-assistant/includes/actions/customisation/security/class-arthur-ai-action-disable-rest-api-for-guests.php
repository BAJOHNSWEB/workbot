<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Disable the WordPress REST API for unauthenticated users.
 *
 * Stores a boolean flag in arthur_ai_disable_rest_api_for_guests. The
 * security customiser uses this flag on the rest_authentication_errors
 * filter to block requests from guests (non‑logged‑in users).
 */
class Arthur_AI_Action_Disable_Rest_Api_For_Guests implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'disable_rest_api_for_guests';
    }

    public function get_label() {
        return __( 'Disable REST API For Guests', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $enabled = false;
        if ( isset( $payload['enabled'] ) ) {
            $enabled = (bool) $payload['enabled'];
        }
        update_option( 'arthur_ai_disable_rest_api_for_guests', $enabled );
        return array( 'success' => true, 'message' => __( 'REST API guest access setting updated.', 'arthur-ai' ) );
    }
}
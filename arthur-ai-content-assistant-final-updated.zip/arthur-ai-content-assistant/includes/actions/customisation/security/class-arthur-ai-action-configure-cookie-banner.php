<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure a cookie consent banner.
 *
 * This action sets the content and behaviour of a cookie banner. If a
 * recognised cookie consent plugin is present (e.g. Complianz, Cookie
 * Notice), it will attempt to update that plugin’s settings. Otherwise,
 * it stores the configuration in an option for the privacy customiser to
 * render a simple banner. It does not implement cookie blocking by
 * itself; it is informational only.
 */
class Arthur_AI_Action_Configure_Cookie_Banner implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'configure_cookie_banner';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Configure Cookie Banner', 'arthur-ai' );
    }

    /**
     * Configure cookie banner settings.
     *
     * @param array $payload {
     *     @type string $plugin   The cookie plugin identifier (complianz, cookie_notice, generic).
     *     @type array  $content  Message and button labels.
     *     @type array  $behaviour Position and blocking mode.
     * }
     * @return array Result.
     */
    public function execute( array $payload ) {
        $plugin    = isset( $payload['plugin'] ) ? sanitize_key( (string) $payload['plugin'] ) : 'generic';
        $content   = isset( $payload['content'] ) && is_array( $payload['content'] ) ? $payload['content'] : array();
        $behaviour = isset( $payload['behaviour'] ) && is_array( $payload['behaviour'] ) ? $payload['behaviour'] : array();
        $applied   = false;
        // Attempt to configure known plugins.
        switch ( $plugin ) {
            case 'complianz':
                if ( class_exists( 'COMPLIANZ' ) ) {
                    // Complianz stores banner content in options; we map simple fields.
                    $cmplz_options = get_option( 'cmplz_options', array() );
                    if ( ! is_array( $cmplz_options ) ) {
                        $cmplz_options = array();
                    }
                    if ( isset( $content['message'] ) ) {
                        $cmplz_options['cookie_warning_text'] = wp_kses_post( $content['message'] );
                    }
                    if ( isset( $content['accept_label'] ) ) {
                        $cmplz_options['cookie_warning_button_text'] = sanitize_text_field( $content['accept_label'] );
                    }
                    update_option( 'cmplz_options', $cmplz_options );
                    $applied = true;
                }
                break;
            case 'cookie_notice':
                if ( class_exists( 'Cookie_Notice' ) ) {
                    // Cookie Notice plugin uses options under cookie_notice_options.
                    $cn_opts = get_option( 'cookie_notice_options', array() );
                    if ( isset( $content['message'] ) ) {
                        $cn_opts['message_text'] = wp_kses_post( $content['message'] );
                    }
                    if ( isset( $content['accept_label'] ) ) {
                        $cn_opts['accept_text'] = sanitize_text_field( $content['accept_label'] );
                    }
                    update_option( 'cookie_notice_options', $cn_opts );
                    $applied = true;
                }
                break;
            default:
                // Unknown plugin or generic; fall through.
                break;
        }
        // Persist our settings for the privacy customiser fallback.
        update_option( 'arthur_ai_cookie_banner', array(
            'plugin'    => $plugin,
            'content'   => $content,
            'behaviour' => $behaviour,
        ) );
        return array(
            'success' => true,
            'plugin'  => $plugin,
            'configured_with_plugin' => $applied,
            'settings' => array(
                'content'   => $content,
                'behaviour' => $behaviour,
            ),
            'message' => $applied
                ? __( 'Cookie banner configured using the selected plugin.', 'arthur-ai' )
                : __( 'Cookie banner settings saved. A compatible plugin may be required for advanced features.', 'arthur-ai' ),
        );
    }
}

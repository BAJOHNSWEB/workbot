<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Show or hide the WordPress version number in page source.
 *
 * This action controls whether the WordPress generator meta tag should be
 * output on front‑end pages. Hiding the version can reduce exposure of
 * installation details. The security customiser filters the generator
 * accordingly based on this option.
 */
class Arthur_AI_Action_Toggle_Wp_Version_Exposure implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'toggle_wp_version_exposure';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Toggle WordPress Version Exposure', 'arthur-ai' );
    }

    /**
     * Toggle WordPress version exposure.
     *
     * @param array $payload {
     *     @type bool $hide_version Whether to hide the version.
     * }
     * @return array Result.
     */
    public function execute( array $payload ) {
        $hide = isset( $payload['hide_version'] ) ? (bool) $payload['hide_version'] : true;
        update_option( 'arthur_ai_hide_wp_version', $hide );
        return array(
            'success' => true,
            'hide_wp_version' => $hide,
            'message' => $hide
                ? __( 'The WordPress version will be hidden from front‑end output.', 'arthur-ai' )
                : __( 'The WordPress version will be displayed in front‑end output.', 'arthur-ai' ),
        );
    }
}

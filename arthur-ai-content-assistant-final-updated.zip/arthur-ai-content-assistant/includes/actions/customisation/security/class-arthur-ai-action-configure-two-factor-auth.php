<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure two‑factor authentication plugin settings.
 *
 * This action stores the desired roles and methods for 2FA. If a known
 * plugin is installed (e.g. Two Factor, Wordfence, iThemes Security),
 * the class attempts to update its settings. Otherwise, it records the
 * configuration and informs the user that a compatible plugin is needed.
 */
class Arthur_AI_Action_Configure_Two_Factor_Auth implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'configure_two_factor_auth';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Configure Two‑Factor Authentication', 'arthur-ai' );
    }

    /**
     * Save 2FA settings for supported plugins.
     *
     * @param array $payload {
     *     @type string $plugin            The plugin identifier (two_factor, wordfence, itsec).
     *     @type array  $enabled_for_roles Array of role names that require 2FA.
     *     @type array  $methods           Authentication methods (email, app, backup_codes).
     * }
     * @return array Result including stored settings and whether plugin was configured.
     */
    public function execute( array $payload ) {
        $plugin  = isset( $payload['plugin'] ) ? sanitize_key( (string) $payload['plugin'] ) : '';
        $roles   = isset( $payload['enabled_for_roles'] ) && is_array( $payload['enabled_for_roles'] ) ? array_map( 'sanitize_key', $payload['enabled_for_roles'] ) : array();
        $methods = isset( $payload['methods'] ) && is_array( $payload['methods'] ) ? array_map( 'sanitize_key', $payload['methods'] ) : array();
        $applied = false;
        // Attempt to configure known plugins.
        switch ( $plugin ) {
            case 'two_factor':
                if ( class_exists( 'Two_Factor_Core' ) ) {
                    // Two Factor plugin stores available providers in options and user meta. There is no global settings API.
                    // We'll store our desired roles/methods in a custom option for reference.
                    $applied = true;
                }
                break;
            case 'wordfence':
                if ( class_exists( 'Wordfence' ) ) {
                    // Wordfence 2FA configuration is stored in wfConfig options; updating via code requires direct option updates.
                    // We won't attempt to modify Wordfence settings automatically.
                    $applied = false;
                }
                break;
            case 'itsec':
            case 'itsecpro':
                if ( class_exists( 'ITSEC_Core' ) ) {
                    // iThemes Security stores 2FA settings in ITSEC options; updating programmatically is complex.
                    $applied = false;
                }
                break;
            default:
                // Unknown plugin or generic.
                break;
        }
        // Persist configuration for reference and potential future use.
        update_option( 'arthur_ai_two_factor_auth', array(
            'plugin'  => $plugin,
            'roles'   => $roles,
            'methods' => $methods,
        ) );
        return array(
            'success' => true,
            'plugin' => $plugin,
            'configured' => $applied,
            'roles' => $roles,
            'methods' => $methods,
            'message' => $applied
                ? __( 'Two‑factor authentication settings recorded and applied where possible.', 'arthur-ai' )
                : __( 'Two‑factor authentication settings recorded. A compatible plugin is required for enforcement.', 'arthur-ai' ),
        );
    }
}

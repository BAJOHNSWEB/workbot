<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Disable the Theme and Plugin file editors in wp-admin by setting a flag.
 *
 * When enabled, the security customiser will attempt to define the
 * DISALLOW_FILE_EDIT constant if it is not already defined. Note that
 * defining constants after wp-config.php is loaded may not always be
 * respected depending on other plugins. The desired state is stored in
 * arthur_ai_disable_file_editing.
 */
class Arthur_AI_Action_Disable_File_Editing implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'disable_file_editing';
    }

    public function get_label() {
        return __( 'Disable File Editing', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $enabled = false;
        if ( isset( $payload['enabled'] ) ) {
            $enabled = (bool) $payload['enabled'];
        }
        update_option( 'arthur_ai_disable_file_editing', $enabled );
        return array( 'success' => true, 'message' => __( 'File editing setting updated.', 'arthur-ai' ) );
    }
}
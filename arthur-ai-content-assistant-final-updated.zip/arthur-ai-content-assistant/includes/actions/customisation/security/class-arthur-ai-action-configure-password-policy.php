<?php
/**
 * Configure password policy rules.
 *
 * Stores requirements for minimum length, character types and expiry. The
 * Arthur security customiser can enforce these rules on user registration
 * and password reset. If enforcement is not yet implemented, the settings
 * still serve as guidance.
 */
class Arthur_AI_Action_Configure_Password_Policy implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'configure_password_policy';
    }
    public function get_label() {
        return __( 'Configure Password Policy', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $settings = array(
            'min_length'        => isset( $payload['min_length'] ) ? absint( $payload['min_length'] ) : 12,
            'require_uppercase' => ! empty( $payload['require_uppercase'] ),
            'require_numbers'   => ! empty( $payload['require_numbers'] ),
            'require_special'   => ! empty( $payload['require_special_chars'] ),
            'expiry_days'       => isset( $payload['expiry_days'] ) ? absint( $payload['expiry_days'] ) : 0,
        );
        update_option( 'arthur_ai_password_policy', $settings );
        return array(
            'success' => true,
            'message' => __( 'Password policy saved. Enforcement may require additional hooks.', 'arthur-ai-content-assistant' ),
            'settings' => $settings,
        );
    }
}
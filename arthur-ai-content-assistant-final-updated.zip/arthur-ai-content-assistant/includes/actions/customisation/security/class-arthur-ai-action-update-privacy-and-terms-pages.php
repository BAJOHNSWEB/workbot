<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Update the site’s privacy policy and terms pages.
 *
 * This action applies sanitized content to designated privacy and terms
 * pages. It can also assign these pages as the default policy/terms
 * pages via WordPress options. It does not generate any legal text; it
 * expects prepared content from upstream systems.
 */
class Arthur_AI_Action_Update_Privacy_And_Terms_Pages implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'update_privacy_and_terms_pages';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Update Privacy and Terms Pages', 'arthur-ai' );
    }

    /**
     * Update content for privacy and terms pages.
     *
     * @param array $payload {
     *     @type int    $privacy_page_id
     *     @type string $privacy_content
     *     @type int    $terms_page_id
     *     @type string $terms_content
     * }
     * @return array Result summarising updates.
     */
    public function execute( array $payload ) {
        $results = array();
        // Privacy page.
        if ( isset( $payload['privacy_page_id'] ) && isset( $payload['privacy_content'] ) ) {
            $privacy_id = (int) $payload['privacy_page_id'];
            $content    = wp_kses_post( (string) $payload['privacy_content'] );
            $update     = wp_update_post( array(
                'ID'           => $privacy_id,
                'post_content' => $content,
            ), true );
            if ( ! is_wp_error( $update ) ) {
                // Set as default privacy policy page.
                update_option( 'wp_page_for_privacy_policy', $privacy_id );
                $results['privacy'] = array(
                    'updated' => true,
                    'page_id' => $privacy_id,
                );
            } else {
                $results['privacy'] = array(
                    'updated' => false,
                    'error'   => $update->get_error_message(),
                );
            }
        }
        // Terms page.
        if ( isset( $payload['terms_page_id'] ) && isset( $payload['terms_content'] ) ) {
            $terms_id = (int) $payload['terms_page_id'];
            $content  = wp_kses_post( (string) $payload['terms_content'] );
            $update   = wp_update_post( array(
                'ID'           => $terms_id,
                'post_content' => $content,
            ), true );
            if ( ! is_wp_error( $update ) ) {
                // Optionally set site terms page – WordPress doesn't have a core option for T&C, but theme may support.
                $results['terms'] = array(
                    'updated' => true,
                    'page_id' => $terms_id,
                );
            } else {
                $results['terms'] = array(
                    'updated' => false,
                    'error'   => $update->get_error_message(),
                );
            }
        }
        return array(
            'success' => true,
            'result'  => $results,
        );
    }
}

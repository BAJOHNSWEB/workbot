<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Audit user roles and capabilities.
 *
 * This read‑only action enumerates all WordPress roles and their associated
 * capabilities. It can optionally filter by a subset of roles. No
 * modifications are made. This is useful for AI analysis of role
 * assignments and potential hardening tasks.
 */
class Arthur_AI_Action_Audit_Roles_And_Capabilities implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'audit_roles_and_capabilities';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Audit Roles and Capabilities', 'arthur-ai' );
    }

    /**
     * Execute the audit.
     *
     * @param array $payload {
     *     @type array $roles Optional subset of role slugs to audit.
     * }
     * @return array Structured list of roles and their capabilities.
     */
    public function execute( array $payload ) {
        global $wp_roles;
        if ( ! isset( $wp_roles ) ) {
            $wp_roles = wp_roles();
        }
        $roles_to_audit = array();
        if ( isset( $payload['roles'] ) && is_array( $payload['roles'] ) ) {
            $roles_to_audit = array_map( 'sanitize_key', $payload['roles'] );
        }
        $result = array();
        foreach ( $wp_roles->roles as $slug => $data ) {
            if ( ! empty( $roles_to_audit ) && ! in_array( $slug, $roles_to_audit, true ) ) {
                continue;
            }
            $result[ $slug ] = array(
                'name' => $data['name'],
                'capabilities' => array_keys( array_filter( $data['capabilities'] ) ),
            );
        }
        return array(
            'success' => true,
            'roles'   => $result,
        );
    }
}

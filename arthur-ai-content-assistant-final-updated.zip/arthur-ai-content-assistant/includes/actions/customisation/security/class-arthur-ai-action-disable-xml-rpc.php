<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Enable or disable WordPress XML‑RPC functionality.
 *
 * Storing a boolean flag in arthur_ai_disable_xml_rpc which the
 * security customiser reads to hook the xmlrpc_enabled filter. When enabled,
 * XML‑RPC requests will be disabled.
 */
class Arthur_AI_Action_Disable_Xml_Rpc implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'disable_xml_rpc';
    }

    public function get_label() {
        return __( 'Disable XML-RPC', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $enabled = false;
        if ( isset( $payload['enabled'] ) ) {
            $enabled = (bool) $payload['enabled'];
        }
        update_option( 'arthur_ai_disable_xml_rpc', $enabled );
        return array( 'success' => true, 'message' => __( 'XML-RPC setting updated.', 'arthur-ai' ) );
    }
}
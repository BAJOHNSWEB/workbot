<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Rename the default WordPress login URL (wp-login.php) by specifying a custom
 * slug. The new slug will be used for login links; attempts to access the
 * default login URL will be redirected. This is a simple obfuscation and is
 * not a replacement for a full security plugin.
 */
class Arthur_AI_Action_Rename_Login_Url implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'rename_login_url';
    }

    public function get_label() {
        return __( 'Rename Login URL', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $slug = '';
        if ( isset( $payload['slug'] ) ) {
            $slug = sanitize_title( (string) $payload['slug'] );
        }
        update_option( 'arthur_ai_login_slug', $slug );
        return array( 'success' => true, 'message' => __( 'Login URL updated.', 'arthur-ai' ) );
    }
}
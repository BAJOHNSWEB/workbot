<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Automatically log out users after a period of inactivity.
 *
 * The payload should specify a timeout in minutes. The value is stored in
 * arthur_ai_auto_logout_timeout and used by the security customiser to
 * track user activity via user meta. When the timeout is exceeded, users
 * will be logged out on the next page load.
 */
class Arthur_AI_Action_Auto_Logout_Inactive_Users implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'auto_logout_inactive_users';
    }

    public function get_label() {
        return __( 'Auto Logout Inactive Users', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $timeout = 60; // minutes
        if ( isset( $payload['timeout'] ) && is_numeric( $payload['timeout'] ) ) {
            $timeout = max( 1, intval( $payload['timeout'] ) );
        }
        update_option( 'arthur_ai_auto_logout_timeout', $timeout );
        return array( 'success' => true, 'message' => __( 'Auto logout timeout updated.', 'arthur-ai' ) );
    }
}
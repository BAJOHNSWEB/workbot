<?php
/**
 * Generate a high-level security report.
 *
 * This action compiles information on failed logins, login lockouts,
 * outdated plugins/themes and basic firewall events where available. It
 * summarises the state of security for administrator review. Since the
 * plugin cannot access all external sources, this report is best-effort.
 */
class Arthur_AI_Action_Generate_Security_Report implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'generate_security_report';
    }
    public function get_label() {
        return __( 'Generate Security Report', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $report = array();
        // Basic info: list outdated plugins/themes
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/update.php';
        $plugins = get_plugins();
        $updates = get_plugin_updates();
        $outdated_plugins = array();
        foreach ( $updates as $file => $info ) {
            $outdated_plugins[] = array(
                'plugin'    => $plugins[ $file ]['Name'],
                'current'   => $plugins[ $file ]['Version'],
                'new'       => $info->update->new_version,
            );
        }
        // Outdated themes
        $themes          = wp_get_themes();
        $theme_updates   = get_theme_updates();
        $outdated_themes = array();
        foreach ( $theme_updates as $slug => $data ) {
            $theme = $themes[ $slug ];
            $outdated_themes[] = array(
                'theme'   => $theme->get( 'Name' ),
                'current' => $theme->get( 'Version' ),
                'new'     => $data->update['new_version'],
            );
        }
        $report['outdated_plugins'] = $outdated_plugins;
        $report['outdated_themes']  = $outdated_themes;

        // Failed login attempts: we cannot access login logs directly; summarise based on our own lockout logs if any.
        $lockouts = get_option( 'arthur_ai_login_lockouts', array() );
        $report['login_lockouts'] = $lockouts;

        // Password policy configured
        $report['password_policy'] = get_option( 'arthur_ai_password_policy', array() );

        // Firewall provider and status
        $report['firewall'] = get_option( 'arthur_ai_firewall_settings', array() );

        return array(
            'success' => true,
            'report'  => $report,
        );
    }
}
<?php
/**
 * Configure region-based cookie rules.
 *
 * Stores consent requirements per region (e.g. EU requires opt-in). This data
 * can be used by the privacy customiser when rendering the cookie banner.
 */
class Arthur_AI_Action_Configure_Region_Based_Cookie_Rules implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'configure_region_based_cookie_rules';
    }
    public function get_label() {
        return __( 'Configure Region-Based Cookie Rules', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $rules = isset( $payload['rules'] ) && is_array( $payload['rules'] ) ? $payload['rules'] : array();
        update_option( 'arthur_ai_region_cookie_rules', $rules );
        return array(
            'success' => true,
            'message' => __( 'Region-based cookie rules saved.', 'arthur-ai-content-assistant' ),
            'rules'   => $rules,
        );
    }
}
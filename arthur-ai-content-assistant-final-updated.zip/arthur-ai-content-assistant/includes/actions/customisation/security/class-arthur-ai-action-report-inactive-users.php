<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Report inactive or rarely used user accounts.
 *
 * This action identifies users who have not logged in or otherwise been
 * active for a specified number of days. It can filter by role and uses
 * user meta (last_login or Arthur AI custom meta) when available. If no
 * meta is present, it will leave the last_seen field empty. This action
 * does not perform any deletion or modification.
 */
class Arthur_AI_Action_Report_Inactive_Users implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'report_inactive_users';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Report Inactive Users', 'arthur-ai' );
    }

    /**
     * Identify inactive users.
     *
     * @param array $payload {
     *     @type int   $inactive_days_threshold Number of days of inactivity.
     *     @type array $roles Optional list of role slugs to include.
     * }
     * @return array List of users with last activity timestamps.
     */
    public function execute( array $payload ) {
        $days  = isset( $payload['inactive_days_threshold'] ) ? max( 1, (int) $payload['inactive_days_threshold'] ) : 180;
        $roles = array();
        if ( isset( $payload['roles'] ) && is_array( $payload['roles'] ) ) {
            $roles = array_map( 'sanitize_key', $payload['roles'] );
        }
        $time_limit = time() - ( $days * DAY_IN_SECONDS );
        $args = array(
            'number'  => -1,
            'fields'  => array( 'ID', 'user_login', 'user_email', 'user_registered', 'roles' ),
        );
        if ( ! empty( $roles ) ) {
            $args['role__in'] = $roles;
        }
        $users = get_users( $args );
        $results = array();
        foreach ( $users as $user ) {
            // Determine last activity: check meta we store or generic last_login meta from plugins.
            $last_login = (int) get_user_meta( $user->ID, 'last_login', true );
            if ( ! $last_login ) {
                $last_login = (int) get_user_meta( $user->ID, 'arthur_ai_last_activity', true );
            }
            if ( $last_login && $last_login >= $time_limit ) {
                continue; // Active recently.
            }
            $results[] = array(
                'user_id'    => $user->ID,
                'user_login' => $user->user_login,
                'user_email' => $user->user_email,
                'roles'      => $user->roles,
                'last_seen'  => $last_login ? gmdate( 'Y-m-d H:i:s', $last_login ) : null,
            );
        }
        return array(
            'success' => true,
            'inactive_users' => $results,
        );
    }
}

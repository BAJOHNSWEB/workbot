<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Hide the WordPress version number from page source and feeds.
 *
 * The payload should contain an 'enabled' boolean. When enabled the security
 * customiser filters the_generator and removes the wp_head generator tag.
 */
class Arthur_AI_Action_Hide_Wp_Version implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'hide_wp_version';
    }

    public function get_label() {
        return __( 'Hide WordPress Version', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $enabled = false;
        if ( isset( $payload['enabled'] ) ) {
            $enabled = (bool) $payload['enabled'];
        }
        update_option( 'arthur_ai_hide_wp_version', $enabled );
        return array( 'success' => true, 'message' => __( 'WordPress version visibility updated.', 'arthur-ai' ) );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure login URL obfuscation.
 *
 * This action allows changing the login URL slug via supported plugins
 * (e.g. WP Rocket hide login, WP Cerber). If no supported plugin is
 * installed, the slug is stored in an option and used by the security
 * customiser to rewrite the login URL. An administrative notice may be
 * displayed informing the site owner that a plugin is required for full
 * protection against direct wp‑admin access.
 */
class Arthur_AI_Action_Configure_Login_Url_Obfuscation implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'configure_login_url_obfuscation';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Configure Login URL Obfuscation', 'arthur-ai' );
    }

    /**
     * Configure login URL obfuscation.
     *
     * @param array $payload {
     *     @type string $plugin    The plugin slug or identifier (e.g. wprocket_hide_login, wpcerber, generic).
     *     @type string $login_slug The desired login slug.
     * }
     * @return array Result.
     */
    public function execute( array $payload ) {
        $plugin    = isset( $payload['plugin'] ) ? sanitize_key( (string) $payload['plugin'] ) : 'generic';
        $login_slug = isset( $payload['login_slug'] ) ? sanitize_title( (string) $payload['login_slug'] ) : '';
        $result     = array(
            'success' => false,
            'plugin'  => $plugin,
            'login_slug' => $login_slug,
        );
        if ( '' === $login_slug ) {
            $result['message'] = __( 'A login slug must be provided.', 'arthur-ai' );
            return $result;
        }
        // Normalise slug: remove slashes.
        $login_slug = trim( $login_slug, '/' );
        $applied    = false;
        // Attempt plugin‑specific configuration.
        switch ( $plugin ) {
            case 'wprocket_hide_login':
                if ( defined( 'WP_ROCKET_VERSION' ) && function_exists( 'rocket_get_option' ) ) {
                    // WP Rocket hide login plugin stores slug in option 'login_slug' inside its options.
                    update_option( 'wp_rocket_advanced', array( 'login_slug' => $login_slug ) );
                    $applied = true;
                }
                break;
            case 'wpcerber':
                if ( class_exists( 'Cerber' ) ) {
                    // WP Cerber stores hide login slug in option 'cerber_hidewp_slug'.
                    update_option( 'cerber_hidewp_slug', $login_slug );
                    $applied = true;
                }
                break;
            default:
                // Generic or unsupported plugin: fall back to Arthur AI customiser.
                break;
        }
        // Always store our slug for the security customiser to use when plugin is generic or unsupported.
        update_option( 'arthur_ai_login_slug', $login_slug );
        $result['success'] = true;
        $result['plugin_applied'] = $applied;
        $result['message'] = $applied
            ? __( 'Login slug configured via selected plugin.', 'arthur-ai' )
            : __( 'Login slug saved. A compatible plugin may be required for full obfuscation.', 'arthur-ai' );
        return $result;
    }
}

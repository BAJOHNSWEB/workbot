<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure login rate limiting settings.
 *
 * This action stores maximum login attempts, lockout duration (in minutes)
 * and optionally a list of whitelisted IP addresses that should bypass
 * the rate limiter. The existing security customiser implements the
 * enforcement using transients and user login hooks. If a more
 * feature‑rich plugin is installed, this action could be extended to
 * update its settings instead.
 */
class Arthur_AI_Action_Configure_Login_Rate_Limiting implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'configure_login_rate_limiting';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Configure Login Rate Limiting', 'arthur-ai' );
    }

    /**
     * Save login rate limiting settings.
     *
     * @param array $payload {
     *     @type int   $max_attempts      Maximum allowed attempts before lockout.
     *     @type int   $lockout_duration  Duration in minutes for the lockout.
     *     @type array $whitelist_ips     Array of IP addresses to bypass the limiter.
     * }
     * @return array Result including stored settings.
     */
    public function execute( array $payload ) {
        $max  = isset( $payload['max_attempts'] ) ? max( 1, (int) $payload['max_attempts'] ) : 5;
        $dur  = isset( $payload['lockout_duration'] ) ? max( 1, (int) $payload['lockout_duration'] ) : 60;
        $wl   = array();
        if ( isset( $payload['whitelist_ips'] ) && is_array( $payload['whitelist_ips'] ) ) {
            foreach ( $payload['whitelist_ips'] as $ip ) {
                $ip = trim( $ip );
                if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                    $wl[] = $ip;
                }
            }
        }
        update_option( 'arthur_ai_limit_login_attempts', array(
            'max'   => $max,
            'duration' => $dur,
            'whitelist' => $wl,
        ) );
        return array(
            'success' => true,
            'max_attempts' => $max,
            'lockout_duration' => $dur,
            'whitelist_ips' => $wl,
        );
    }
}

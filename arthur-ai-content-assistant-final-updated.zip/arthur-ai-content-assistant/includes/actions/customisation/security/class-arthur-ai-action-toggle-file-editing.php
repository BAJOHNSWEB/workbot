<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Toggle the ability to edit theme and plugin files via the admin editor.
 *
 * This action allows enabling or disabling the built‑in file editors in
 * WordPress. When disabled, the DISALLOW_FILE_EDIT constant is defined at
 * runtime and a flag is persisted. When re‑enabled, the option is cleared
 * but note that constants defined in wp‑config.php cannot be removed at
 * runtime. This class does not attempt to write to wp‑config.php for
 * security reasons; instead, administrators should manually remove the
 * constant if it was previously defined. It is similar to the existing
 * disable_file_editing action but uses a different slug for clarity.
 */
class Arthur_AI_Action_Toggle_File_Editing implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'toggle_file_editing';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Toggle File Editing', 'arthur-ai' );
    }

    /**
     * Enable or disable the theme/plugin file editors.
     *
     * @param array $payload {
     *     @type bool $enabled Whether file editing should be allowed. When
     *          false, DISALLOW_FILE_EDIT will be defined via the security
     *          customiser.
     * }
     * @return array Result including desired state and a message.
     */
    public function execute( array $payload ) {
        $enabled = isset( $payload['enabled'] ) ? (bool) $payload['enabled'] : false;
        // Persist the inverse because our security customiser reads a
        // disable flag.
        update_option( 'arthur_ai_disable_file_editing', $enabled ? false : true );
        return array(
            'success' => true,
            'file_editing_enabled' => $enabled,
            'message' => $enabled
                ? __( 'File editing via the WordPress admin has been enabled (note: may still be disabled if DISALLOW_FILE_EDIT is defined in wp‑config).', 'arthur-ai' )
                : __( 'File editing via the WordPress admin has been disabled.', 'arthur-ai' ),
        );
    }
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Enable or disable XML‑RPC access.
 *
 * This action stores a flag indicating whether XML‑RPC should be enabled.
 * The security customiser respects this option and filters the
 * xmlrpc_enabled flag accordingly. If other plugins define their own
 * disabling constants, they will override this setting. The default
 * state is enabled.
 */
class Arthur_AI_Action_Toggle_Xmlrpc implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'toggle_xmlrpc';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Toggle XML‑RPC', 'arthur-ai' );
    }

    /**
     * Toggle XML‑RPC capability.
     *
     * @param array $payload {
     *     @type bool $enabled True to enable XML‑RPC, false to disable it.
     * }
     * @return array Result.
     */
    public function execute( array $payload ) {
        $enabled = isset( $payload['enabled'] ) ? (bool) $payload['enabled'] : true;
        // Our security customiser uses a disable flag; invert.
        update_option( 'arthur_ai_disable_xml_rpc', $enabled ? false : true );
        return array(
            'success' => true,
            'xmlrpc_enabled' => $enabled,
            'message' => $enabled
                ? __( 'XML‑RPC has been enabled.', 'arthur-ai' )
                : __( 'XML‑RPC has been disabled.', 'arthur-ai' ),
        );
    }
}

<?php
/**
 * Enable or disable a specific tracking event.
 */
class Arthur_AI_Action_Toggle_Tracking_Event implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'toggle_tracking_event';
    }
    public function get_label() {
        return __( 'Toggle Tracking Event', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $event_name = isset( $payload['event_name'] ) ? sanitize_key( $payload['event_name'] ) : '';
        $enabled    = isset( $payload['enabled'] ) ? (bool) $payload['enabled'] : true;
        $events     = get_option( 'arthur_ai_tracking_events', array() );
        if ( isset( $events[ $event_name ] ) ) {
            $events[ $event_name ]['enabled'] = $enabled;
            update_option( 'arthur_ai_tracking_events', $events );
            return array( 'success' => true, 'message' => __( 'Event updated.', 'arthur-ai-content-assistant' ), 'event' => $events[ $event_name ] );
        }
        return array( 'success' => false, 'message' => __( 'Event not found.', 'arthur-ai-content-assistant' ) );
    }
}
<?php
/**
 * Report system errors and logs.
 *
 * Reads the WordPress debug log or PHP error log if available and returns
 * recent lines. This helps administrators diagnose issues. The action will
 * only read files within the `wp-content` directory for security reasons.
 */
class Arthur_AI_Action_Report_System_Errors implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'report_system_errors';
    }
    public function get_label() {
        return __( 'Report System Errors', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $limit = isset( $payload['limit'] ) ? absint( $payload['limit'] ) : 100;
        $logs  = array();
        $debug_log = WP_CONTENT_DIR . '/debug.log';
        if ( file_exists( $debug_log ) && is_readable( $debug_log ) ) {
            $lines = file( $debug_log );
            $lines = array_slice( $lines, -$limit );
            $logs['debug_log'] = implode( '', $lines );
        } else {
            $logs['debug_log'] = __( 'Debug log not found or not readable.', 'arthur-ai-content-assistant' );
        }
        // Optionally include php error log if within WP_CONTENT_DIR
        $php_error_log = ini_get( 'error_log' );
        if ( $php_error_log && strpos( $php_error_log, WP_CONTENT_DIR ) === 0 && is_readable( $php_error_log ) ) {
            $lines = file( $php_error_log );
            $lines = array_slice( $lines, -$limit );
            $logs['php_error_log'] = implode( '', $lines );
        }
        return array(
            'success' => true,
            'logs'    => $logs,
        );
    }
}
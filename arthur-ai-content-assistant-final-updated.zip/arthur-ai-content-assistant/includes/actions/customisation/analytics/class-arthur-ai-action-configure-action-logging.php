<?php
/**
 * Configure Arthur action logging settings.
 *
 * Allows enabling/disabling logging and setting retention periods. These
 * settings influence how the assistant stores its action logs.
 */
class Arthur_AI_Action_Configure_Action_Logging implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'configure_action_logging';
    }
    public function get_label() {
        return __( 'Configure Action Logging', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $enabled        = isset( $payload['enabled'] ) ? (bool) $payload['enabled'] : true;
        $retention_days = isset( $payload['retention_days'] ) ? absint( $payload['retention_days'] ) : 30;
        $settings       = array(
            'enabled'        => $enabled,
            'retention_days' => $retention_days,
        );
        update_option( 'arthur_ai_action_logging_settings', $settings );
        return array(
            'success'  => true,
            'settings' => $settings,
            'message'  => __( 'Action logging settings updated.', 'arthur-ai-content-assistant' ),
        );
    }
}
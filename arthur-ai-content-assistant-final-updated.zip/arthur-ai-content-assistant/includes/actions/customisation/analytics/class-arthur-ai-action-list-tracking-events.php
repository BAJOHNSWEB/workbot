<?php
/**
 * List configured tracking events.
 *
 * Returns all tracking event definitions stored via configure_tracking_events.
 */
class Arthur_AI_Action_List_Tracking_Events implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'list_tracking_events';
    }
    public function get_label() {
        return __( 'List Tracking Events', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $events = get_option( 'arthur_ai_tracking_events', array() );
        return array(
            'success' => true,
            'events'  => $events,
        );
    }
}
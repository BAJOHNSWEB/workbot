<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Change the WordPress permalink structure.
 *
 * This action updates the 'permalink_structure' option and flushes rewrite
 * rules. It accepts a structure string (e.g. '/%postname%/') and performs
 * basic validation. Changing permalinks can impact SEO and existing
 * URLs; use with caution.
 */
class Arthur_AI_Action_Change_Permalink_Structure implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'change_permalink_structure';
    }
    public function get_label() {
        return __( 'Change Permalink Structure', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['structure'] ) || '' === trim( (string) $payload['structure'] ) ) {
            return array( 'success' => false, 'message' => __( 'structure is required.', 'arthur-ai' ) );
        }
        $structure = trim( (string) $payload['structure'] );
        // Basic validation: must start with a slash and contain no spaces.
        if ( '/' !== $structure[0] || false !== strpos( $structure, ' ' ) ) {
            return array( 'success' => false, 'message' => __( 'Invalid permalink structure.', 'arthur-ai' ) );
        }
        update_option( 'permalink_structure', $structure );
        // Flush rewrite rules to apply changes.
        global $wp_rewrite;
        if ( $wp_rewrite instanceof WP_Rewrite ) {
            $wp_rewrite->set_permalink_structure( $structure );
            flush_rewrite_rules();
        }
        return array( 'success' => true, 'message' => __( 'Permalink structure updated.', 'arthur-ai' ) );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Force all front-end requests to use HTTPS.
 *
 * Stores a boolean flag in arthur_ai_force_https_redirects. The site
 * customiser checks this flag on template_redirect and redirects
 * non-SSL requests to HTTPS. Admin and CLI requests are not affected.
 */
class Arthur_AI_Action_Force_Https_Redirects implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'force_https_redirects';
    }
    public function get_label() {
        return __( 'Force HTTPS Redirects', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $enabled = false;
        if ( isset( $payload['enabled'] ) ) {
            $enabled = (bool) $payload['enabled'];
        }
        update_option( 'arthur_ai_force_https_redirects', $enabled );
        return array( 'success' => true, 'message' => __( 'HTTPS redirect setting updated.', 'arthur-ai' ) );
    }
}
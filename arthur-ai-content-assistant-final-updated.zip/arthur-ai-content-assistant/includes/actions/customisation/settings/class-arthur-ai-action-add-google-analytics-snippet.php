<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Add or update a Google Analytics tracking code or snippet.
 *
 * Accepts a tracking ID (UA- or G- prefixed) or a full GA snippet. The
 * value is stored in arthur_ai_google_analytics_snippet and output by the
 * site customiser in the head. Provide either the ID or the full script;
 * the customiser will handle wrapping IDs into the appropriate script tag.
 */
class Arthur_AI_Action_Add_Google_Analytics_Snippet implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'add_google_analytics_snippet';
    }
    public function get_label() {
        return __( 'Add Google Analytics Snippet', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['snippet'] ) || '' === trim( (string) $payload['snippet'] ) ) {
            return array( 'success' => false, 'message' => __( 'snippet is required.', 'arthur-ai' ) );
        }
        $snippet = trim( (string) $payload['snippet'] );
        // Store raw snippet or ID; customiser will wrap IDs appropriately.
        update_option( 'arthur_ai_google_analytics_snippet', $snippet );
        return array( 'success' => true, 'message' => __( 'Google Analytics snippet updated.', 'arthur-ai' ) );
    }
}
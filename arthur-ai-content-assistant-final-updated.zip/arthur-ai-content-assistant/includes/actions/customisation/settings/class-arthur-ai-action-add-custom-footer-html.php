<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Add arbitrary custom HTML to the site footer.
 *
 * Accepts a 'html' field which may contain any HTML. The value is stored in
 * arthur_ai_custom_footer_html and output by the site customiser on
 * wp_footer. Administrators should provide trusted HTML, as it will be
 * echoed without escaping.
 */
class Arthur_AI_Action_Add_Custom_Footer_Html implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'add_custom_footer_html';
    }
    public function get_label() {
        return __( 'Add Custom Footer HTML', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['html'] ) ) {
            return array( 'success' => false, 'message' => __( 'html is required.', 'arthur-ai' ) );
        }
        $html = (string) $payload['html'];
        update_option( 'arthur_ai_custom_footer_html', $html );
        return array( 'success' => true, 'message' => __( 'Custom footer HTML updated.', 'arthur-ai' ) );
    }
}
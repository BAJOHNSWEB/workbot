<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Enable or disable comments globally across the site.
 *
 * Stores a boolean flag in arthur_ai_comments_global_enabled. The site
 * customiser uses this flag to filter comments_open, pings_open and
 * default comment status to prevent new comments when disabled.
 */
class Arthur_AI_Action_Toggle_Comments_Global implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'toggle_comments_global';
    }
    public function get_label() {
        return __( 'Toggle Comments Global', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $enabled = true;
        if ( isset( $payload['enabled'] ) ) {
            $enabled = (bool) $payload['enabled'];
        }
        update_option( 'arthur_ai_comments_global_enabled', $enabled );
        return array( 'success' => true, 'message' => __( 'Global comments setting updated.', 'arthur-ai' ) );
    }
}
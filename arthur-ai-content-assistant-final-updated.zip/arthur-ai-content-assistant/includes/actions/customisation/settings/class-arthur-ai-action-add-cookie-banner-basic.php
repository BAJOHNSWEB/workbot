<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Add a basic cookie consent banner to the site.
 *
 * The payload should include 'text' (the banner message) and 'button_label'
 * (the label on the accept button). Optional 'background' and 'color'
 * fields can define banner and text colours. The options are stored in
 * arthur_ai_cookie_banner_options and used by the site customiser on
 * wp_footer.
 */
class Arthur_AI_Action_Add_Cookie_Banner_Basic implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'add_cookie_banner_basic';
    }
    public function get_label() {
        return __( 'Add Cookie Banner (Basic)', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['text'] ) || ! isset( $payload['button_label'] ) ) {
            return array( 'success' => false, 'message' => __( 'text and button_label are required.', 'arthur-ai' ) );
        }
        $banner = array(
            'text'         => (string) $payload['text'],
            'button_label' => (string) $payload['button_label'],
        );
        if ( isset( $payload['background'] ) ) {
            $banner['background'] = (string) $payload['background'];
        }
        if ( isset( $payload['color'] ) ) {
            $banner['color'] = (string) $payload['color'];
        }
        update_option( 'arthur_ai_cookie_banner_options', $banner );
        return array( 'success' => true, 'message' => __( 'Cookie banner settings updated.', 'arthur-ai' ) );
    }
}
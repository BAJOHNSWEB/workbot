<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Change the site title (blog name) option.
 */
class Arthur_AI_Action_Change_Site_Title implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'change_site_title';
    }
    public function get_label() {
        return __( 'Change Site Title', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['title'] ) || '' === trim( (string) $payload['title'] ) ) {
            return array( 'success' => false, 'message' => __( 'title is required.', 'arthur-ai' ) );
        }
        $title = sanitize_text_field( (string) $payload['title'] );
        update_option( 'blogname', $title );
        return array( 'success' => true, 'message' => __( 'Site title updated.', 'arthur-ai' ) );
    }
}
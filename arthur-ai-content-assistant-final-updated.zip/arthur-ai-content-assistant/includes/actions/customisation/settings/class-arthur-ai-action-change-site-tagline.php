<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Change the site tagline (blog description) option.
 */
class Arthur_AI_Action_Change_Site_Tagline implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'change_site_tagline';
    }
    public function get_label() {
        return __( 'Change Site Tagline', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['tagline'] ) || '' === trim( (string) $payload['tagline'] ) ) {
            return array( 'success' => false, 'message' => __( 'tagline is required.', 'arthur-ai' ) );
        }
        $tagline = sanitize_text_field( (string) $payload['tagline'] );
        update_option( 'blogdescription', $tagline );
        return array( 'success' => true, 'message' => __( 'Site tagline updated.', 'arthur-ai' ) );
    }
}
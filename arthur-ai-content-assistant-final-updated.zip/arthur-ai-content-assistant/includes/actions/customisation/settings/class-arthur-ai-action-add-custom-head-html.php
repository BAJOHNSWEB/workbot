<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Add arbitrary custom HTML to the site <head> section.
 *
 * Accepts a 'html' field which may contain any HTML or script tags. The
 * value is stored in arthur_ai_custom_head_html and output by the site
 * customiser on wp_head. Administrators should take care to provide
 * trusted content, as it will be echoed without escaping.
 */
class Arthur_AI_Action_Add_Custom_Head_Html implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'add_custom_head_html';
    }
    public function get_label() {
        return __( 'Add Custom Head HTML', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['html'] ) ) {
            return array( 'success' => false, 'message' => __( 'html is required.', 'arthur-ai' ) );
        }
        $html = (string) $payload['html'];
        update_option( 'arthur_ai_custom_head_html', $html );
        return array( 'success' => true, 'message' => __( 'Custom head HTML updated.', 'arthur-ai' ) );
    }
}
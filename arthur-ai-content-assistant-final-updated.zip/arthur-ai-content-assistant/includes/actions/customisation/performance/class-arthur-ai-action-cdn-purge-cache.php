<?php
/**
 * Purge the CDN cache.
 *
 * This action clears caches for supported CDN providers. If the provider
 * integration plugin is available, it will attempt to call its API. If not,
 * it simply records the request and returns a descriptive error.
 */
class Arthur_AI_Action_Cdn_Purge_Cache implements Arthur_AI_Action_Interface {

    /**
     * {@inheritdoc}
     */
    public function get_type() {
        return 'cdn_purge_cache';
    }

    /**
     * {@inheritdoc}
     */
    public function get_label() {
        return __( 'Purge CDN Cache', 'arthur-ai-content-assistant' );
    }

    /**
     * {@inheritdoc}
     */
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_text_field( $payload['provider'] ) : '';
        $scope    = isset( $payload['scope'] ) ? $payload['scope'] : 'all';
        $urls     = isset( $payload['urls'] ) && is_array( $payload['urls'] ) ? $payload['urls'] : array();

        $result  = array();
        $success = false;
        $message = '';

        switch ( $provider ) {
            case 'cloudflare':
                if ( class_exists( '\\Cloudflare\\API\\Auth\\APIKey' ) ) {
                    // Attempt to call Cloudflare purge API using stored config.
                    $config = get_option( 'arthur_ai_cdn_config', array() );
                    if ( ! empty( $config['auth'] ) && ! empty( $config['zone_id'] ) ) {
                        try {
                            $auth   = new \Cloudflare\API\Auth\APIKey( $config['auth']['email'], $config['auth']['key'] );
                            $adapter = new \Cloudflare\API\Adapter\Guzzle( $auth );
                            $zones  = new \Cloudflare\API\Endpoints\Zones( $adapter );
                            if ( 'urls' === $scope && ! empty( $urls ) ) {
                                $purge = $zones->purgeFiles( $config['zone_id'], $urls );
                            } else {
                                $purge = $zones->purgeCache( $config['zone_id'] );
                            }
                            $success = isset( $purge->success ) ? $purge->success : false;
                            $message = $success ? __( 'Cloudflare cache purged.', 'arthur-ai-content-assistant' ) : __( 'Failed to purge Cloudflare cache.', 'arthur-ai-content-assistant' );
                        } catch ( \Exception $e ) {
                            $success = false;
                            $message = sprintf( __( 'Cloudflare purge error: %s', 'arthur-ai-content-assistant' ), $e->getMessage() );
                        }
                    } else {
                        $message = __( 'Cloudflare not fully configured. Please configure CDN first.', 'arthur-ai-content-assistant' );
                    }
                } else {
                    $message = __( 'Cloudflare plugin not detected. Unable to purge cache.', 'arthur-ai-content-assistant' );
                }
                break;
            case 'generic':
            default:
                // Generic fallback: nothing to purge directly.
                $message = __( 'No specific CDN integration detected. Nothing was purged.', 'arthur-ai-content-assistant' );
                $success = false;
                break;
        }

        return array(
            'success' => $success,
            'message' => $message,
            'provider' => $provider,
            'scope' => $scope,
            'urls' => $urls,
        );
    }
}
<?php
/**
 * Execute a predefined housekeeping profile.
 *
 * This action retrieves the tasks defined for a profile and sequentially
 * executes them by instantiating corresponding Arthur actions in dry-run
 * or real mode. Only tasks known to the assistant are executed; unknown
 * identifiers are skipped. Results are aggregated and returned.
 */
class Arthur_AI_Action_Run_Housekeeping_Profile implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'run_housekeeping_profile';
    }
    public function get_label() {
        return __( 'Run Housekeeping Profile', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $profile_name = isset( $payload['profile_name'] ) ? sanitize_key( $payload['profile_name'] ) : '';
        $dry_run      = isset( $payload['dry_run'] ) ? (bool) $payload['dry_run'] : false;

        $profiles = get_option( 'arthur_ai_housekeeping_profiles', array() );
        if ( ! isset( $profiles[ $profile_name ] ) ) {
            return array( 'success' => false, 'message' => __( 'Profile not found.', 'arthur-ai-content-assistant' ) );
        }

        $tasks     = $profiles[ $profile_name ];
        $results   = array();
        $overall   = true;
        foreach ( $tasks as $task ) {
            $slug   = isset( $task['slug'] ) ? $task['slug'] : '';
            $params = isset( $task['params'] ) && is_array( $task['params'] ) ? $task['params'] : array();
            $result = array( 'slug' => $slug, 'skipped' => false );
            if ( $dry_run ) {
                $result['dry_run'] = true;
                // Provide simple simulation summary: just note the task would run.
                $result['message'] = sprintf( __( 'Task %s would run with parameters.', 'arthur-ai-content-assistant' ), $slug );
            } else {
                // Instantiate the corresponding action class if available.
                $class = 'Arthur_AI_Action_' . str_replace( ' ', '', ucwords( str_replace( '_', ' ', $slug ) ) );
                if ( class_exists( $class ) ) {
                    $action_instance = new $class();
                    if ( $action_instance instanceof Arthur_AI_Action_Interface ) {
                        $res = $action_instance->execute( $params );
                        $result['result'] = $res;
                        if ( isset( $res['success'] ) ) {
                            $overall = $overall && $res['success'];
                        }
                    } else {
                        $result['skipped'] = true;
                        $result['message'] = __( 'Not a valid action.', 'arthur-ai-content-assistant' );
                    }
                } else {
                    $result['skipped'] = true;
                    $result['message'] = __( 'Action class not found.', 'arthur-ai-content-assistant' );
                }
            }
            $results[] = $result;
        }
        return array(
            'success' => $overall,
            'dry_run' => $dry_run,
            'profile' => $profile_name,
            'results' => $results,
        );
    }
}
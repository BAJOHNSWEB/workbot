<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure CSS/JS minification and concatenation settings via optimisation plugins.
 *
 * This action accepts a target plugin slug (e.g. autoptimize, w3tc, wp_rocket)
 * and a settings array specifying which types of files to minify and/or
 * combine. Where possible it updates plugin options; otherwise it stores
 * the configuration in the arthur_ai_asset_optimisation_settings option.
 */
class Arthur_AI_Action_Configure_Asset_Optimisation implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_asset_optimisation';
    }

    public function get_label() {
        return __( 'Configure Asset Optimisation', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $plugin   = isset( $payload['plugin'] ) ? sanitize_key( $payload['plugin'] ) : '';
        $settings = isset( $payload['settings'] ) && is_array( $payload['settings'] ) ? $payload['settings'] : array();
        $applied  = array();
        $detected = false;
        switch ( $plugin ) {
            case 'wp_rocket':
                if ( defined( 'WP_ROCKET_VERSION' ) && function_exists( 'update_rocket_option' ) ) {
                    $detected = true;
                    if ( isset( $settings['minify_css'] ) ) {
                        update_rocket_option( 'minify_css', (bool) $settings['minify_css'] );
                        $applied['minify_css'] = (bool) $settings['minify_css'];
                    }
                    if ( isset( $settings['minify_js'] ) ) {
                        update_rocket_option( 'minify_js', (bool) $settings['minify_js'] );
                        $applied['minify_js'] = (bool) $settings['minify_js'];
                    }
                    if ( isset( $settings['combine_css'] ) ) {
                        update_rocket_option( 'combine_css', (bool) $settings['combine_css'] );
                        $applied['combine_css'] = (bool) $settings['combine_css'];
                    }
                    if ( isset( $settings['combine_js'] ) ) {
                        update_rocket_option( 'combine_js', (bool) $settings['combine_js'] );
                        $applied['combine_js'] = (bool) $settings['combine_js'];
                    }
                }
                break;
            case 'autoptimize':
                // Autoptimize stores settings in options.
                if ( function_exists( 'autoptimize_get_options' ) || function_exists( 'autoptimize_update_settings' ) ) {
                    $detected = true;
                    $ao_opts = get_option( 'autoptimize_options', array() );
                    if ( isset( $settings['minify_css'] ) ) {
                        $ao_opts['css_optimize'] = (bool) $settings['minify_css'];
                        $applied['minify_css'] = (bool) $settings['minify_css'];
                    }
                    if ( isset( $settings['minify_js'] ) ) {
                        $ao_opts['js_optimize'] = (bool) $settings['minify_js'];
                        $applied['minify_js'] = (bool) $settings['minify_js'];
                    }
                    if ( isset( $settings['combine_css'] ) ) {
                        $ao_opts['css_aggregate'] = (bool) $settings['combine_css'];
                        $applied['combine_css'] = (bool) $settings['combine_css'];
                    }
                    if ( isset( $settings['combine_js'] ) ) {
                        $ao_opts['js_aggregate'] = (bool) $settings['combine_js'];
                        $applied['combine_js'] = (bool) $settings['combine_js'];
                    }
                    // Excludes are not handled for specific handles here; store separately.
                    update_option( 'autoptimize_options', $ao_opts );
                }
                break;
            case 'w3tc':
                if ( defined( 'W3TC' ) || class_exists( 'W3TC' ) ) {
                    $detected = true;
                    $config = get_option( 'w3tc_config', array() );
                    if ( isset( $settings['minify_css'] ) ) {
                        $config['minify.css.enable'] = (bool) $settings['minify_css'];
                        $applied['minify_css'] = (bool) $settings['minify_css'];
                    }
                    if ( isset( $settings['minify_js'] ) ) {
                        $config['minify.js.enable'] = (bool) $settings['minify_js'];
                        $applied['minify_js'] = (bool) $settings['minify_js'];
                    }
                    if ( isset( $settings['combine_css'] ) ) {
                        $config['minify.css.combine'] = (bool) $settings['combine_css'];
                        $applied['combine_css'] = (bool) $settings['combine_css'];
                    }
                    if ( isset( $settings['combine_js'] ) ) {
                        $config['minify.js.combine'] = (bool) $settings['combine_js'];
                        $applied['combine_js'] = (bool) $settings['combine_js'];
                    }
                    update_option( 'w3tc_config', $config );
                }
                break;
            default:
                break;
        }
        // Persist our own settings for reference.
        $stored = get_option( 'arthur_ai_asset_optimisation_settings', array() );
        if ( ! is_array( $stored ) ) {
            $stored = array();
        }
        $stored[ $plugin ] = $settings;
        update_option( 'arthur_ai_asset_optimisation_settings', $stored );
        if ( ! $detected && 'generic' !== $plugin ) {
            return array(
                'success' => false,
                'message' => sprintf( __( 'Asset optimisation plugin %s not detected. Settings saved for reference.', 'arthur-ai' ), esc_html( $plugin ) ),
                'settings' => $settings,
            );
        }
        return array(
            'success' => true,
            'message' => __( 'Asset optimisation settings applied.', 'arthur-ai' ),
            'plugin' => $plugin,
            'settings' => $applied,
        );
    }
}
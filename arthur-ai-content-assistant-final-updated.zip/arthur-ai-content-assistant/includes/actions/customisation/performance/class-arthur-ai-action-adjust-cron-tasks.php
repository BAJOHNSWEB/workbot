<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Pause or reschedule scheduled cron tasks.
 *
 * The AI can pause events associated with specific hooks or reschedule them
 * with a new interval. Rescheduling unschedules existing occurrences and
 * schedules new ones at the specified interval. If a numeric interval is
 * provided it represents seconds until the next run; otherwise it should
 * match an existing cron schedule slug such as hourly or daily.
 */
class Arthur_AI_Action_Adjust_Cron_Tasks implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'adjust_cron_tasks';
    }

    public function get_label() {
        return __( 'Adjust Cron Tasks', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! isset( $payload['tasks'] ) || ! is_array( $payload['tasks'] ) ) {
            return array( 'success' => false, 'message' => __( 'No tasks provided.', 'arthur-ai' ) );
        }
        $results = array();
        foreach ( $payload['tasks'] as $task ) {
            if ( ! isset( $task['hook'] ) ) {
                continue;
            }
            $hook  = sanitize_key( $task['hook'] );
            $args  = isset( $task['args'] ) && is_array( $task['args'] ) ? $task['args'] : array();
            $action = isset( $task['action'] ) ? sanitize_key( $task['action'] ) : '';
            $detail = array( 'hook' => $hook );
            // Unschedule existing events for this hook/args combination.
            while ( $timestamp = wp_next_scheduled( $hook, $args ) ) {
                wp_unschedule_event( $timestamp, $hook, $args );
            }
            if ( 'pause' === $action ) {
                $detail['action'] = 'paused';
            } elseif ( 'reschedule' === $action ) {
                $new_sched = isset( $task['new_schedule'] ) ? $task['new_schedule'] : '';
                $interval  = 0;
                $sched_hook = '';
                if ( is_numeric( $new_sched ) ) {
                    $interval = max( 60, intval( $new_sched ) );
                    wp_schedule_single_event( time() + $interval, $hook, $args );
                } else {
                    // Check if schedule slug exists.
                    $schedules = wp_get_schedules();
                    if ( isset( $schedules[ $new_sched ] ) ) {
                        wp_schedule_event( time() + $schedules[ $new_sched ]['interval'], $new_sched, $hook, $args );
                    } else {
                        // Unknown schedule, schedule single event after 5 minutes.
                        wp_schedule_single_event( time() + 300, $hook, $args );
                        $new_sched = 'single';
                    }
                }
                $detail['action'] = 'rescheduled';
                $detail['schedule'] = $new_sched;
            } else {
                $detail['action'] = 'none';
            }
            $results[] = $detail;
        }
        return array(
            'success' => true,
            'tasks'   => $results,
        );
    }
}
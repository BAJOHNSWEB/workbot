<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Optimise WordPress database tables.
 *
 * This action allows the AI to trigger an OPTIMIZE TABLE command on all
 * WordPress tables or a subset thereof. It first checks whether a known
 * optimisation plugin is present; if so, it may delegate to that plugin's
 * functionality. Otherwise, it calls the database directly via the
 * Arthur_AI_Db_Housekeeping helper. The list of optimised tables is
 * returned.
 */
class Arthur_AI_Action_Optimise_Database_Tables implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'optimise_database_tables';
    }

    public function get_label() {
        return __( 'Optimise Database Tables', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        // Determine tables; the caller may pass prefixes or full names.
        $tables = array();
        if ( isset( $payload['tables'] ) && is_array( $payload['tables'] ) ) {
            foreach ( $payload['tables'] as $tbl ) {
                $tbl = preg_replace( '/[^a-zA-Z0-9_]/', '', $tbl );
                if ( $tbl ) {
                    $tables[] = $tbl;
                }
            }
        }
        $plugin_used = null;
        $optimised   = array();
        // Detect WP-Optimize plugin or similar by class existence; no specific API used here.
        if ( class_exists( 'WP_Optimize' ) ) {
            $plugin_used = 'wp-optimize';
            // WP-Optimize does not expose a simple API so we fall back to manual OPTIMIZE.
        }
        // Optimise via helper.
        $optimised = Arthur_AI_Db_Housekeeping::optimise_tables( $tables );
        return array(
            'success'    => true,
            'message'    => __( 'Database tables optimised.', 'arthur-ai' ),
            'plugin_used' => $plugin_used,
            'tables'     => $optimised,
        );
    }
}
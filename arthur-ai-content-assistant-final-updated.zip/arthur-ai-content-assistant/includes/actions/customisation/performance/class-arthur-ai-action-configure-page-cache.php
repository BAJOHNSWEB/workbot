<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure settings for a page caching plugin or store generic cache settings.
 *
 * This action accepts a plugin slug (e.g. wp_super_cache, w3tc, wp_rocket) and
 * a set of high‑level toggles such as caching logged in users, cache lifespan
 * and whether to preload pages. Where supported, it attempts to update the
 * relevant plugin options. If the specified plugin is not active, the
 * configuration is saved in an Arthur option for later reference. A summary
 * of the applied settings or an error is returned.
 */
class Arthur_AI_Action_Configure_Page_Cache implements Arthur_AI_Action_Interface {

    /**
     * {@inheritdoc}
     */
    public function get_type() {
        return 'configure_page_cache';
    }

    /**
     * {@inheritdoc}
     */
    public function get_label() {
        return __( 'Configure Page Cache', 'arthur-ai' );
    }

    /**
     * {@inheritdoc}
     */
    public function execute( array $payload ) {
        $plugin   = isset( $payload['plugin'] ) ? sanitize_key( $payload['plugin'] ) : '';
        $settings = isset( $payload['settings'] ) && is_array( $payload['settings'] ) ? $payload['settings'] : array();
        if ( empty( $plugin ) ) {
            return array( 'success' => false, 'message' => __( 'No caching plugin specified.', 'arthur-ai' ) );
        }

        $applied  = array();
        $detected = false;
        // Normalise boolean values.
        foreach ( $settings as $k => $v ) {
            if ( is_string( $v ) ) {
                $settings[ $k ] = ( 'false' !== strtolower( $v ) && $v );
            }
        }

        switch ( $plugin ) {
            case 'wp_rocket':
                if ( defined( 'WP_ROCKET_VERSION' ) ) {
                    $detected = true;
                    // WP Rocket settings API: update_rocket_option() is available when plugin active.
                    if ( function_exists( 'update_rocket_option' ) ) {
                        if ( isset( $settings['cache_logged_in_users'] ) ) {
                            update_rocket_option( 'cache_logged_user', (bool) $settings['cache_logged_in_users'] );
                            $applied['cache_logged_in_users'] = (bool) $settings['cache_logged_in_users'];
                        }
                        if ( isset( $settings['cache_lifespan'] ) ) {
                            update_rocket_option( 'purge_cron_interval', (int) $settings['cache_lifespan'] );
                            $applied['cache_lifespan'] = (int) $settings['cache_lifespan'];
                        }
                        if ( isset( $settings['preload_enabled'] ) ) {
                            update_rocket_option( 'manual_preload', (bool) $settings['preload_enabled'] );
                            $applied['preload_enabled'] = (bool) $settings['preload_enabled'];
                        }
                        if ( isset( $settings['mobile_cache'] ) ) {
                            update_rocket_option( 'cache_mobile', (bool) $settings['mobile_cache'] );
                            $applied['mobile_cache'] = (bool) $settings['mobile_cache'];
                        }
                    }
                }
                break;
            case 'w3tc':
                // W3 Total Cache: check for main class and option names.
                if ( defined( 'W3TC' ) || class_exists( 'W3TC' ) ) {
                    $detected = true;
                    // Use w3tc functions if available; otherwise update options.
                    // Page caching settings live in w3tc options.
                    $config = get_option( 'w3tc_config', array() );
                    if ( ! is_array( $config ) ) {
                        $config = array();
                    }
                    if ( isset( $settings['cache_logged_in_users'] ) ) {
                        $config['pgcache.cache.logged_in'] = (bool) $settings['cache_logged_in_users'];
                        $applied['cache_logged_in_users']   = (bool) $settings['cache_logged_in_users'];
                    }
                    if ( isset( $settings['cache_lifespan'] ) ) {
                        $config['pgcache.lifetime'] = (int) $settings['cache_lifespan'];
                        $applied['cache_lifespan'] = (int) $settings['cache_lifespan'];
                    }
                    if ( isset( $settings['preload_enabled'] ) ) {
                        $config['pgcache.preload_enabled'] = (bool) $settings['preload_enabled'];
                        $applied['preload_enabled'] = (bool) $settings['preload_enabled'];
                    }
                    if ( isset( $settings['mobile_cache'] ) ) {
                        $config['pgcache.cache.mobile'] = (bool) $settings['mobile_cache'];
                        $applied['mobile_cache'] = (bool) $settings['mobile_cache'];
                    }
                    update_option( 'w3tc_config', $config );
                }
                break;
            case 'wp_super_cache':
                // WP Super Cache detection via function existence.
                if ( function_exists( 'prune_super_cache' ) || defined( 'WPCACHEHOME' ) ) {
                    $detected = true;
                    // WP Super Cache stores options in global $wp_cache_config, but editing config file is risky.
                    // Instead, store in Arthur's option and inform user.
                }
                break;
            default:
                // Unknown plugin; treat as generic.
                break;
        }
        // Save a copy of the requested settings for reference.
        $stored = get_option( 'arthur_ai_cache_settings', array() );
        if ( ! is_array( $stored ) ) {
            $stored = array();
        }
        $stored[ $plugin ] = $settings;
        update_option( 'arthur_ai_cache_settings', $stored );

        if ( ! $detected && 'generic' !== $plugin ) {
            return array(
                'success' => false,
                'message' => sprintf( __( 'Caching plugin %s is not active or recognised. Settings saved for reference.', 'arthur-ai' ), esc_html( $plugin ) ),
                'settings' => $settings,
            );
        }
        return array(
            'success'  => true,
            'message'  => __( 'Cache settings applied.', 'arthur-ai' ),
            'plugin'   => $plugin,
            'settings' => $applied,
        );
    }
}
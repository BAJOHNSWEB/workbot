<?php
/**
 * Configure object cache behaviour.
 *
 * This action toggles persistent object caching (e.g. Redis, Memcached) when
 * available via a plugin. If no supported plugin is active, it stores the
 * preferred state for documentation but does not modify runtime behaviour.
 */
class Arthur_AI_Action_Configure_Object_Cache implements Arthur_AI_Action_Interface {

    /**
     * {@inheritdoc}
     */
    public function get_type() {
        return 'configure_object_cache';
    }

    /**
     * {@inheritdoc}
     */
    public function get_label() {
        return __( 'Configure Object Cache', 'arthur-ai-content-assistant' );
    }

    /**
     * {@inheritdoc}
     */
    public function execute( array $payload ) {
        $enabled = isset( $payload['enabled'] ) ? (bool) $payload['enabled'] : false;
        $plugin  = isset( $payload['plugin'] ) ? sanitize_text_field( $payload['plugin'] ) : '';

        $message = '';
        $applied = false;

        if ( $enabled ) {
            switch ( $plugin ) {
                case 'redis':
                    if ( class_exists( '\\WP_Object_Cache' ) && method_exists( '\\WP_Object_Cache', 'redis_server_info' ) ) {
                        // With object cache plugin installed, enabling is a matter of ensuring object-cache.php drop-in is active.
                        $message = __( 'Redis object caching is enabled via drop-in.', 'arthur-ai-content-assistant' );
                        $applied = true;
                    } else {
                        $message = __( 'Redis object cache plugin not detected. Settings stored only.', 'arthur-ai-content-assistant' );
                    }
                    break;
                case 'memcached':
                    if ( class_exists( '\\Memcached' ) ) {
                        $message = __( 'Memcached object caching configured (if drop-in present).', 'arthur-ai-content-assistant' );
                        $applied = true;
                    } else {
                        $message = __( 'Memcached extension not available. Settings stored only.', 'arthur-ai-content-assistant' );
                    }
                    break;
                default:
                    $message = __( 'Generic object cache configuration stored.', 'arthur-ai-content-assistant' );
                    break;
            }
        } else {
            // Disabling cache: flush and note.
            wp_cache_flush();
            $message = __( 'Object cache disabled and flushed.', 'arthur-ai-content-assistant' );
            $applied = true;
        }

        update_option( 'arthur_ai_object_cache_settings', array(
            'enabled' => $enabled,
            'plugin'  => $plugin,
        ) );

        return array(
            'success' => true,
            'applied' => $applied,
            'message' => $message,
            'settings' => array(
                'enabled' => $enabled,
                'plugin'  => $plugin,
            ),
        );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Inspect WordPress scheduled tasks and return a structured list for AI review.
 *
 * This action enumerates events from the cron array, optionally filtering by
 * hook name and limiting the number of results. Each entry includes the
 * hook, schedule, next run timestamp and args. Results are sorted by
 * next run time ascending.
 */
class Arthur_AI_Action_Inspect_Scheduled_Tasks implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'inspect_scheduled_tasks';
    }

    public function get_label() {
        return __( 'Inspect Scheduled Tasks', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $hook  = isset( $payload['hook'] ) ? sanitize_key( $payload['hook'] ) : '';
        $limit = isset( $payload['limit'] ) ? max( 1, intval( $payload['limit'] ) ) : 50;
        if ( ! function_exists( '_get_cron_array' ) ) {
            require_once ABSPATH . WPINC . '/cron.php';
        }
        $cron = _get_cron_array();
        $events = array();
        foreach ( $cron as $timestamp => $hooks ) {
            foreach ( $hooks as $hook_name => $schedules ) {
                if ( $hook && $hook_name !== $hook ) {
                    continue;
                }
                foreach ( $schedules as $key => $event ) {
                    $events[] = array(
                        'hook'     => $hook_name,
                        'timestamp'=> $timestamp,
                        'schedule' => isset( $event['schedule'] ) ? $event['schedule'] : '',
                        'args'     => isset( $event['args'] ) ? $event['args'] : array(),
                    );
                }
            }
        }
        // Sort events by timestamp.
        usort( $events, function( $a, $b ) {
            return $a['timestamp'] <=> $b['timestamp'];
        } );
        if ( $limit && count( $events ) > $limit ) {
            $events = array_slice( $events, 0, $limit );
        }
        // Format timestamps for readability.
        foreach ( $events as &$event ) {
            $event['next_run'] = date_i18n( 'Y-m-d H:i:s', $event['timestamp'] );
            unset( $event['timestamp'] );
        }
        return array(
            'success' => true,
            'tasks'   => $events,
        );
    }
}
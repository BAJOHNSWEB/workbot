<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Clear cached pages or purge specific URLs via supported caching plugins.
 *
 * This action attempts to call plugin-specific purge functions if available.
 * For WP Rocket it uses rocket_clean_domain() or rocket_clean_files(). For
 * W3 Total Cache it calls w3tc_flush_all(). For WP Super Cache it calls
 * wp_cache_flush(). If none of these are available, wp_cache_flush() is used
 * as a generic fallback. When scope is `urls`, a list of URLs may be
 * provided; plugins that support per-URL purging are called accordingly.
 */
class Arthur_AI_Action_Clear_Site_Cache implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'clear_site_cache';
    }

    public function get_label() {
        return __( 'Clear Site Cache', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $scope = isset( $payload['scope'] ) ? sanitize_key( $payload['scope'] ) : 'all';
        $urls  = array();
        if ( 'urls' === $scope && isset( $payload['urls'] ) && is_array( $payload['urls'] ) ) {
            $urls = array_filter( array_map( 'esc_url_raw', $payload['urls'] ) );
        }
        $summary = array();
        $used_plugin = null;
        // WP Rocket
        if ( function_exists( 'rocket_clean_domain' ) ) {
            $used_plugin = 'wp_rocket';
            if ( 'all' === $scope ) {
                rocket_clean_domain();
                $summary['flushed'] = 'domain';
            } elseif ( ! empty( $urls ) && function_exists( 'rocket_clean_files' ) ) {
                rocket_clean_files( $urls );
                $summary['urls'] = $urls;
            } else {
                rocket_clean_domain();
                $summary['flushed'] = 'domain';
            }
        }
        // W3 Total Cache
        elseif ( function_exists( 'w3tc_flush_all' ) ) {
            $used_plugin = 'w3tc';
            w3tc_flush_all();
            $summary['flushed'] = 'w3tc_all';
        }
        // WP Super Cache
        elseif ( function_exists( 'wp_cache_clear_cache' ) || function_exists( 'wp_cache_flush' ) ) {
            $used_plugin = 'wp_super_cache';
            if ( function_exists( 'wp_cache_clear_cache' ) ) {
                wp_cache_clear_cache();
            } elseif ( function_exists( 'wp_cache_flush' ) ) {
                wp_cache_flush();
            }
            $summary['flushed'] = 'wp_cache_flush';
        } else {
            // Generic fallback: flush Object Cache if available.
            if ( function_exists( 'wp_cache_flush' ) ) {
                wp_cache_flush();
                $summary['flushed'] = 'wp_cache_flush';
            }
        }
        return array(
            'success' => true,
            'plugin'  => $used_plugin,
            'summary' => $summary,
        );
    }
}
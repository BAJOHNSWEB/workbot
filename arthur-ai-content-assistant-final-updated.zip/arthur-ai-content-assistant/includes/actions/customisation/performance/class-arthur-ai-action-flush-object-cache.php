<?php
/**
 * Flush the persistent object cache.
 *
 * This action triggers an object cache flush when supported. When no
 * object caching mechanism is present, it returns an informative error.
 */
class Arthur_AI_Action_Flush_Object_Cache implements Arthur_AI_Action_Interface {

    /**
     * {@inheritdoc}
     */
    public function get_type() {
        return 'flush_object_cache';
    }

    /**
     * {@inheritdoc}
     */
    public function get_label() {
        return __( 'Flush Object Cache', 'arthur-ai-content-assistant' );
    }

    /**
     * {@inheritdoc}
     */
    public function execute( array $payload ) {
        $success = false;
        $message = '';

        if ( function_exists( 'wp_cache_flush' ) ) {
            $success = wp_cache_flush();
            $message = $success ? __( 'Object cache flushed.', 'arthur-ai-content-assistant' ) : __( 'Object cache flush failed or no cache configured.', 'arthur-ai-content-assistant' );
        } else {
            $message = __( 'Object caching functions not available.', 'arthur-ai-content-assistant' );
        }
        return array(
            'success' => $success,
            'message' => $message,
        );
    }
}
<?php
/**
 * Configure a housekeeping profile consisting of multiple maintenance tasks.
 *
 * A housekeeping profile defines a set of tasks to run together, such as
 * database cleanup, cache clearing and optimisation. Profiles are stored in
 * an option and can be executed on demand or scheduled via cron.
 */
class Arthur_AI_Action_Configure_Housekeeping_Profile implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_housekeeping_profile';
    }

    public function get_label() {
        return __( 'Configure Housekeeping Profile', 'arthur-ai-content-assistant' );
    }

    public function execute( array $payload ) {
        $profile_name = isset( $payload['profile_name'] ) ? sanitize_key( $payload['profile_name'] ) : '';
        $tasks        = isset( $payload['tasks'] ) && is_array( $payload['tasks'] ) ? $payload['tasks'] : array();
        if ( empty( $profile_name ) || empty( $tasks ) ) {
            return array( 'success' => false, 'message' => __( 'Profile name and tasks are required.', 'arthur-ai-content-assistant' ) );
        }
        $profiles = get_option( 'arthur_ai_housekeeping_profiles', array() );
        $profiles[ $profile_name ] = $tasks;
        update_option( 'arthur_ai_housekeeping_profiles', $profiles );
        return array(
            'success' => true,
            'message' => __( 'Housekeeping profile saved.', 'arthur-ai-content-assistant' ),
            'profile' => array(
                'name'  => $profile_name,
                'tasks' => $tasks,
            ),
        );
    }
}
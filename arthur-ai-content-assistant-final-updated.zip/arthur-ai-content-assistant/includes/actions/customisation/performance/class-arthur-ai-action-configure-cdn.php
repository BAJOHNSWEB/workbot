<?php
/**
 * Configure CDN integration settings.
 *
 * This action allows the assistant to store CDN credentials or configuration for
 * supported providers (e.g. Cloudflare, CloudFront) and toggle features such
 * as development mode. When a provider plugin is installed, the action will
 * delegate to the plugin API; otherwise, it simply stores the configuration
 * for future use.
 */
class Arthur_AI_Action_Configure_Cdn implements Arthur_AI_Action_Interface {
    /**
     * {@inheritdoc}
     */
    public function get_type() {
        return 'configure_cdn';
    }

    /**
     * {@inheritdoc}
     */
    public function get_label() {
        return __( 'Configure CDN', 'arthur-ai-content-assistant' );
    }

    /**
     * {@inheritdoc}
     */
    public function execute( array $payload ) {
        $provider   = isset( $payload['provider'] ) ? sanitize_text_field( $payload['provider'] ) : '';
        $auth       = isset( $payload['auth'] ) ? $payload['auth'] : array();
        $zone_id    = isset( $payload['zone_id'] ) ? sanitize_text_field( $payload['zone_id'] ) : '';
        $settings   = isset( $payload['settings'] ) && is_array( $payload['settings'] ) ? $payload['settings'] : array();

        // Normalise settings structure.
        $config = array(
            'provider' => $provider,
            'auth'     => $auth,
            'zone_id'  => $zone_id,
            'settings' => $settings,
        );

        // Attempt provider-specific configuration if plugin exists.
        $message = '';
        switch ( $provider ) {
            case 'cloudflare':
                // Check if the Cloudflare plugin defines necessary functions.
                if ( class_exists( '\\Cloudflare\\API\\Auth\\APIKey' ) ) {
                    // Store configuration regardless; deeper integration could be implemented later.
                    $message = __( 'Cloudflare configuration stored. Advanced integration may require additional setup.', 'arthur-ai-content-assistant' );
                } else {
                    $message = __( 'Cloudflare plugin not detected. Settings saved for future use.', 'arthur-ai-content-assistant' );
                }
                break;
            case 'generic':
            default:
                $message = __( 'Generic CDN configuration stored.', 'arthur-ai-content-assistant' );
                break;
        }

        // Persist configuration in an option for use by runtime customisers.
        update_option( 'arthur_ai_cdn_config', $config );

        return array(
            'success' => true,
            'message' => $message,
            'config'  => $config,
        );
    }
}
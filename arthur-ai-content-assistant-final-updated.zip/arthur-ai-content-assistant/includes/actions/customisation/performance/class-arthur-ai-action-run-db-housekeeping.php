<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Run various database cleanup routines such as pruning old revisions, deleting
 * transients, cleaning spam or trash comments and removing orphaned meta.
 *
 * The action accepts fine‑grained configuration for each housekeeping area
 * and returns counts of removed items. Heavy operations are delegated to
 * Arthur_AI_Db_Housekeeping.
 */
class Arthur_AI_Action_Run_Db_Housekeeping implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'run_db_housekeeping';
    }

    public function get_label() {
        return __( 'Run Database Housekeeping', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        // Build configuration arrays with sensible defaults.
        $config = array(
            'revisions' => array(
                'enabled'       => false,
                'max_revisions' => 0,
            ),
            'transients' => array(
                'delete_expired' => false,
                'delete_all'     => false,
            ),
            'comments' => array(
                'delete_spam'  => false,
                'delete_trash' => false,
            ),
            'other' => array(
                'delete_autodrafts'    => false,
                'delete_orphan_postmeta' => false,
            ),
        );
        if ( isset( $payload['revisions'] ) && is_array( $payload['revisions'] ) ) {
            $config['revisions']['enabled']       = ! empty( $payload['revisions']['enabled'] );
            $config['revisions']['max_revisions'] = isset( $payload['revisions']['max_revisions'] ) ? intval( $payload['revisions']['max_revisions'] ) : 0;
        }
        if ( isset( $payload['transients'] ) && is_array( $payload['transients'] ) ) {
            $config['transients']['delete_expired'] = ! empty( $payload['transients']['delete_expired'] );
            $config['transients']['delete_all']     = ! empty( $payload['transients']['delete_all'] );
        }
        if ( isset( $payload['comments'] ) && is_array( $payload['comments'] ) ) {
            $config['comments']['delete_spam']  = ! empty( $payload['comments']['delete_spam'] );
            $config['comments']['delete_trash'] = ! empty( $payload['comments']['delete_trash'] );
        }
        if ( isset( $payload['other'] ) && is_array( $payload['other'] ) ) {
            $config['other']['delete_autodrafts']     = ! empty( $payload['other']['delete_autodrafts'] );
            $config['other']['delete_orphan_postmeta'] = ! empty( $payload['other']['delete_orphan_postmeta'] );
        }
        // Run housekeeping tasks.
        $counts = Arthur_AI_Db_Housekeeping::run( $config );
        return array(
            'success' => true,
            'message' => __( 'Database housekeeping completed.', 'arthur-ai' ),
            'counts'  => $counts,
        );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Configure lazy loading behaviour for images on the front end.
 *
 * This action stores a simple enabled flag and optional CSS selectors to
 * exclude from lazy loading. When no dedicated plugin provides lazy load
 * functionality, the Arthur AI Performance customiser will add
 * loading="lazy" to images and apply exclusion rules. The stored settings
 * allow the user to toggle lazy loading on or off via the AI assistant.
 */
class Arthur_AI_Action_Configure_Lazy_Loading implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_lazy_loading';
    }

    public function get_label() {
        return __( 'Configure Lazy Loading', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $enabled = isset( $payload['enabled'] ) ? (bool) $payload['enabled'] : false;
        $exclude = array();
        if ( isset( $payload['exclude_selectors'] ) && is_array( $payload['exclude_selectors'] ) ) {
            foreach ( $payload['exclude_selectors'] as $sel ) {
                $exclude[] = sanitize_text_field( (string) $sel );
            }
        }
        $settings = array(
            'enabled'  => $enabled,
            'exclude'  => $exclude,
        );
        update_option( 'arthur_ai_lazy_loading', $settings );
        return array(
            'success' => true,
            'settings' => $settings,
            'message' => __( 'Lazy loading configuration saved.', 'arthur-ai' ),
        );
    }
}
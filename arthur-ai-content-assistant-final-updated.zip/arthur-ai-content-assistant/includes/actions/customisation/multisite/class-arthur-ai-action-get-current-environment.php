<?php
/**
 * Get the current environment profile.
 *
 * Returns the current environment type (dev/staging/production) as reported by
 * `wp_get_environment_type()` and any corresponding profile settings stored.
 */
class Arthur_AI_Action_Get_Current_Environment implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'get_current_environment';
    }
    public function get_label() {
        return __( 'Get Current Environment', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        if ( function_exists( 'wp_get_environment_type' ) ) {
            $env = wp_get_environment_type();
        } else {
            $env = defined( 'WP_ENV' ) ? WP_ENV : 'production';
        }
        $profiles = get_option( 'arthur_ai_environment_profiles', array() );
        $settings = isset( $profiles[ $env ] ) ? $profiles[ $env ] : array();
        return array(
            'success' => true,
            'environment' => $env,
            'settings' => $settings,
        );
    }
}
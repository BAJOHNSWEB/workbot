<?php
/**
 * Configure environment profiles for dev/stage/prod.
 *
 * Stores environment-specific settings such as API keys, debug mode and
 * restrictions. These profiles can be referenced when deploying or when
 * performing environment-aware operations.
 */
class Arthur_AI_Action_Configure_Environment_Profiles implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'configure_environment_profiles';
    }
    public function get_label() {
        return __( 'Configure Environment Profiles', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        $profiles = isset( $payload['profiles'] ) && is_array( $payload['profiles'] ) ? $payload['profiles'] : array();
        update_option( 'arthur_ai_environment_profiles', $profiles );
        return array(
            'success'  => true,
            'profiles' => $profiles,
            'message'  => __( 'Environment profiles saved.', 'arthur-ai-content-assistant' ),
        );
    }
}
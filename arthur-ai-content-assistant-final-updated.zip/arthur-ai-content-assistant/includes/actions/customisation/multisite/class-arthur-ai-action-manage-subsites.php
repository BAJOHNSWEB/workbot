<?php
/**
 * Manage WordPress multisite subsites.
 *
 * Supports creation, update and deletion of subsites via the multisite API. This
 * action is guarded by `is_multisite()`. When not in multisite mode, an
 * error is returned.
 */
class Arthur_AI_Action_Manage_Subsites implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'manage_subsites';
    }
    public function get_label() {
        return __( 'Manage Subsites', 'arthur-ai-content-assistant' );
    }
    public function execute( array $payload ) {
        if ( ! is_multisite() ) {
            return array( 'success' => false, 'error' => __( 'Not a multisite installation.', 'arthur-ai-content-assistant' ) );
        }
        $action    = isset( $payload['action'] ) ? sanitize_key( $payload['action'] ) : '';
        $site_id   = isset( $payload['site_id'] ) ? absint( $payload['site_id'] ) : 0;
        $domain    = isset( $payload['domain'] ) ? sanitize_text_field( $payload['domain'] ) : '';
        $path      = isset( $payload['path'] ) ? trailingslashit( $payload['path'] ) : '/';
        $title     = isset( $payload['title'] ) ? sanitize_text_field( $payload['title'] ) : '';
        $admin_email = isset( $payload['admin_email'] ) ? sanitize_email( $payload['admin_email'] ) : get_site_option( 'admin_email' );
        switch ( $action ) {
            case 'create':
                // Create a new site
                $new_id = wpmu_create_blog( $domain, $path, $title, get_current_user_id(), array( 'public' => 1 ), get_current_network_id() );
                if ( is_wp_error( $new_id ) ) {
                    return array( 'success' => false, 'error' => $new_id->get_error_message() );
                }
                return array( 'success' => true, 'site_id' => $new_id );
            case 'update':
                if ( ! $site_id ) {
                    return array( 'success' => false, 'error' => __( 'Site ID required for update.', 'arthur-ai-content-assistant' ) );
                }
                $details = array();
                if ( $domain ) {
                    $details['domain'] = $domain;
                }
                if ( $path ) {
                    $details['path'] = $path;
                }
                if ( $title ) {
                    $details['blogname'] = $title;
                }
                if ( ! empty( $details ) ) {
                    $result = wpmu_update_blog( $site_id, $details );
                    if ( is_wp_error( $result ) ) {
                        return array( 'success' => false, 'error' => $result->get_error_message() );
                    }
                    return array( 'success' => true, 'site_id' => $site_id );
                }
                return array( 'success' => false, 'error' => __( 'No update parameters provided.', 'arthur-ai-content-assistant' ) );
            case 'delete':
                if ( ! $site_id ) {
                    return array( 'success' => false, 'error' => __( 'Site ID required for deletion.', 'arthur-ai-content-assistant' ) );
                }
                // Delete site permanently
                wpmu_delete_blog( $site_id, true );
                return array( 'success' => true, 'deleted' => $site_id );
            default:
                return array( 'success' => false, 'error' => __( 'Unknown action.', 'arthur-ai-content-assistant' ) );
        }
    }
}
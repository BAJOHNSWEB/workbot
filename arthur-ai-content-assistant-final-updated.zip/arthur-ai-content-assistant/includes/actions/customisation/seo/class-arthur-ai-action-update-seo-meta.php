<?php
/**
 * Update SEO metadata such as title, meta description and focus keyword.
 *
 * This action writes SEO metadata to the appropriate fields depending on the
 * installed SEO plugin. If Yoast SEO is active, it writes to Yoast’s meta
 * fields. If Rank Math is active, it writes to its custom fields. Otherwise
 * it stores the values in Arthur AI custom meta keys and relies on the
 * Arthur_AI_SEO_Customiser to output them in the front end.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Update_Seo_Meta implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'update_seo_meta';
    }

    public function get_label() {
        return __( 'Update SEO metadata', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $items = isset( $payload['items'] ) && is_array( $payload['items'] ) ? $payload['items'] : array();
        $results = array();
        foreach ( $items as $item ) {
            $post_id = isset( $item['post_id'] ) ? intval( $item['post_id'] ) : 0;
            if ( $post_id <= 0 || ! get_post( $post_id ) ) {
                continue;
            }
            $seo_title  = isset( $item['seo_title'] ) ? sanitize_text_field( $item['seo_title'] ) : null;
            $meta_desc  = isset( $item['meta_description'] ) ? sanitize_text_field( $item['meta_description'] ) : null;
            $focus_kw   = isset( $item['focus_keyword'] ) ? sanitize_text_field( $item['focus_keyword'] ) : null;
            $provider   = 'custom';
            // Yoast SEO integration
            if ( defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Meta' ) ) {
                if ( null !== $seo_title ) {
                    update_post_meta( $post_id, '_yoast_wpseo_title', $seo_title );
                }
                if ( null !== $meta_desc ) {
                    update_post_meta( $post_id, '_yoast_wpseo_metadesc', $meta_desc );
                }
                if ( null !== $focus_kw ) {
                    update_post_meta( $post_id, '_yoast_wpseo_focuskw', $focus_kw );
                }
                $provider = 'yoast';
            } elseif ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) {
                // Rank Math SEO integration
                if ( null !== $seo_title ) {
                    update_post_meta( $post_id, 'rank_math_title', $seo_title );
                }
                if ( null !== $meta_desc ) {
                    update_post_meta( $post_id, 'rank_math_description', $meta_desc );
                }
                if ( null !== $focus_kw ) {
                    update_post_meta( $post_id, 'rank_math_focus_keyword', $focus_kw );
                }
                $provider = 'rank_math';
            } else {
                // Fallback to Arthur AI custom meta keys
                if ( null !== $seo_title ) {
                    update_post_meta( $post_id, '_arthur_ai_seo_title', $seo_title );
                }
                if ( null !== $meta_desc ) {
                    update_post_meta( $post_id, '_arthur_ai_seo_description', $meta_desc );
                }
                if ( null !== $focus_kw ) {
                    update_post_meta( $post_id, '_arthur_ai_seo_focus_keyword', $focus_kw );
                }
            }
            $results[] = array(
                'post_id'          => $post_id,
                'seo_title'        => $seo_title,
                'meta_description' => $meta_desc,
                'focus_keyword'    => $focus_kw,
                'provider'         => $provider,
            );
        }
        return array( 'items' => $results );
    }
}
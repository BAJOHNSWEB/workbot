<?php
/**
 * Set noindex/nofollow/noarchive flags on posts or terms.
 *
 * This action updates robots meta flags for posts or terms. If a supported
 * SEO plugin is present (Yoast or Rank Math), the flags are stored using
 * the plugin’s own meta keys. Otherwise the flags are saved to custom
 * Arthur AI meta keys which will be output via the Arthur_AI_SEO_Customiser.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Set_Indexing_Flags implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'set_indexing_flags';
    }

    public function get_label() {
        return __( 'Set indexing flags', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $items   = isset( $payload['items'] ) && is_array( $payload['items'] ) ? $payload['items'] : array();
        $results = array();

        foreach ( $items as $item ) {
            $provider = 'custom';
            $flags    = array();
            // Determine target type: post or term
            $post_id  = isset( $item['post_id'] ) ? intval( $item['post_id'] ) : 0;
            $term_id  = isset( $item['term_id'] ) ? intval( $item['term_id'] ) : 0;
            $taxonomy = isset( $item['taxonomy'] ) ? sanitize_key( $item['taxonomy'] ) : '';
            if ( $post_id <= 0 && ( $term_id <= 0 || empty( $taxonomy ) ) ) {
                continue;
            }
            // Sanitise flags
            $noindex   = isset( $item['noindex'] ) ? (bool) $item['noindex'] : null;
            $nofollow  = isset( $item['nofollow'] ) ? (bool) $item['nofollow'] : null;
            $noarchive = isset( $item['noarchive'] ) ? (bool) $item['noarchive'] : null;

            // If Yoast SEO is installed
            if ( defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Meta' ) ) {
                $provider = 'yoast';
                if ( $noindex !== null ) {
                    $val = $noindex ? '1' : '0';
                    if ( $post_id > 0 ) {
                        update_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', $val );
                    } else {
                        update_term_meta( $term_id, '_yoast_wpseo_meta-robots-noindex', $val );
                    }
                    $flags['noindex'] = $val;
                }
                if ( $nofollow !== null ) {
                    $val = $nofollow ? '1' : '0';
                    if ( $post_id > 0 ) {
                        update_post_meta( $post_id, '_yoast_wpseo_meta-robots-nofollow', $val );
                    } else {
                        update_term_meta( $term_id, '_yoast_wpseo_meta-robots-nofollow', $val );
                    }
                    $flags['nofollow'] = $val;
                }
                if ( $noarchive !== null ) {
                    $val = $noarchive ? '1' : '0';
                    if ( $post_id > 0 ) {
                        update_post_meta( $post_id, '_yoast_wpseo_meta-robots-noarchive', $val );
                    } else {
                        update_term_meta( $term_id, '_yoast_wpseo_meta-robots-noarchive', $val );
                    }
                    $flags['noarchive'] = $val;
                }
            } elseif ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) {
                // Rank Math uses a single meta key `rank_math_robots` storing an array of directives
                $provider = 'rank_math';
                // Build list of robots directives
                $robots = array();
                if ( $noindex ) {
                    $robots[] = 'noindex';
                }
                if ( $nofollow ) {
                    $robots[] = 'nofollow';
                }
                if ( $noarchive ) {
                    $robots[] = 'noarchive';
                }
                if ( $post_id > 0 ) {
                    // Store as serialized array for Rank Math
                    update_post_meta( $post_id, 'rank_math_robots', $robots );
                } else {
                    update_term_meta( $term_id, 'rank_math_robots', $robots );
                }
                $flags['robots'] = $robots;
            } else {
                // Fallback: store in custom meta keys to be output via SEO customiser
                if ( $noindex !== null ) {
                    $val = $noindex ? '1' : '0';
                    if ( $post_id > 0 ) {
                        update_post_meta( $post_id, '_arthur_ai_noindex', $val );
                    } else {
                        update_term_meta( $term_id, '_arthur_ai_noindex', $val );
                    }
                    $flags['noindex'] = $val;
                }
                if ( $nofollow !== null ) {
                    $val = $nofollow ? '1' : '0';
                    if ( $post_id > 0 ) {
                        update_post_meta( $post_id, '_arthur_ai_nofollow', $val );
                    } else {
                        update_term_meta( $term_id, '_arthur_ai_nofollow', $val );
                    }
                    $flags['nofollow'] = $val;
                }
                if ( $noarchive !== null ) {
                    $val = $noarchive ? '1' : '0';
                    if ( $post_id > 0 ) {
                        update_post_meta( $post_id, '_arthur_ai_noarchive', $val );
                    } else {
                        update_term_meta( $term_id, '_arthur_ai_noarchive', $val );
                    }
                    $flags['noarchive'] = $val;
                }
            }
            $results[] = array(
                'post_id'  => $post_id,
                'term_id'  => $term_id,
                'taxonomy' => $taxonomy,
                'flags'    => $flags,
                'provider' => $provider,
            );
        }
        return array( 'items' => $results );
    }
}
<?php
/**
 * Create an advertising landing page with focused layout and copy.
 *
 * This action creates a new page using supplied content and optional
 * template and campaign tagging metadata. The page is published by default
 * and includes full block or HTML markup provided by AI. Campaign tags
 * are stored as custom meta prefixed with `_arthur_ai_campaign_`.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Create_Landing_Page implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'create_landing_page';
    }

    public function get_label() {
        return __( 'Create landing page', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $title          = isset( $payload['title'] ) ? sanitize_text_field( $payload['title'] ) : '';
        $slug           = isset( $payload['slug'] ) ? sanitize_title( $payload['slug'] ) : '';
        $content        = isset( $payload['content'] ) ? $payload['content'] : '';
        $template       = isset( $payload['template'] ) ? sanitize_text_field( $payload['template'] ) : '';
        $campaign_tags  = isset( $payload['campaign_tags'] ) && is_array( $payload['campaign_tags'] ) ? $payload['campaign_tags'] : array();
        if ( empty( $title ) || empty( $content ) ) {
            return array( 'error' => 'Title and content are required' );
        }
        $sanitised_content = wp_kses_post( $content );
        $post_data        = array(
            'post_title'   => $title,
            'post_name'    => $slug ? $slug : sanitize_title( $title ),
            'post_content' => $sanitised_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
        );
        $post_id = wp_insert_post( $post_data, true );
        if ( is_wp_error( $post_id ) ) {
            return array( 'error' => $post_id->get_error_message() );
        }
        // Apply template if provided
        if ( ! empty( $template ) ) {
            update_post_meta( $post_id, '_wp_page_template', $template );
        }
        // Store campaign tags as individual meta keys
        foreach ( $campaign_tags as $key => $value ) {
            $meta_key = '_arthur_ai_campaign_' . sanitize_key( $key );
            $meta_val = sanitize_text_field( $value );
            update_post_meta( $post_id, $meta_key, $meta_val );
        }
        return array(
            'page_id' => $post_id,
            'url'     => get_permalink( $post_id ),
        );
    }
}
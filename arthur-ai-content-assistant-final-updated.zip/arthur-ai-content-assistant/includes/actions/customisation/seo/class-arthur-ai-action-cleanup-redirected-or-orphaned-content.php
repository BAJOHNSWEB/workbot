<?php
/**
 * Clean up redirected or orphaned content.
 *
 * This action performs bulk operations on posts identified as redirected or
 * orphaned by AI or external tools. For each candidate, one of three actions
 * is taken: trash the post, unpublish it (set to draft), or mark it as
 * noindex. The action does not determine whether a post is redirected or
 * orphaned; it simply applies the requested behaviour.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Cleanup_Redirected_Or_Orphaned_Content implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'cleanup_redirected_or_orphaned_content';
    }

    public function get_label() {
        return __( 'Clean up redirected or orphaned content', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $candidates = isset( $payload['candidates'] ) && is_array( $payload['candidates'] ) ? $payload['candidates'] : array();
        $report     = array();
        foreach ( $candidates as $candidate ) {
            $post_id = isset( $candidate['post_id'] ) ? intval( $candidate['post_id'] ) : 0;
            if ( $post_id <= 0 || ! get_post( $post_id ) ) {
                continue;
            }
            $action = isset( $candidate['action'] ) ? sanitize_key( $candidate['action'] ) : '';
            $status = isset( $candidate['status'] ) ? sanitize_key( $candidate['status'] ) : '';
            $result = array( 'post_id' => $post_id, 'status' => $status, 'action' => $action, 'outcome' => '' );
            switch ( $action ) {
                case 'trash':
                    wp_trash_post( $post_id );
                    $result['outcome'] = 'trashed';
                    break;
                case 'unpublish':
                    wp_update_post( array( 'ID' => $post_id, 'post_status' => 'draft' ) );
                    $result['outcome'] = 'unpublished';
                    break;
                case 'set_noindex':
                    // Set custom noindex flag to hide from search engines
                    update_post_meta( $post_id, '_arthur_ai_noindex', '1' );
                    $result['outcome'] = 'noindexed';
                    break;
                default:
                    $result['outcome'] = 'no_action';
                    break;
            }
            $report[] = $result;
        }
        return array( 'report' => $report );
    }
}
<?php
/**
 * Apply AI-generated SEO optimised content to a post.
 *
 * This action replaces a post’s content with the supplied block or HTML
 * content. It assumes the AI has already optimised headings, internal
 * linking, and overall structure. Content is sanitised before saving.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Apply_Seo_Optimised_Content implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'apply_seo_optimised_content';
    }
    public function get_label() {
        return __( 'Apply SEO optimised content', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $post_id      = isset( $payload['post_id'] ) ? intval( $payload['post_id'] ) : 0;
        $post_content = isset( $payload['post_content'] ) ? $payload['post_content'] : '';
        if ( $post_id <= 0 || ! get_post( $post_id ) ) {
            return array( 'error' => 'Invalid post_id' );
        }
        $post_content = wp_kses_post( $post_content );
        $result = wp_update_post( array(
            'ID'           => $post_id,
            'post_content' => $post_content,
        ), true );
        if ( is_wp_error( $result ) ) {
            return array( 'error' => $result->get_error_message() );
        }
        return array(
            'post_id' => $post_id,
            'status'  => 'updated',
        );
    }
}
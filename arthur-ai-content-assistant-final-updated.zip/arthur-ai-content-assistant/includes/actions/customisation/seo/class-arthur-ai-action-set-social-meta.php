<?php
/**
 * Set Open Graph and Twitter Card metadata for posts.
 *
 * This action allows AI to specify titles, descriptions and images for social
 * sharing. When popular SEO plugins are active, their social meta keys are
 * updated; otherwise values are stored in Arthur AI custom meta and later
 * rendered via the Arthur_AI_Social_Customiser.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Set_Social_Meta implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'set_social_meta';
    }

    public function get_label() {
        return __( 'Set social meta', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $items   = isset( $payload['items'] ) && is_array( $payload['items'] ) ? $payload['items'] : array();
        $results = array();
        foreach ( $items as $item ) {
            $post_id = isset( $item['post_id'] ) ? intval( $item['post_id'] ) : 0;
            if ( $post_id <= 0 || ! get_post( $post_id ) ) {
                continue;
            }
            // Collect provided data
            $og_title       = isset( $item['og_title'] ) ? sanitize_text_field( $item['og_title'] ) : null;
            $og_description = isset( $item['og_description'] ) ? sanitize_text_field( $item['og_description'] ) : null;
            $og_image_id    = isset( $item['og_image_id'] ) ? intval( $item['og_image_id'] ) : 0;
            $og_image_url   = isset( $item['og_image_url'] ) ? esc_url_raw( $item['og_image_url'] ) : '';
            $tw_title       = isset( $item['twitter_title'] ) ? sanitize_text_field( $item['twitter_title'] ) : null;
            $tw_description = isset( $item['twitter_description'] ) ? sanitize_text_field( $item['twitter_description'] ) : null;
            $tw_image_id    = isset( $item['twitter_image_id'] ) ? intval( $item['twitter_image_id'] ) : 0;
            $tw_image_url   = isset( $item['twitter_image_url'] ) ? esc_url_raw( $item['twitter_image_url'] ) : '';
            $provider       = 'custom';
            // Determine actual image URLs
            $og_image_actual = '';
            if ( $og_image_id > 0 ) {
                $src = wp_get_attachment_image_src( $og_image_id, 'full' );
                if ( $src && ! empty( $src[0] ) ) {
                    $og_image_actual = esc_url_raw( $src[0] );
                }
            } elseif ( ! empty( $og_image_url ) ) {
                $og_image_actual = $og_image_url;
            }
            $tw_image_actual = '';
            if ( $tw_image_id > 0 ) {
                $src = wp_get_attachment_image_src( $tw_image_id, 'full' );
                if ( $src && ! empty( $src[0] ) ) {
                    $tw_image_actual = esc_url_raw( $src[0] );
                }
            } elseif ( ! empty( $tw_image_url ) ) {
                $tw_image_actual = $tw_image_url;
            }
            // Yoast SEO integration
            if ( defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Meta' ) ) {
                $provider = 'yoast';
                if ( null !== $og_title ) {
                    update_post_meta( $post_id, '_yoast_wpseo_opengraph-title', $og_title );
                }
                if ( null !== $og_description ) {
                    update_post_meta( $post_id, '_yoast_wpseo_opengraph-description', $og_description );
                }
                if ( $og_image_actual ) {
                    update_post_meta( $post_id, '_yoast_wpseo_opengraph-image', $og_image_actual );
                }
                if ( null !== $tw_title ) {
                    update_post_meta( $post_id, '_yoast_wpseo_twitter-title', $tw_title );
                }
                if ( null !== $tw_description ) {
                    update_post_meta( $post_id, '_yoast_wpseo_twitter-description', $tw_description );
                }
                if ( $tw_image_actual ) {
                    update_post_meta( $post_id, '_yoast_wpseo_twitter-image', $tw_image_actual );
                }
            } elseif ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) {
                // Rank Math integration
                $provider = 'rank_math';
                if ( null !== $og_title ) {
                    update_post_meta( $post_id, 'rank_math_facebook_title', $og_title );
                }
                if ( null !== $og_description ) {
                    update_post_meta( $post_id, 'rank_math_facebook_description', $og_description );
                }
                if ( $og_image_actual ) {
                    update_post_meta( $post_id, 'rank_math_facebook_image', $og_image_actual );
                }
                if ( null !== $tw_title ) {
                    update_post_meta( $post_id, 'rank_math_twitter_title', $tw_title );
                }
                if ( null !== $tw_description ) {
                    update_post_meta( $post_id, 'rank_math_twitter_description', $tw_description );
                }
                if ( $tw_image_actual ) {
                    update_post_meta( $post_id, 'rank_math_twitter_image', $tw_image_actual );
                }
            } else {
                // Fallback: store in Arthur AI custom meta
                if ( null !== $og_title ) {
                    update_post_meta( $post_id, '_arthur_ai_og_title', $og_title );
                }
                if ( null !== $og_description ) {
                    update_post_meta( $post_id, '_arthur_ai_og_description', $og_description );
                }
                if ( $og_image_actual ) {
                    update_post_meta( $post_id, '_arthur_ai_og_image', $og_image_actual );
                }
                if ( null !== $tw_title ) {
                    update_post_meta( $post_id, '_arthur_ai_tw_title', $tw_title );
                }
                if ( null !== $tw_description ) {
                    update_post_meta( $post_id, '_arthur_ai_tw_description', $tw_description );
                }
                if ( $tw_image_actual ) {
                    update_post_meta( $post_id, '_arthur_ai_tw_image', $tw_image_actual );
                }
            }
            $results[] = array(
                'post_id'           => $post_id,
                'provider'          => $provider,
                'og_title'          => $og_title,
                'og_description'    => $og_description,
                'og_image'          => $og_image_actual,
                'twitter_title'     => $tw_title,
                'twitter_description' => $tw_description,
                'twitter_image'     => $tw_image_actual,
            );
        }
        return array( 'items' => $results );
    }
}
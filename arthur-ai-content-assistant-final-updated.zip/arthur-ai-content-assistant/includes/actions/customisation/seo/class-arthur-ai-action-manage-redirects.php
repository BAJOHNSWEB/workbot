<?php
/**
 * Manage permanent and temporary redirects.
 *
 * This action stores a set of redirect rules and applies them via the
 * Arthur_AI_Redirects_Customiser. Rules can be appended to the existing list
 * or replace it entirely. Each rule defines a source URL/path, target URL,
 * status code and whether it is enabled. Matching is performed on the
 * request URI path (without scheme or host).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Manage_Redirects implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'manage_redirects';
    }

    public function get_label() {
        return __( 'Manage redirects', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $rules_input = isset( $payload['rules'] ) && is_array( $payload['rules'] ) ? $payload['rules'] : array();
        $mode        = isset( $payload['mode'] ) ? sanitize_key( $payload['mode'] ) : 'append';
        // Load existing rules
        $existing_rules = get_option( 'arthur_ai_redirect_rules', array() );
        if ( ! is_array( $existing_rules ) ) {
            $existing_rules = array();
        }
        $new_rules = array();
        foreach ( $rules_input as $rule ) {
            $source = isset( $rule['source_url'] ) ? trim( $rule['source_url'] ) : '';
            $target = isset( $rule['target_url'] ) ? trim( $rule['target_url'] ) : '';
            $status = isset( $rule['status_code'] ) && in_array( intval( $rule['status_code'] ), array( 301, 302 ), true ) ? intval( $rule['status_code'] ) : 302;
            $enabled = isset( $rule['enabled'] ) ? (bool) $rule['enabled'] : true;
            if ( empty( $source ) || empty( $target ) ) {
                continue;
            }
            // Normalise source as path only
            $path = parse_url( $source, PHP_URL_PATH );
            if ( ! $path ) {
                $path = $source;
            }
            $path = '/' . ltrim( untrailingslashit( $path ), '/' );
            $new_rules[ $path ] = array(
                'source_url'  => $path,
                'target_url'  => $target,
                'status_code' => $status,
                'enabled'     => $enabled,
            );
        }
        if ( 'replace_all' === $mode ) {
            $merged_rules = $new_rules;
        } else {
            // Append: merge with existing, new rules override duplicates
            $merged_rules = $existing_rules;
            foreach ( $new_rules as $key => $val ) {
                $merged_rules[ $key ] = $val;
            }
        }
        // Save rules
        update_option( 'arthur_ai_redirect_rules', $merged_rules );
        return array( 'rules' => array_values( $merged_rules ) );
    }
}
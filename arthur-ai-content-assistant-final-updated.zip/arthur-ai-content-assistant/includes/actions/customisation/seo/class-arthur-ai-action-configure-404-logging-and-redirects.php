<?php
/**
 * Configure 404 logging and apply auto‑suggested redirects.
 *
 * This action toggles 404 logging and optionally accepts a batch of suggested
 * redirect rules to apply automatically. Logging records the request URI and
 * timestamp for any 404 page, storing up to a limited number of entries. Auto
 * suggestions are appended to the existing redirect rules using the same
 * structure as `manage_redirects`.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Configure_404_Logging_And_Redirects implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_404_logging_and_redirects';
    }

    public function get_label() {
        return __( 'Configure 404 logging and redirects', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $logging_enabled = isset( $payload['logging_enabled'] ) ? (bool) $payload['logging_enabled'] : false;
        update_option( 'arthur_ai_404_logging_enabled', $logging_enabled );

        $applied_rules = array();
        // Handle auto redirects
        if ( isset( $payload['auto_redirects'] ) && is_array( $payload['auto_redirects'] ) ) {
            $auto = $payload['auto_redirects'];
            $enabled = isset( $auto['enabled'] ) ? (bool) $auto['enabled'] : false;
            if ( $enabled && ! empty( $auto['suggestions'] ) && is_array( $auto['suggestions'] ) ) {
                $existing_rules = get_option( 'arthur_ai_redirect_rules', array() );
                if ( ! is_array( $existing_rules ) ) {
                    $existing_rules = array();
                }
                foreach ( $auto['suggestions'] as $s ) {
                    $apply  = isset( $s['apply'] ) ? (bool) $s['apply'] : false;
                    if ( ! $apply ) {
                        continue;
                    }
                    $source = isset( $s['source_url'] ) ? trim( $s['source_url'] ) : '';
                    $target = isset( $s['suggested_target_url'] ) ? trim( $s['suggested_target_url'] ) : '';
                    $status = isset( $s['status_code'] ) && in_array( intval( $s['status_code'] ), array( 301, 302 ), true ) ? intval( $s['status_code'] ) : 302;
                    if ( empty( $source ) || empty( $target ) ) {
                        continue;
                    }
                    $path = parse_url( $source, PHP_URL_PATH );
                    if ( ! $path ) {
                        $path = $source;
                    }
                    $path = '/' . ltrim( untrailingslashit( $path ), '/' );
                    $existing_rules[ $path ] = array(
                        'source_url'  => $path,
                        'target_url'  => $target,
                        'status_code' => $status,
                        'enabled'     => true,
                    );
                    $applied_rules[] = $existing_rules[ $path ];
                }
                update_option( 'arthur_ai_redirect_rules', $existing_rules );
            }
        }
        // Return current log as part of response
        $log = get_option( 'arthur_ai_404_log', array() );
        return array(
            'logging_enabled' => $logging_enabled,
            'applied_rules'   => $applied_rules,
            'current_log'     => $log,
        );
    }
}
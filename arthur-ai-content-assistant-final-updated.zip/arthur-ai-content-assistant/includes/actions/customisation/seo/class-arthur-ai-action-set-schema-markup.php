<?php
/**
 * Store JSON-LD schema markup for a post.
 *
 * This action accepts a schema type and the JSON-LD payload (either as a
 * JSON string or an associative array) for a specific post. The data is
 * stored in custom meta keys for later output by the Arthur_AI_SEO_Customiser.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Set_Schema_Markup implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'set_schema_markup';
    }
    public function get_label() {
        return __( 'Set schema markup', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $post_id     = isset( $payload['post_id'] ) ? intval( $payload['post_id'] ) : 0;
        $schema_type = isset( $payload['schema_type'] ) ? sanitize_text_field( $payload['schema_type'] ) : '';
        $schema_json = isset( $payload['schema_json'] ) ? $payload['schema_json'] : '';
        if ( $post_id <= 0 || ! get_post( $post_id ) ) {
            return array( 'error' => 'Invalid post_id' );
        }
        if ( empty( $schema_type ) ) {
            return array( 'error' => 'schema_type is required' );
        }
        // Accept both JSON strings and arrays; encode arrays to JSON
        if ( is_array( $schema_json ) ) {
            $schema_json = wp_json_encode( $schema_json );
        } elseif ( is_string( $schema_json ) ) {
            $schema_json = wp_kses_post( $schema_json );
        }
        update_post_meta( $post_id, '_arthur_ai_schema_type', $schema_type );
        update_post_meta( $post_id, '_arthur_ai_schema_json', $schema_json );
        return array(
            'post_id'      => $post_id,
            'schema_type'  => $schema_type,
            'schema_json'  => $schema_json,
        );
    }
}
<?php
/**
 * Configure XML sitemap settings such as post type and taxonomy inclusion/exclusion.
 *
 * This action stores global sitemap configuration used by the SEO customiser to
 * include or exclude post types and taxonomies from the WordPress XML sitemap
 * and optionally define priority rules. If another sitemap management action is
 * present, this action supplements rather than overrides its data structure.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Configure_Sitemap_Settings implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_sitemap_settings';
    }

    public function get_label() {
        return __( 'Configure sitemap settings', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $include_post_types  = isset( $payload['include_post_types'] ) && is_array( $payload['include_post_types'] ) ? $payload['include_post_types'] : array();
        $exclude_post_types  = isset( $payload['exclude_post_types'] ) && is_array( $payload['exclude_post_types'] ) ? $payload['exclude_post_types'] : array();
        $include_taxonomies  = isset( $payload['include_taxonomies'] ) && is_array( $payload['include_taxonomies'] ) ? $payload['include_taxonomies'] : array();
        $exclude_taxonomies  = isset( $payload['exclude_taxonomies'] ) && is_array( $payload['exclude_taxonomies'] ) ? $payload['exclude_taxonomies'] : array();
        $priority_rules      = isset( $payload['priority_rules'] ) && is_array( $payload['priority_rules'] ) ? $payload['priority_rules'] : array();

        // Sanitise
        $include_post_types = array_values( array_unique( array_map( 'sanitize_key', $include_post_types ) ) );
        $exclude_post_types = array_values( array_unique( array_map( 'sanitize_key', $exclude_post_types ) ) );
        $include_taxonomies = array_values( array_unique( array_map( 'sanitize_key', $include_taxonomies ) ) );
        $exclude_taxonomies = array_values( array_unique( array_map( 'sanitize_key', $exclude_taxonomies ) ) );
        // Priority rules may be provided as associative array of object => priority
        $sanitised_priority = array();
        foreach ( $priority_rules as $key => $priority ) {
            $key = sanitize_key( $key );
            // accept numeric or numeric string between 0 and 10 as priority; else ignore
            $priority = is_numeric( $priority ) ? max( 0, min( 10, floatval( $priority ) ) ) : null;
            if ( null !== $priority ) {
                $sanitised_priority[ $key ] = $priority;
            }
        }
        $settings = array(
            'include_post_types' => $include_post_types,
            'exclude_post_types' => $exclude_post_types,
            'include_taxonomies' => $include_taxonomies,
            'exclude_taxonomies' => $exclude_taxonomies,
            'priority_rules'     => $sanitised_priority,
        );
        update_option( 'arthur_ai_sitemap_settings', $settings );
        return array( 'settings' => $settings );
    }
}
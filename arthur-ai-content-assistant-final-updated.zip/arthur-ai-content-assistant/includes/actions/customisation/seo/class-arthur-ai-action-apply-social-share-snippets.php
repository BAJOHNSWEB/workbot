<?php
/**
 * Apply social share snippets to posts.
 *
 * This action stores or inserts short social sharing snippets (text or HTML)
 * into the content of posts. Snippets can be placed at the top or bottom of
 * the content, or stored in a custom field for later rendering.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Apply_Social_Share_Snippets implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'apply_social_share_snippets';
    }

    public function get_label() {
        return __( 'Apply social share snippets', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $items   = isset( $payload['items'] ) && is_array( $payload['items'] ) ? $payload['items'] : array();
        $results = array();
        foreach ( $items as $item ) {
            $post_id = isset( $item['post_id'] ) ? intval( $item['post_id'] ) : 0;
            if ( $post_id <= 0 || ! get_post( $post_id ) ) {
                continue;
            }
            $snippet  = isset( $item['snippet'] ) ? wp_kses_post( $item['snippet'] ) : '';
            $location = isset( $item['location'] ) ? sanitize_key( $item['location'] ) : 'bottom';
            $outcome  = '';
            if ( ! $snippet ) {
                $results[] = array( 'post_id' => $post_id, 'outcome' => 'no_snippet' );
                continue;
            }
            if ( 'custom_field' === $location ) {
                update_post_meta( $post_id, '_arthur_ai_social_snippet', $snippet );
                $outcome = 'stored_custom_field';
            } else {
                // Insert into post content
                $post = get_post( $post_id );
                if ( ! $post ) {
                    continue;
                }
                $content = $post->post_content;
                if ( 'top' === $location ) {
                    $new_content = $snippet . "\n\n" . $content;
                    $outcome     = 'prepended';
                } else { // bottom or any other value
                    $new_content = $content . "\n\n" . $snippet;
                    $outcome     = 'appended';
                }
                $result = wp_update_post( array( 'ID' => $post_id, 'post_content' => $new_content ), true );
                if ( is_wp_error( $result ) ) {
                    $outcome = 'error:' . $result->get_error_message();
                }
            }
            $results[] = array( 'post_id' => $post_id, 'outcome' => $outcome );
        }
        return array( 'results' => $results );
    }
}
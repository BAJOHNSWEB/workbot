<?php
/**
 * Duplicate a landing page for A/B testing with optional content overrides.
 *
 * This action clones an existing page and applies specific overrides for
 * headline, subheadline, call‑to‑action text or fully replaced content. It
 * preserves templates and campaign tags and marks the variant via metadata.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Duplicate_Landing_Page_For_Ab implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'duplicate_landing_page_for_ab';
    }

    public function get_label() {
        return __( 'Duplicate landing page for A/B test', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $source_id       = isset( $payload['source_page_id'] ) ? intval( $payload['source_page_id'] ) : 0;
        $variant_suffix  = isset( $payload['variant_suffix'] ) ? sanitize_title( $payload['variant_suffix'] ) : '';
        $overrides       = isset( $payload['content_overrides'] ) && is_array( $payload['content_overrides'] ) ? $payload['content_overrides'] : array();
        $status          = isset( $payload['status'] ) ? sanitize_key( $payload['status'] ) : 'draft';
        if ( $source_id <= 0 ) {
            return array( 'error' => 'Invalid source_page_id' );
        }
        $source_post = get_post( $source_id );
        if ( ! $source_post || 'page' !== $source_post->post_type ) {
            return array( 'error' => 'Source page not found or not a page' );
        }
        if ( empty( $variant_suffix ) ) {
            return array( 'error' => 'variant_suffix is required' );
        }
        // Create a new slug and title based on the variant suffix
        $new_title = $source_post->post_title . ' ' . strtoupper( $variant_suffix );
        $base_slug = $source_post->post_name ? $source_post->post_name : sanitize_title( $source_post->post_title );
        $new_slug  = sanitize_title( $base_slug . '-' . $variant_suffix );
        // Copy content
        $new_content = $source_post->post_content;
        // Apply content overrides
        if ( isset( $overrides['post_content'] ) ) {
            $new_content = wp_kses_post( $overrides['post_content'] );
        } else {
            // Targeted replacements
            if ( isset( $overrides['headline'] ) ) {
                $headline = wp_kses_post( $overrides['headline'] );
                // Replace first <h1> tag content
                $new_content = preg_replace( '/<h1( [^>]*)?>.*?<\/h1>/i', '<h1$1>' . $headline . '</h1>', $new_content, 1 );
            }
            if ( isset( $overrides['subheadline'] ) ) {
                $sub = wp_kses_post( $overrides['subheadline'] );
                $new_content = preg_replace( '/<h2( [^>]*)?>.*?<\/h2>/i', '<h2$1>' . $sub . '</h2>', $new_content, 1 );
            }
            if ( isset( $overrides['cta_text'] ) ) {
                $cta = wp_kses_post( $overrides['cta_text'] );
                // Replace first anchor text content
                $new_content = preg_replace_callback( '/<a([^>]*)>(.*?)<\/a>/i', function ( $matches ) use ( $cta ) {
                    // Preserve attributes
                    return '<a' . $matches[1] . '>' . $cta . '</a>';
                }, $new_content, 1 );
            }
        }
        $new_post = array(
            'post_title'   => $new_title,
            'post_name'    => $new_slug,
            'post_content' => $new_content,
            'post_status'  => in_array( $status, array( 'publish', 'draft', 'private' ), true ) ? $status : 'draft',
            'post_type'    => 'page',
            'post_parent'  => 0,
        );
        $new_id = wp_insert_post( $new_post, true );
        if ( is_wp_error( $new_id ) ) {
            return array( 'error' => $new_id->get_error_message() );
        }
        // Copy page template
        $template = get_post_meta( $source_id, '_wp_page_template', true );
        if ( $template ) {
            update_post_meta( $new_id, '_wp_page_template', $template );
        }
        // Copy campaign tags
        $meta = get_post_meta( $source_id );
        foreach ( $meta as $meta_key => $meta_values ) {
            if ( strpos( $meta_key, '_arthur_ai_campaign_' ) === 0 ) {
                foreach ( $meta_values as $meta_value ) {
                    update_post_meta( $new_id, $meta_key, maybe_unserialize( $meta_value ) );
                }
            }
        }
        // Mark variant relationship
        update_post_meta( $new_id, '_arthur_ai_ab_parent', $source_id );
        update_post_meta( $new_id, '_arthur_ai_ab_variant', $variant_suffix );
        return array(
            'variant_page_id' => $new_id,
            'url'             => get_permalink( $new_id ),
        );
    }
}
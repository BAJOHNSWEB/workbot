<?php
/**
 * Apply generated lesson content and quiz questions.
 *
 * This action updates a lesson with AI-generated summary content and creates
 * or updates a related quiz with provided questions. It assumes the AI has
 * already generated the content and questions. Supported providers include
 * LearnDash, LifterLMS and TutorLMS. If the provider or LMS plugin is not
 * active it returns an error.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Apply_Generated_Lesson_Content implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'apply_generated_lesson_content';
    }
    public function get_label() {
        return __( 'Apply generated lesson content', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        $supported = array( 'learndash', 'lifterlms', 'tutorlms' );
        if ( ! in_array( $provider, $supported, true ) ) {
            return array( 'error' => 'Unsupported LMS provider ' . $provider . '.' );
        }
        // Check plugin activation
        $active = false;
        if ( 'learndash' === $provider && defined( 'LEARNDASH_VERSION' ) ) {
            $active = true;
        } elseif ( 'lifterlms' === $provider && ( defined( 'LLMS_VERSION' ) || function_exists( 'llms' ) ) ) {
            $active = true;
        } elseif ( 'tutorlms' === $provider && ( function_exists( 'tutor_utils' ) || defined( 'TUTOR_VERSION' ) ) ) {
            $active = true;
        }
        if ( ! $active ) {
            return array( 'error' => 'LMS provider ' . $provider . ' is not active.' );
        }
        $lesson_id = isset( $payload['lesson_id'] ) ? intval( $payload['lesson_id'] ) : 0;
        if ( $lesson_id <= 0 || ! get_post( $lesson_id ) ) {
            return array( 'error' => 'Invalid lesson_id.' );
        }
        $summary = isset( $payload['summary'] ) ? wp_kses_post( $payload['summary'] ) : '';
        $quiz_questions = isset( $payload['quiz_questions'] ) && is_array( $payload['quiz_questions'] ) ? $payload['quiz_questions'] : array();
        // Update lesson content
        $update_result = wp_update_post( array(
            'ID'           => $lesson_id,
            'post_content' => $summary,
        ), true );
        if ( is_wp_error( $update_result ) ) {
            return array( 'error' => 'Failed to update lesson content.' );
        }
        // Create or update an associated quiz if questions provided
        $quiz_id = 0;
        if ( ! empty( $quiz_questions ) ) {
            // See if a quiz is already linked via meta
            $existing_quiz_ids = get_posts( array(
                'post_type'      => array( 'sfwd-quiz', 'quiz', 'tutor_quiz' ),
                'meta_key'       => '_arthur_ai_lesson_id',
                'meta_value'     => $lesson_id,
                'posts_per_page' => 1,
                'fields'         => 'ids',
            ) );
            if ( ! empty( $existing_quiz_ids ) ) {
                $quiz_id = $existing_quiz_ids[0];
                update_post_meta( $quiz_id, '_arthur_ai_quiz_questions', $quiz_questions );
            } else {
                // Create a new quiz using create_or_update_quizzes mapping; choose quiz post type based on provider
                $quiz_type_map = array(
                    'learndash' => 'sfwd-quiz',
                    'lifterlms' => 'quiz',
                    'tutorlms'  => 'tutor_quiz',
                );
                $quiz_type = isset( $quiz_type_map[ $provider ] ) ? $quiz_type_map[ $provider ] : 'quiz';
                $quiz_id = wp_insert_post( array(
                    'post_title'  => get_the_title( $lesson_id ) . ' Quiz',
                    'post_status' => 'publish',
                    'post_type'   => $quiz_type,
                ), true );
                if ( ! is_wp_error( $quiz_id ) && $quiz_id ) {
                    update_post_meta( $quiz_id, '_arthur_ai_lesson_id', $lesson_id );
                    update_post_meta( $quiz_id, '_arthur_ai_quiz_questions', $quiz_questions );
                }
            }
        }
        return array(
            'provider'   => $provider,
            'lesson_id'  => $lesson_id,
            'quiz_id'    => $quiz_id,
        );
    }
}
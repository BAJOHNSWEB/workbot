<?php
/**
 * Create or update quizzes for courses or lessons.
 *
 * Supports LearnDash, LifterLMS and TutorLMS. Each quiz can include an
 * arbitrary question structure provided by the AI. Questions are stored as
 * serialized meta for later consumption. If the provider plugin is not
 * active, the action returns an error.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Create_Or_Update_Quizzes implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'create_or_update_quizzes';
    }
    public function get_label() {
        return __( 'Create or update quizzes', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        $supported = array( 'learndash', 'lifterlms', 'tutorlms' );
        if ( ! in_array( $provider, $supported, true ) ) {
            return array( 'error' => 'Unsupported LMS provider ' . $provider . '.' );
        }
        // Determine plugin availability
        $active = false;
        if ( 'learndash' === $provider && defined( 'LEARNDASH_VERSION' ) ) {
            $active = true;
        } elseif ( 'lifterlms' === $provider && ( defined( 'LLMS_VERSION' ) || function_exists( 'llms' ) ) ) {
            $active = true;
        } elseif ( 'tutorlms' === $provider && ( function_exists( 'tutor_utils' ) || defined( 'TUTOR_VERSION' ) ) ) {
            $active = true;
        }
        if ( ! $active ) {
            return array( 'error' => 'LMS provider ' . $provider . ' is not active.' );
        }
        // At least one of course_id or lesson_id must be provided
        $course_id = isset( $payload['course_id'] ) ? intval( $payload['course_id'] ) : 0;
        $lesson_id = isset( $payload['lesson_id'] ) ? intval( $payload['lesson_id'] ) : 0;
        if ( $course_id <= 0 && $lesson_id <= 0 ) {
            return array( 'error' => 'course_id or lesson_id must be provided.' );
        }
        $quizzes = isset( $payload['quizzes'] ) && is_array( $payload['quizzes'] ) ? $payload['quizzes'] : array();
        if ( empty( $quizzes ) ) {
            return array( 'error' => 'quizzes array is required' );
        }
        $quiz_map = array(
            'learndash' => 'sfwd-quiz',
            'lifterlms' => 'quiz',
            'tutorlms'  => 'tutor_quiz',
        );
        $quiz_type = isset( $quiz_map[ $provider ] ) ? $quiz_map[ $provider ] : 'quiz';
        $results = array();
        foreach ( $quizzes as $quiz ) {
            $quiz_id   = isset( $quiz['quiz_id'] ) ? intval( $quiz['quiz_id'] ) : 0;
            $title     = isset( $quiz['title'] ) ? sanitize_text_field( $quiz['title'] ) : '';
            $questions = isset( $quiz['questions'] ) && is_array( $quiz['questions'] ) ? $quiz['questions'] : array();
            if ( empty( $title ) ) {
                continue;
            }
            $is_update = ( $quiz_id > 0 && get_post( $quiz_id ) );
            $args = array(
                'post_title'   => $title,
                'post_status'  => 'publish',
                'post_type'    => $quiz_type,
            );
            if ( $is_update ) {
                $args['ID'] = $quiz_id;
                $new_quiz_id = wp_update_post( $args, true );
            } else {
                $new_quiz_id = wp_insert_post( $args, true );
            }
            if ( is_wp_error( $new_quiz_id ) || ! $new_quiz_id ) {
                continue;
            }
            // Link quiz to course or lesson via custom meta
            if ( $course_id > 0 ) {
                update_post_meta( $new_quiz_id, '_arthur_ai_course_id', $course_id );
            }
            if ( $lesson_id > 0 ) {
                update_post_meta( $new_quiz_id, '_arthur_ai_lesson_id', $lesson_id );
            }
            // Store questions as serialised meta
            update_post_meta( $new_quiz_id, '_arthur_ai_quiz_questions', $questions );
            $results[] = array(
                'quiz_id'   => $new_quiz_id,
                'title'     => $title,
                'is_update' => $is_update,
            );
        }
        return array(
            'provider'  => $provider,
            'course_id' => $course_id,
            'lesson_id' => $lesson_id,
            'quizzes'   => $results,
        );
    }
}
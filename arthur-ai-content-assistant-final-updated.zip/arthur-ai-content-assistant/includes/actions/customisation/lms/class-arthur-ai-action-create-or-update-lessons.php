<?php
/**
 * Create or update lessons associated with a course.
 *
 * Supports LearnDash, LifterLMS and TutorLMS. Lessons are created as posts
 * in provider-specific CPTs and linked to their course via meta fields. If a
 * lesson_id is provided, the existing lesson will be updated.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Create_Or_Update_Lessons implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'create_or_update_lessons';
    }
    public function get_label() {
        return __( 'Create or update lessons', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        $supported = array( 'learndash', 'lifterlms', 'tutorlms' );
        if ( ! in_array( $provider, $supported, true ) ) {
            return array( 'error' => 'Unsupported LMS provider ' . $provider . '.' );
        }
        // Validate provider activation
        $active = false;
        if ( 'learndash' === $provider && defined( 'LEARNDASH_VERSION' ) ) {
            $active = true;
        } elseif ( 'lifterlms' === $provider && ( defined( 'LLMS_VERSION' ) || function_exists( 'llms' ) ) ) {
            $active = true;
        } elseif ( 'tutorlms' === $provider && ( function_exists( 'tutor_utils' ) || defined( 'TUTOR_VERSION' ) ) ) {
            $active = true;
        }
        if ( ! $active ) {
            return array( 'error' => 'LMS provider ' . $provider . ' is not active.' );
        }
        $course_id = isset( $payload['course_id'] ) ? intval( $payload['course_id'] ) : 0;
        if ( $course_id <= 0 ) {
            return array( 'error' => 'course_id is required' );
        }
        $lessons = isset( $payload['lessons'] ) && is_array( $payload['lessons'] ) ? $payload['lessons'] : array();
        if ( empty( $lessons ) ) {
            return array( 'error' => 'lessons array is required' );
        }
        $cpt_map = array(
            'learndash' => 'sfwd-lessons',
            'lifterlms' => 'lesson',
            'tutorlms'  => 'tutor_lesson',
        );
        $lesson_type = isset( $cpt_map[ $provider ] ) ? $cpt_map[ $provider ] : 'lesson';
        $results = array();
        foreach ( $lessons as $item ) {
            $lesson_id  = isset( $item['lesson_id'] ) ? intval( $item['lesson_id'] ) : 0;
            $title      = isset( $item['title'] ) ? sanitize_text_field( $item['title'] ) : '';
            $content    = isset( $item['content'] ) ? wp_kses_post( $item['content'] ) : '';
            $position   = isset( $item['position'] ) ? intval( $item['position'] ) : 0;
            if ( empty( $title ) ) {
                continue;
            }
            $is_update = ( $lesson_id > 0 && get_post( $lesson_id ) );
            $args = array(
                'post_title'   => $title,
                'post_content' => $content,
                'post_status'  => 'publish',
                'post_type'    => $lesson_type,
                'menu_order'   => $position,
            );
            if ( $is_update ) {
                $args['ID'] = $lesson_id;
                $new_lesson_id = wp_update_post( $args, true );
            } else {
                $new_lesson_id = wp_insert_post( $args, true );
            }
            if ( is_wp_error( $new_lesson_id ) || ! $new_lesson_id ) {
                continue;
            }
            // Link lesson to course using a generic meta key. Individual LMS
            // providers use their own meta relations but this stores the
            // association for AI-managed courses.
            update_post_meta( $new_lesson_id, '_arthur_ai_course_id', $course_id );
            $results[] = array(
                'lesson_id' => $new_lesson_id,
                'title'     => $title,
                'position'  => $position,
                'is_update' => $is_update,
            );
        }
        return array(
            'provider'   => $provider,
            'course_id'  => $course_id,
            'lessons'    => $results,
        );
    }
}
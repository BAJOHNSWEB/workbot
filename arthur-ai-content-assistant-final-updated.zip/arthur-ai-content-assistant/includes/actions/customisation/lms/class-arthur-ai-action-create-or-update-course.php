<?php
/**
 * Create or update a course in a supported LMS provider.
 *
 * Supported providers include LearnDash, LifterLMS and TutorLMS. If the
 * specified provider is not active the action returns an error. Courses are
 * created as custom post types with provider-specific slugs. Additional
 * metadata such as price and access mode are stored as custom fields.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Create_Or_Update_Course implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'create_or_update_course';
    }
    public function get_label() {
        return __( 'Create or update course', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        $supported = array( 'learndash', 'lifterlms', 'tutorlms' );
        if ( ! in_array( $provider, $supported, true ) ) {
            return array( 'error' => 'Unsupported LMS provider ' . $provider . '.' );
        }
        // Check plugin activation per provider
        $active = false;
        if ( 'learndash' === $provider && defined( 'LEARNDASH_VERSION' ) ) {
            $active = true;
        } elseif ( 'lifterlms' === $provider && ( defined( 'LLMS_VERSION' ) || function_exists( 'llms' ) ) ) {
            $active = true;
        } elseif ( 'tutorlms' === $provider && ( function_exists( 'tutor_utils' ) || defined( 'TUTOR_VERSION' ) ) ) {
            $active = true;
        }
        if ( ! $active ) {
            return array( 'error' => 'LMS provider ' . $provider . ' is not active.' );
        }
        $course_id = isset( $payload['course_id'] ) ? intval( $payload['course_id'] ) : 0;
        $title     = isset( $payload['title'] ) ? sanitize_text_field( $payload['title'] ) : '';
        if ( empty( $title ) ) {
            return array( 'error' => 'title is required' );
        }
        $description = isset( $payload['description'] ) ? wp_kses_post( $payload['description'] ) : '';
        $excerpt    = isset( $payload['excerpt'] ) ? wp_kses_post( $payload['excerpt'] ) : '';
        $price      = isset( $payload['price'] ) ? floatval( $payload['price'] ) : 0.0;
        $access_mode = isset( $payload['access_mode'] ) ? sanitize_text_field( $payload['access_mode'] ) : '';
        $categories  = isset( $payload['categories'] ) && is_array( $payload['categories'] ) ? $payload['categories'] : array();
        $tags        = isset( $payload['tags'] ) && is_array( $payload['tags'] ) ? $payload['tags'] : array();

        // CPT mapping per LMS
        $cpt_map = array(
            'learndash' => 'sfwd-courses',
            'lifterlms' => 'course',
            'tutorlms'  => 'tutor_course',
        );
        $post_type = isset( $cpt_map[ $provider ] ) ? $cpt_map[ $provider ] : 'course';
        $is_update = ( $course_id > 0 && get_post( $course_id ) );

        $args = array(
            'post_title'   => $title,
            'post_content' => $description,
            'post_excerpt' => $excerpt,
            'post_status'  => 'publish',
            'post_type'    => $post_type,
        );
        if ( $is_update ) {
            $args['ID'] = $course_id;
            $new_id = wp_update_post( $args, true );
        } else {
            $new_id = wp_insert_post( $args, true );
        }
        if ( is_wp_error( $new_id ) || ! $new_id ) {
            return array( 'error' => 'Failed to save course.' );
        }
        $course_id = $new_id;
        // Save price and access mode as custom meta
        update_post_meta( $course_id, '_arthur_ai_course_price', $price );
        update_post_meta( $course_id, '_arthur_ai_course_access_mode', $access_mode );
        // Assign categories and tags if provided. We try to use built-in taxonomies for courses when possible.
        if ( ! empty( $categories ) ) {
            // Try course category taxonomy; fallback to regular category
            $course_cat_tax = ( 'learndash' === $provider ) ? 'ld_course_category' : ( 'lifterlms' === $provider ? 'course_cat' : 'course-category' );
            if ( taxonomy_exists( $course_cat_tax ) ) {
                $term_ids = array();
                foreach ( $categories as $cat ) {
                    if ( is_numeric( $cat ) ) {
                        $term_ids[] = (int) $cat;
                    } else {
                        $term = term_exists( $cat, $course_cat_tax );
                        if ( ! $term ) {
                            $new_term = wp_insert_term( sanitize_text_field( $cat ), $course_cat_tax );
                            if ( ! is_wp_error( $new_term ) ) {
                                $term_ids[] = $new_term['term_id'];
                            }
                        } else {
                            $term_ids[] = $term['term_id'];
                        }
                    }
                }
                wp_set_post_terms( $course_id, $term_ids, $course_cat_tax, false );
            } else {
                // fallback to default category taxonomy
                $term_ids = array();
                foreach ( $categories as $cat ) {
                    if ( is_numeric( $cat ) ) {
                        $term_ids[] = (int) $cat;
                    } else {
                        $term = term_exists( $cat, 'category' );
                        if ( ! $term ) {
                            $new_term = wp_insert_term( sanitize_text_field( $cat ), 'category' );
                            if ( ! is_wp_error( $new_term ) ) {
                                $term_ids[] = $new_term['term_id'];
                            }
                        } else {
                            $term_ids[] = $term['term_id'];
                        }
                    }
                }
                wp_set_post_terms( $course_id, $term_ids, 'category', false );
            }
        }
        if ( ! empty( $tags ) ) {
            $tag_tax = ( 'learndash' === $provider ) ? 'ld_course_tag' : ( 'lifterlms' === $provider ? 'course_tag' : 'course-tag' );
            if ( taxonomy_exists( $tag_tax ) ) {
                $term_ids = array();
                foreach ( $tags as $tag ) {
                    if ( is_numeric( $tag ) ) {
                        $term_ids[] = (int) $tag;
                    } else {
                        $term = term_exists( $tag, $tag_tax );
                        if ( ! $term ) {
                            $new_term = wp_insert_term( sanitize_text_field( $tag ), $tag_tax );
                            if ( ! is_wp_error( $new_term ) ) {
                                $term_ids[] = $new_term['term_id'];
                            }
                        } else {
                            $term_ids[] = $term['term_id'];
                        }
                    }
                }
                wp_set_post_terms( $course_id, $term_ids, $tag_tax, false );
            } else {
                // fallback to post_tag
                $term_ids = array();
                foreach ( $tags as $tag ) {
                    if ( is_numeric( $tag ) ) {
                        $term_ids[] = (int) $tag;
                    } else {
                        $term = term_exists( $tag, 'post_tag' );
                        if ( ! $term ) {
                            $new_term = wp_insert_term( sanitize_text_field( $tag ), 'post_tag' );
                            if ( ! is_wp_error( $new_term ) ) {
                                $term_ids[] = $new_term['term_id'];
                            }
                        } else {
                            $term_ids[] = $term['term_id'];
                        }
                    }
                }
                wp_set_post_terms( $course_id, $term_ids, 'post_tag', false );
            }
        }

        return array(
            'provider'   => $provider,
            'course_id'  => $course_id,
            'title'      => $title,
            'is_update'  => $is_update,
        );
    }
}
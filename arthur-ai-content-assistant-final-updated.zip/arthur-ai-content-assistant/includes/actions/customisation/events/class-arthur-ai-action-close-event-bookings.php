<?php
/**
 * Close bookings for an event with custom front‑end behaviour.
 *
 * Stores closure state and UI behaviour settings as event meta. The
 * Arthur_AI_Bookings_Customiser will respect these settings to hide
 * ticket purchase forms and optionally display a message or allow
 * cancellations. Supports different modes like soft_close and hard_close.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Close_Event_Bookings implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'close_event_bookings';
    }

    public function get_label() {
        return __( 'Close event bookings', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! class_exists( 'Tribe__Events__Main' ) || ! class_exists( 'Tribe__Tickets__Tickets' ) ) {
            return array( 'error' => 'Event Tickets and The Events Calendar must be active to close bookings.' );
        }
        $event_id = isset( $payload['event_id'] ) ? (int) $payload['event_id'] : 0;
        if ( ! $event_id || ! get_post( $event_id ) ) {
            return array( 'error' => 'Invalid event_id provided.' );
        }
        $mode      = isset( $payload['mode'] ) ? sanitize_key( $payload['mode'] ) : 'soft_close';
        $behaviour = isset( $payload['frontend_behaviour'] ) && is_array( $payload['frontend_behaviour'] ) ? $payload['frontend_behaviour'] : array();
        $state     = array(
            'mode'              => $mode,
            'hide_tickets'      => isset( $behaviour['hide_tickets'] ) ? (bool) $behaviour['hide_tickets'] : true,
            'show_message'      => isset( $behaviour['show_message'] ) ? wp_kses_post( $behaviour['show_message'] ) : '',
            'allow_view_ticket' => isset( $behaviour['allow_view_ticket'] ) ? (bool) $behaviour['allow_view_ticket'] : true,
            'allow_cancellations' => isset( $behaviour['allow_cancellations'] ) ? (bool) $behaviour['allow_cancellations'] : false,
        );
        update_post_meta( $event_id, 'arthur_ai_event_closed_state', $state );
        return array( 'event_id' => $event_id, 'closed_state' => $state );
    }
}
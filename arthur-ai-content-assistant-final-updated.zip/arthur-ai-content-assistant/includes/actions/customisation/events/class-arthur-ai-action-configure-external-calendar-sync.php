<?php
/**
 * Configure external calendar sync for events.
 *
 * This action stores configuration for exporting events to external
 * calendars. Currently only a high‑level configuration is stored.
 * Supports generating iCal feed subscription links for different
 * scopes (site‑wide, category, organiser, single event) using The
 * Events Calendar’s built‑in feed system. API‑based sync is left
 * for future implementation. Requires The Events Calendar to be
 * active for feed link generation.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Configure_External_Calendar_Sync implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'configure_external_calendar_sync';
    }
    public function get_label() {
        return __( 'Configure external calendar sync', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $mode = isset( $payload['mode'] ) ? sanitize_key( $payload['mode'] ) : 'ics_feed';
        // For API mode we simply store provided configuration
        $config = array( 'mode' => $mode );
        if ( 'ics_feed' === $mode ) {
            // Generate feed link(s) if TEC is active
            if ( ! class_exists( 'Tribe__Events__Main' ) ) {
                return array( 'error' => 'The Events Calendar must be active for iCal feeds.' );
            }
            $scope = isset( $payload['scope'] ) ? sanitize_key( $payload['scope'] ) : 'site_wide';
            $config['scope'] = $scope;
            $feed_links = array();
            switch ( $scope ) {
                case 'category':
                    if ( isset( $payload['category_slug'] ) ) {
                        $slug        = sanitize_title( $payload['category_slug'] );
                        $feed_links[] = home_url( '/events/category/' . $slug . '/?ical=1' );
                    }
                    break;
                case 'organiser':
                    if ( isset( $payload['organiser_slug'] ) ) {
                        $slug        = sanitize_title( $payload['organiser_slug'] );
                        $feed_links[] = home_url( '/events/organizer/' . $slug . '/?ical=1' );
                    }
                    break;
                case 'single_event':
                    if ( isset( $payload['event_id'] ) ) {
                        $event_id = (int) $payload['event_id'];
                        $feed_links[] = home_url( '/?ical=1&event=' . $event_id );
                    }
                    break;
                case 'site_wide':
                default:
                    $feed_links[] = home_url( '/?ical=1' );
                    break;
            }
            $config['feed_links'] = $feed_links;
        } elseif ( 'api' === $mode ) {
            // Store provider, auth and rules for later use
            $config['provider']     = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
            $config['auth_config']  = isset( $payload['auth_config'] ) ? $payload['auth_config'] : array();
            $config['sync_rules']   = isset( $payload['sync_rules'] ) ? $payload['sync_rules'] : array();
        }
        update_option( 'arthur_ai_external_calendar_sync', $config );
        return array( 'configuration' => $config );
    }
}
<?php
/**
 * Manage event attendees: list, add, update or remove attendees.
 *
 * For listing, returns the attendees for an event. For adding, it creates
 * a new attendee associated with a given ticket. Updating modifies
 * attendee meta fields. Removing deletes the attendee post. Requires
 * Event Tickets to be active. Use action list for retrieval; for other
 * actions provide the necessary parameters as documented.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Manage_Event_Attendees implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'manage_event_attendees';
    }

    public function get_label() {
        return __( 'Manage event attendees', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! class_exists( 'Tribe__Tickets__Tickets' ) ) {
            return array( 'error' => 'The Event Tickets plugin is not active.' );
        }
        $event_id  = isset( $payload['event_id'] ) ? (int) $payload['event_id'] : 0;
        $operations= isset( $payload['operations'] ) && is_array( $payload['operations'] ) ? $payload['operations'] : array();
        if ( ! $event_id || ! get_post( $event_id ) ) {
            return array( 'error' => 'Invalid event_id provided.' );
        }
        $results = array();
        foreach ( $operations as $op ) {
            $action = isset( $op['action'] ) ? $op['action'] : '';
            switch ( $action ) {
                case 'list':
                    // Return attendee list
                    $attendees = array();
                    if ( method_exists( 'Tribe__Tickets__Tickets', 'get_event_attendees' ) ) {
                        $attendees = Tribe__Tickets__Tickets::get_event_attendees( $event_id );
                    }
                    $results[] = array( 'attendees' => $attendees );
                    break;
                case 'add':
                    // Create new attendee
                    $ticket_id = isset( $op['ticket_id'] ) ? (int) $op['ticket_id'] : 0;
                    $attendee  = isset( $op['attendee'] ) && is_array( $op['attendee'] ) ? $op['attendee'] : array();
                    if ( ! $ticket_id || ! get_post( $ticket_id ) ) {
                        $results[] = array( 'error' => 'Invalid ticket_id for add attendee.' );
                        break;
                    }
                    // Build attendee data for create_attendee
                    $att_data = array();
                    if ( isset( $attendee['name'] ) ) {
                        $att_data['full_name'] = sanitize_text_field( $attendee['name'] );
                    }
                    if ( isset( $attendee['email'] ) ) {
                        $att_data['email'] = sanitize_email( $attendee['email'] );
                    }
                    // Additional meta fields
                    if ( isset( $attendee['meta'] ) && is_array( $attendee['meta'] ) ) {
                        foreach ( $attendee['meta'] as $meta_key => $meta_value ) {
                            $att_data[ $meta_key ] = sanitize_text_field( $meta_value );
                        }
                    }
                    // Create attendee
                    try {
                        $att_post = Tribe__Tickets__Tickets::create_attendee( $ticket_id, $att_data );
                        if ( $att_post ) {
                            $results[] = array( 'attendee_id' => $att_post->ID, 'created' => true );
                        } else {
                            $results[] = array( 'error' => 'Failed to create attendee.' );
                        }
                    } catch ( Exception $e ) {
                        $results[] = array( 'error' => $e->getMessage() );
                    }
                    break;
                case 'update':
                    $attendee_id = isset( $op['attendee_id'] ) ? (int) $op['attendee_id'] : 0;
                    $changes     = isset( $op['changes'] ) && is_array( $op['changes'] ) ? $op['changes'] : array();
                    if ( ! $attendee_id || ! get_post( $attendee_id ) ) {
                        $results[] = array( 'error' => 'Invalid attendee_id for update.' );
                        break;
                    }
                    // Update attendee meta
                    foreach ( $changes as $field => $value ) {
                        if ( 'name' === $field ) {
                            wp_update_post( array( 'ID' => $attendee_id, 'post_title' => sanitize_text_field( $value ) ) );
                        } elseif ( 'email' === $field ) {
                            update_post_meta( $attendee_id, '_tribe_tickets_email', sanitize_email( $value ) );
                        } else {
                            update_post_meta( $attendee_id, sanitize_key( $field ), maybe_serialize( $value ) );
                        }
                    }
                    $results[] = array( 'attendee_id' => $attendee_id, 'updated' => true );
                    break;
                case 'remove':
                    $attendee_id = isset( $op['attendee_id'] ) ? (int) $op['attendee_id'] : 0;
                    if ( ! $attendee_id || ! get_post( $attendee_id ) ) {
                        $results[] = array( 'error' => 'Invalid attendee_id for removal.' );
                        break;
                    }
                    wp_delete_post( $attendee_id, true );
                    $results[] = array( 'attendee_id' => $attendee_id, 'removed' => true );
                    break;
                default:
                    $results[] = array( 'error' => 'Invalid attendee action provided.' );
                    break;
            }
        }
        return $results;
    }
}
<?php
/**
 * Update ticket capacity and sales windows for existing event tickets.
 *
 * Requires Event Tickets to be active. Iterates through provided ticket
 * definitions and updates the capacity and sales start/end dates on
 * existing ticket posts. This does not create new tickets.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Update_Ticket_Caps implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'update_ticket_caps';
    }

    public function get_label() {
        return __( 'Update ticket caps', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! class_exists( 'Tribe__Tickets__Tickets' ) ) {
            return array( 'error' => 'The Event Tickets plugin is not active.' );
        }
        $event_id = isset( $payload['event_id'] ) ? (int) $payload['event_id'] : 0;
        if ( ! $event_id || ! get_post( $event_id ) ) {
            return array( 'error' => 'Invalid event_id provided.' );
        }
        $tickets = isset( $payload['tickets'] ) && is_array( $payload['tickets'] ) ? $payload['tickets'] : array();
        $updated = array();
        foreach ( $tickets as $ticket ) {
            if ( empty( $ticket['id'] ) ) {
                continue;
            }
            $ticket_id   = (int) $ticket['id'];
            $capacity    = isset( $ticket['capacity'] ) && $ticket['capacity'] !== '' ? intval( $ticket['capacity'] ) : null;
            $sales_start = isset( $ticket['start_datetime'] ) ? sanitize_text_field( $ticket['start_datetime'] ) : '';
            $sales_end   = isset( $ticket['end_datetime'] ) ? sanitize_text_field( $ticket['end_datetime'] ) : '';
            // Verify ticket exists
            if ( ! get_post( $ticket_id ) ) {
                $updated[] = array( 'ticket_id' => $ticket_id, 'error' => 'Ticket not found' );
                continue;
            }
            if ( null !== $capacity ) {
                update_post_meta( $ticket_id, '_tribe_ticket_capacity', $capacity );
            }
            if ( $sales_start ) {
                update_post_meta( $ticket_id, '_ticket_start_date', date( 'Y-m-d H:i:s', strtotime( $sales_start ) ) );
            }
            if ( $sales_end ) {
                update_post_meta( $ticket_id, '_ticket_end_date', date( 'Y-m-d H:i:s', strtotime( $sales_end ) ) );
            }
            $updated[] = array( 'ticket_id' => $ticket_id, 'updated' => true );
        }
        return $updated;
    }
}
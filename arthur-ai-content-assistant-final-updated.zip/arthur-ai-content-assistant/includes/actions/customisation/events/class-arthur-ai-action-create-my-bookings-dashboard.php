<?php
/**
 * Create or update a "My bookings" dashboard page.
 *
 * This action creates a page (or updates it if already present) that
 * displays a user’s bookings and tickets. The layout content is
 * provided by the payload. The page ID is saved in an option so the
 * Arthur_AI_Bookings_Customiser can hook a shortcode or block to
 * render dynamic content for logged‑in users. Requires The Events
 * Calendar and Event Tickets for the dynamic portion but page creation
 * will still succeed if not active.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Create_My_Bookings_Dashboard implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'create_my_bookings_dashboard';
    }

    public function get_label() {
        return __( 'Create My bookings dashboard', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $page_title = isset( $payload['page_title'] ) ? sanitize_text_field( $payload['page_title'] ) : '';
        $slug       = isset( $payload['slug'] ) ? sanitize_title( $payload['slug'] ) : '';
        $layout     = isset( $payload['layout'] ) ? wp_kses_post( $payload['layout'] ) : '';
        if ( empty( $page_title ) ) {
            return array( 'error' => 'page_title is required.' );
        }
        // See if page exists by slug or title
        $page_id = 0;
        if ( $slug ) {
            $existing = get_page_by_path( $slug, OBJECT, 'page' );
            if ( $existing ) {
                $page_id = $existing->ID;
            }
        }
        if ( ! $page_id ) {
            $existing_by_title = get_page_by_title( $page_title, OBJECT, 'page' );
            if ( $existing_by_title ) {
                $page_id = $existing_by_title->ID;
            }
        }
        if ( $page_id ) {
            // Update page content
            wp_update_post( array( 'ID' => $page_id, 'post_content' => $layout, 'post_title' => $page_title ) );
        } else {
            // Create new page
            $page_id = wp_insert_post( array(
                'post_title'   => $page_title,
                'post_name'    => $slug ? $slug : sanitize_title( $page_title ),
                'post_type'    => 'page',
                'post_status'  => 'publish',
                'post_content' => $layout,
            ) );
        }
        if ( is_wp_error( $page_id ) || ! $page_id ) {
            return array( 'error' => 'Failed to create or update page.' );
        }
        // Save page ID to an option so the customiser can hook in
        update_option( 'arthur_ai_my_bookings_page_id', (int) $page_id );
        return array( 'page_id' => (int) $page_id, 'page_url' => get_permalink( $page_id ) );
    }
}
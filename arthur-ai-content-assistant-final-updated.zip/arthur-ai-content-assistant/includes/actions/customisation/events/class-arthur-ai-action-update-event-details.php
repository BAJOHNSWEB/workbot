<?php
/**
 * Update an event's details and metadata.
 *
 * Allows updating the title, description, dates, all‑day flag,
 * venue, organiser, categories and arbitrary custom meta. Only fields
 * present in the payload will be updated.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Update_Event_Details implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'update_event_details';
    }

    public function get_label() {
        return __( 'Update event details', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! class_exists( 'Tribe__Events__Main' ) ) {
            return array( 'error' => 'The Events Calendar plugin is not active.' );
        }
        $event_id = isset( $payload['event_id'] ) ? (int) $payload['event_id'] : 0;
        if ( ! $event_id || ! get_post( $event_id ) ) {
            return array( 'error' => 'Invalid event_id provided.' );
        }
        $post_update = array( 'ID' => $event_id );
        // Update title and description if provided
        if ( isset( $payload['title'] ) ) {
            $post_update['post_title'] = sanitize_text_field( $payload['title'] );
        }
        if ( isset( $payload['description'] ) ) {
            $post_update['post_content'] = wp_kses_post( $payload['description'] );
        }
        if ( count( $post_update ) > 1 ) {
            wp_update_post( $post_update );
        }
        // Update dates
        if ( isset( $payload['start_datetime'] ) ) {
            $start_dt = date( 'Y-m-d H:i:s', strtotime( sanitize_text_field( $payload['start_datetime'] ) ) );
            update_post_meta( $event_id, '_EventStartDate', $start_dt );
        }
        if ( isset( $payload['end_datetime'] ) ) {
            $end_dt = date( 'Y-m-d H:i:s', strtotime( sanitize_text_field( $payload['end_datetime'] ) ) );
            update_post_meta( $event_id, '_EventEndDate', $end_dt );
        }
        if ( isset( $payload['all_day'] ) ) {
            update_post_meta( $event_id, '_EventAllDay', $payload['all_day'] ? 'yes' : 'no' );
        }
        // Venue update
        if ( isset( $payload['venue'] ) && is_array( $payload['venue'] ) ) {
            $venue_data = $payload['venue'];
            $venue_id   = 0;
            if ( ! empty( $venue_data['name'] ) ) {
                $venue_name = sanitize_text_field( $venue_data['name'] );
                // Try to find existing
                $existing = get_posts( array(
                    'post_type'      => Tribe__Events__Main::VENUE_POST_TYPE,
                    'post_status'    => 'publish',
                    'title'          => $venue_name,
                    'posts_per_page' => 1,
                ) );
                if ( ! empty( $existing ) ) {
                    $venue_id = $existing[0]->ID;
                } else {
                    $venue_id = wp_insert_post( array(
                        'post_title'  => $venue_name,
                        'post_status' => 'publish',
                        'post_type'   => Tribe__Events__Main::VENUE_POST_TYPE,
                    ) );
                }
                if ( $venue_id ) {
                    // Update venue meta fields
                    if ( isset( $venue_data['address'] ) ) {
                        update_post_meta( $venue_id, '_VenueAddress', sanitize_text_field( $venue_data['address'] ) );
                    }
                    if ( isset( $venue_data['city'] ) ) {
                        update_post_meta( $venue_id, '_VenueCity', sanitize_text_field( $venue_data['city'] ) );
                    }
                    if ( isset( $venue_data['postcode'] ) ) {
                        update_post_meta( $venue_id, '_VenueZip', sanitize_text_field( $venue_data['postcode'] ) );
                    }
                    if ( isset( $venue_data['country'] ) ) {
                        update_post_meta( $venue_id, '_VenueCountry', sanitize_text_field( $venue_data['country'] ) );
                    }
                    if ( isset( $venue_data['phone'] ) ) {
                        update_post_meta( $venue_id, '_VenuePhone', sanitize_text_field( $venue_data['phone'] ) );
                    }
                    if ( isset( $venue_data['website'] ) ) {
                        update_post_meta( $venue_id, '_VenueURL', esc_url_raw( $venue_data['website'] ) );
                    }
                    update_post_meta( $event_id, '_EventVenueID', (int) $venue_id );
                }
            }
        }
        // Organiser update
        if ( isset( $payload['organiser'] ) && is_array( $payload['organiser'] ) ) {
            $organiser_data = $payload['organiser'];
            $organiser_id   = 0;
            if ( ! empty( $organiser_data['name'] ) ) {
                $org_name = sanitize_text_field( $organiser_data['name'] );
                $existing = get_posts( array(
                    'post_type'      => Tribe__Events__Main::ORGANIZER_POST_TYPE,
                    'post_status'    => 'publish',
                    'title'          => $org_name,
                    'posts_per_page' => 1,
                ) );
                if ( ! empty( $existing ) ) {
                    $organiser_id = $existing[0]->ID;
                } else {
                    $organiser_id = wp_insert_post( array(
                        'post_title'  => $org_name,
                        'post_status' => 'publish',
                        'post_type'   => Tribe__Events__Main::ORGANIZER_POST_TYPE,
                    ) );
                }
                if ( $organiser_id ) {
                    if ( isset( $organiser_data['email'] ) ) {
                        update_post_meta( $organiser_id, '_OrganizerEmail', sanitize_email( $organiser_data['email'] ) );
                    }
                    if ( isset( $organiser_data['phone'] ) ) {
                        update_post_meta( $organiser_id, '_OrganizerPhone', sanitize_text_field( $organiser_data['phone'] ) );
                    }
                    if ( isset( $organiser_data['website'] ) ) {
                        update_post_meta( $organiser_id, '_OrganizerWebsite', esc_url_raw( $organiser_data['website'] ) );
                    }
                    update_post_meta( $event_id, '_EventOrganizerID', (int) $organiser_id );
                }
            }
        }
        // Update categories
        if ( isset( $payload['categories'] ) && is_array( $payload['categories'] ) ) {
            $terms = array();
            foreach ( $payload['categories'] as $cat ) {
                if ( is_numeric( $cat ) ) {
                    $terms[] = (int) $cat;
                } else {
                    $term_obj = term_exists( $cat, 'tribe_events_cat' );
                    if ( ! $term_obj ) {
                        $term = wp_insert_term( sanitize_text_field( $cat ), 'tribe_events_cat' );
                        if ( ! is_wp_error( $term ) && isset( $term['term_id'] ) ) {
                            $terms[] = $term['term_id'];
                        }
                    } else {
                        $terms[] = $term_obj['term_id'];
                    }
                }
            }
            if ( ! empty( $terms ) ) {
                wp_set_object_terms( $event_id, $terms, 'tribe_events_cat' );
            }
        }
        // Custom meta update
        if ( isset( $payload['custom_meta'] ) && is_array( $payload['custom_meta'] ) ) {
            foreach ( $payload['custom_meta'] as $key => $value ) {
                $meta_key = sanitize_key( $key );
                update_post_meta( $event_id, $meta_key, maybe_serialize( $value ) );
            }
        }
        return array( 'event_id' => $event_id, 'message' => 'Event updated successfully.' );
    }
}
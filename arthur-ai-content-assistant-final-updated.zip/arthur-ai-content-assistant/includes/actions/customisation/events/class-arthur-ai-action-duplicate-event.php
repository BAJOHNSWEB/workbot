<?php
/**
 * Duplicate an existing event with new dates.
 *
 * This action creates a copy of an existing event post along with
 * its metadata, venue, organiser and categories. The start and end dates
 * can be overridden when duplicating. If The Events Calendar is not
 * active, the action returns an error.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Duplicate_Event implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'duplicate_event';
    }

    public function get_label() {
        return __( 'Duplicate event', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! class_exists( 'Tribe__Events__Main' ) ) {
            return array( 'error' => 'The Events Calendar plugin is not active.' );
        }
        $event_id = isset( $payload['event_id'] ) ? (int) $payload['event_id'] : 0;
        $new_start = isset( $payload['new_start_datetime'] ) ? sanitize_text_field( $payload['new_start_datetime'] ) : '';
        $new_end   = isset( $payload['new_end_datetime'] ) ? sanitize_text_field( $payload['new_end_datetime'] ) : '';
        $status    = isset( $payload['status'] ) ? sanitize_key( $payload['status'] ) : 'publish';
        if ( ! $event_id || ! get_post( $event_id ) ) {
            return array( 'error' => 'Invalid event_id provided.' );
        }
        // Get source event post
        $source = get_post( $event_id );
        if ( ! $source || $source->post_type !== Tribe__Events__Main::POSTTYPE ) {
            return array( 'error' => 'Provided post is not an event.' );
        }
        // Determine new dates
        if ( empty( $new_start ) ) {
            return array( 'error' => 'new_start_datetime is required.' );
        }
        $start_dt = date( 'Y-m-d H:i:s', strtotime( $new_start ) );
        if ( $new_end ) {
            $end_dt = date( 'Y-m-d H:i:s', strtotime( $new_end ) );
        } else {
            // Default to same duration as original event
            $orig_start = get_post_meta( $event_id, '_EventStartDate', true );
            $orig_end   = get_post_meta( $event_id, '_EventEndDate', true );
            if ( $orig_start && $orig_end ) {
                $duration_seconds = strtotime( $orig_end ) - strtotime( $orig_start );
                $end_dt = date( 'Y-m-d H:i:s', strtotime( $start_dt ) + $duration_seconds );
            } else {
                $end_dt = date( 'Y-m-d H:i:s', strtotime( $start_dt . ' +1 hour' ) );
            }
        }
        // Create new event post
        $new_post = array(
            'post_title'   => $source->post_title,
            'post_content' => $source->post_content,
            'post_status'  => $status,
            'post_type'    => Tribe__Events__Main::POSTTYPE,
        );
        $new_event_id = wp_insert_post( $new_post );
        if ( is_wp_error( $new_event_id ) || ! $new_event_id ) {
            return array( 'error' => 'Failed to duplicate event.' );
        }
        // Copy meta
        $meta = get_post_meta( $event_id );
        foreach ( $meta as $key => $values ) {
            // Skip date-related meta keys and some protected keys
            if ( in_array( $key, array( '_EventStartDate', '_EventEndDate', '_EventSchedule', '_EventDuration' ), true ) ) {
                continue;
            }
            foreach ( $values as $value ) {
                update_post_meta( $new_event_id, $key, maybe_unserialize( $value ) );
            }
        }
        // Update new dates and all-day flag accordingly
        update_post_meta( $new_event_id, '_EventStartDate', $start_dt );
        update_post_meta( $new_event_id, '_EventEndDate', $end_dt );
        $all_day = get_post_meta( $event_id, '_EventAllDay', true );
        update_post_meta( $new_event_id, '_EventAllDay', $all_day ? $all_day : 'no' );
        // Copy categories
        $terms = wp_get_object_terms( $event_id, 'tribe_events_cat', array( 'fields' => 'ids' ) );
        if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
            wp_set_object_terms( $new_event_id, $terms, 'tribe_events_cat' );
        }
        return array(
            'event_id'   => (int) $new_event_id,
            'start_date' => $start_dt,
            'end_date'   => $end_dt,
        );
    }
}
<?php
/**
 * Customise The Events Calendar views and event card settings.
 *
 * Stores view and card configuration in a persistent option so that
 * Arthur_AI_Events_Customiser can adjust TEC’s list/grid layouts. If
 * TEC is inactive this action returns an error. Settings include
 * enabled view types, a default view, filters to enable/disable and
 * which fields to show on event cards.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Customise_Event_Views implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'customise_event_views';
    }
    public function get_label() {
        return __( 'Customise event views', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! class_exists( 'Tribe__Events__Main' ) ) {
            return array( 'error' => 'The Events Calendar plugin is not active.' );
        }
        $settings = array();
        $settings['view_types']    = isset( $payload['view_types'] ) && is_array( $payload['view_types'] ) ? array_map( 'sanitize_key', $payload['view_types'] ) : array();
        $settings['default_view']  = isset( $payload['default_view'] ) ? sanitize_key( $payload['default_view'] ) : '';
        $settings['filters']       = isset( $payload['filters'] ) && is_array( $payload['filters'] ) ? $payload['filters'] : array();
        $settings['card_settings'] = isset( $payload['card_settings'] ) && is_array( $payload['card_settings'] ) ? $payload['card_settings'] : array();
        update_option( 'arthur_ai_event_view_settings', $settings );
        return array( 'settings' => $settings );
    }
}
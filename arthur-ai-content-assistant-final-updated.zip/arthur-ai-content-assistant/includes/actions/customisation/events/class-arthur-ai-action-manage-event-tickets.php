<?php
/**
 * Create or update event tickets using the Event Tickets / Event Tickets Plus API.
 *
 * When the Event Tickets plugin is active, this action will iterate over
 * provided ticket definitions and either create new tickets or update
 * existing ones. Tickets can be RSVP, Tickets Commerce or WooCommerce
 * providers. If WooCommerce is required for a ticket and WooCommerce is
 * inactive the ticket will be skipped with an error entry. Price, capacity
 * and sales windows are stored in ticket meta. When creating a ticket the
 * plugin will associate it with the specified event.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Manage_Event_Tickets implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'manage_event_tickets';
    }

    public function get_label() {
        return __( 'Manage event tickets', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        // Ensure Event Tickets is active
        if ( ! class_exists( 'Tribe__Tickets__Tickets' ) ) {
            return array( 'error' => 'The Event Tickets plugin is not active.' );
        }
        $event_id = isset( $payload['event_id'] ) ? (int) $payload['event_id'] : 0;
        if ( ! $event_id || ! get_post( $event_id ) ) {
            return array( 'error' => 'Invalid event_id provided.' );
        }
        $tickets = isset( $payload['tickets'] ) && is_array( $payload['tickets'] ) ? $payload['tickets'] : array();
        $results = array();
        foreach ( $tickets as $ticket ) {
            // Normalise ticket fields
            $ticket_id    = isset( $ticket['id'] ) ? (int) $ticket['id'] : 0;
            $name         = isset( $ticket['name'] ) ? sanitize_text_field( $ticket['name'] ) : '';
            $desc         = isset( $ticket['description'] ) ? wp_kses_post( $ticket['description'] ) : '';
            $price        = isset( $ticket['price'] ) && $ticket['price'] !== '' ? floatval( $ticket['price'] ) : null;
            $capacity     = isset( $ticket['capacity'] ) && '' !== $ticket['capacity'] ? intval( $ticket['capacity'] ) : null;
            $sales_start  = isset( $ticket['start_datetime'] ) ? sanitize_text_field( $ticket['start_datetime'] ) : '';
            $sales_end    = isset( $ticket['end_datetime'] ) ? sanitize_text_field( $ticket['end_datetime'] ) : '';
            $provider     = isset( $ticket['provider'] ) ? sanitize_key( $ticket['provider'] ) : 'rsvp';
            // For Woo tickets ensure WooCommerce is active
            if ( 'woo' === $provider && ! class_exists( 'WooCommerce' ) ) {
                $results[] = array( 'error' => "WooCommerce must be active for Woo tickets: {$name}" );
                continue;
            }
            // Update existing ticket
            if ( $ticket_id ) {
                // Ticket posts use their own post type (e.g. tribe_tickets)
                $ticket_post = get_post( $ticket_id );
                if ( ! $ticket_post ) {
                    $results[] = array( 'error' => "Ticket ID {$ticket_id} not found." );
                    continue;
                }
                // Update title and description
                $update = array( 'ID' => $ticket_id );
                if ( $name ) {
                    $update['post_title'] = $name;
                }
                if ( $desc ) {
                    $update['post_excerpt'] = $desc;
                }
                wp_update_post( $update );
                // Update meta
                if ( null !== $price ) {
                    // Price meta names vary by provider; set both _price and _regular_price for Woo
                    update_post_meta( $ticket_id, '_price', $price );
                    update_post_meta( $ticket_id, '_regular_price', $price );
                }
                if ( null !== $capacity ) {
                    update_post_meta( $ticket_id, '_tribe_ticket_capacity', $capacity );
                }
                if ( $sales_start ) {
                    update_post_meta( $ticket_id, '_ticket_start_date', date( 'Y-m-d H:i:s', strtotime( $sales_start ) ) );
                }
                if ( $sales_end ) {
                    update_post_meta( $ticket_id, '_ticket_end_date', date( 'Y-m-d H:i:s', strtotime( $sales_end ) ) );
                }
                $results[] = array( 'ticket_id' => $ticket_id, 'updated' => true );
            } else {
                // Create a new ticket via the ticket repository API
                if ( ! function_exists( 'tribe_tickets' ) ) {
                    $results[] = array( 'error' => 'Unable to access ticket repository.' );
                    continue;
                }
                $args = array(
                    'title'  => $name,
                    'status' => 'publish',
                );
                // Set provider-specific fields
                if ( 'rsvp' === $provider ) {
                    // Associate with event
                    $args['_tribe_rsvp_for_event'] = $event_id;
                } else {
                    // tickets-commerce or woo
                    $args['event'] = $event_id;
                }
                if ( $desc ) {
                    $args['excerpt'] = $desc;
                    $args['_tribe_ticket_show_description'] = true;
                }
                if ( null !== $price ) {
                    $args['_price']        = $price;
                    $args['_regular_price']= $price;
                }
                if ( null !== $capacity ) {
                    $args['_tribe_ticket_capacity'] = $capacity;
                }
                if ( $sales_start ) {
                    $args['_ticket_start_date'] = date( 'Y-m-d H:i:s', strtotime( $sales_start ) );
                }
                if ( $sales_end ) {
                    $args['_ticket_end_date'] = date( 'Y-m-d H:i:s', strtotime( $sales_end ) );
                }
                try {
                    $ticket_obj = tribe_tickets( $provider )->set_args( $args )->create();
                    if ( $ticket_obj ) {
                        $results[] = array( 'ticket_id' => $ticket_obj->ID, 'created' => true );
                    } else {
                        $results[] = array( 'error' => "Failed to create ticket {$name}" );
                    }
                } catch ( Exception $e ) {
                    $results[] = array( 'error' => $e->getMessage() );
                }
            }
        }
        return $results;
    }
}
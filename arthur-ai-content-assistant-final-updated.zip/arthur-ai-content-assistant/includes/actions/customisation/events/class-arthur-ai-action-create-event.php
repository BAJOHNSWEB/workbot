<?php
/**
 * Create a new event using The Events Calendar (TEC).
 *
 * This action checks if The Events Calendar plugin is active and then
 * programmatically creates an event post with associated venue, organiser,
 * schedule details and categories. If TEC is not active the action
 * returns an error.
 *
 * The payload should include:
 * - title (string, required)
 * - description (string, optional HTML/block markup)
 * - start_datetime (string in Y-m-d H:i:s format, required)
 * - end_datetime (string in Y-m-d H:i:s format, optional)
 * - all_day (bool, optional)
 * - venue (array with name, address, city, postcode, country, phone, website)
 * - organiser (array with name, email, phone, website)
 * - categories (array of term IDs or names, optional)
 * - status (string, optional, defaults to 'publish')
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Create_Event implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'create_event';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Create event', 'arthur-ai' );
    }

    /**
     * {@inheritDoc}
     */
    public function execute( array $payload ) {
        // Check that The Events Calendar is active
        if ( ! class_exists( 'Tribe__Events__Main' ) ) {
            return array( 'error' => 'The Events Calendar plugin is not active.' );
        }

        $title         = isset( $payload['title'] ) ? sanitize_text_field( $payload['title'] ) : '';
        $description   = isset( $payload['description'] ) ? wp_kses_post( $payload['description'] ) : '';
        $start         = isset( $payload['start_datetime'] ) ? sanitize_text_field( $payload['start_datetime'] ) : '';
        $end           = isset( $payload['end_datetime'] ) ? sanitize_text_field( $payload['end_datetime'] ) : '';
        $all_day       = isset( $payload['all_day'] ) ? (bool) $payload['all_day'] : false;
        $venue_data    = isset( $payload['venue'] ) && is_array( $payload['venue'] ) ? $payload['venue'] : array();
        $organiser_data= isset( $payload['organiser'] ) && is_array( $payload['organiser'] ) ? $payload['organiser'] : array();
        $categories    = isset( $payload['categories'] ) && is_array( $payload['categories'] ) ? $payload['categories'] : array();
        $status        = isset( $payload['status'] ) ? sanitize_key( $payload['status'] ) : 'publish';

        if ( empty( $title ) || empty( $start ) ) {
            return array( 'error' => 'title and start_datetime are required.' );
        }

        // Parse dates. If end not provided, set end equal to start for all‑day or 1 hour after start for timed events.
        $start_dt = date( 'Y-m-d H:i:s', strtotime( $start ) );
        if ( $end ) {
            $end_dt = date( 'Y-m-d H:i:s', strtotime( $end ) );
        } else {
            if ( $all_day ) {
                // For all day events end date should match start date but at 23:59:59
                $end_dt = date( 'Y-m-d 23:59:59', strtotime( $start ) );
            } else {
                // Default to 1 hour duration
                $end_dt = date( 'Y-m-d H:i:s', strtotime( $start . ' +1 hour' ) );
            }
        }

        // Create or find venue
        $venue_id = 0;
        if ( ! empty( $venue_data['name'] ) ) {
            $venue_name = sanitize_text_field( $venue_data['name'] );
            // Try to find an existing venue with the same name
            $existing = get_posts( array(
                'post_type'      => Tribe__Events__Main::VENUE_POST_TYPE,
                'post_status'    => 'publish',
                'title'          => $venue_name,
                'posts_per_page' => 1,
            ) );
            if ( ! empty( $existing ) ) {
                $venue_id = $existing[0]->ID;
            } else {
                // Build venue post
                $venue_post = array(
                    'post_title'   => $venue_name,
                    'post_status'  => 'publish',
                    'post_type'    => Tribe__Events__Main::VENUE_POST_TYPE,
                );
                $venue_id = wp_insert_post( $venue_post );
                if ( $venue_id ) {
                    // Store venue details in meta
                    if ( isset( $venue_data['address'] ) ) {
                        update_post_meta( $venue_id, '_VenueAddress', sanitize_text_field( $venue_data['address'] ) );
                    }
                    if ( isset( $venue_data['city'] ) ) {
                        update_post_meta( $venue_id, '_VenueCity', sanitize_text_field( $venue_data['city'] ) );
                    }
                    if ( isset( $venue_data['postcode'] ) ) {
                        update_post_meta( $venue_id, '_VenueZip', sanitize_text_field( $venue_data['postcode'] ) );
                    }
                    if ( isset( $venue_data['country'] ) ) {
                        update_post_meta( $venue_id, '_VenueCountry', sanitize_text_field( $venue_data['country'] ) );
                    }
                    if ( isset( $venue_data['phone'] ) ) {
                        update_post_meta( $venue_id, '_VenuePhone', sanitize_text_field( $venue_data['phone'] ) );
                    }
                    if ( isset( $venue_data['website'] ) ) {
                        update_post_meta( $venue_id, '_VenueURL', esc_url_raw( $venue_data['website'] ) );
                    }
                }
            }
        }

        // Create or find organiser
        $organiser_id = 0;
        if ( ! empty( $organiser_data['name'] ) ) {
            $org_name = sanitize_text_field( $organiser_data['name'] );
            $existing = get_posts( array(
                'post_type'      => Tribe__Events__Main::ORGANIZER_POST_TYPE,
                'post_status'    => 'publish',
                'title'          => $org_name,
                'posts_per_page' => 1,
            ) );
            if ( ! empty( $existing ) ) {
                $organiser_id = $existing[0]->ID;
            } else {
                $organiser_post = array(
                    'post_title'  => $org_name,
                    'post_status' => 'publish',
                    'post_type'   => Tribe__Events__Main::ORGANIZER_POST_TYPE,
                );
                $organiser_id = wp_insert_post( $organiser_post );
                if ( $organiser_id ) {
                    if ( isset( $organiser_data['email'] ) ) {
                        update_post_meta( $organiser_id, '_OrganizerEmail', sanitize_email( $organiser_data['email'] ) );
                    }
                    if ( isset( $organiser_data['phone'] ) ) {
                        update_post_meta( $organiser_id, '_OrganizerPhone', sanitize_text_field( $organiser_data['phone'] ) );
                    }
                    if ( isset( $organiser_data['website'] ) ) {
                        update_post_meta( $organiser_id, '_OrganizerWebsite', esc_url_raw( $organiser_data['website'] ) );
                    }
                }
            }
        }

        // Build event post
        $event_post = array(
            'post_title'   => $title,
            'post_content' => $description,
            'post_status'  => $status,
            'post_type'    => Tribe__Events__Main::POSTTYPE,
        );

        // Insert the event
        $event_id = wp_insert_post( $event_post );
        if ( is_wp_error( $event_id ) || ! $event_id ) {
            return array( 'error' => 'Failed to create the event.' );
        }

        // Save meta fields for TEC
        update_post_meta( $event_id, '_EventStartDate', $start_dt );
        update_post_meta( $event_id, '_EventEndDate', $end_dt );
        update_post_meta( $event_id, '_EventAllDay', $all_day ? 'yes' : 'no' );
        if ( $venue_id ) {
            update_post_meta( $event_id, '_EventVenueID', (int) $venue_id );
        }
        if ( $organiser_id ) {
            update_post_meta( $event_id, '_EventOrganizerID', (int) $organiser_id );
        }

        // Assign categories if provided
        if ( ! empty( $categories ) ) {
            $term_ids = array();
            foreach ( $categories as $cat ) {
                if ( is_numeric( $cat ) ) {
                    $term_ids[] = (int) $cat;
                } else {
                    // Create term if not exists
                    $term_obj = term_exists( $cat, 'tribe_events_cat' );
                    if ( ! $term_obj ) {
                        $term = wp_insert_term( sanitize_text_field( $cat ), 'tribe_events_cat' );
                        if ( ! is_wp_error( $term ) && isset( $term['term_id'] ) ) {
                            $term_ids[] = $term['term_id'];
                        }
                    } else {
                        $term_ids[] = $term_obj['term_id'];
                    }
                }
            }
            if ( ! empty( $term_ids ) ) {
                wp_set_object_terms( $event_id, $term_ids, 'tribe_events_cat' );
            }
        }

        return array(
            'event_id'   => (int) $event_id,
            'start_date' => $start_dt,
            'end_date'   => $end_dt,
            'all_day'    => $all_day,
            'venue_id'   => $venue_id,
            'organiser_id' => $organiser_id,
        );
    }
}
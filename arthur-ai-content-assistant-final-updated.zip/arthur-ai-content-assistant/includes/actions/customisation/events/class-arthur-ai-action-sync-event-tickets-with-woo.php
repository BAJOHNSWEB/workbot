<?php
/**
 * Synchronise Event Tickets with WooCommerce products.
 *
 * For each ticket definition, this action ensures there is a linked WooCommerce
 * product. If a product_id is provided it will update the existing
 * product’s price and stock according to the ticket definition. If no
 * product_id is provided a new simple product will be created. The
 * resulting product ID is stored on the ticket meta so that Event Tickets
 * knows which Woo product corresponds to the ticket. Requires Event
 * Tickets and WooCommerce.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Sync_Event_Tickets_With_Woo implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'sync_event_tickets_with_woo';
    }
    public function get_label() {
        return __( 'Sync event tickets with WooCommerce', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! class_exists( 'Tribe__Tickets__Tickets' ) ) {
            return array( 'error' => 'Event Tickets must be active.' );
        }
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'error' => 'WooCommerce must be active to sync tickets.' );
        }
        $event_id = isset( $payload['event_id'] ) ? (int) $payload['event_id'] : 0;
        if ( ! $event_id || ! get_post( $event_id ) ) {
            return array( 'error' => 'Invalid event_id provided.' );
        }
        $tickets = isset( $payload['tickets'] ) && is_array( $payload['tickets'] ) ? $payload['tickets'] : array();
        $results = array();
        foreach ( $tickets as $ticket ) {
            $ticket_id  = isset( $ticket['ticket_id'] ) ? (int) $ticket['ticket_id'] : 0;
            $product_id = isset( $ticket['product_id'] ) ? (int) $ticket['product_id'] : 0;
            $reg_price  = isset( $ticket['regular_price'] ) ? floatval( $ticket['regular_price'] ) : null;
            $sale_price = isset( $ticket['sale_price'] ) ? floatval( $ticket['sale_price'] ) : null;
            $manage_stock = isset( $ticket['stock_management'] ) ? (bool) $ticket['stock_management'] : false;
            $ticket_post = get_post( $ticket_id );
            if ( ! $ticket_post ) {
                $results[] = array( 'error' => "Ticket ID {$ticket_id} not found." );
                continue;
            }
            // Determine or create product
            $product = null;
            if ( $product_id ) {
                $product = wc_get_product( $product_id );
            }
            if ( ! $product ) {
                // Create a new simple product
                $product = new WC_Product_Simple();
                $product->set_name( $ticket_post->post_title );
            }
            // Set pricing
            if ( null !== $reg_price ) {
                $product->set_regular_price( $reg_price );
                $product->set_price( $reg_price );
            }
            if ( null !== $sale_price && $sale_price < $reg_price ) {
                $product->set_sale_price( $sale_price );
            }
            // Manage stock
            $capacity = get_post_meta( $ticket_id, '_tribe_ticket_capacity', true );
            if ( $manage_stock && $capacity ) {
                $product->set_manage_stock( true );
                $product->set_stock_quantity( (int) $capacity );
                $product->set_stock_status( 'instock' );
            } else {
                $product->set_manage_stock( false );
            }
            // Hide ticket products from catalogue
            $product->set_catalog_visibility( 'hidden' );
            // Link product to ticket
            $product->save();
            $new_product_id = $product->get_id();
            // Store product ID on ticket meta
            update_post_meta( $ticket_id, '_tribe_wooticket_product', $new_product_id );
            // Also store event association on product meta
            update_post_meta( $new_product_id, '_tribe_wooticket_for_event', $event_id );
            $results[] = array( 'ticket_id' => $ticket_id, 'product_id' => $new_product_id );
        }
        return $results;
    }
}
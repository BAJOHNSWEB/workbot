<?php
/**
 * Configure booking rules, cancellation policies and capacity limits for an event.
 *
 * Stores booking window (open/close), cancellation policies and capacity rules
 * as event meta in a single array. These rules will be enforced by the
 * Arthur_AI_Bookings_Customiser when users attempt to book tickets or
 * cancel their bookings. Requires The Events Calendar and Event Tickets.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Configure_Event_Booking_Rules implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_event_booking_rules';
    }

    public function get_label() {
        return __( 'Configure event booking rules', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! class_exists( 'Tribe__Events__Main' ) || ! class_exists( 'Tribe__Tickets__Tickets' ) ) {
            return array( 'error' => 'Event Tickets and The Events Calendar must be active to configure booking rules.' );
        }
        $event_id = isset( $payload['event_id'] ) ? (int) $payload['event_id'] : 0;
        if ( ! $event_id || ! get_post( $event_id ) ) {
            return array( 'error' => 'Invalid event_id provided.' );
        }
        $rules = array();
        if ( isset( $payload['booking_window'] ) && is_array( $payload['booking_window'] ) ) {
            $open  = isset( $payload['booking_window']['open_datetime'] ) ? sanitize_text_field( $payload['booking_window']['open_datetime'] ) : '';
            $close = isset( $payload['booking_window']['close_datetime'] ) ? sanitize_text_field( $payload['booking_window']['close_datetime'] ) : '';
            $rules['booking_window'] = array(
                'open'  => $open ? date( 'Y-m-d H:i:s', strtotime( $open ) ) : '',
                'close' => $close ? date( 'Y-m-d H:i:s', strtotime( $close ) ) : '',
            );
        }
        if ( isset( $payload['cancellation_policy'] ) && is_array( $payload['cancellation_policy'] ) ) {
            $allowed_until = isset( $payload['cancellation_policy']['allowed_until'] ) ? sanitize_text_field( $payload['cancellation_policy']['allowed_until'] ) : '';
            $message       = isset( $payload['cancellation_policy']['message'] ) ? wp_kses_post( $payload['cancellation_policy']['message'] ) : '';
            $rules['cancellation_policy'] = array(
                'allowed_until' => $allowed_until ? date( 'Y-m-d H:i:s', strtotime( $allowed_until ) ) : '',
                'message'       => $message,
            );
        }
        if ( isset( $payload['capacity_rules'] ) && is_array( $payload['capacity_rules'] ) ) {
            $rules['capacity_rules'] = $payload['capacity_rules'];
        }
        // Store in event meta
        update_post_meta( $event_id, 'arthur_ai_booking_rules', $rules );
        return array( 'event_id' => $event_id, 'booking_rules' => $rules );
    }
}
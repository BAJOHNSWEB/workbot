<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to toggle whether the admin menu is collapsed by default.
 *
 * Payload field:
 * - `collapsed`: boolean value (true to collapse, false to expand). When
 *   set to true, the admin menu will be collapsed on each page load by
 *   adding the `folded` class to the body. The state is stored in the
 *   option `arthur_ai_admin_collapse_menu`.
 */
class Arthur_AI_Action_Collapse_Admin_Menu implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'collapse_admin_menu';
    }
    public function get_label() {
        return __( 'Collapse Admin Menu', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! array_key_exists( 'collapsed', $payload ) ) {
            return array(
                'success' => false,
                'message' => 'collapsed field is required.',
            );
        }
        $collapsed = $payload['collapsed'];
        // Interpret truthy values
        $bool_value = false;
        if ( is_bool( $collapsed ) ) {
            $bool_value = $collapsed;
        } elseif ( is_string( $collapsed ) ) {
            $collapsed_lower = strtolower( $collapsed );
            $bool_value = in_array( $collapsed_lower, array( '1', 'true', 'yes', 'on' ), true );
        } elseif ( is_numeric( $collapsed ) ) {
            $bool_value = intval( $collapsed ) !== 0;
        }
        update_option( 'arthur_ai_admin_collapse_menu', $bool_value );
        return array(
            'success' => true,
            'message' => $bool_value ? 'Admin menu will be collapsed.' : 'Admin menu will be expanded.',
            'data'    => array( 'collapsed' => $bool_value ),
        );
    }
}
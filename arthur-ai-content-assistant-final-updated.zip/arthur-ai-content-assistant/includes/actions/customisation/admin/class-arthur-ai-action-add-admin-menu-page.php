<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to add a new top-level admin menu page.
 *
 * The payload must include at minimum `menu_slug`, `menu_title`,
 * `page_title` and `content`. Optional fields are `capability` (defaults
 * to manage_options), `icon` (dashicon slug or URL) and `position` (an
 * integer for ordering). Multiple pages can be added; each call will
 * append or replace by slug. Pages are stored in the option
 * `arthur_ai_admin_custom_pages` as an array of definitions.
 */
class Arthur_AI_Action_Add_Admin_Menu_Page implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'add_admin_menu_page';
    }
    public function get_label() {
        return __( 'Add Admin Menu Page', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $slug       = isset( $payload['menu_slug'] ) ? sanitize_text_field( (string) $payload['menu_slug'] ) : '';
        $menu_title = isset( $payload['menu_title'] ) ? trim( (string) $payload['menu_title'] ) : '';
        $page_title = isset( $payload['page_title'] ) ? trim( (string) $payload['page_title'] ) : '';
        $content    = isset( $payload['content'] ) ? (string) $payload['content'] : '';
        if ( '' === $slug || '' === $menu_title || '' === $page_title || '' === $content ) {
            return array(
                'success' => false,
                'message' => 'menu_slug, menu_title, page_title and content are required.',
            );
        }
        $capability = isset( $payload['capability'] ) && '' !== $payload['capability'] ? sanitize_text_field( (string) $payload['capability'] ) : 'manage_options';
        $icon       = isset( $payload['icon'] ) && '' !== $payload['icon'] ? sanitize_text_field( (string) $payload['icon'] ) : '';
        $position   = isset( $payload['position'] ) && is_numeric( $payload['position'] ) ? intval( $payload['position'] ) : null;
        // Sanitise content to allow safe HTML
        $safe_content = wp_kses_post( $content );
        $pages = get_option( 'arthur_ai_admin_custom_pages', array() );
        if ( ! is_array( $pages ) ) {
            $pages = array();
        }
        // Replace existing entry with same slug or append
        $new_page = array(
            'menu_slug'  => $slug,
            'menu_title' => $menu_title,
            'page_title' => $page_title,
            'capability' => $capability,
            'icon'       => $icon,
            'position'   => $position,
            'content'    => $safe_content,
        );
        $found = false;
        foreach ( $pages as $idx => $page ) {
            if ( isset( $page['menu_slug'] ) && $page['menu_slug'] === $slug ) {
                $pages[ $idx ] = $new_page;
                $found         = true;
                break;
            }
        }
        if ( ! $found ) {
            $pages[] = $new_page;
        }
        update_option( 'arthur_ai_admin_custom_pages', $pages );
        return array(
            'success' => true,
            'message' => 'Admin menu page added.',
            'data'    => $new_page,
        );
    }
}
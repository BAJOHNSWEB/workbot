<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to rename a top-level admin menu item.
 *
 * The payload must include `menu_slug` (the slug/identifier of the menu)
 * and `new_title` (the desired label). Multiple calls can rename
 * multiple menus; each invocation updates the option
 * `arthur_ai_admin_renamed_menus` with slug => title mappings. Both
 * menu and page titles are updated when rendered.
 */
class Arthur_AI_Action_Rename_Admin_Menu_Item implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'rename_admin_menu_item';
    }

    public function get_label() {
        return __( 'Rename Admin Menu Item', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $slug = isset( $payload['menu_slug'] ) ? sanitize_text_field( (string) $payload['menu_slug'] ) : '';
        $title = isset( $payload['new_title'] ) ? trim( (string) $payload['new_title'] ) : '';

        if ( '' === $slug || '' === $title ) {
            return array(
                'success' => false,
                'message' => 'menu_slug and new_title are required.',
            );
        }

        // Load existing renames
        $renames = get_option( 'arthur_ai_admin_renamed_menus', array() );
        if ( ! is_array( $renames ) ) {
            $renames = array();
        }
        $renames[ $slug ] = sanitize_text_field( $title );
        update_option( 'arthur_ai_admin_renamed_menus', $renames );

        return array(
            'success' => true,
            'message' => 'Menu item renamed.',
            'data'    => array( 'menu_slug' => $slug, 'new_title' => $renames[ $slug ] ),
        );
    }
}
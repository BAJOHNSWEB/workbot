<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to add a new submenu page under an existing admin menu.
 *
 * Required fields: `parent_slug`, `menu_slug`, `menu_title`, `page_title` and
 * `content`. Optional `capability` (defaults to manage_options). This
 * definition is appended to the `arthur_ai_admin_custom_subpages` option
 * array. Existing entries with the same `menu_slug` will be replaced.
 */
class Arthur_AI_Action_Add_Admin_Submenu_Page implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'add_admin_submenu_page';
    }
    public function get_label() {
        return __( 'Add Admin Submenu Page', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $parent_slug = isset( $payload['parent_slug'] ) ? sanitize_text_field( (string) $payload['parent_slug'] ) : '';
        $submenu_slug = isset( $payload['menu_slug'] ) ? sanitize_text_field( (string) $payload['menu_slug'] ) : '';
        $menu_title  = isset( $payload['menu_title'] ) ? trim( (string) $payload['menu_title'] ) : '';
        $page_title  = isset( $payload['page_title'] ) ? trim( (string) $payload['page_title'] ) : '';
        $content     = isset( $payload['content'] ) ? (string) $payload['content'] : '';
        if ( '' === $parent_slug || '' === $submenu_slug || '' === $menu_title || '' === $page_title || '' === $content ) {
            return array(
                'success' => false,
                'message' => 'parent_slug, menu_slug, menu_title, page_title and content are required.',
            );
        }
        $capability = isset( $payload['capability'] ) && '' !== $payload['capability'] ? sanitize_text_field( (string) $payload['capability'] ) : 'manage_options';
        $safe_content = wp_kses_post( $content );
        $subpages = get_option( 'arthur_ai_admin_custom_subpages', array() );
        if ( ! is_array( $subpages ) ) {
            $subpages = array();
        }
        $new_sub = array(
            'parent_slug' => $parent_slug,
            'menu_slug'   => $submenu_slug,
            'menu_title'  => $menu_title,
            'page_title'  => $page_title,
            'capability'  => $capability,
            'content'     => $safe_content,
        );
        $found = false;
        foreach ( $subpages as $idx => $sub ) {
            if ( isset( $sub['menu_slug'] ) && $sub['menu_slug'] === $submenu_slug ) {
                $subpages[ $idx ] = $new_sub;
                $found = true;
                break;
            }
        }
        if ( ! $found ) {
            $subpages[] = $new_sub;
        }
        update_option( 'arthur_ai_admin_custom_subpages', $subpages );
        return array(
            'success' => true,
            'message' => 'Admin submenu page added.',
            'data'    => $new_sub,
        );
    }
}
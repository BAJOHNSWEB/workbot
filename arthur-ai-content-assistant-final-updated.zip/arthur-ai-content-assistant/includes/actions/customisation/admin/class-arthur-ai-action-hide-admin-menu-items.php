<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to globally hide specific top-level admin menu items.
 *
 * The payload should contain either a `menu_slugs` array or a single
 * `menu_slug` string. Each slug corresponds to the fourth parameter
 * passed to add_menu_page() for built-in or custom menu pages (e.g.
 * 'woocommerce', 'edit.php', 'tools.php'). This action updates the
 * option `arthur_ai_admin_hidden_menus` with a list of slugs to
 * remove on every admin load.
 */
class Arthur_AI_Action_Hide_Admin_Menu_Items implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'hide_admin_menu_items';
    }

    public function get_label() {
        return __( 'Hide Admin Menu Items', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $slugs = array();
        if ( ! empty( $payload['menu_slugs'] ) && is_array( $payload['menu_slugs'] ) ) {
            $slugs = $payload['menu_slugs'];
        } elseif ( ! empty( $payload['menu_slug'] ) ) {
            $slugs = array( $payload['menu_slug'] );
        }

        if ( empty( $slugs ) ) {
            return array(
                'success' => false,
                'message' => 'No menu slugs provided.',
            );
        }

        // Sanitize each slug and build a unique list
        $existing = get_option( 'arthur_ai_admin_hidden_menus', array() );
        if ( ! is_array( $existing ) ) {
            $existing = array();
        }

        foreach ( $slugs as $slug ) {
            $san = sanitize_text_field( (string) $slug );
            if ( '' !== $san ) {
                $existing[] = $san;
            }
        }
        // Remove duplicates
        $existing = array_values( array_unique( $existing ) );
        update_option( 'arthur_ai_admin_hidden_menus', $existing );

        return array(
            'success'   => true,
            'message'   => 'Menu items hidden.',
            'data'      => array( 'menu_slugs' => $existing ),
        );
    }
}
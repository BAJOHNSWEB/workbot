<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to customise the WordPress admin toolbar colours.
 *
 * This mirrors the structure of the login customisation actions. It accepts
 * optional colour values for the admin toolbar background, text and hover
 * states. Values are stored as an associative array in the option
 * `arthur_ai_admin_toolbar_colors` and are later applied by the
 * Arthur_AI_Admin_Customiser class.
 */
class Arthur_AI_Action_Change_Admin_Toolbar_Colors implements Arthur_AI_Action_Interface {

    /**
     * The unique action type used by the AI model.
     *
     * @return string
     */
    public function get_type() {
        return 'change_admin_toolbar_colors';
    }

    /**
     * Human‑readable label for this action.
     *
     * @return string
     */
    public function get_label() {
        return __( 'Change Admin Toolbar Colours', 'arthur-ai' );
    }

    /**
     * Update the stored toolbar colour settings. Accepts four optional keys:
     * `toolbar_background`, `toolbar_text`, `toolbar_hover_background` and
     * `toolbar_hover_text`. Any provided value will override the existing
     * setting; omitted values will leave previous settings intact.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $background       = $payload['toolbar_background']       ?? '';
        $text             = $payload['toolbar_text']             ?? '';
        $hover_background = $payload['toolbar_hover_background'] ?? '';
        $hover_text       = $payload['toolbar_hover_text']       ?? '';

        if ( '' === $background && '' === $text && '' === $hover_background && '' === $hover_text ) {
            return array(
                'success' => false,
                'message' => 'No toolbar colour fields provided.',
            );
        }

        // Start from existing settings to allow partial updates.
        $settings = get_option( 'arthur_ai_admin_toolbar_colors', array() );
        if ( ! is_array( $settings ) ) {
            $settings = array();
        }

        if ( '' !== $background ) {
            $settings['toolbar_background'] = sanitize_text_field( $background );
        }
        if ( '' !== $text ) {
            $settings['toolbar_text'] = sanitize_text_field( $text );
        }
        if ( '' !== $hover_background ) {
            $settings['toolbar_hover_background'] = sanitize_text_field( $hover_background );
        }
        if ( '' !== $hover_text ) {
            $settings['toolbar_hover_text'] = sanitize_text_field( $hover_text );
        }

        update_option( 'arthur_ai_admin_toolbar_colors', $settings );

        return array(
            'success' => true,
            'message' => 'Admin toolbar colour settings saved.',
            'data'    => $settings,
        );
    }
}
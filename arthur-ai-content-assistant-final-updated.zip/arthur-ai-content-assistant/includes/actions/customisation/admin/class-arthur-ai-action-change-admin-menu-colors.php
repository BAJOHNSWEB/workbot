<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to customise the WordPress admin side menu colours.
 *
 * This accepts optional colour values for the admin menu background,
 * text colour and hover states. It stores values in the option
 * `arthur_ai_admin_menu_colors`, similar to how login customisation
 * actions work. The Arthur_AI_Admin_Customiser class will later
 * apply these colours via CSS on admin pages.
 */
class Arthur_AI_Action_Change_Admin_Menu_Colors implements Arthur_AI_Action_Interface {

    /**
     * The unique action type used by the AI model.
     *
     * @return string
     */
    public function get_type() {
        return 'change_admin_menu_colors';
    }

    /**
     * Human‑readable label for this action.
     *
     * @return string
     */
    public function get_label() {
        return __( 'Change Admin Menu Colours', 'arthur-ai' );
    }

    /**
     * Update the stored admin menu colour settings. Accepts four optional
     * fields: `menu_background`, `menu_text`, `menu_hover_background`
     * and `menu_hover_text`. Missing values leave existing settings untouched.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $background       = $payload['menu_background']       ?? '';
        $text             = $payload['menu_text']             ?? '';
        $hover_background = $payload['menu_hover_background'] ?? '';
        $hover_text       = $payload['menu_hover_text']       ?? '';

        if ( '' === $background && '' === $text && '' === $hover_background && '' === $hover_text ) {
            return array(
                'success' => false,
                'message' => 'No menu colour fields provided.',
            );
        }

        // Merge with existing settings for partial updates.
        $settings = get_option( 'arthur_ai_admin_menu_colors', array() );
        if ( ! is_array( $settings ) ) {
            $settings = array();
        }

        if ( '' !== $background ) {
            $settings['menu_background'] = sanitize_text_field( $background );
        }
        if ( '' !== $text ) {
            $settings['menu_text'] = sanitize_text_field( $text );
        }
        if ( '' !== $hover_background ) {
            $settings['menu_hover_background'] = sanitize_text_field( $hover_background );
        }
        if ( '' !== $hover_text ) {
            $settings['menu_hover_text'] = sanitize_text_field( $hover_text );
        }

        update_option( 'arthur_ai_admin_menu_colors', $settings );

        return array(
            'success' => true,
            'message' => 'Admin menu colour settings saved.',
            'data'    => $settings,
        );
    }
}
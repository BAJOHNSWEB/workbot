<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to reposition the Settings menu in the admin sidebar.
 *
 * Payload fields:
 * - `position`: integer representing the 1‑based position in the top-level
 *   menu list. For example, 1 moves Settings to the top. Positions less
 *   than 1 are treated as 1. Missing or invalid values return an error.
 *
 * The chosen position is stored in the option
 * `arthur_ai_admin_settings_position`. This position overrides any
 * ordering defined by reorder_admin_menu_items. When the menu order is
 * rebuilt, Settings will be inserted at this index.
 */
class Arthur_AI_Action_Move_Admin_Settings implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'move_admin_settings';
    }
    public function get_label() {
        return __( 'Move Admin Settings', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        if ( ! isset( $payload['position'] ) || ! is_numeric( $payload['position'] ) ) {
            return array(
                'success' => false,
                'message' => 'position must be a numeric value.',
            );
        }
        $pos = intval( $payload['position'] );
        if ( $pos < 1 ) {
            $pos = 1;
        }
        update_option( 'arthur_ai_admin_settings_position', $pos );
        return array(
            'success' => true,
            'message' => 'Settings menu position updated.',
            'data'    => array( 'position' => $pos ),
        );
    }
}
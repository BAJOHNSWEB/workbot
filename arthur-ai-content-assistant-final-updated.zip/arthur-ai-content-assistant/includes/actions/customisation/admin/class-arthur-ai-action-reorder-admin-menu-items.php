<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to define a new order for top-level admin menu items.
 *
 * The payload should contain an `order` array of menu slugs in the
 * desired order. Any slugs not specified will retain their existing
 * relative order after those in the list. The ordering will be
 * applied on every admin load. To reposition the Settings menu
 * independently, see the move_admin_settings action.
 */
class Arthur_AI_Action_Reorder_Admin_Menu_Items implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'reorder_admin_menu_items';
    }
    public function get_label() {
        return __( 'Reorder Admin Menu Items', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $order = isset( $payload['order'] ) && is_array( $payload['order'] ) ? $payload['order'] : array();
        if ( empty( $order ) ) {
            return array(
                'success' => false,
                'message' => 'No order array provided.',
            );
        }
        $sanitised = array();
        foreach ( $order as $slug ) {
            $san = sanitize_text_field( (string) $slug );
            if ( '' !== $san ) {
                $sanitised[] = $san;
            }
        }
        if ( empty( $sanitised ) ) {
            return array(
                'success' => false,
                'message' => 'No valid menu slugs provided in order array.',
            );
        }
        update_option( 'arthur_ai_admin_menu_order', $sanitised );
        return array(
            'success' => true,
            'message' => 'Admin menu order saved.',
            'data'    => array( 'order' => $sanitised ),
        );
    }
}
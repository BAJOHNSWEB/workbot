<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to hide specific admin menu items for certain user roles.
 *
 * Payload fields:
 * - `roles`: array of role slugs (e.g. ['editor','author']).
 * - `menu_slugs`: array of menu slugs to hide for those roles.
 * Missing or empty values will return an error. The mapping is stored in
 * the option `arthur_ai_admin_hidden_menus_by_role` as a role => slugs array.
 */
class Arthur_AI_Action_Hide_Admin_Menu_Items_By_Role implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'hide_admin_menu_items_by_role';
    }
    public function get_label() {
        return __( 'Hide Admin Menu Items by Role', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $roles = isset( $payload['roles'] ) && is_array( $payload['roles'] ) ? $payload['roles'] : array();
        $slugs = isset( $payload['menu_slugs'] ) && is_array( $payload['menu_slugs'] ) ? $payload['menu_slugs'] : array();
        if ( empty( $roles ) || empty( $slugs ) ) {
            return array(
                'success' => false,
                'message' => 'roles and menu_slugs arrays are required.',
            );
        }
        $mapping = get_option( 'arthur_ai_admin_hidden_menus_by_role', array() );
        if ( ! is_array( $mapping ) ) {
            $mapping = array();
        }
        foreach ( $roles as $role ) {
            $role_key = sanitize_text_field( (string) $role );
            if ( '' === $role_key ) {
                continue;
            }
            if ( ! isset( $mapping[ $role_key ] ) || ! is_array( $mapping[ $role_key ] ) ) {
                $mapping[ $role_key ] = array();
            }
            foreach ( $slugs as $slug ) {
                $san_slug = sanitize_text_field( (string) $slug );
                if ( '' !== $san_slug ) {
                    $mapping[ $role_key ][] = $san_slug;
                }
            }
            // Ensure uniqueness for each role
            $mapping[ $role_key ] = array_values( array_unique( $mapping[ $role_key ] ) );
        }
        update_option( 'arthur_ai_admin_hidden_menus_by_role', $mapping );
        return array(
            'success' => true,
            'message' => 'Role-based menu visibility updated.',
            'data'    => $mapping,
        );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to set custom CSS for WordPress admin pages.
 *
 * Similar to the login custom CSS action, this allows administrators to
 * provide bespoke CSS that will be output on every admin page. The CSS
 * should be trusted input and therefore escaped on output only. The
 * custom CSS is stored in the option `arthur_ai_admin_custom_css`.
 */
class Arthur_AI_Action_Set_Admin_Custom_CSS implements Arthur_AI_Action_Interface {

    /**
     * Return the action type identifier.
     *
     * @return string
     */
    public function get_type() {
        return 'set_admin_custom_css';
    }

    /**
     * Return a human‑friendly label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'Set Admin Custom CSS', 'arthur-ai' );
    }

    /**
     * Store the provided CSS string. Expects a `css` key in the payload. Empty
     * strings are rejected. The CSS is stored as‑is; it should only be
     * rendered in a trusted context (admin area) and not escaped here.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $css = isset( $payload['css'] ) ? (string) $payload['css'] : '';
        $css = trim( $css );
        if ( '' === $css ) {
            return array(
                'success' => false,
                'message' => 'No admin custom CSS provided.',
            );
        }

        // Do not escape here – this is trusted admin input and will be
        // escaped at output time.
        update_option( 'arthur_ai_admin_custom_css', $css );

        return array(
            'success' => true,
            'message' => 'Admin custom CSS saved.',
            'data'    => array(
                'css' => $css,
            ),
        );
    }
}
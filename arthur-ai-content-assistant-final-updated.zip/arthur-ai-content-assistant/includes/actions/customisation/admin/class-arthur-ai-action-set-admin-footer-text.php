<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Action to set the admin footer text displayed on WordPress admin pages.
 *
 * WordPress typically displays “Thank you for creating with WordPress.” in the
 * bottom left of admin screens. This action allows that message to be
 * customised. It stores the text in the option `arthur_ai_admin_footer_text`.
 */
class Arthur_AI_Action_Set_Admin_Footer_Text implements Arthur_AI_Action_Interface {

    /**
     * Return the unique action type.
     *
     * @return string
     */
    public function get_type() {
        return 'set_admin_footer_text';
    }

    /**
     * Return a descriptive label.
     *
     * @return string
     */
    public function get_label() {
        return __( 'Set Admin Footer Text', 'arthur-ai' );
    }

    /**
     * Execute the action. Expects a `footer_text` field in the payload.
     * The string is trimmed and filtered via wp_kses_post to allow basic
     * HTML formatting. Empty or missing values result in an error.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $footer = isset( $payload['footer_text'] ) ? trim( (string) $payload['footer_text'] ) : '';
        if ( '' === $footer ) {
            return array(
                'success' => false,
                'message' => 'No admin footer text provided.',
            );
        }

        $sanitised_footer = wp_kses_post( $footer );

        update_option( 'arthur_ai_admin_footer_text', $sanitised_footer );

        return array(
            'success' => true,
            'message' => 'Admin footer text saved.',
            'data'    => array(
                'footer_text' => $sanitised_footer,
            ),
        );
    }
}
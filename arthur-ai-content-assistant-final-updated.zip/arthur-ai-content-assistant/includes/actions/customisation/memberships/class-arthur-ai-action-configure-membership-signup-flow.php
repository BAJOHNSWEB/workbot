<?php
/**
 * Configure membership signup and onboarding flows.
 *
 * This action stores settings describing which pages should be used for
 * membership signup and subsequent onboarding steps. The provider must be
 * specified and active. The Arthur_AI_Memberships_Customiser will read these
 * settings to redirect new members through the specified onboarding sequence.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Configure_Membership_Signup_Flow implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'configure_membership_signup_flow';
    }
    public function get_label() {
        return __( 'Configure membership signup flow', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        if ( empty( $provider ) ) {
            return array( 'error' => 'provider is required' );
        }
        // Validate provider presence
        $active = false;
        if ( 'woo_memberships' === $provider && class_exists( 'WC_Memberships' ) ) {
            $active = true;
        } elseif ( 'pmpro' === $provider && function_exists( 'pmpro_getAllLevels' ) ) {
            $active = true;
        } elseif ( 'memberpress' === $provider && class_exists( 'MeprProduct' ) ) {
            $active = true;
        }
        if ( ! $active ) {
            return array( 'error' => 'Provider ' . $provider . ' is not active.' );
        }
        $level_id = isset( $payload['level_id'] ) ? sanitize_text_field( $payload['level_id'] ) : '';
        $signup_page_id = isset( $payload['signup_page_id'] ) ? intval( $payload['signup_page_id'] ) : 0;
        $onboarding_pages = isset( $payload['onboarding_pages'] ) && is_array( $payload['onboarding_pages'] ) ? $payload['onboarding_pages'] : array();
        $post_signup_redirect = isset( $payload['post_signup_redirect'] ) ? $payload['post_signup_redirect'] : '';
        // Save configuration
        $configs = get_option( 'arthur_ai_membership_onboarding', array() );
        if ( ! isset( $configs[ $provider ] ) ) {
            $configs[ $provider ] = array();
        }
        $configs[ $provider ][ $level_id ] = array(
            'signup_page_id'     => $signup_page_id,
            'onboarding_pages'   => $onboarding_pages,
            'post_signup_redirect' => $post_signup_redirect,
        );
        update_option( 'arthur_ai_membership_onboarding', $configs );
        return array(
            'provider' => $provider,
            'level_id' => $level_id,
            'signup_page_id' => $signup_page_id,
            'onboarding_pages' => $onboarding_pages,
            'post_signup_redirect' => $post_signup_redirect,
        );
    }
}
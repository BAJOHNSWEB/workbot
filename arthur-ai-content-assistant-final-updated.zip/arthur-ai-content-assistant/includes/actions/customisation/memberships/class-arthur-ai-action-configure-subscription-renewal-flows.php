<?php
/**
 * Configure renewal messaging and failed payment flows for subscriptions.
 *
 * This action stores email template overrides and retry policies for
 * WooCommerce Subscriptions. The actual application of these settings is
 * handled by the Arthur_AI_Subscriptions_Customiser which hooks into
 * Woo subscriptions events and email filters. The provider must be
 * `woo_subscriptions` and the plugin must be active.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Configure_Subscription_Renewal_Flows implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'configure_subscription_renewal_flows';
    }
    public function get_label() {
        return __( 'Configure subscription renewal flows', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        if ( 'woo_subscriptions' !== $provider ) {
            return array( 'error' => 'Only Woo Subscriptions provider is supported.' );
        }
        if ( ! class_exists( 'WC_Subscriptions' ) ) {
            return array( 'error' => 'WooCommerce Subscriptions plugin is not active.' );
        }
        $renewal_emails = isset( $payload['renewal_emails'] ) && is_array( $payload['renewal_emails'] ) ? $payload['renewal_emails'] : array();
        $failed_payment_policy = isset( $payload['failed_payment_policy'] ) && is_array( $payload['failed_payment_policy'] ) ? $payload['failed_payment_policy'] : array();
        $config = get_option( 'arthur_ai_subscription_flows', array() );
        $config['woo_subscriptions'] = array(
            'renewal_emails'       => $renewal_emails,
            'failed_payment_policy' => $failed_payment_policy,
        );
        update_option( 'arthur_ai_subscription_flows', $config );
        return array(
            'provider'              => $provider,
            'renewal_emails'        => $renewal_emails,
            'failed_payment_policy' => $failed_payment_policy,
        );
    }
}
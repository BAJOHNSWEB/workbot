<?php
/**
 * Configure member-specific content recommendations.
 *
 * This action lets the AI define rules for recommending courses and content to
 * members based on their membership level, enrolments, and progress. Rules
 * are stored in an option and are processed at runtime by the Member
 * Dashboard or LMS customiser to display personalised recommendations.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Configure_Member_Recommendations implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'configure_member_recommendations';
    }
    public function get_label() {
        return __( 'Configure member recommendations', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $rules = isset( $payload['rules'] ) && is_array( $payload['rules'] ) ? $payload['rules'] : array();
        // Validate each rule to ensure required fields exist
        $validated = array();
        foreach ( $rules as $rule ) {
            $segment = isset( $rule['segment'] ) && is_array( $rule['segment'] ) ? $rule['segment'] : array();
            $recs    = isset( $rule['recommendations'] ) && is_array( $rule['recommendations'] ) ? $rule['recommendations'] : array();
            $validated[] = array(
                'segment'        => $segment,
                'recommendations' => $recs,
            );
        }
        update_option( 'arthur_ai_member_recommendations', $validated );
        return array( 'rules' => $validated );
    }
}
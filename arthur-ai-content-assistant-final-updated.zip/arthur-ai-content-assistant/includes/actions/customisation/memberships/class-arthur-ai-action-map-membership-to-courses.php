<?php
/**
 * Map membership levels to LMS courses or bundles.
 *
 * This action configures which courses are included with each membership
 * level. When a user purchases or activates a membership, the
 * Arthur_AI_Memberships_Customiser will enrol them in the mapped courses, and
 * optionally unenrol when the membership expires. The provider (membership
 * plugin) and LMS provider must be specified.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Map_Membership_To_Courses implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'map_membership_to_courses';
    }
    public function get_label() {
        return __( 'Map membership to courses', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $provider     = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        $lms_provider = isset( $payload['lms_provider'] ) ? sanitize_key( $payload['lms_provider'] ) : '';
        if ( empty( $provider ) || empty( $lms_provider ) ) {
            return array( 'error' => 'provider and lms_provider are required' );
        }
        $mappings = isset( $payload['mappings'] ) && is_array( $payload['mappings'] ) ? $payload['mappings'] : array();
        // Validate and normalise mappings
        $normalised = array();
        foreach ( $mappings as $map ) {
            $level_id  = isset( $map['membership_level_id'] ) ? sanitize_text_field( $map['membership_level_id'] ) : '';
            $courses   = isset( $map['course_ids'] ) && is_array( $map['course_ids'] ) ? array_map( 'intval', $map['course_ids'] ) : array();
            if ( $level_id && ! empty( $courses ) ) {
                $normalised[] = array(
                    'membership_level_id' => $level_id,
                    'course_ids'         => $courses,
                );
            }
        }
        $existing = get_option( 'arthur_ai_membership_lms_map', array() );
        if ( ! isset( $existing[ $provider ] ) ) {
            $existing[ $provider ] = array();
        }
        $existing[ $provider ][ $lms_provider ] = $normalised;
        update_option( 'arthur_ai_membership_lms_map', $existing );
        return array(
            'provider'     => $provider,
            'lms_provider' => $lms_provider,
            'mappings'     => $normalised,
        );
    }
}
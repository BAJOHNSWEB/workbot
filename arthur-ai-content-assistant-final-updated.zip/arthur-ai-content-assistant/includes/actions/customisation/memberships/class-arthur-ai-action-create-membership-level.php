<?php
/**
 * Create a membership level using a supported membership provider.
 *
 * This action accepts a provider (woo_memberships, pmpro or memberpress) and
 * details for the membership level such as name, slug, description, pricing
 * and access length. Where possible it will attempt to create a real
 * membership plan via the provider’s API. For unsupported providers or if
 * the plugin is not active, it will return an error. Created plans are
 * recorded in an option for later reference.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Create_Membership_Level implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'create_membership_level';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Create membership level', 'arthur-ai' );
    }

    /**
     * {@inheritDoc}
     */
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        if ( empty( $provider ) ) {
            return array( 'error' => 'provider is required' );
        }

        $name        = isset( $payload['name'] ) ? sanitize_text_field( $payload['name'] ) : '';
        if ( empty( $name ) ) {
            return array( 'error' => 'name is required' );
        }

        $slug        = isset( $payload['slug'] ) && $payload['slug'] ? sanitize_title( $payload['slug'] ) : sanitize_title( $name );
        $description = isset( $payload['description'] ) ? wp_kses_post( $payload['description'] ) : '';
        $price       = isset( $payload['price'] ) ? floatval( $payload['price'] ) : 0.0;
        $billing_cycle = isset( $payload['billing_cycle'] ) && is_array( $payload['billing_cycle'] ) ? $payload['billing_cycle'] : array();
        $interval    = isset( $billing_cycle['interval'] ) ? max( 1, intval( $billing_cycle['interval'] ) ) : 1;
        $period      = isset( $billing_cycle['period'] ) ? sanitize_key( $billing_cycle['period'] ) : 'month';
        $expiration  = null;
        if ( isset( $payload['access_length'] ) ) {
            $expiration = sanitize_text_field( $payload['access_length'] );
        } elseif ( isset( $payload['expiration'] ) ) {
            $expiration = sanitize_text_field( $payload['expiration'] );
        }
        $benefits    = isset( $payload['benefits'] ) && is_array( $payload['benefits'] ) ? $payload['benefits'] : array();

        // WooCommerce Memberships provider
        if ( 'woo_memberships' === $provider ) {
            if ( ! class_exists( 'WC_Memberships' ) ) {
                return array( 'error' => 'WooCommerce Memberships plugin is not active.' );
            }
            // Create a membership plan using the plan custom post type. If a plan
            // with the same slug exists, create a new one anyway to avoid name
            // collisions.
            $plan_post = array(
                'post_type'    => 'wc_memberships_membership_plan',
                'post_title'   => $name,
                'post_name'    => $slug,
                'post_status'  => 'publish',
                'post_content' => $description,
            );
            $plan_id = wp_insert_post( $plan_post );
            if ( is_wp_error( $plan_id ) || ! $plan_id ) {
                return array( 'error' => 'Failed to create membership plan.' );
            }
            // Store basic settings as meta on the plan. Woo Memberships doesn’t
            // document plan meta publicly; these keys are arbitrary to help
            // preserve data. Woo will ignore unknown meta keys.
            update_post_meta( $plan_id, '_arthur_ai_membership_price', $price );
            update_post_meta( $plan_id, '_arthur_ai_membership_billing_interval', $interval );
            update_post_meta( $plan_id, '_arthur_ai_membership_billing_period', $period );
            if ( $expiration ) {
                update_post_meta( $plan_id, '_arthur_ai_membership_expiration', $expiration );
            }
            update_post_meta( $plan_id, '_arthur_ai_membership_benefits', $benefits );

            // Record in plugin option for later reference
            $levels = get_option( 'arthur_ai_membership_levels', array() );
            $levels[] = array(
                'provider'    => $provider,
                'id'          => $plan_id,
                'name'        => $name,
                'slug'        => $slug,
                'description' => $description,
                'price'       => $price,
                'interval'    => $interval,
                'period'      => $period,
                'expiration'  => $expiration,
                'benefits'    => $benefits,
            );
            update_option( 'arthur_ai_membership_levels', $levels );

            return array(
                'provider' => $provider,
                'level_id' => $plan_id,
                'name'     => $name,
                'slug'     => $slug,
            );
        }

        // Paid Memberships Pro
        if ( 'pmpro' === $provider ) {
            if ( ! function_exists( 'pmpro_getAllLevels' ) ) {
                return array( 'error' => 'Paid Memberships Pro plugin is not active.' );
            }
            // PMPro does not provide a straightforward public API for creating
            // levels programmatically. Instead of attempting to manipulate
            // internal tables directly, record the level data in an option. An
            // administrator can later create the level via the PMPro UI.
            $levels = get_option( 'arthur_ai_membership_levels', array() );
            $level_id = time();
            $levels[] = array(
                'provider'    => $provider,
                'id'          => $level_id,
                'name'        => $name,
                'slug'        => $slug,
                'description' => $description,
                'price'       => $price,
                'interval'    => $interval,
                'period'      => $period,
                'expiration'  => $expiration,
                'benefits'    => $benefits,
            );
            update_option( 'arthur_ai_membership_levels', $levels );
            return array(
                'provider' => $provider,
                'level_id' => $level_id,
                'name'     => $name,
                'slug'     => $slug,
                'note'     => 'Level stored for PMPro; please configure via the PMPro admin.',
            );
        }

        // MemberPress
        if ( 'memberpress' === $provider ) {
            if ( ! class_exists( 'MeprProduct' ) ) {
                return array( 'error' => 'MemberPress plugin is not active.' );
            }
            // Create a simple membership product in MemberPress. The API uses
            // MeprProduct objects.
            try {
                $product = new MeprProduct();
                $product->post_title   = $name;
                $product->post_content = $description;
                $product->post_name    = $slug;
                $product->product_price = $price;
                // Set recurring payment fields if interval/period not default
                $product->period = $period;
                $product->period_type = $period;
                $product->price = $price;
                $product->trial = 0;
                $product->trial_days = 0;
                $product_id = $product->store();
                // Save benefits as post meta for reference
                update_post_meta( $product_id, '_arthur_ai_membership_benefits', $benefits );
                // Record in option
                $levels = get_option( 'arthur_ai_membership_levels', array() );
                $levels[] = array(
                    'provider'    => $provider,
                    'id'          => $product_id,
                    'name'        => $name,
                    'slug'        => $slug,
                    'description' => $description,
                    'price'       => $price,
                    'interval'    => $interval,
                    'period'      => $period,
                    'expiration'  => $expiration,
                    'benefits'    => $benefits,
                );
                update_option( 'arthur_ai_membership_levels', $levels );
                return array(
                    'provider' => $provider,
                    'level_id' => $product_id,
                    'name'     => $name,
                    'slug'     => $slug,
                );
            } catch ( Exception $e ) {
                return array( 'error' => 'Failed to create MemberPress membership: ' . $e->getMessage() );
            }
        }

        return array( 'error' => 'Provider ' . $provider . ' is not supported.' );
    }
}
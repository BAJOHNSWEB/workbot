<?php
/**
 * Create or update a “My Membership” dashboard page.
 *
 * This action allows the AI to set up a WordPress page that will act as the
 * central hub for members, displaying membership levels, subscriptions,
 * enrolled courses, perks, and order history. It accepts a title, optional
 * slug and block/shortcode markup for the layout. The page ID is saved in an
 * option so that other parts of the plugin know where to render dashboard
 * content via the Arthur_AI_Member_Dashboard helper.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Create_My_Membership_Dashboard implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'create_my_membership_dashboard';
    }
    public function get_label() {
        return __( 'Create My Membership dashboard', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $title  = isset( $payload['page_title'] ) ? sanitize_text_field( $payload['page_title'] ) : '';
        if ( empty( $title ) ) {
            return array( 'error' => 'page_title is required' );
        }
        $slug   = isset( $payload['slug'] ) && $payload['slug'] ? sanitize_title( $payload['slug'] ) : sanitize_title( $title );
        $layout = isset( $payload['layout'] ) ? wp_kses_post( $payload['layout'] ) : '';
        // Find existing page by slug or title
        $page_id = 0;
        $existing = get_page_by_path( $slug, OBJECT, 'page' );
        if ( $existing ) {
            $page_id = $existing->ID;
        } else {
            $existing = get_page_by_title( $title, OBJECT, 'page' );
            if ( $existing ) {
                $page_id = $existing->ID;
            }
        }
        $post_arr = array(
            'post_title'   => $title,
            'post_name'    => $slug,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_content' => $layout,
        );
        if ( $page_id ) {
            $post_arr['ID'] = $page_id;
            $new_page_id = wp_update_post( $post_arr, true );
        } else {
            $new_page_id = wp_insert_post( $post_arr, true );
        }
        if ( is_wp_error( $new_page_id ) || ! $new_page_id ) {
            return array( 'error' => 'Failed to create or update dashboard page.' );
        }
        // Store the page ID for dashboard rendering
        update_option( 'arthur_ai_my_membership_page_id', $new_page_id );
        return array(
            'page_id' => $new_page_id,
            'title'   => $title,
            'slug'    => $slug,
            'url'     => get_permalink( $new_page_id ),
        );
    }
}
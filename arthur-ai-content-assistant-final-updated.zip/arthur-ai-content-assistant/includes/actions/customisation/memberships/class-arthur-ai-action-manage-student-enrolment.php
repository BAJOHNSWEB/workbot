<?php
/**
 * Manage student enrolment and progress for LMS courses.
 *
 * This action allows the AI to enrol or unenrol users from courses, reset
 * progress or mark completion. It supports multiple LMS providers and
 * gracefully handles situations where provider APIs are not available by
 * storing enrolment status in user meta. For LearnDash, LifterLMS and
 * TutorLMS, it calls provider-specific functions if present.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Manage_Student_Enrolment implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'manage_student_enrolment';
    }

    public function get_label() {
        return __( 'Manage student enrolment', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        $supported = array( 'learndash', 'lifterlms', 'tutorlms' );
        if ( ! in_array( $provider, $supported, true ) ) {
            return array( 'error' => 'Unsupported LMS provider ' . $provider . '.' );
        }
        // Determine if the provider plugin is active
        $active = false;
        if ( 'learndash' === $provider && defined( 'LEARNDASH_VERSION' ) ) {
            $active = true;
        } elseif ( 'lifterlms' === $provider && ( defined( 'LLMS_VERSION' ) || function_exists( 'llms' ) ) ) {
            $active = true;
        } elseif ( 'tutorlms' === $provider && ( function_exists( 'tutor_utils' ) || defined( 'TUTOR_VERSION' ) ) ) {
            $active = true;
        }
        if ( ! $active ) {
            return array( 'error' => 'LMS provider ' . $provider . ' is not active.' );
        }
        $operations = isset( $payload['operations'] ) && is_array( $payload['operations'] ) ? $payload['operations'] : array();
        if ( empty( $operations ) ) {
            return array( 'error' => 'operations array is required' );
        }
        $results = array();
        foreach ( $operations as $op ) {
            $action = isset( $op['action'] ) ? sanitize_key( $op['action'] ) : '';
            $user_id = isset( $op['user_id'] ) ? intval( $op['user_id'] ) : 0;
            $course_id = isset( $op['course_id'] ) ? intval( $op['course_id'] ) : 0;
            if ( $user_id <= 0 || $course_id <= 0 ) {
                $results[] = array( 'error' => 'user_id and course_id are required', 'action' => $action );
                continue;
            }
            $outcome = array( 'user_id' => $user_id, 'course_id' => $course_id, 'action' => $action );
            switch ( $action ) {
                case 'enrol':
                    $outcome['result'] = $this->enrol_user( $provider, $user_id, $course_id );
                    break;
                case 'unenrol':
                    $outcome['result'] = $this->unenrol_user( $provider, $user_id, $course_id );
                    break;
                case 'reset_progress':
                    $outcome['result'] = $this->reset_progress( $provider, $user_id, $course_id );
                    break;
                case 'update_completion':
                    $progress = isset( $op['progress'] ) ? $op['progress'] : null;
                    $outcome['result'] = $this->update_completion( $provider, $user_id, $course_id, $progress );
                    break;
                default:
                    $outcome['result'] = array( 'error' => 'Unsupported operation ' . $action );
            }
            $results[] = $outcome;
        }
        return array( 'provider' => $provider, 'results' => $results );
    }

    /**
     * Enrol a user into a course.
     */
    protected function enrol_user( $provider, $user_id, $course_id ) {
        if ( 'learndash' === $provider ) {
            if ( function_exists( 'ld_update_course_access' ) ) {
                ld_update_course_access( $user_id, $course_id, 'add' );
                return array( 'enrolled' => true );
            }
        } elseif ( 'lifterlms' === $provider ) {
            if ( class_exists( 'LLMS_Student' ) ) {
                $student = new LLMS_Student( $user_id );
                $student->enroll( $course_id );
                return array( 'enrolled' => true );
            }
        } elseif ( 'tutorlms' === $provider ) {
            if ( function_exists( 'tutor_utils' ) && method_exists( tutor_utils(), 'enroll_user' ) ) {
                $enrolled = tutor_utils()->enroll_user( $course_id, $user_id );
                return array( 'enrolled' => (bool) $enrolled );
            }
        }
        // Fallback: mark enrolment in user meta
        $enrolments = get_user_meta( $user_id, '_arthur_ai_enrolments', true );
        if ( ! is_array( $enrolments ) ) {
            $enrolments = array();
        }
        $enrolments[ $provider ][ $course_id ] = array( 'status' => 'enrolled', 'progress' => 0 );
        update_user_meta( $user_id, '_arthur_ai_enrolments', $enrolments );
        return array( 'enrolled' => true, 'note' => 'Enrolled via fallback meta' );
    }

    /**
     * Unenrol a user from a course.
     */
    protected function unenrol_user( $provider, $user_id, $course_id ) {
        if ( 'learndash' === $provider ) {
            if ( function_exists( 'ld_update_course_access' ) ) {
                ld_update_course_access( $user_id, $course_id, 'remove' );
                return array( 'unenrolled' => true );
            }
        } elseif ( 'lifterlms' === $provider ) {
            if ( class_exists( 'LLMS_Student' ) ) {
                $student = new LLMS_Student( $user_id );
                $student->unenroll( $course_id );
                return array( 'unenrolled' => true );
            }
        } elseif ( 'tutorlms' === $provider ) {
            if ( function_exists( 'tutor_utils' ) && method_exists( tutor_utils(), 'unenroll_user' ) ) {
                tutor_utils()->unenroll_user( $course_id, $user_id );
                return array( 'unenrolled' => true );
            }
        }
        // Fallback: update meta
        $enrolments = get_user_meta( $user_id, '_arthur_ai_enrolments', true );
        if ( isset( $enrolments[ $provider ][ $course_id ] ) ) {
            unset( $enrolments[ $provider ][ $course_id ] );
            update_user_meta( $user_id, '_arthur_ai_enrolments', $enrolments );
        }
        return array( 'unenrolled' => true );
    }

    /**
     * Reset a user's progress for a course.
     */
    protected function reset_progress( $provider, $user_id, $course_id ) {
        if ( 'learndash' === $provider && function_exists( 'ld_reset_course_progress' ) ) {
            ld_reset_course_progress( $user_id, $course_id );
            return array( 'reset' => true );
        } elseif ( 'lifterlms' === $provider && class_exists( 'LLMS_Student' ) ) {
            $student = new LLMS_Student( $user_id );
            // LifterLMS does not provide a direct reset; unenrol and re-enrol
            $student->unenroll( $course_id );
            $student->enroll( $course_id );
            return array( 'reset' => true );
        } elseif ( 'tutorlms' === $provider && function_exists( 'tutor_utils' ) ) {
            // TutorLMS does not expose reset; treat as unenrol + enrol
            if ( method_exists( tutor_utils(), 'unenroll_user' ) ) {
                tutor_utils()->unenroll_user( $course_id, $user_id );
            }
            if ( method_exists( tutor_utils(), 'enroll_user' ) ) {
                tutor_utils()->enroll_user( $course_id, $user_id );
            }
            return array( 'reset' => true );
        }
        // Fallback meta
        $enrolments = get_user_meta( $user_id, '_arthur_ai_enrolments', true );
        if ( isset( $enrolments[ $provider ][ $course_id ] ) ) {
            $enrolments[ $provider ][ $course_id ]['progress'] = 0;
            update_user_meta( $user_id, '_arthur_ai_enrolments', $enrolments );
        }
        return array( 'reset' => true );
    }

    /**
     * Update completion or progress for a user in a course.
     */
    protected function update_completion( $provider, $user_id, $course_id, $progress ) {
        if ( 'learndash' === $provider ) {
            if ( null === $progress ) {
                // mark complete
                if ( function_exists( 'ld_course_mark_complete' ) ) {
                    ld_course_mark_complete( $user_id, $course_id );
                    return array( 'completed' => true );
                }
            } else {
                // update progress not supported; fallback to meta
            }
        } elseif ( 'lifterlms' === $provider && class_exists( 'LLMS_Student' ) ) {
            $student = new LLMS_Student( $user_id );
            if ( null === $progress ) {
                // mark complete
                $student->complete_course( $course_id );
                return array( 'completed' => true );
            }
        } elseif ( 'tutorlms' === $provider ) {
            if ( null === $progress && function_exists( 'tutor_utils' ) && method_exists( tutor_utils(), 'complete_course' ) ) {
                tutor_utils()->complete_course( $course_id, $user_id );
                return array( 'completed' => true );
            }
        }
        // Fallback: store progress in meta
        $enrolments = get_user_meta( $user_id, '_arthur_ai_enrolments', true );
        if ( ! isset( $enrolments[ $provider ] ) ) {
            $enrolments[ $provider ] = array();
        }
        if ( ! isset( $enrolments[ $provider ][ $course_id ] ) ) {
            $enrolments[ $provider ][ $course_id ] = array( 'status' => 'enrolled' );
        }
        $enrolments[ $provider ][ $course_id ]['progress'] = ( null === $progress ) ? 100 : floatval( $progress );
        update_user_meta( $user_id, '_arthur_ai_enrolments', $enrolments );
        return array( 'progress_updated' => true );
    }
}
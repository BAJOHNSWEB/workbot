<?php
/**
 * Configure the structure and prerequisites of a course for an LMS provider.
 *
 * This action allows the AI to define how a course should be organised (modules,
 * sections, lesson ordering) and specify prerequisites such as required courses
 * or lessons. The structure is stored as meta on the course post and can be
 * interpreted by the Arthur_AI_Lms_Customiser or downstream processes to
 * rearrange lessons and enforce prerequisites. The action validates the
 * provider and course existence but does not attempt to reorder lessons in
 * provider-specific ways at runtime.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Configure_Course_Structure implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'configure_course_structure';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Configure course structure', 'arthur-ai' );
    }

    /**
     * {@inheritDoc}
     */
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        $supported = array( 'learndash', 'lifterlms', 'tutorlms' );
        if ( ! in_array( $provider, $supported, true ) ) {
            return array( 'error' => 'Unsupported LMS provider ' . $provider . '.' );
        }
        // Validate provider activation
        $active = false;
        if ( 'learndash' === $provider && defined( 'LEARNDASH_VERSION' ) ) {
            $active = true;
        } elseif ( 'lifterlms' === $provider && ( defined( 'LLMS_VERSION' ) || function_exists( 'llms' ) ) ) {
            $active = true;
        } elseif ( 'tutorlms' === $provider && ( function_exists( 'tutor_utils' ) || defined( 'TUTOR_VERSION' ) ) ) {
            $active = true;
        }
        if ( ! $active ) {
            return array( 'error' => 'LMS provider ' . $provider . ' is not active.' );
        }
        $course_id = isset( $payload['course_id'] ) ? intval( $payload['course_id'] ) : 0;
        if ( $course_id <= 0 || ! get_post( $course_id ) ) {
            return array( 'error' => 'Valid course_id is required.' );
        }
        $structure = isset( $payload['structure'] ) && is_array( $payload['structure'] ) ? $payload['structure'] : array();
        $prereqs  = isset( $payload['prerequisites'] ) && is_array( $payload['prerequisites'] ) ? $payload['prerequisites'] : array();
        // Persist as serialized meta. These keys are internal to Arthur AI.
        update_post_meta( $course_id, '_arthur_ai_course_structure', $structure );
        update_post_meta( $course_id, '_arthur_ai_course_prerequisites', $prereqs );
        return array(
            'provider'   => $provider,
            'course_id'  => $course_id,
            'structure'  => $structure,
            'prerequisites' => $prereqs,
        );
    }
}
<?php
/**
 * Configure membership content protection rules.
 *
 * This action stores rules describing which membership levels protect what
 * content. The actual enforcement of these rules is handled by the
 * Arthur_AI_Memberships_Customiser class. A rule consists of a list of level
 * identifiers and a content scope (post IDs, post types, taxonomies) plus
 * behaviour directives (redirect URL, teaser mode).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Protect_Content_By_Membership implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'protect_content_by_membership';
    }

    public function get_label() {
        return __( 'Protect content by membership', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        if ( empty( $provider ) ) {
            return array( 'error' => 'provider is required' );
        }
        // Check provider plugin presence
        $active = false;
        if ( 'woo_memberships' === $provider && class_exists( 'WC_Memberships' ) ) {
            $active = true;
        } elseif ( 'pmpro' === $provider && function_exists( 'pmpro_getAllLevels' ) ) {
            $active = true;
        } elseif ( 'memberpress' === $provider && class_exists( 'MeprProduct' ) ) {
            $active = true;
        }
        if ( ! $active ) {
            return array( 'error' => 'Provider ' . $provider . ' is not active.' );
        }

        $rules = isset( $payload['rules'] ) && is_array( $payload['rules'] ) ? $payload['rules'] : array();
        $behaviour = isset( $payload['behaviour'] ) && is_array( $payload['behaviour'] ) ? $payload['behaviour'] : array();
        // Persist rules per provider
        $existing = get_option( 'arthur_ai_membership_protection_rules', array() );
        $existing[ $provider ] = array(
            'rules'     => $rules,
            'behaviour' => $behaviour,
        );
        update_option( 'arthur_ai_membership_protection_rules', $existing );
        return array(
            'provider'  => $provider,
            'rules'     => $rules,
            'behaviour' => $behaviour,
        );
    }
}
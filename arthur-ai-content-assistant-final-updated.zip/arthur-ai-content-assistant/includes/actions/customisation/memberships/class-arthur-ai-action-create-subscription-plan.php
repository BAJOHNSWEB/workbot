<?php
/**
 * Create a subscription plan using WooCommerce Subscriptions.
 *
 * This action supports the `woo_subscriptions` provider. When Woo
 * Subscriptions is active it will programmatically create a subscription
 * product with the provided parameters. If the provider is not supported or
 * not active, it returns an error.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Create_Subscription_Plan implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'create_subscription_plan';
    }
    public function get_label() {
        return __( 'Create subscription plan', 'arthur-ai' );
    }
    public function execute( array $payload ) {
        $provider = isset( $payload['provider'] ) ? sanitize_key( $payload['provider'] ) : '';
        if ( 'woo_subscriptions' !== $provider ) {
            return array( 'error' => 'Only Woo Subscriptions provider is supported.' );
        }
        if ( ! class_exists( 'WC_Subscriptions' ) ) {
            return array( 'error' => 'WooCommerce Subscriptions plugin is not active.' );
        }
        $name  = isset( $payload['name'] ) ? sanitize_text_field( $payload['name'] ) : '';
        if ( empty( $name ) ) {
            return array( 'error' => 'name is required' );
        }
        $price = isset( $payload['price'] ) ? floatval( $payload['price'] ) : 0.0;
        $interval = isset( $payload['billing_interval'] ) ? max( 1, intval( $payload['billing_interval'] ) ) : 1;
        $period   = isset( $payload['billing_period'] ) ? sanitize_key( $payload['billing_period'] ) : 'month';
        $trial_length = isset( $payload['trial_length'] ) ? intval( $payload['trial_length'] ) : 0;
        $trial_period = isset( $payload['trial_period'] ) ? sanitize_key( $payload['trial_period'] ) : $period;
        $sign_up_fee  = isset( $payload['sign_up_fee'] ) ? floatval( $payload['sign_up_fee'] ) : 0.0;
        $membership_levels = isset( $payload['membership_levels'] ) && is_array( $payload['membership_levels'] ) ? $payload['membership_levels'] : array();

        // Attempt to create a subscription product using the Woo Subscriptions API.
        if ( class_exists( 'WC_Product_Subscription' ) ) {
            $product = new WC_Product_Subscription();
            $product->set_name( $name );
            $product->set_status( 'publish' );
            $product->set_regular_price( $price );
            // Set subscription interval and period
            if ( method_exists( $product, 'set_interval' ) ) {
                $product->set_interval( $interval );
            }
            if ( method_exists( $product, 'set_period' ) ) {
                $product->set_period( $period );
            }
            if ( $trial_length > 0 && method_exists( $product, 'set_trial_length' ) ) {
                $product->set_trial_length( $trial_length );
            }
            if ( $trial_length > 0 && method_exists( $product, 'set_trial_period' ) ) {
                $product->set_trial_period( $trial_period );
            }
            if ( $sign_up_fee > 0 && method_exists( $product, 'set_sign_up_fee' ) ) {
                $product->set_sign_up_fee( $sign_up_fee );
            }
            // Save the product
            $product_id = $product->save();
        } else {
            // Fallback: create a simple product and store subscription meta
            $product_id = wp_insert_post( array(
                'post_title'   => $name,
                'post_type'    => 'product',
                'post_status'  => 'publish',
                'post_content' => '',
            ) );
            if ( is_wp_error( $product_id ) || ! $product_id ) {
                return array( 'error' => 'Failed to create subscription product.' );
            }
            update_post_meta( $product_id, '_regular_price', $price );
            update_post_meta( $product_id, '_price', $price );
            update_post_meta( $product_id, '_subscription_period', $period );
            update_post_meta( $product_id, '_subscription_period_interval', $interval );
            if ( $trial_length > 0 ) {
                update_post_meta( $product_id, '_subscription_trial_length', $trial_length );
                update_post_meta( $product_id, '_subscription_trial_period', $trial_period );
            }
            if ( $sign_up_fee > 0 ) {
                update_post_meta( $product_id, '_subscription_sign_up_fee', $sign_up_fee );
            }
        }

        // Associate with membership levels if provided
        if ( ! empty( $membership_levels ) ) {
            $map = get_option( 'arthur_ai_subscription_level_map', array() );
            foreach ( $membership_levels as $level_id ) {
                $map[] = array(
                    'subscription_id' => $product_id,
                    'membership_level_id' => $level_id,
                );
            }
            update_option( 'arthur_ai_subscription_level_map', $map );
        }

        return array(
            'provider'        => $provider,
            'subscription_id' => $product_id,
            'name'            => $name,
            'price'           => $price,
            'interval'        => $interval,
            'period'          => $period,
            'trial_length'    => $trial_length,
        );
    }
}
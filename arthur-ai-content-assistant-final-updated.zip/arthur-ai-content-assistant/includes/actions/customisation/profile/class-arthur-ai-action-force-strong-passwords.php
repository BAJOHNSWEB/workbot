<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Enforce strong passwords for users when updating their profile. Stores an
 * enabled flag and a minimum strength threshold in options. The actual
 * enforcement logic is handled by Arthur_AI_Security_Customiser.
 */
class Arthur_AI_Action_Force_Strong_Passwords implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'force_strong_passwords';
    }

    public function get_label() {
        return __( 'Force Strong Passwords', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $enabled = false;
        $threshold = 12; // default minimum length
        if ( isset( $payload['enabled'] ) ) {
            $enabled = (bool) $payload['enabled'];
        }
        if ( isset( $payload['threshold'] ) && is_numeric( $payload['threshold'] ) ) {
            $threshold = max( 6, intval( $payload['threshold'] ) );
        }
        update_option( 'arthur_ai_force_strong_passwords_enabled', $enabled );
        update_option( 'arthur_ai_force_strong_passwords_threshold', $threshold );
        return array(
            'success' => true,
            'message' => __( 'Strong password policy updated.', 'arthur-ai' )
        );
    }
}
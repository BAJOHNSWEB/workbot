<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Rename existing user roles by updating the $wp_roles global. Stores the
 * overrides so they can be re-applied on each page load via the security
 * customiser. Only display names are changed; capabilities remain untouched.
 */
class Arthur_AI_Action_Rename_User_Roles implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'rename_user_roles';
    }

    public function get_label() {
        return __( 'Rename User Roles', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! isset( $payload['roles'] ) || ! is_array( $payload['roles'] ) ) {
            return array( 'success' => false, 'message' => __( 'roles mapping is required.', 'arthur-ai' ) );
        }
        $overrides = get_option( 'arthur_ai_role_label_overrides', array() );
        if ( ! is_array( $overrides ) ) {
            $overrides = array();
        }
        foreach ( $payload['roles'] as $role => $label ) {
            $role_key = sanitize_key( (string) $role );
            $label    = sanitize_text_field( (string) $label );
            if ( '' === $role_key || '' === $label ) {
                continue;
            }
            // update global roles immediately if role exists
            global $wp_roles;
            if ( ! empty( $wp_roles->roles[ $role_key ] ) ) {
                $wp_roles->roles[ $role_key ]['name'] = $label;
                $wp_roles->role_names[ $role_key ]     = $label;
            }
            $overrides[ $role_key ] = $label;
        }
        update_option( 'arthur_ai_role_label_overrides', $overrides );
        return array(
            'success' => true,
            'message' => __( 'User role labels updated.', 'arthur-ai' )
        );
    }
}
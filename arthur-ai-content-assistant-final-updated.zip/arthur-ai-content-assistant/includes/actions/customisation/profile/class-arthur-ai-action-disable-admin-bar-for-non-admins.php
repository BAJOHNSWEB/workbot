<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Disable the WordPress admin bar for users without the administrator role.
 *
 * The payload should contain an 'enabled' boolean. When enabled, the
 * profile customiser hooks show_admin_bar to hide the admin bar for
 * non-admins. The flag is stored in arthur_ai_disable_admin_bar_non_admins.
 */
class Arthur_AI_Action_Disable_Admin_Bar_For_Non_Admins implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'disable_admin_bar_for_non_admins';
    }

    public function get_label() {
        return __( 'Disable Admin Bar For Non Admins', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $enabled = false;
        if ( isset( $payload['enabled'] ) ) {
            $enabled = (bool) $payload['enabled'];
        }
        update_option( 'arthur_ai_disable_admin_bar_non_admins', $enabled );
        return array( 'success' => true, 'message' => __( 'Admin bar visibility updated.', 'arthur-ai' ) );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Redirect users on login based on their primary role.
 *
 * The payload should provide a 'redirects' associative array mapping role
 * slugs to absolute URLs. These mappings are stored in the option
 * arthur_ai_login_redirects and are used by the profile customiser on
 * the login_redirect filter. Invalid roles or URLs are ignored.
 */
class Arthur_AI_Action_Redirect_On_Login implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'redirect_on_login';
    }

    public function get_label() {
        return __( 'Redirect On Login', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! isset( $payload['redirects'] ) || ! is_array( $payload['redirects'] ) ) {
            return array( 'success' => false, 'message' => __( 'redirects mapping is required.', 'arthur-ai' ) );
        }
        $redirects = array();
        foreach ( $payload['redirects'] as $role => $url ) {
            $role_key = sanitize_key( (string) $role );
            $url      = esc_url_raw( (string) $url );
            if ( '' !== $role_key && '' !== $url ) {
                $redirects[ $role_key ] = $url;
            }
        }
        update_option( 'arthur_ai_login_redirects', $redirects );
        return array( 'success' => true, 'message' => __( 'Login redirects updated.', 'arthur-ai' ) );
    }
}
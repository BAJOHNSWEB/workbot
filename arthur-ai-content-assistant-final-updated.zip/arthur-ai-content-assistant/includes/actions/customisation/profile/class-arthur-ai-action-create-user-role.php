<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Create a new WordPress user role with the provided capabilities.
 *
 * This action sanitises the role key and label, registers the role via
 * add_role(), and persists the definition to re‑register it on future
 * requests. Capabilities should be provided as an associative array of
 * capability => bool. Role names must be unique; if a role with the
 * same key already exists it will be overwritten.
 */
class Arthur_AI_Action_Create_User_Role implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'create_user_role';
    }

    public function get_label() {
        return __( 'Create User Role', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! isset( $payload['role_key'] ) || ! isset( $payload['label'] ) ) {
            return array( 'success' => false, 'message' => __( 'role_key and label are required.', 'arthur-ai' ) );
        }
        $role_key = sanitize_key( (string) $payload['role_key'] );
        $label    = sanitize_text_field( (string) $payload['label'] );
        if ( '' === $role_key || '' === $label ) {
            return array( 'success' => false, 'message' => __( 'Invalid role_key or label.', 'arthur-ai' ) );
        }
        $caps = array();
        if ( isset( $payload['capabilities'] ) && is_array( $payload['capabilities'] ) ) {
            foreach ( $payload['capabilities'] as $cap => $grant ) {
                $cap_key = sanitize_key( (string) $cap );
                $caps[ $cap_key ] = (bool) $grant;
            }
        }
        // Register the role. add_role() returns null on failure.
        add_role( $role_key, $label, $caps );
        // Persist to options for re‑registration on init.
        $stored = get_option( 'arthur_ai_custom_roles', array() );
        if ( ! is_array( $stored ) ) {
            $stored = array();
        }
        $stored[ $role_key ] = array( 'label' => $label, 'capabilities' => $caps );
        update_option( 'arthur_ai_custom_roles', $stored );
        return array( 'success' => true, 'message' => __( 'User role created.', 'arthur-ai' ) );
    }
}
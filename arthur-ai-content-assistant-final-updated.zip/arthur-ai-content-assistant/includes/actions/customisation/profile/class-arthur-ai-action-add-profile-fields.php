<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Add custom fields to the user profile screen.
 *
 * The payload should contain a 'fields' array where each element is an
 * associative array with keys: id (required), label (required), and type
 * (optional, defaults to text). Supported types are text and textarea.
 * The configuration is stored and used by the profile customiser to
 * render fields and save values as user meta.
 */
class Arthur_AI_Action_Add_Profile_Fields implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'add_profile_fields';
    }

    public function get_label() {
        return __( 'Add Profile Fields', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( ! isset( $payload['fields'] ) || ! is_array( $payload['fields'] ) ) {
            return array( 'success' => false, 'message' => __( 'fields array is required.', 'arthur-ai' ) );
        }
        $existing = get_option( 'arthur_ai_custom_profile_fields', array() );
        if ( ! is_array( $existing ) ) {
            $existing = array();
        }
        foreach ( $payload['fields'] as $field ) {
            if ( ! is_array( $field ) ) {
                continue;
            }
            $id    = isset( $field['id'] ) ? sanitize_key( (string) $field['id'] ) : '';
            $label = isset( $field['label'] ) ? sanitize_text_field( (string) $field['label'] ) : '';
            $type  = isset( $field['type'] ) ? sanitize_key( (string) $field['type'] ) : 'text';
            if ( '' === $id || '' === $label ) {
                continue;
            }
            $type = in_array( $type, array( 'text', 'textarea' ), true ) ? $type : 'text';
            $existing[ $id ] = array(
                'id'    => $id,
                'label' => $label,
                'type'  => $type,
            );
        }
        update_option( 'arthur_ai_custom_profile_fields', $existing );
        return array( 'success' => true, 'message' => __( 'Profile fields updated.', 'arthur-ai' ) );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Redirect users to a specific URL after logout.
 *
 * The payload should provide a 'url' string. The value is stored in
 * arthur_ai_logout_redirect_url and used by the profile customiser on
 * the wp_logout action. If empty, the option is cleared.
 */
class Arthur_AI_Action_Redirect_On_Logout implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'redirect_on_logout';
    }

    public function get_label() {
        return __( 'Redirect On Logout', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $url = '';
        if ( isset( $payload['url'] ) ) {
            $url = trim( (string) $payload['url'] );
        }
        if ( '' !== $url ) {
            $url = esc_url_raw( $url );
        }
        update_option( 'arthur_ai_logout_redirect_url', $url );
        return array( 'success' => true, 'message' => __( 'Logout redirect updated.', 'arthur-ai' ) );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Hide specified fields from the user/profile edit screen.
 *
 * The payload should contain a 'fields' array of field IDs to hide, such as
 * ['nickname','first_name','last_name','description']. The field IDs
 * correspond to the HTML wrappers (tr.user-{field}-wrap) used on the
 * profile editing screens. The list is stored and consumed by the
 * profile customiser to output appropriate CSS.
 */
class Arthur_AI_Action_Hide_Profile_Fields implements Arthur_AI_Action_Interface {
    public function get_type() {
        return 'hide_profile_fields';
    }

    public function get_label() {
        return __( 'Hide Profile Fields', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $fields = array();
        if ( isset( $payload['fields'] ) && is_array( $payload['fields'] ) ) {
            foreach ( $payload['fields'] as $field ) {
                $field_id = sanitize_key( (string) $field );
                if ( '' !== $field_id ) {
                    $fields[] = $field_id;
                }
            }
        }
        update_option( 'arthur_ai_hidden_profile_fields', $fields );
        return array( 'success' => true, 'message' => __( 'Profile field visibility updated.', 'arthur-ai' ) );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Apply a bundle of option updates in a safe, whitelisted manner.
 *
 * This action accepts a domain and an associative array of key/value
 * pairs representing desired configuration changes. Only recognised
 * options for the given domain will be updated. Unknown keys are
 * ignored. Values are sanitised and cast to appropriate types
 * where possible. On completion, the action returns a summary of
 * changes including previous and new values. If the domain is
 * unknown, it will return an error.
 */
class Arthur_AI_Action_Apply_Options_Bundle implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'apply_options_bundle';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Apply Options Bundle', 'arthur-ai' );
    }

    /**
     * Execute the application of option updates.
     *
     * @param array $payload {
     *     @type string $domain   The domain/bundle to update.
     *     @type array  $options  An associative array of option names => values.
     * }
     *
     * @return array Result summary.
     */
    public function execute( array $payload ) {
        $domain  = isset( $payload['domain'] ) ? sanitize_key( $payload['domain'] ) : '';
        $updates = isset( $payload['options'] ) && is_array( $payload['options'] ) ? $payload['options'] : array();
        if ( ! $domain ) {
            return array( 'success' => false, 'message' => __( 'No domain specified.', 'arthur-ai' ) );
        }
        if ( empty( $updates ) ) {
            return array( 'success' => false, 'message' => __( 'No options provided for update.', 'arthur-ai' ) );
        }

        // Define allowed keys per domain.
        $allowed = array();
        switch ( $domain ) {
            case 'general':
                $allowed = array( 'blogname', 'blogdescription', 'admin_email', 'timezone_string', 'date_format', 'time_format', 'start_of_week', 'WPLANG' );
                break;
            case 'reading':
                $allowed = array( 'show_on_front', 'page_on_front', 'page_for_posts', 'posts_per_page', 'posts_per_rss', 'rss_use_excerpt', 'blog_public' );
                break;
            case 'discussion':
                $allowed = array( 'default_comment_status', 'comment_registration', 'require_name_email', 'comment_moderation', 'comment_previously_approved', 'comment_max_links', 'moderation_keys', 'blacklist_keys' );
                break;
            case 'permalinks':
                $allowed = array( 'permalink_structure', 'category_base', 'tag_base' );
                break;
            case 'woocommerce_store':
                if ( ! class_exists( 'WooCommerce' ) ) {
                    return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
                }
                $allowed = array( 'woocommerce_store_address', 'woocommerce_store_address_2', 'woocommerce_store_city', 'woocommerce_store_postcode', 'woocommerce_default_country', 'woocommerce_currency', 'woocommerce_tax_display_shop' );
                break;
            case 'arthur_ai_performance':
                $allowed = array( 'arthur_ai_cache_settings', 'arthur_ai_asset_optimisation_settings', 'arthur_ai_lazy_loading' );
                break;
            default:
                return array( 'success' => false, 'message' => __( 'Unknown options domain.', 'arthur-ai' ) );
        }
        $changes = array();
        foreach ( $updates as $key => $value ) {
            if ( ! in_array( $key, $allowed, true ) ) {
                continue;
            }
            // Fetch old value.
            $old = get_option( $key );
            // Sanitise and cast based on old value type.
            if ( is_bool( $old ) ) {
                $new_val = (bool) $value;
            } elseif ( is_int( $old ) ) {
                $new_val = (int) $value;
            } elseif ( is_float( $old ) ) {
                $new_val = (float) $value;
            } else {
                $new_val = maybe_serialize( $value );
                // Do not serialise strings for plain values.
                if ( ! is_array( $value ) ) {
                    $new_val = $value;
                }
            }
            update_option( $key, $new_val );
            $changes[] = array( 'option' => $key, 'old' => $old, 'new' => get_option( $key ) );
        }
        return array( 'success' => true, 'changes' => $changes );
    }
}
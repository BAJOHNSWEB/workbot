<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Retrieve a snapshot of key WordPress or plugin settings for a given domain.
 *
 * This read‑only action returns a structured array of option values
 * across common settings domains such as general, reading,
 * discussion, permalinks, WooCommerce store and Arthur AI plugin
 * settings. It is intended to provide the AI with context about
 * current configuration without altering anything. Additional
 * domains may be added over time. Unknown domains will return an
 * error.
 */
class Arthur_AI_Action_Get_Settings_Snapshot implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'get_settings_snapshot';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Get Settings Snapshot', 'arthur-ai' );
    }

    /**
     * Execute the action to fetch settings.
     *
     * @param array $payload {
     *     @type string $domain The domain/bundle of settings to fetch (general, reading, discussion, permalinks, woocommerce_store, arthur_ai_performance).
     * }
     * @return array Snapshot of settings.
     */
    public function execute( array $payload ) {
        $domain = isset( $payload['domain'] ) ? sanitize_key( $payload['domain'] ) : '';
        if ( ! $domain ) {
            return array( 'success' => false, 'message' => __( 'No settings domain specified.', 'arthur-ai' ) );
        }
        switch ( $domain ) {
            case 'general':
                return array( 'success' => true, 'settings' => $this->get_general_settings() );
            case 'reading':
                return array( 'success' => true, 'settings' => $this->get_reading_settings() );
            case 'discussion':
                return array( 'success' => true, 'settings' => $this->get_discussion_settings() );
            case 'permalinks':
                return array( 'success' => true, 'settings' => $this->get_permalink_settings() );
            case 'woocommerce_store':
                return array( 'success' => true, 'settings' => $this->get_wc_store_settings() );
            case 'arthur_ai_performance':
                return array( 'success' => true, 'settings' => $this->get_arthur_performance_settings() );
            default:
                return array( 'success' => false, 'message' => __( 'Unknown settings domain.', 'arthur-ai' ) );
        }
    }

    /**
     * General site settings snapshot.
     */
    protected function get_general_settings() {
        $opts = array(
            'site_title'       => get_option( 'blogname' ),
            'site_tagline'     => get_option( 'blogdescription' ),
            'site_url'         => get_option( 'siteurl' ),
            'home_url'         => get_option( 'home' ),
            'admin_email'      => get_option( 'admin_email' ),
            'timezone'         => get_option( 'timezone_string' ),
            'date_format'      => get_option( 'date_format' ),
            'time_format'      => get_option( 'time_format' ),
            'start_of_week'    => get_option( 'start_of_week' ),
            'language'         => get_option( 'WPLANG' ),
        );
        return $opts;
    }

    /**
     * Reading settings snapshot.
     */
    protected function get_reading_settings() {
        $opts = array(
            'show_on_front'      => get_option( 'show_on_front' ),
            'page_on_front'      => get_option( 'page_on_front' ),
            'page_for_posts'     => get_option( 'page_for_posts' ),
            'posts_per_page'     => get_option( 'posts_per_page' ),
            'posts_per_rss'      => get_option( 'posts_per_rss' ),
            'rss_use_excerpt'    => get_option( 'rss_use_excerpt' ),
            'blog_public'        => get_option( 'blog_public' ),
        );
        return $opts;
    }

    /**
     * Discussion settings snapshot.
     */
    protected function get_discussion_settings() {
        $opts = array(
            'default_comment_status'     => get_option( 'default_comment_status' ),
            'comment_registration'       => get_option( 'comment_registration' ),
            'require_name_email'         => get_option( 'require_name_email' ),
            'comment_moderation'         => get_option( 'comment_moderation' ),
            'comment_previously_approved'=> get_option( 'comment_previously_approved' ),
            'comment_max_links'          => get_option( 'comment_max_links' ),
            'moderation_keys'            => get_option( 'moderation_keys' ),
            'blacklist_keys'             => get_option( 'blacklist_keys' ),
        );
        return $opts;
    }

    /**
     * Permalink settings snapshot.
     */
    protected function get_permalink_settings() {
        $opts = array(
            'permalink_structure' => get_option( 'permalink_structure' ),
            'category_base'       => get_option( 'category_base' ),
            'tag_base'            => get_option( 'tag_base' ),
        );
        return $opts;
    }

    /**
     * WooCommerce store settings snapshot.
     */
    protected function get_wc_store_settings() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'error' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        $opts = array(
            'store_address_1' => get_option( 'woocommerce_store_address' ),
            'store_address_2' => get_option( 'woocommerce_store_address_2' ),
            'store_city'      => get_option( 'woocommerce_store_city' ),
            'store_postcode'  => get_option( 'woocommerce_store_postcode' ),
            'default_country' => get_option( 'woocommerce_default_country' ),
            'currency'        => get_option( 'woocommerce_currency' ),
            'tax_display'     => get_option( 'woocommerce_tax_display_shop' ),
        );
        return $opts;
    }

    /**
     * Arthur AI performance settings snapshot.
     */
    protected function get_arthur_performance_settings() {
        $opts = array(
            'cache_settings'        => get_option( 'arthur_ai_cache_settings' ),
            'asset_optimisation'    => get_option( 'arthur_ai_asset_optimisation_settings' ),
            'lazy_loading'          => get_option( 'arthur_ai_lazy_loading' ),
        );
        return $opts;
    }
}
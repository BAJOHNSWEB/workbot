<?php
/**
 * Action: Create Site Checkpoint
 *
 * This action triggers a backup via an available backup plugin (e.g. UpdraftPlus) to capture the state of the site.
 * When no backup plugin is detected, it records a logical checkpoint without performing a backup.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Create_Site_Checkpoint implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'create_site_checkpoint';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Create Site Checkpoint', 'arthur-ai' );
    }

    /**
     * Execute the checkpoint creation.
     *
     * @param array $payload {
     *     @type string $label Optional description for the checkpoint.
     * }
     * @return array
     */
    public function execute( array $payload ) {
        $label = isset( $payload['label'] ) ? sanitize_text_field( $payload['label'] ) : '';

        $checkpoint = array(
            'id'        => uniqid( 'checkpoint_', true ),
            'timestamp' => current_time( 'mysql' ),
            'label'     => $label,
            'plugin'    => 'none',
            'status'    => 'recorded',
        );

        // Detect UpdraftPlus or other backup plugins and trigger a backup if possible.
        if ( class_exists( 'UpdraftPlus' ) ) {
            // UpdraftPlus offers action hooks to trigger backup; 'updraftplus_backupnow' is common.
            do_action( 'updraftplus_backupnow' );
            $checkpoint['plugin'] = 'updraftplus';
            $checkpoint['status'] = 'backup_triggered';
        }

        // Persist the checkpoint in an option.
        $checkpoints = get_option( 'arthur_ai_site_checkpoints', array() );
        $checkpoints[] = $checkpoint;
        update_option( 'arthur_ai_site_checkpoints', $checkpoints );

        return array(
            'success'    => true,
            'checkpoint' => $checkpoint,
            'message'    => __( 'Checkpoint created. If a backup plugin is installed, a backup was triggered.', 'arthur-ai' ),
        );
    }
}
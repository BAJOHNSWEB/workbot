<?php
/**
 * Action: Execute Change Plan
 *
 * Executes a previously simulated or exported change plan. This action will perform the actual operations
 * described in the plan. It currently supports deleting posts. To guard against accidental deletion, a
 * `confirm` flag is required. After execution, a summary of successes and failures is returned. The plan
 * may be passed directly or referenced via a stored plan ID (not currently persisted).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Execute_Change_Plan implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'execute_change_plan';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Execute Change Plan', 'arthur-ai' );
    }

    /**
     * Executes the plan.
     *
     * @param array $payload {
     *     @type array  $plan    The plan array returned from simulate_changes or export_change_plan.
     *     @type bool   $confirm Whether to proceed with execution. Must be true.
     * }
     *
     * @return array
     */
    public function execute( array $payload ) {
        // Require confirm flag to proceed.
        if ( empty( $payload['confirm'] ) ) {
            return array(
                'error'   => true,
                'message' => 'Execution requires confirmation. Set confirm=true to proceed.',
            );
        }

        $plan = isset( $payload['plan'] ) && is_array( $payload['plan'] ) ? $payload['plan'] : array();

        if ( empty( $plan ) ) {
            return array(
                'error'   => true,
                'message' => 'No change plan provided for execution.',
            );
        }

        $successes = array();
        $failures  = array();

        // Determine operation type if provided.
        $operation_type = isset( $payload['operation_type'] ) ? sanitize_key( $payload['operation_type'] ) : ( isset( $plan['operation_type'] ) ? sanitize_key( $plan['operation_type'] ) : '' );
        $items          = isset( $plan['items'] ) ? $plan['items'] : $plan; // allow plan to be raw items array

        // Execute based on operation.
        switch ( $operation_type ) {
            case 'bulk_delete_posts':
                foreach ( $items as $item ) {
                    if ( empty( $item['id'] ) ) {
                        continue;
                    }
                    $post_id = intval( $item['id'] );
                    $result  = wp_delete_post( $post_id, true );
                    if ( $result ) {
                        $successes[] = $post_id;
                    } else {
                        $failures[]  = $post_id;
                    }
                }
                break;
            default:
                return array(
                    'error'   => true,
                    'message' => 'Unsupported operation_type for execution: ' . $operation_type,
                );
        }

        // Log the action.
        $this->log_action( $operation_type, $successes, $failures );

        return array(
            'success'   => true,
            'operation' => $operation_type,
            'deleted'   => $successes,
            'failed'    => $failures,
            'message'   => sprintf( '%d item(s) deleted, %d failed.', count( $successes ), count( $failures ) ),
        );
    }

    /**
     * Append a record to the Arthur action log.
     *
     * @param string $operation
     * @param array  $successes
     * @param array  $failures
     */
    protected function log_action( $operation, array $successes, array $failures ) {
        $log = get_option( 'arthur_ai_action_log', array() );
        $log[] = array(
            'timestamp' => current_time( 'mysql' ),
            'user_id'   => get_current_user_id(),
            'action'    => 'execute_change_plan',
            'operation' => $operation,
            'successes' => $successes,
            'failures'  => $failures,
        );
        update_option( 'arthur_ai_action_log', $log );
    }
}
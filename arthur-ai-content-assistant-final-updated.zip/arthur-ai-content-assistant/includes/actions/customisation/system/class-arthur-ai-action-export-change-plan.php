<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Export a change plan for review or storage.
 *
 * This simple action accepts a structured plan (which might have been
 * produced by the preview_change_plan action) and returns it
 * unchanged. It can be extended to write the plan to a file or
 * persistent storage. For now, it simply echoes the plan for
 * consumption by the AI or external tooling.
 */
class Arthur_AI_Action_Export_Change_Plan implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'export_change_plan';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Export Change Plan', 'arthur-ai' );
    }

    /**
     * Execute the export.
     *
     * @param array $payload {
     *     @type array $plan The plan to export.
     * }
     * @return array The plan as provided.
     */
    public function execute( array $payload ) {
        $plan = isset( $payload['plan'] ) ? $payload['plan'] : array();
        return array(
            'success' => true,
            'plan'    => $plan,
            'message' => __( 'Change plan exported successfully.', 'arthur-ai' ),
        );
    }
}
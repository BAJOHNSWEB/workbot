<?php
/**
 * Action: List Arthur Action Log
 *
 * Returns a list of entries from the Arthur AI internal action log. The log entries are stored in
 * the option `arthur_ai_action_log` and may include timestamps, user IDs, action names, and basic
 * result data. This action is read‑only and does not modify the log.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_List_Arthur_Action_Log implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'list_arthur_action_log';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'List Arthur Action Log', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $log = get_option( 'arthur_ai_action_log', array() );
        return array(
            'success' => true,
            'log'     => $log,
        );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Inspect a bundle of site options without changing them.
 *
 * This action is a thin wrapper around the Get Settings Snapshot
 * action. It accepts a bundle/domain name and returns the current
 * settings as a structured array. It is intended to be used by AI
 * clients that want to understand current configuration before
 * proposing changes. Domains mirror those supported by
 * Arthur_AI_Action_Get_Settings_Snapshot.
 */
class Arthur_AI_Action_Inspect_Options_Bundle implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'inspect_options_bundle';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Inspect Options Bundle', 'arthur-ai' );
    }

    /**
     * Execute the inspection.
     *
     * @param array $payload {
     *     @type string $domain The domain/bundle of options to inspect.
     * }
     * @return array Snapshot.
     */
    public function execute( array $payload ) {
        $domain = isset( $payload['domain'] ) ? $payload['domain'] : '';
        // Reuse the Get Settings Snapshot action for retrieval.
        if ( class_exists( 'Arthur_AI_Action_Get_Settings_Snapshot' ) ) {
            $snapshot_action = new Arthur_AI_Action_Get_Settings_Snapshot();
            return $snapshot_action->execute( array( 'domain' => $domain ) );
        }
        return array( 'success' => false, 'message' => __( 'Settings snapshot action unavailable.', 'arthur-ai' ) );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Preview the changes of another action without applying them.
 *
 * This meta‑action accepts the slug of a potentially destructive
 * action and the payload that would be passed to it. It returns a
 * representation of what the action would do without performing any
 * updates. At present, it simply echoes the payload and notes that
 * nothing has been executed. Future enhancements could call into
 * specific actions in a dry‑run mode if they support it.
 */
class Arthur_AI_Action_Preview_Change_Plan implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'preview_change_plan';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Preview Change Plan', 'arthur-ai' );
    }

    /**
     * Execute the preview.
     *
     * @param array $payload {
     *     @type string $action  The slug of the action to preview.
     *     @type array  $plan    The payload that would be sent to that action.
     * }
     *
     * @return array Preview result.
     */
    public function execute( array $payload ) {
        $action_slug = isset( $payload['action'] ) ? sanitize_key( $payload['action'] ) : '';
        $plan        = isset( $payload['plan'] ) ? $payload['plan'] : array();
        if ( ! $action_slug ) {
            return array( 'success' => false, 'message' => __( 'No action specified for preview.', 'arthur-ai' ) );
        }
        return array(
            'success'      => true,
            'preview_only' => true,
            'action'       => $action_slug,
            'plan'         => $plan,
            'message'      => __( 'This is a dry run. No changes have been applied.', 'arthur-ai' ),
        );
    }
}
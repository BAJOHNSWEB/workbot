<?php
/**
 * Action: List Site Checkpoints
 *
 * Returns all recorded checkpoints created via the create_site_checkpoint action. If none exist,
 * an empty array is returned.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_List_Site_Checkpoints implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'list_site_checkpoints';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'List Site Checkpoints', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * @param array $payload
     * @return array
     */
    public function execute( array $payload ) {
        $checkpoints = get_option( 'arthur_ai_site_checkpoints', array() );
        return array(
            'success'     => true,
            'checkpoints' => $checkpoints,
        );
    }
}
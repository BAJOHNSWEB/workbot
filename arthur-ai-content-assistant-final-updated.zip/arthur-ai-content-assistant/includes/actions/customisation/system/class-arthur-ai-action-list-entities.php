<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * List various WordPress entities based on criteria.
 *
 * This action provides a generic way to inspect objects in the site
 * without making any changes. It can list posts, pages, users,
 * products (via WooCommerce) and events (via The Events Calendar) with
 * optional filters. It is intended for read‑only inspection and
 * diagnostics. When listing posts, you may filter by status, author,
 * taxonomy and date range. When listing users, you may filter by role
 * and search term. When listing products or events, it will only work
 * if the relevant plugin is active. The result contains basic
 * information about each item.
 */
class Arthur_AI_Action_List_Entities implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'list_entities';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'List Entities', 'arthur-ai' );
    }

    /**
     * Execute the action.
     *
     * @param array $payload {
     *     @type string $entity   Entity type: 'post', 'page', 'user', 'product', 'event'.
     *     @type array  $criteria Optional filters specific to the entity type.
     * }
     *
     * @return array Result array with success flag and items or error message.
     */
    public function execute( array $payload ) {
        $entity   = isset( $payload['entity'] ) ? sanitize_key( $payload['entity'] ) : 'post';
        $criteria = isset( $payload['criteria'] ) && is_array( $payload['criteria'] ) ? $payload['criteria'] : array();

        // Limit the number of results to prevent memory exhaustion.
        $limit = isset( $criteria['limit'] ) ? max( 1, (int) $criteria['limit'] ) : 50;

        switch ( $entity ) {
            case 'post':
            case 'page':
                return $this->list_posts( $entity, $criteria, $limit );
            case 'user':
            case 'users':
                return $this->list_users( $criteria, $limit );
            case 'product':
            case 'products':
                return $this->list_products( $criteria, $limit );
            case 'event':
            case 'events':
                return $this->list_events( $criteria, $limit );
            default:
                return array( 'success' => false, 'message' => __( 'Unknown entity type.', 'arthur-ai' ) );
        }
    }

    /**
     * List posts/pages with optional filters.
     *
     * @param string $type     Post type.
     * @param array  $criteria Filters.
     * @param int    $limit    Maximum items.
     *
     * @return array
     */
    protected function list_posts( $type, $criteria, $limit ) {
        $args = array(
            'post_type'      => $type,
            'post_status'    => 'any',
            'posts_per_page' => $limit,
        );
        if ( isset( $criteria['status'] ) ) {
            $args['post_status'] = $criteria['status'];
        }
        if ( isset( $criteria['author'] ) ) {
            $args['author'] = intval( $criteria['author'] );
        }
        if ( isset( $criteria['search'] ) ) {
            $args['s'] = sanitize_text_field( $criteria['search'] );
        }
        // Taxonomy filter: expects an array of arrays (taxonomy, terms).
        if ( isset( $criteria['tax_query'] ) && is_array( $criteria['tax_query'] ) ) {
            $args['tax_query'] = array();
            foreach ( $criteria['tax_query'] as $tax ) {
                if ( isset( $tax['taxonomy'] ) && isset( $tax['terms'] ) ) {
                    $args['tax_query'][] = array(
                        'taxonomy' => sanitize_key( $tax['taxonomy'] ),
                        'field'    => is_int( reset( (array) $tax['terms'] ) ) ? 'term_id' : 'slug',
                        'terms'    => $tax['terms'],
                    );
                }
            }
        }
        // Date query filters.
        if ( isset( $criteria['date_after'] ) || isset( $criteria['date_before'] ) ) {
            $args['date_query'] = array();
            if ( isset( $criteria['date_after'] ) ) {
                $args['date_query'][] = array( 'after' => $criteria['date_after'] );
            }
            if ( isset( $criteria['date_before'] ) ) {
                $args['date_query'][] = array( 'before' => $criteria['date_before'] );
            }
        }
        $query = new WP_Query( $args );
        $items = array();
        foreach ( $query->posts as $post ) {
            $items[] = array(
                'ID'     => $post->ID,
                'title'  => $post->post_title,
                'status' => $post->post_status,
                'type'   => $post->post_type,
                'slug'   => $post->post_name,
            );
        }
        return array( 'success' => true, 'items' => $items );
    }

    /**
     * List users with optional filters.
     *
     * @param array $criteria Filters.
     * @param int   $limit    Max.
     *
     * @return array
     */
    protected function list_users( $criteria, $limit ) {
        $args = array();
        if ( isset( $criteria['role'] ) ) {
            $args['role__in'] = (array) $criteria['role'];
        }
        if ( isset( $criteria['search'] ) ) {
            $args['search'] = '*' . $criteria['search'] . '*';
            $args['search_columns'] = array( 'user_login', 'user_email', 'display_name' );
        }
        if ( $limit ) {
            $args['number'] = $limit;
        }
        $users = get_users( $args );
        $items = array();
        foreach ( $users as $user ) {
            $items[] = array(
                'ID'           => $user->ID,
                'user_login'   => $user->user_login,
                'display_name' => $user->display_name,
                'email'        => $user->user_email,
                'roles'        => $user->roles,
            );
        }
        return array( 'success' => true, 'items' => $items );
    }

    /**
     * List WooCommerce products if WooCommerce is active.
     *
     * @param array $criteria Filters.
     * @param int   $limit    Max.
     *
     * @return array
     */
    protected function list_products( $criteria, $limit ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return array( 'success' => false, 'message' => __( 'WooCommerce is not active.', 'arthur-ai' ) );
        }
        $args = array(
            'status' => isset( $criteria['status'] ) ? (array) $criteria['status'] : array( 'publish', 'private' ),
            'limit'  => $limit,
        );
        if ( isset( $criteria['category'] ) ) {
            $args['category'] = $criteria['category'];
        }
        if ( isset( $criteria['stock_status'] ) ) {
            $args['stock_status'] = $criteria['stock_status'];
        }
        if ( isset( $criteria['search'] ) ) {
            $args['search'] = $criteria['search'];
        }
        $products = wc_get_products( $args );
        $items    = array();
        foreach ( $products as $product ) {
            /* @var WC_Product $product */
            $items[] = array(
                'ID'           => $product->get_id(),
                'name'         => $product->get_name(),
                'status'       => $product->get_status(),
                'price'        => $product->get_price(),
                'stock_status' => $product->get_stock_status(),
            );
        }
        return array( 'success' => true, 'items' => $items );
    }

    /**
     * List events if The Events Calendar is active.
     *
     * @param array $criteria Filters.
     * @param int   $limit    Max.
     *
     * @return array
     */
    protected function list_events( $criteria, $limit ) {
        if ( ! class_exists( 'Tribe__Events__Main' ) ) {
            return array( 'success' => false, 'message' => __( 'The Events Calendar is not active.', 'arthur-ai' ) );
        }
        $args = array(
            'post_type'      => Tribe__Events__Main::POSTTYPE,
            'posts_per_page' => $limit,
            'post_status'    => isset( $criteria['status'] ) ? $criteria['status'] : 'publish',
        );
        // Date filters operate on _EventStartDate meta.
        $meta_query = array();
        if ( isset( $criteria['date_after'] ) ) {
            $meta_query[] = array(
                'key'     => '_EventStartDate',
                'value'   => $criteria['date_after'],
                'compare' => '>=',
                'type'    => 'DATETIME',
            );
        }
        if ( isset( $criteria['date_before'] ) ) {
            $meta_query[] = array(
                'key'     => '_EventStartDate',
                'value'   => $criteria['date_before'],
                'compare' => '<=',
                'type'    => 'DATETIME',
            );
        }
        if ( ! empty( $meta_query ) ) {
            $args['meta_query'] = $meta_query;
        }
        $events = get_posts( $args );
        $items  = array();
        foreach ( $events as $event ) {
            $start = get_post_meta( $event->ID, '_EventStartDate', true );
            $items[] = array(
                'ID'         => $event->ID,
                'title'      => $event->post_title,
                'status'     => $event->post_status,
                'start_date' => $start,
            );
        }
        return array( 'success' => true, 'items' => $items );
    }
}
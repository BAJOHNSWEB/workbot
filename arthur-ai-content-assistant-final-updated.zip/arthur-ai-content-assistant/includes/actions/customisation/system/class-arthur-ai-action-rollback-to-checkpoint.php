<?php
/**
 * Action: Rollback to Site Checkpoint
 *
 * Attempts to roll back the site to a previously recorded checkpoint. At present, this action only
 * validates the checkpoint and returns a message instructing the administrator to perform a manual
 * restore via the configured backup plugin. Automated restore is not yet supported.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Rollback_To_Checkpoint implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'rollback_to_checkpoint';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Rollback to Checkpoint', 'arthur-ai' );
    }

    /**
     * Execute rollback. Currently a stub as automated restore requires integration with a backup plugin.
     *
     * @param array $payload {
     *     @type string $checkpoint_id The ID of the checkpoint to restore.
     *     @type bool   $confirm       Confirmation flag.
     * }
     *
     * @return array
     */
    public function execute( array $payload ) {
        $checkpoint_id = isset( $payload['checkpoint_id'] ) ? sanitize_text_field( $payload['checkpoint_id'] ) : '';
        $confirm       = ! empty( $payload['confirm'] );
        if ( ! $checkpoint_id ) {
            return array(
                'error'   => true,
                'message' => 'No checkpoint_id specified.',
            );
        }
        if ( ! $confirm ) {
            return array(
                'error'   => true,
                'message' => 'Rollback requires confirmation. Set confirm=true to proceed.',
            );
        }

        $checkpoints = get_option( 'arthur_ai_site_checkpoints', array() );
        foreach ( $checkpoints as $checkpoint ) {
            if ( $checkpoint['id'] === $checkpoint_id ) {
                // Check if backup plugin is present for actual restore
                if ( class_exists( 'UpdraftPlus' ) ) {
                    return array(
                        'error'   => true,
                        'message' => 'Automated restore is not implemented. Please restore the backup labeled ' . $checkpoint_id . ' via your backup plugin interface.',
                    );
                }
                return array(
                    'error'   => true,
                    'message' => 'Cannot rollback automatically: no supported backup plugin found. Please restore manually from your backup.',
                );
            }
        }
        return array(
            'error'   => true,
            'message' => 'Checkpoint not found.',
        );
    }
}
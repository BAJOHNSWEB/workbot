<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Scan content for common issues such as missing featured images,
 * missing SEO metadata and noindex flags.
 *
 * This read‑only action inspects a subset of posts and pages (up to a
 * sensible limit) and reports content that may need attention. It
 * does not modify any data. The scan helps the AI decide which
 * posts/pages might need optimisation or fixes before further
 * operations. You can extend the scan criteria by adding more checks.
 */
class Arthur_AI_Action_Scan_Content_Issues implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'scan_content_issues';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Scan Content Issues', 'arthur-ai' );
    }

    /**
     * Execute the scan.
     *
     * @param array $payload Unused for now; reserved for future filters.
     * @return array Results of the scan.
     */
    public function execute( array $payload ) {
        // How many posts to inspect at most.
        $limit = 100;
        $args  = array(
            'post_type'      => array( 'post', 'page' ),
            'posts_per_page' => $limit,
            'post_status'    => array( 'publish', 'draft', 'pending' ),
        );
        $posts = get_posts( $args );
        $issues = array(
            'missing_featured_image' => array(),
            'missing_seo_meta'       => array(),
            'noindex'                => array(),
        );
        foreach ( $posts as $post ) {
            // Missing featured image.
            if ( ! has_post_thumbnail( $post->ID ) ) {
                $issues['missing_featured_image'][] = array( 'ID' => $post->ID, 'title' => $post->post_title );
            }
            // Missing SEO meta: check Yoast or Rank Math keys; fall back to Arthur AI keys.
            $has_seo = false;
            // Yoast SEO.
            if ( class_exists( 'WPSEO_Meta' ) || defined( 'WPSEO_VERSION' ) ) {
                $title  = get_post_meta( $post->ID, '_yoast_wpseo_title', true );
                $desc   = get_post_meta( $post->ID, '_yoast_wpseo_metadesc', true );
                if ( ! empty( $title ) || ! empty( $desc ) ) {
                    $has_seo = true;
                }
            }
            // Rank Math.
            if ( ! $has_seo && defined( 'RANK_MATH_VERSION' ) ) {
                $title = get_post_meta( $post->ID, 'rank_math_title', true );
                $desc  = get_post_meta( $post->ID, 'rank_math_description', true );
                if ( ! empty( $title ) || ! empty( $desc ) ) {
                    $has_seo = true;
                }
            }
            // Arthur AI custom meta.
            if ( ! $has_seo ) {
                $title = get_post_meta( $post->ID, '_arthur_ai_seo_title', true );
                $desc  = get_post_meta( $post->ID, '_arthur_ai_seo_description', true );
                if ( ! empty( $title ) || ! empty( $desc ) ) {
                    $has_seo = true;
                }
            }
            if ( ! $has_seo ) {
                $issues['missing_seo_meta'][] = array( 'ID' => $post->ID, 'title' => $post->post_title );
            }
            // Noindex flags: check Yoast, Rank Math and Arthur AI.
            $noindex = false;
            $meta_val = '';
            if ( class_exists( 'WPSEO_Meta' ) || defined( 'WPSEO_VERSION' ) ) {
                $noindex = get_post_meta( $post->ID, '_yoast_wpseo_meta-robots-noindex', true );
            }
            if ( ! $noindex && defined( 'RANK_MATH_VERSION' ) ) {
                $robots = get_post_meta( $post->ID, 'rank_math_robots', true );
                if ( is_array( $robots ) && in_array( 'noindex', $robots, true ) ) {
                    $noindex = true;
                }
            }
            if ( ! $noindex ) {
                $noindex = (bool) get_post_meta( $post->ID, '_arthur_ai_noindex', true );
            }
            if ( $noindex ) {
                $issues['noindex'][] = array( 'ID' => $post->ID, 'title' => $post->post_title );
            }
        }
        return array( 'success' => true, 'issues' => $issues );
    }
}
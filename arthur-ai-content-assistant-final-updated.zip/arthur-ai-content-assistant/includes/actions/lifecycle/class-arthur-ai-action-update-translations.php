<?php
/**
 * Action: Update Translations
 *
 * Triggers updates for WordPress translations, including core, plugins and themes. Uses built‑in APIs
 * available in WordPress 5.9+. Returns a summary of updated items.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Update_Translations implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'update_translations';
    }

    public function get_label() {
        return __( 'Update Translations', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        include_once ABSPATH . 'wp-admin/includes/update.php';
        include_once ABSPATH . 'wp-admin/includes/translation-install.php';

        // Update core translations.
        $core_updated = wp_update_core();
        // Update plugin translations.
        $plugin_translations = wp_update_plugins();
        // Update theme translations.
        $theme_translations  = wp_update_themes();
        // Update language packs (calls API to download translations for languages installed).
        $language_updates    = wp_update_languages();

        return array(
            'success'            => true,
            'core_updated'       => $core_updated,
            'plugin_translations'=> $plugin_translations,
            'theme_translations' => $theme_translations,
            'language_updates'   => $language_updates,
        );
    }
}
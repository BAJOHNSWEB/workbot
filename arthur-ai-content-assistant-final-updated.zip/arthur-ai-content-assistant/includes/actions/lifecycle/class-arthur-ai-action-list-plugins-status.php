<?php
/**
 * Action: List Plugins Status
 *
 * Returns a list of installed plugins with their status (active/inactive), version, auto update flag and update available.
 * This action duplicates some information from list_plugins_themes but focuses on plugin lifecycle.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_List_Plugins_Status implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'list_plugins_status';
    }

    public function get_label() {
        return __( 'List Plugins Status', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        include_once ABSPATH . 'wp-admin/includes/plugin.php';
        include_once ABSPATH . 'wp-admin/includes/update.php';

        $plugins = get_plugins();
        $updates = get_plugin_updates();
        $auto   = (array) get_site_option( 'auto_update_plugins', array() );
        $data   = array();
        foreach ( $plugins as $file => $info ) {
            $update_available = isset( $updates[ $file ] );
            $data[] = array(
                'file'           => $file,
                'name'           => $info['Name'],
                'version'        => $info['Version'],
                'status'         => is_plugin_active( $file ) ? 'active' : 'inactive',
                'auto_update'    => in_array( $file, $auto, true ),
                'update_available'=> $update_available,
            );
        }
        return array(
            'success' => true,
            'plugins' => $data,
        );
    }
}
<?php
/**
 * Action: Configure Core Auto Update Policy
 *
 * Stores a preferred core auto‑update policy (minor_only, all, none) for future reference. This action
 * does not directly modify WordPress behaviour; rather, it persists the desired policy so that site
 * administrators or future automation can apply it via filters/constants as needed.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Configure_Core_Auto_Update implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'configure_core_auto_update';
    }

    public function get_label() {
        return __( 'Configure Core Auto Update', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $policy = isset( $payload['policy'] ) ? sanitize_key( $payload['policy'] ) : 'minor_only';
        $valid  = array( 'minor_only', 'all', 'none' );
        if ( ! in_array( $policy, $valid, true ) ) {
            return array(
                'error'   => true,
                'message' => 'Invalid policy. Valid values are minor_only, all, none.',
            );
        }
        update_option( 'arthur_ai_core_auto_update_policy', $policy );
        return array(
            'success' => true,
            'policy'  => $policy,
            'message' => 'Core auto update policy saved.',
        );
    }
}
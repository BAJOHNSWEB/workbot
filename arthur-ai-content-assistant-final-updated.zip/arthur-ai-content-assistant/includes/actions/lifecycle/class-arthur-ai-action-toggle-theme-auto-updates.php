<?php
/**
 * Action: Toggle Theme Auto Updates
 *
 * Enables or disables auto updates for a theme. WordPress stores auto update preferences in the
 * 'auto_update_themes' site option.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Toggle_Theme_Auto_Updates implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'toggle_theme_auto_updates';
    }

    public function get_label() {
        return __( 'Toggle Theme Auto Updates', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        $theme   = isset( $payload['theme'] ) ? sanitize_text_field( $payload['theme'] ) : '';
        $enabled = isset( $payload['enabled'] ) ? (bool) $payload['enabled'] : false;
        if ( ! $theme ) {
            return array(
                'error'   => true,
                'message' => 'No theme specified.',
            );
        }
        $auto = (array) get_site_option( 'auto_update_themes', array() );
        if ( $enabled ) {
            if ( ! in_array( $theme, $auto, true ) ) {
                $auto[] = $theme;
            }
        } else {
            $auto = array_diff( $auto, array( $theme ) );
        }
        update_site_option( 'auto_update_themes', array_values( $auto ) );
        return array(
            'success' => true,
            'theme'   => $theme,
            'enabled' => $enabled,
        );
    }
}
<?php
/**
 * Action: Deactivate Plugins
 *
 * Deactivates one or more plugins. Accepts plugin file paths or slugs. Returns arrays of successfully
 * deactivated plugins and failures.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Deactivate_Plugins implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'deactivate_plugins';
    }

    public function get_label() {
        return __( 'Deactivate Plugins', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        include_once ABSPATH . 'wp-admin/includes/plugin.php';

        $plugins = isset( $payload['plugins'] ) && is_array( $payload['plugins'] ) ? $payload['plugins'] : array();
        if ( empty( $plugins ) ) {
            return array(
                'error'   => true,
                'message' => 'No plugins specified for deactivation.',
            );
        }
        $deactivated = array();
        $failed      = array();
        foreach ( $plugins as $identifier ) {
            $file = $this->resolve_plugin_file( $identifier );
            if ( ! $file ) {
                $failed[] = array( 'plugin' => $identifier, 'error' => 'Plugin file could not be resolved.' );
                continue;
            }
            deactivate_plugins( $file );
            // Check if deactivated.
            if ( is_plugin_active( $file ) ) {
                $failed[] = array( 'plugin' => $file, 'error' => 'Failed to deactivate.' );
            } else {
                $deactivated[] = $file;
            }
        }
        $this->log_action( $deactivated, $failed );
        return array(
            'success'    => true,
            'deactivated'=> $deactivated,
            'failed'     => $failed,
        );
    }

    protected function resolve_plugin_file( $identifier ) {
        $identifier = trim( $identifier );
        if ( strpos( $identifier, '/' ) !== false ) {
            return $identifier;
        }
        $plugins = get_plugins();
        foreach ( $plugins as $file => $data ) {
            if ( strpos( $file, $identifier . '/' ) === 0 ) {
                return $file;
            }
        }
        return null;
    }

    protected function log_action( array $deactivated, array $failed ) {
        $log = get_option( 'arthur_ai_action_log', array() );
        $log[] = array(
            'timestamp'    => current_time( 'mysql' ),
            'user_id'      => get_current_user_id(),
            'action'       => 'deactivate_plugins',
            'deactivated'  => $deactivated,
            'failed'       => $failed,
        );
        update_option( 'arthur_ai_action_log', $log );
    }
}
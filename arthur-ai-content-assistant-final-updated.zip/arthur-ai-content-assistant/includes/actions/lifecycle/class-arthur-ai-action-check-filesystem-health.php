<?php
/**
 * Action: Check Filesystem Health
 *
 * Performs a simple filesystem health check to determine whether the WordPress environment has appropriate
 * permissions for updates. Reports on key directories like wp-content, plugins, themes, and uploads.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Check_Filesystem_Health implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'check_filesystem_health';
    }

    public function get_label() {
        return __( 'Check Filesystem Health', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        // Directories to check.
        $dirs = array(
            'wp_content' => WP_CONTENT_DIR,
            'plugins'    => WP_PLUGIN_DIR,
            'themes'     => get_theme_root(),
        );
        $wp_uploads = wp_upload_dir( null, false );
        if ( ! empty( $wp_uploads['basedir'] ) ) {
            $dirs['uploads'] = $wp_uploads['basedir'];
        }

        $results = array();
        foreach ( $dirs as $key => $path ) {
            $writable = is_writable( $path );
            $results[ $key ] = array(
                'path'     => $path,
                'writable' => $writable,
            );
        }
        return array(
            'success' => true,
            'paths'   => $results,
        );
    }
}
<?php
/**
 * Action: Install Theme
 *
 * Installs a theme from the WordPress.org repository or from a provided zip URL. Accepts a theme slug
 * or a direct URL to a zip file. Utilises the Theme_Upgrader class. If the theme is already installed,
 * it will not be reinstalled.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Install_Theme implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'install_theme';
    }

    public function get_label() {
        return __( 'Install Theme', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        include_once ABSPATH . 'wp-admin/includes/theme.php';
        include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        include_once ABSPATH . 'wp-admin/includes/file.php';
        include_once ABSPATH . 'wp-admin/includes/misc.php';

        $slug   = isset( $payload['slug'] ) ? sanitize_key( $payload['slug'] ) : '';
        $zip    = isset( $payload['zip_url'] ) ? esc_url_raw( $payload['zip_url'] ) : '';
        if ( ! $slug && ! $zip ) {
            return array(
                'error'   => true,
                'message' => 'A theme slug or zip_url must be provided.',
            );
        }
        // If theme already installed, skip installation.
        if ( $slug && wp_get_theme( $slug )->exists() ) {
            return array(
                'success' => true,
                'message' => 'Theme already installed.',
                'theme'   => $slug,
            );
        }
        $upgrader = new Theme_Upgrader( new Automatic_Upgrader_Skin() );
        $result   = false;
        if ( $zip ) {
            $result = $upgrader->install( $zip );
        } elseif ( $slug ) {
            // Fetch theme info from wp.org API.
            $api = themes_api( 'theme_information', array( 'slug' => $slug, 'fields' => array( 'sections' => false ) ) );
            if ( is_wp_error( $api ) ) {
                return array(
                    'error'   => true,
                    'message' => 'Error retrieving theme information: ' . $api->get_error_message(),
                );
            }
            $result = $upgrader->install( $api->download_link );
        }
        if ( is_wp_error( $result ) ) {
            return array(
                'error'   => true,
                'message' => 'Theme installation failed: ' . $result->get_error_message(),
            );
        }
        // Flush caches after installation.
        wp_clean_themes_cache();
        return array(
            'success' => true,
            'message' => 'Theme installed successfully.',
        );
    }
}
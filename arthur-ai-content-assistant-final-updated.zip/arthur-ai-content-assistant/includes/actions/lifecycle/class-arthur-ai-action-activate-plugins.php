<?php
/**
 * Action: Activate Plugins
 *
 * Activates one or more plugins. Requires valid plugin file paths or slugs. Slugs will be resolved
 * to the first matching plugin file within the plugins directory. Returns lists of activated and failed plugins.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Activate_Plugins implements Arthur_AI_Action_Interface {

    /**
     * {@inheritDoc}
     */
    public function get_type() {
        return 'activate_plugins';
    }

    /**
     * {@inheritDoc}
     */
    public function get_label() {
        return __( 'Activate Plugins', 'arthur-ai' );
    }

    /**
     * Activate the specified plugins.
     *
     * @param array $payload {
     *     @type array $plugins Array of plugin file paths or slugs to activate.
     *     @type bool  $network Optional. Activate network wide on multisite. Default false.
     * }
     * @return array
     */
    public function execute( array $payload ) {
        include_once ABSPATH . 'wp-admin/includes/plugin.php';
        include_once ABSPATH . 'wp-admin/includes/update.php';

        $plugins      = isset( $payload['plugins'] ) && is_array( $payload['plugins'] ) ? $payload['plugins'] : array();
        $network      = isset( $payload['network'] ) ? (bool) $payload['network'] : false;

        if ( empty( $plugins ) ) {
            return array(
                'error'   => true,
                'message' => 'No plugins specified for activation.',
            );
        }

        $activated = array();
        $failed    = array();

        foreach ( $plugins as $plugin_identifier ) {
            $plugin_file = $this->resolve_plugin_file( $plugin_identifier );
            if ( ! $plugin_file ) {
                $failed[] = array( 'plugin' => $plugin_identifier, 'error' => 'Plugin file could not be resolved.' );
                continue;
            }
            $result = activate_plugin( $plugin_file, '', $network );
            if ( is_wp_error( $result ) ) {
                $failed[] = array( 'plugin' => $plugin_file, 'error' => $result->get_error_message() );
            } else {
                $activated[] = $plugin_file;
            }
        }

        // Log the action.
        $this->log_action( $activated, $failed );

        return array(
            'success'   => true,
            'activated' => $activated,
            'failed'    => $failed,
        );
    }

    /**
     * Resolve a plugin identifier to its plugin file path.
     * Accepts either a plugin file path (e.g. plugin-folder/plugin.php) or a slug (plugin-folder).
     *
     * @param string $identifier
     * @return string|null
     */
    protected function resolve_plugin_file( $identifier ) {
        $identifier = trim( $identifier );
        // If identifier contains a slash, assume it's already a plugin file.
        if ( false !== strpos( $identifier, '/' ) ) {
            return $identifier;
        }
        // Otherwise, look for the first file in the plugin directory matching the slug.
        $plugins = get_plugins();
        foreach ( $plugins as $file => $data ) {
            if ( strpos( $file, $identifier . '/' ) === 0 ) {
                return $file;
            }
        }
        return null;
    }

    /**
     * Log activation attempt.
     *
     * @param array $activated
     * @param array $failed
     */
    protected function log_action( array $activated, array $failed ) {
        $log = get_option( 'arthur_ai_action_log', array() );
        $log[] = array(
            'timestamp' => current_time( 'mysql' ),
            'user_id'   => get_current_user_id(),
            'action'    => 'activate_plugins',
            'activated' => $activated,
            'failed'    => $failed,
        );
        update_option( 'arthur_ai_action_log', $log );
    }
}
<?php
/**
 * Action: Update WordPress Core
 *
 * Performs a WordPress core update. Allows specifying whether to apply only minor updates or all available
 * updates. Runs through the Core_Upgrader API and returns the outcome. If no updates are available, returns
 * a message indicating so. This action may take a while to run; ensure appropriate timeouts are handled by
 * the calling environment.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Update_Core implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'update_core';
    }

    public function get_label() {
        return __( 'Update WordPress Core', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        include_once ABSPATH . 'wp-admin/includes/update.php';
        include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

        $channel = isset( $payload['channel'] ) ? sanitize_key( $payload['channel'] ) : 'minor_only';

        // Check for core updates.
        wp_version_check();
        $updates = get_core_updates();
        if ( empty( $updates ) || ! is_array( $updates ) ) {
            return array(
                'success' => true,
                'message' => 'WordPress is already up to date.',
            );
        }

        // Determine which update to apply.
        $update_to_apply = null;
        foreach ( $updates as $update ) {
            /* @var object $update */
            if ( 'minor_only' === $channel ) {
                // Apply only maintenance or minor updates (version like 6.2.X).
                if ( $update->response === 'upgrade' && strpos( $update->current, wp_get_update_php_version() ) === 0 ) {
                    $update_to_apply = $update;
                    break;
                }
            } else {
                // For 'major' or 'all' channels, take the first update.
                $update_to_apply = $update;
                break;
            }
        }

        if ( ! $update_to_apply ) {
            return array(
                'success' => true,
                'message' => 'No applicable core update found for the selected channel.',
            );
        }

        // Perform the update.
        $upgrader = new Core_Upgrader( new Automatic_Upgrader_Skin() );
        $result   = $upgrader->upgrade( $update_to_apply );
        if ( is_wp_error( $result ) ) {
            return array(
                'error'   => true,
                'message' => 'Core update failed: ' . $result->get_error_message(),
            );
        }
        return array(
            'success'    => true,
            'message'    => 'WordPress core updated successfully.',
            'new_version'=> $update_to_apply->current,
        );
    }
}
<?php
/**
 * Action: Delete Plugins
 *
 * Permanently deletes one or more plugins. Requires confirmation to proceed. Returns the list of deleted
 * plugins and any failures. If no plugins are specified or confirmation is missing, no action is taken.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Delete_Plugins implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'delete_plugins';
    }

    public function get_label() {
        return __( 'Delete Plugins', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        include_once ABSPATH . 'wp-admin/includes/plugin.php';

        $plugins  = isset( $payload['plugins'] ) && is_array( $payload['plugins'] ) ? $payload['plugins'] : array();
        $confirm  = ! empty( $payload['confirm'] );
        if ( empty( $plugins ) ) {
            return array(
                'error'   => true,
                'message' => 'No plugins specified for deletion.',
            );
        }
        if ( ! $confirm ) {
            return array(
                'error'   => true,
                'message' => 'Deletion requires confirmation. Set confirm=true to proceed.',
            );
        }
        $deleted = array();
        $failed  = array();
        foreach ( $plugins as $identifier ) {
            $file = $this->resolve_plugin_file( $identifier );
            if ( ! $file ) {
                $failed[] = array( 'plugin' => $identifier, 'error' => 'Plugin file could not be resolved.' );
                continue;
            }
            $result = delete_plugins( array( $file ) );
            if ( is_wp_error( $result ) ) {
                $failed[] = array( 'plugin' => $file, 'error' => $result->get_error_message() );
            } else {
                $deleted[] = $file;
            }
        }
        $this->log_action( $deleted, $failed );
        return array(
            'success' => true,
            'deleted' => $deleted,
            'failed'  => $failed,
        );
    }

    protected function resolve_plugin_file( $identifier ) {
        $identifier = trim( $identifier );
        if ( strpos( $identifier, '/' ) !== false ) {
            return $identifier;
        }
        $plugins = get_plugins();
        foreach ( $plugins as $file => $data ) {
            if ( strpos( $file, $identifier . '/' ) === 0 ) {
                return $file;
            }
        }
        return null;
    }

    protected function log_action( array $deleted, array $failed ) {
        $log = get_option( 'arthur_ai_action_log', array() );
        $log[] = array(
            'timestamp' => current_time( 'mysql' ),
            'user_id'   => get_current_user_id(),
            'action'    => 'delete_plugins',
            'deleted'   => $deleted,
            'failed'    => $failed,
        );
        update_option( 'arthur_ai_action_log', $log );
    }
}
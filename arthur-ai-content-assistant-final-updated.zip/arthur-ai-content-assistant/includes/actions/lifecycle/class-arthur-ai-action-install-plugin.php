<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Install a WordPress plugin from the official repository or a ZIP file.
 *
 * This action uses WordPress’s Plugin_Upgrader to download and install
 * a plugin given either a repository slug or a URL/file path to a ZIP
 * package. It detects if the plugin is already installed and returns
 * a structured result. Automatic activation is not performed here –
 * use the activate_plugins action to enable plugins after installation.
 */
class Arthur_AI_Action_Install_Plugin implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'install_plugin';
    }

    public function get_label() {
        return __( 'Install Plugin', 'arthur-ai' );
    }

    /**
     * Execute the plugin installation.
     *
     * @param array $payload {
     *     @type string $slug     Plugin slug from WordPress.org repository.
     *     @type string $source   URL or local path to a ZIP package (alternative to slug).
     * }
     * @return array Result of installation.
     */
    public function execute( array $payload ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        $slug   = isset( $payload['slug'] ) ? sanitize_key( $payload['slug'] ) : '';
        $source = isset( $payload['source'] ) ? $payload['source'] : '';
        if ( empty( $slug ) && empty( $source ) ) {
            return array( 'success' => false, 'message' => __( 'No plugin slug or source provided.', 'arthur-ai' ) );
        }
        $result = array();
        // Check if plugin already installed.
        $plugins = get_plugins();
        foreach ( $plugins as $file => $data ) {
            $plugin_slug = dirname( $file );
            if ( $slug && $plugin_slug === $slug ) {
                return array( 'success' => true, 'message' => __( 'Plugin already installed.', 'arthur-ai' ), 'plugin_file' => $file );
            }
        }
        // Prepare upgrader.
        $skin     = new Automatic_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader( $skin );
        if ( $slug ) {
            // Fetch plugin info from API.
            $api = plugins_api( 'plugin_information', array( 'slug' => $slug, 'fields' => array( 'sections' => false ) ) );
            if ( is_wp_error( $api ) ) {
                return array( 'success' => false, 'message' => $api->get_error_message() );
            }
            $package = $api->download_link;
        } else {
            // Use provided source (URL or local path).
            $package = $source;
        }
        $installed = $upgrader->install( $package );
        if ( is_wp_error( $installed ) ) {
            return array( 'success' => false, 'message' => $installed->get_error_message() );
        }
        // After install, find the plugin file.
        $plugins = get_plugins();
        $installed_file = '';
        foreach ( $plugins as $file => $data ) {
            $plugin_slug = dirname( $file );
            if ( ( $slug && $plugin_slug === $slug ) || ( ! $slug && strpos( $file, basename( $package, '.zip' ) ) !== false ) ) {
                $installed_file = $file;
                break;
            }
        }
        return array( 'success' => true, 'message' => __( 'Plugin installed successfully.', 'arthur-ai' ), 'plugin_file' => $installed_file );
    }
}
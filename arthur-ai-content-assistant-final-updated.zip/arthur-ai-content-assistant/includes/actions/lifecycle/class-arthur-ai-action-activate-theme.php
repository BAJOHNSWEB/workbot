<?php
/**
 * Action: Activate Theme
 *
 * Activates the specified theme. Accepts a stylesheet (directory name). Ensures the theme exists and
 * is not already active.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Activate_Theme implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'activate_theme';
    }

    public function get_label() {
        return __( 'Activate Theme', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        include_once ABSPATH . 'wp-admin/includes/theme.php';
        $stylesheet = isset( $payload['theme'] ) ? sanitize_text_field( $payload['theme'] ) : '';
        if ( ! $stylesheet ) {
            return array(
                'error'   => true,
                'message' => 'No theme specified to activate.',
            );
        }
        $theme = wp_get_theme( $stylesheet );
        if ( ! $theme->exists() ) {
            return array(
                'error'   => true,
                'message' => 'Theme does not exist.',
            );
        }
        if ( $theme->stylesheet === get_stylesheet() ) {
            return array(
                'success' => true,
                'message' => 'Theme is already active.',
            );
        }
        switch_theme( $theme->stylesheet );
        return array(
            'success' => true,
            'message' => 'Theme activated.',
            'theme'   => $theme->stylesheet,
        );
    }
}
<?php
/**
 * Action: Delete Theme
 *
 * Deletes an installed theme. The active theme cannot be deleted. Requires confirmation flag.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Delete_Theme implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'delete_theme';
    }

    public function get_label() {
        return __( 'Delete Theme', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        include_once ABSPATH . 'wp-admin/includes/theme.php';
        $stylesheet = isset( $payload['theme'] ) ? sanitize_text_field( $payload['theme'] ) : '';
        $confirm    = ! empty( $payload['confirm'] );
        if ( ! $stylesheet ) {
            return array(
                'error'   => true,
                'message' => 'No theme specified to delete.',
            );
        }
        if ( ! $confirm ) {
            return array(
                'error'   => true,
                'message' => 'Deletion requires confirmation. Set confirm=true to proceed.',
            );
        }
        $theme = wp_get_theme( $stylesheet );
        if ( ! $theme->exists() ) {
            return array(
                'error'   => true,
                'message' => 'Theme does not exist.',
            );
        }
        if ( $theme->stylesheet === get_stylesheet() ) {
            return array(
                'error'   => true,
                'message' => 'Cannot delete the active theme.',
            );
        }
        $deleted = delete_theme( $stylesheet );
        if ( is_wp_error( $deleted ) ) {
            return array(
                'error'   => true,
                'message' => $deleted->get_error_message(),
            );
        }
        return array(
            'success' => true,
            'message' => 'Theme deleted.',
            'theme'   => $stylesheet,
        );
    }
}
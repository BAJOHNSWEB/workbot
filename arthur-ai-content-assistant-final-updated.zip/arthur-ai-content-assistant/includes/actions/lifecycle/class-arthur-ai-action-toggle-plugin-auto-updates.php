<?php
/**
 * Action: Toggle Plugin Auto Updates
 *
 * Enables or disables auto updates for a specified plugin. The plugin must be referenced by its file
 * identifier (folder/file.php). WordPress stores auto update preferences in the 'auto_update_plugins'
 * site option.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Action_Toggle_Plugin_Auto_Updates implements Arthur_AI_Action_Interface {

    public function get_type() {
        return 'toggle_plugin_auto_updates';
    }

    public function get_label() {
        return __( 'Toggle Plugin Auto Updates', 'arthur-ai' );
    }

    public function execute( array $payload ) {
        if ( empty( $payload['plugin'] ) ) {
            return array(
                'error'   => true,
                'message' => 'No plugin specified.',
            );
        }
        $plugin = $payload['plugin'];
        $enabled = isset( $payload['enabled'] ) ? (bool) $payload['enabled'] : false;
        $auto_updates = (array) get_site_option( 'auto_update_plugins', array() );
        if ( $enabled ) {
            if ( ! in_array( $plugin, $auto_updates, true ) ) {
                $auto_updates[] = $plugin;
            }
        } else {
            $auto_updates = array_diff( $auto_updates, array( $plugin ) );
        }
        update_site_option( 'auto_update_plugins', array_values( $auto_updates ) );
        // Log the change.
        $log = get_option( 'arthur_ai_action_log', array() );
        $log[] = array(
            'timestamp' => current_time( 'mysql' ),
            'user_id'   => get_current_user_id(),
            'action'    => 'toggle_plugin_auto_updates',
            'plugin'    => $plugin,
            'enabled'   => $enabled,
        );
        update_option( 'arthur_ai_action_log', $log );
        return array(
            'success' => true,
            'plugin'  => $plugin,
            'enabled' => $enabled,
            'message' => $enabled ? 'Auto updates enabled.' : 'Auto updates disabled.',
        );
    }
}
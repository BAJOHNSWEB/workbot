<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Applies Arthur AI admin customisation options across the WordPress admin.
 *
 * This class outputs CSS to change colours for the admin toolbar and
 * side menu, applies a custom admin footer message and injects any
 * custom CSS. The options are configured by the corresponding
 * AI actions and stored using update_option().
 */
class Arthur_AI_Admin_Customiser {

    /**
     * Initialise hooks for admin customisation.
     */
    public static function init() {
        // Output CSS for toolbar, menu and custom CSS on every admin page.
        add_action( 'admin_head', array( __CLASS__, 'output_admin_styles' ) );
        // Override the footer text if provided.
        add_filter( 'admin_footer_text', array( __CLASS__, 'filter_admin_footer_text' ), 100 );

        // Customise the admin menu structure and items.
        add_action( 'admin_menu', array( __CLASS__, 'customise_admin_menu' ), 100 );
    }

    /**
     * Emit a style tag containing admin custom CSS based on stored options.
     */
    public static function output_admin_styles() {
        // Toolbar colour settings
        $toolbar_colors = get_option( 'arthur_ai_admin_toolbar_colors', array() );
        if ( ! is_array( $toolbar_colors ) ) {
            $toolbar_colors = array();
        }
        $tb_bg         = isset( $toolbar_colors['toolbar_background'] ) ? sanitize_text_field( $toolbar_colors['toolbar_background'] ) : '';
        $tb_text       = isset( $toolbar_colors['toolbar_text'] ) ? sanitize_text_field( $toolbar_colors['toolbar_text'] ) : '';
        $tb_hover_bg   = isset( $toolbar_colors['toolbar_hover_background'] ) ? sanitize_text_field( $toolbar_colors['toolbar_hover_background'] ) : '';
        $tb_hover_text = isset( $toolbar_colors['toolbar_hover_text'] ) ? sanitize_text_field( $toolbar_colors['toolbar_hover_text'] ) : '';

        // Menu colour settings
        $menu_colors = get_option( 'arthur_ai_admin_menu_colors', array() );
        if ( ! is_array( $menu_colors ) ) {
            $menu_colors = array();
        }
        $menu_bg         = isset( $menu_colors['menu_background'] ) ? sanitize_text_field( $menu_colors['menu_background'] ) : '';
        $menu_text       = isset( $menu_colors['menu_text'] ) ? sanitize_text_field( $menu_colors['menu_text'] ) : '';
        $menu_hover_bg   = isset( $menu_colors['menu_hover_background'] ) ? sanitize_text_field( $menu_colors['menu_hover_background'] ) : '';
        $menu_hover_text = isset( $menu_colors['menu_hover_text'] ) ? sanitize_text_field( $menu_colors['menu_hover_text'] ) : '';

        // Custom CSS
        $custom_css = (string) get_option( 'arthur_ai_admin_custom_css', '' );

        // Only output styles when there is something to change.
        if ( empty( $tb_bg ) && empty( $tb_text ) && empty( $tb_hover_bg ) && empty( $tb_hover_text )
            && empty( $menu_bg ) && empty( $menu_text ) && empty( $menu_hover_bg ) && empty( $menu_hover_text )
            && empty( $custom_css ) ) {
            return;
        }

        ?>
        <style type="text/css">
            <?php if ( $tb_bg || $tb_text || $tb_hover_bg || $tb_hover_text ) : ?>
            /* Admin toolbar colours applied by Arthur AI */
            #wpadminbar {
                <?php if ( $tb_bg ) : ?>background-color: <?php echo esc_attr( $tb_bg ); ?> !important;<?php endif; ?>
                <?php if ( $tb_text ) : ?>color: <?php echo esc_attr( $tb_text ); ?> !important;<?php endif; ?>
            }
            <?php if ( $tb_text ) : ?>
            #wpadminbar * {
                color: <?php echo esc_attr( $tb_text ); ?> !important;
            }
            <?php endif; ?>
            <?php if ( $tb_hover_bg || $tb_hover_text ) : ?>
            #wpadminbar .ab-top-menu > li > .ab-item:hover, #wpadminbar .ab-top-menu > li.hover > .ab-item {
                <?php if ( $tb_hover_bg ) : ?>background-color: <?php echo esc_attr( $tb_hover_bg ); ?> !important;<?php endif; ?>
                <?php if ( $tb_hover_text ) : ?>color: <?php echo esc_attr( $tb_hover_text ); ?> !important;<?php endif; ?>
            }
            <?php endif; ?>
            <?php endif; ?>

            <?php if ( $menu_bg || $menu_text || $menu_hover_bg || $menu_hover_text ) : ?>
            /* Admin menu colours applied by Arthur AI */
            #adminmenu, #adminmenu .wp-submenu, #adminmenuback, #adminmenuwrap {
                <?php if ( $menu_bg ) : ?>background-color: <?php echo esc_attr( $menu_bg ); ?> !important;<?php endif; ?>
            }
            <?php if ( $menu_text ) : ?>
            #adminmenu a, #adminmenu .wp-submenu a {
                color: <?php echo esc_attr( $menu_text ); ?> !important;
            }
            <?php endif; ?>
            <?php if ( $menu_hover_bg || $menu_hover_text ) : ?>
            #adminmenu li.menu-top:hover > a, #adminmenu li.menu-top.focus > a, #adminmenu li.menu-top.current > a {
                <?php if ( $menu_hover_bg ) : ?>background-color: <?php echo esc_attr( $menu_hover_bg ); ?> !important;<?php endif; ?>
                <?php if ( $menu_hover_text ) : ?>color: <?php echo esc_attr( $menu_hover_text ); ?> !important;<?php endif; ?>
            }
            #adminmenu .wp-submenu a:hover {
                <?php if ( $menu_hover_text ) : ?>color: <?php echo esc_attr( $menu_hover_text ); ?> !important;<?php endif; ?>
            }
            <?php endif; ?>
            <?php endif; ?>

            <?php if ( ! empty( $custom_css ) ) : ?>
            /* Custom admin CSS from Arthur AI */
            <?php echo $custom_css; // trusted admin input ?>
            <?php endif; ?>

            <?php
            // Collapse menu by default if configured. This adds the "folded" class
            // to the body element on page load. Using JavaScript avoids altering
            // user meta and applies immediately.
            $collapse_menu = get_option( 'arthur_ai_admin_collapse_menu', false );
            if ( $collapse_menu ) :
            ?>
            </style>
            <script type="text/javascript">
            (function() {
                document.addEventListener('DOMContentLoaded', function() {
                    document.body.classList.add('folded');
                });
            })();
            </script>
            <style type="text/css">
            <?php endif; ?>
        </style>
        <?php
    }

    /**
     * Override the admin footer text if a custom one has been set.
     *
     * @param string $text Existing footer text.
     * @return string Modified footer text.
     */
    public static function filter_admin_footer_text( $text ) {
        $footer = (string) get_option( 'arthur_ai_admin_footer_text', '' );
        if ( '' === trim( $footer ) ) {
            return $text;
        }
        return wp_kses_post( $footer );
    }

    /**
     * Customise the admin menu structure by hiding, renaming, reordering and
     * adding pages based on stored AI options. Runs on the admin_menu hook.
     */
    public static function customise_admin_menu() {
        global $menu, $submenu;

        // Hide menu items globally
        $hidden = get_option( 'arthur_ai_admin_hidden_menus', array() );
        if ( is_string( $hidden ) ) {
            $hidden = array( $hidden );
        }
        if ( is_array( $hidden ) ) {
            foreach ( $hidden as $slug ) {
                if ( ! empty( $slug ) ) {
                    remove_menu_page( $slug );
                }
            }
        }

        // Hide menu items by user role
        $hidden_by_role = get_option( 'arthur_ai_admin_hidden_menus_by_role', array() );
        if ( is_array( $hidden_by_role ) && ! empty( $hidden_by_role ) ) {
            $current_user = wp_get_current_user();
            $roles        = is_array( $current_user->roles ) ? $current_user->roles : array();
            foreach ( $roles as $role ) {
                if ( isset( $hidden_by_role[ $role ] ) && is_array( $hidden_by_role[ $role ] ) ) {
                    foreach ( $hidden_by_role[ $role ] as $slug ) {
                        if ( ! empty( $slug ) ) {
                            remove_menu_page( $slug );
                        }
                    }
                }
            }
        }

        // Rename menu items
        $renames = get_option( 'arthur_ai_admin_renamed_menus', array() );
        if ( is_array( $renames ) && ! empty( $renames ) && is_array( $menu ) ) {
            foreach ( $menu as $index => $item ) {
                // Each menu item is array: 0 => menu title, 2 => slug
                if ( isset( $item[2] ) && isset( $renames[ $item[2] ] ) ) {
                    $new_title        = sanitize_text_field( $renames[ $item[2] ] );
                    $menu[ $index ][0] = $new_title;
                    // Also update page title at index 3 if set
                    if ( isset( $menu[ $index ][3] ) ) {
                        $menu[ $index ][3] = $new_title;
                    }
                }
            }
        }

        // Reorder menu items
        $order = get_option( 'arthur_ai_admin_menu_order', array() );
        if ( is_array( $order ) && ! empty( $order ) && is_array( $menu ) ) {
            $ordered = array();
            // Build new ordered list
            foreach ( $order as $slug ) {
                foreach ( $menu as $key => $item ) {
                    if ( isset( $item[2] ) && $item[2] === $slug ) {
                        $ordered[] = $item;
                        unset( $menu[ $key ] );
                        break;
                    }
                }
            }

            // Settings position override
            $settings_pos = get_option( 'arthur_ai_admin_settings_position', null );
            if ( null !== $settings_pos ) {
                // find settings item slug
                $settings_slug = 'options-general.php';
                $settings_item = null;
                // Search in ordered
                foreach ( $ordered as $i => $itm ) {
                    if ( isset( $itm[2] ) && $itm[2] === $settings_slug ) {
                        $settings_item = $itm;
                        unset( $ordered[ $i ] );
                        break;
                    }
                }
                if ( ! $settings_item ) {
                    // Search in remaining menu
                    foreach ( $menu as $i => $itm ) {
                        if ( isset( $itm[2] ) && $itm[2] === $settings_slug ) {
                            $settings_item = $itm;
                            unset( $menu[ $i ] );
                            break;
                        }
                    }
                }
                if ( $settings_item ) {
                    $pos = intval( $settings_pos );
                    if ( $pos < 1 ) {
                        $pos = 1;
                    }
                    // Convert to zero‑based index
                    $insert_idx = $pos - 1;
                    // Reindex ordered to fill numeric keys
                    $ordered = array_values( $ordered );
                    array_splice( $ordered, $insert_idx, 0, array( $settings_item ) );
                }
            }

            // Append remaining original menu items
            foreach ( $menu as $item ) {
                $ordered[] = $item;
            }
            // Reassign
            $menu = $ordered;
        }

        // Load custom pages from option and register via add_menu_page.
        $custom_pages = get_option( 'arthur_ai_admin_custom_pages', array() );
        if ( is_array( $custom_pages ) ) {
            foreach ( $custom_pages as $page ) {
                if ( empty( $page['menu_slug'] ) ) {
                    continue;
                }
                $page_slug  = sanitize_key( $page['menu_slug'] );
                $page_title = isset( $page['page_title'] ) ? wp_kses_post( $page['page_title'] ) : '';
                $menu_title = isset( $page['menu_title'] ) ? wp_kses_post( $page['menu_title'] ) : $page_title;
                $capability = isset( $page['capability'] ) ? sanitize_text_field( $page['capability'] ) : 'manage_options';
                $icon       = isset( $page['icon'] ) ? sanitize_text_field( $page['icon'] ) : '';
                $position   = isset( $page['position'] ) ? intval( $page['position'] ) : null;
                $content    = isset( $page['content'] ) ? $page['content'] : '';
                // Store content for callback lookup
                self::$custom_pages_storage[ $page_slug ] = array(
                    'content' => $content,
                );
                // Register the page
                add_menu_page( $page_title, $menu_title, $capability, $page_slug, array( __CLASS__, 'render_custom_page' ), $icon, $position );
            }
        }

        // Load custom subpages from option and register via add_submenu_page.
        $custom_subpages = get_option( 'arthur_ai_admin_custom_subpages', array() );
        if ( is_array( $custom_subpages ) ) {
            foreach ( $custom_subpages as $sub ) {
                if ( empty( $sub['parent_slug'] ) || empty( $sub['menu_slug'] ) ) {
                    continue;
                }
                $parent_slug = sanitize_key( $sub['parent_slug'] );
                $submenu_slug = sanitize_key( $sub['menu_slug'] );
                $page_title = isset( $sub['page_title'] ) ? wp_kses_post( $sub['page_title'] ) : '';
                $menu_title = isset( $sub['menu_title'] ) ? wp_kses_post( $sub['menu_title'] ) : $page_title;
                $capability = isset( $sub['capability'] ) ? sanitize_text_field( $sub['capability'] ) : 'manage_options';
                $content    = isset( $sub['content'] ) ? $sub['content'] : '';
                // Store content
                self::$custom_subpages_storage[ $submenu_slug ] = array(
                    'content' => $content,
                );
                add_submenu_page( $parent_slug, $page_title, $menu_title, $capability, $submenu_slug, array( __CLASS__, 'render_custom_subpage' ) );
            }
        }
    }

    /**
     * Storage for custom menu page content indexed by slug.
     * @var array
     */
    protected static $custom_pages_storage = array();

    /**
     * Storage for custom submenu page content indexed by slug.
     * @var array
     */
    protected static $custom_subpages_storage = array();

    /**
     * Callback to render a custom admin page. Retrieves the stored
     * content and outputs it. If none is found for the slug, nothing
     * is output.
     */
    public static function render_custom_page() {
        $slug = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
        if ( isset( self::$custom_pages_storage[ $slug ] ) ) {
            $data = self::$custom_pages_storage[ $slug ];
            if ( ! empty( $data['content'] ) ) {
                // Echo trusted HTML content
                echo wp_kses_post( $data['content'] );
            }
        }
    }

    /**
     * Callback to render a custom admin submenu page.
     */
    public static function render_custom_subpage() {
        $slug = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
        if ( isset( self::$custom_subpages_storage[ $slug ] ) ) {
            $data = self::$custom_subpages_storage[ $slug ];
            if ( ! empty( $data['content'] ) ) {
                echo wp_kses_post( $data['content'] );
            }
        }
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Applies profile and user account related customisations configured via AI actions.
 *
 * This class handles renaming roles, creating custom roles, hiding core fields,
 * adding custom profile fields, login/logout redirects and admin bar visibility
 * for non‑admin users. It reads configuration from options written by the
 * corresponding Arthur_AI_Action classes.
 */
class Arthur_AI_Profile_Customiser {

    /**
     * Initialise hooks.
     */
    public static function init() {
        // Apply role label overrides and custom roles on init.
        add_action( 'init', array( __CLASS__, 'apply_role_overrides' ), 5 );
        add_action( 'init', array( __CLASS__, 'register_custom_roles' ), 6 );

        // Render and save custom profile fields.
        add_action( 'show_user_profile', array( __CLASS__, 'render_custom_profile_fields' ) );
        add_action( 'edit_user_profile', array( __CLASS__, 'render_custom_profile_fields' ) );
        add_action( 'personal_options_update', array( __CLASS__, 'save_custom_profile_fields' ) );
        add_action( 'edit_user_profile_update', array( __CLASS__, 'save_custom_profile_fields' ) );

        // Hide specified profile fields using CSS.
        add_action( 'admin_head-profile.php', array( __CLASS__, 'output_hidden_fields_css' ) );
        add_action( 'admin_head-user-edit.php', array( __CLASS__, 'output_hidden_fields_css' ) );

        // Redirect on login and logout.
        add_filter( 'login_redirect', array( __CLASS__, 'filter_login_redirect' ), 10, 3 );
        add_action( 'wp_logout', array( __CLASS__, 'handle_logout_redirect' ) );

        // Disable admin bar for non‑admins.
        add_filter( 'show_admin_bar', array( __CLASS__, 'filter_show_admin_bar' ) );
    }

    /**
     * Apply user role display name overrides stored in arthur_ai_role_label_overrides.
     */
    public static function apply_role_overrides() {
        $overrides = get_option( 'arthur_ai_role_label_overrides', array() );
        if ( ! is_array( $overrides ) || empty( $overrides ) ) {
            return;
        }
        global $wp_roles;
        if ( ! isset( $wp_roles ) || ! $wp_roles instanceof WP_Roles ) {
            $wp_roles = wp_roles();
        }
        foreach ( $overrides as $role_key => $label ) {
            $role_key = sanitize_key( $role_key );
            $label    = sanitize_text_field( (string) $label );
            if ( '' === $role_key || '' === $label ) {
                continue;
            }
            if ( ! empty( $wp_roles->roles[ $role_key ] ) ) {
                $wp_roles->roles[ $role_key ]['name'] = $label;
                $wp_roles->role_names[ $role_key ]     = $label;
            }
        }
    }

    /**
     * Register custom roles stored in arthur_ai_custom_roles. Ensures roles
     * persist across requests.
     */
    public static function register_custom_roles() {
        $custom = get_option( 'arthur_ai_custom_roles', array() );
        if ( ! is_array( $custom ) || empty( $custom ) ) {
            return;
        }
        foreach ( $custom as $role_key => $def ) {
            $role_key = sanitize_key( $role_key );
            $label    = isset( $def['label'] ) ? sanitize_text_field( (string) $def['label'] ) : '';
            $caps     = isset( $def['capabilities'] ) && is_array( $def['capabilities'] ) ? $def['capabilities'] : array();
            if ( '' === $role_key || '' === $label ) {
                continue;
            }
            // Add role if not exists. WordPress will ignore duplicates.
            add_role( $role_key, $label, $caps );
        }
    }

    /**
     * Output additional custom fields on the user profile screens.
     *
     * @param WP_User $user The user object being edited.
     */
    public static function render_custom_profile_fields( $user ) {
        $fields = get_option( 'arthur_ai_custom_profile_fields', array() );
        if ( ! is_array( $fields ) || empty( $fields ) ) {
            return;
        }
        echo '<h2>' . esc_html__( 'Additional Profile Information', 'arthur-ai' ) . '</h2>';
        echo '<table class="form-table" role="presentation">';
        foreach ( $fields as $field ) {
            $id    = isset( $field['id'] ) ? sanitize_key( (string) $field['id'] ) : '';
            $label = isset( $field['label'] ) ? (string) $field['label'] : $id;
            $type  = isset( $field['type'] ) ? (string) $field['type'] : 'text';
            if ( '' === $id ) {
                continue;
            }
            $value = get_user_meta( $user->ID, $id, true );
            echo '<tr class="arthur-ai-profile-field arthur-ai-profile-field-' . esc_attr( $id ) . '">';
            echo '<th><label for="arthur_ai_pf_' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label></th>';
            echo '<td>';
            if ( 'textarea' === $type ) {
                echo '<textarea name="arthur_ai_pf[' . esc_attr( $id ) . ']" id="arthur_ai_pf_' . esc_attr( $id ) . '" rows="5" class="regular-text" style="width:100%;">' . esc_textarea( $value ) . '</textarea>';
            } else {
                echo '<input type="text" name="arthur_ai_pf[' . esc_attr( $id ) . ']" id="arthur_ai_pf_' . esc_attr( $id ) . '" value="' . esc_attr( $value ) . '" class="regular-text" style="width:100%;" />';
            }
            echo '</td></tr>';
        }
        echo '</table>';
    }

    /**
     * Save custom profile fields when a user profile is updated.
     *
     * @param int $user_id The ID of the user being saved.
     */
    public static function save_custom_profile_fields( $user_id ) {
        if ( ! current_user_can( 'edit_user', $user_id ) ) {
            return;
        }
        if ( isset( $_POST['arthur_ai_pf'] ) && is_array( $_POST['arthur_ai_pf'] ) ) {
            $fields = get_option( 'arthur_ai_custom_profile_fields', array() );
            foreach ( $_POST['arthur_ai_pf'] as $id => $value ) {
                $id = sanitize_key( $id );
                if ( ! empty( $fields[ $id ] ) ) {
                    $val = is_string( $value ) ? trim( $value ) : '';
                    update_user_meta( $user_id, $id, sanitize_text_field( $val ) );
                }
            }
        }
    }

    /**
     * Output CSS in the profile edit screens to hide specified fields.
     */
    public static function output_hidden_fields_css() {
        $fields = get_option( 'arthur_ai_hidden_profile_fields', array() );
        if ( ! is_array( $fields ) || empty( $fields ) ) {
            return;
        }
        echo '<style type="text/css">';
        foreach ( $fields as $field ) {
            $field_id = sanitize_key( (string) $field );
            if ( '' === $field_id ) {
                continue;
            }
            // WordPress wraps many core fields in tr.user-{field}-wrap rows.
            echo 'tr.user-' . esc_attr( $field_id ) . '-wrap { display: none !important; }';
        }
        echo '</style>';
    }

    /**
     * Filter the login redirect URL based on the user role mappings.
     *
     * @param string         $redirect_to The URL the user is redirected to.
     * @param string         $requested   The originally requested redirect URL.
     * @param WP_User|WP_Error $user     User object or WP_Error on failure.
     *
     * @return string
     */
    public static function filter_login_redirect( $redirect_to, $requested, $user ) {
        if ( ! $user || is_wp_error( $user ) ) {
            return $redirect_to;
        }
        $redirects = get_option( 'arthur_ai_login_redirects', array() );
        if ( ! is_array( $redirects ) || empty( $redirects ) ) {
            return $redirect_to;
        }
        $roles = (array) $user->roles;
        foreach ( $roles as $role ) {
            $role_key = sanitize_key( $role );
            if ( isset( $redirects[ $role_key ] ) && '' !== $redirects[ $role_key ] ) {
                return esc_url_raw( $redirects[ $role_key ] );
            }
        }
        return $redirect_to;
    }

    /**
     * Perform a safe redirect after logout if configured.
     */
    public static function handle_logout_redirect() {
        $url = (string) get_option( 'arthur_ai_logout_redirect_url', '' );
        if ( '' !== $url ) {
            wp_safe_redirect( $url );
            exit;
        }
    }

    /**
     * Hide the admin bar for non‑administrators when enabled.
     *
     * @param bool $show Current show_admin_bar value.
     * @return bool
     */
    public static function filter_show_admin_bar( $show ) {
        $enabled = get_option( 'arthur_ai_disable_admin_bar_non_admins', false );
        if ( $enabled ) {
            // Only allow administrators (manage_options capability) to see the bar.
            if ( ! current_user_can( 'manage_options' ) ) {
                return false;
            }
        }
        return $show;
    }
}
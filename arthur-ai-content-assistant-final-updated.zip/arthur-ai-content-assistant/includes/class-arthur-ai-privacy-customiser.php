<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Privacy‑related runtime customisations.
 *
 * This class renders a simple cookie banner when configured and no other
 * cookie consent plugin is handling it. It also prepares the groundwork
 * for other privacy features (e.g. policy page linking) should they be
 * required in the future.
 */
class Arthur_AI_Privacy_Customiser {

    /**
     * Initialise hooks.
     */
    public static function init() {
        add_action( 'wp_footer', array( __CLASS__, 'render_cookie_banner' ) );
    }

    /**
     * Render a simple cookie banner if configured and not handled by a plugin.
     */
    public static function render_cookie_banner() {
        $settings = get_option( 'arthur_ai_cookie_banner', array() );
        if ( ! is_array( $settings ) || empty( $settings ) ) {
            return;
        }
        $plugin = isset( $settings['plugin'] ) ? $settings['plugin'] : 'generic';
        if ( 'generic' !== $plugin ) {
            // A plugin should render its own banner.
            return;
        }
        $content   = isset( $settings['content'] ) ? $settings['content'] : array();
        $behaviour = isset( $settings['behaviour'] ) ? $settings['behaviour'] : array();
        $message    = isset( $content['message'] ) ? $content['message'] : __( 'We use cookies to optimise our website and our service.', 'arthur-ai' );
        $accept_label = isset( $content['accept_label'] ) ? $content['accept_label'] : __( 'Accept', 'arthur-ai' );
        $reject_label = isset( $content['reject_label'] ) ? $content['reject_label'] : __( 'Reject', 'arthur-ai' );
        $position   = isset( $behaviour['position'] ) ? $behaviour['position'] : 'bottom';
        $blocking   = isset( $behaviour['blocking_mode'] ) ? $behaviour['blocking_mode'] : 'soft';
        ?>
        <div id="arthur-ai-cookie-banner" class="arthur-ai-cookie-banner" style="position:fixed;<?php echo ( $position === 'top' ) ? 'top:0;' : 'bottom:0;'; ?>left:0;width:100%;background:#222;color:#fff;padding:1em;text-align:center;z-index:9999;">
            <p style="margin:0 0 10px 0;"><?php echo wp_kses_post( $message ); ?></p>
            <button id="arthur-ai-cookie-accept" style="margin-right:10px;"><?php echo esc_html( $accept_label ); ?></button>
            <button id="arthur-ai-cookie-reject"><?php echo esc_html( $reject_label ); ?></button>
        </div>
        <script>
        (function(){
            if ( document.cookie.indexOf( 'arthur_ai_cookie_consent=' ) !== -1 ) {
                document.getElementById('arthur-ai-cookie-banner').style.display = 'none';
                return;
            }
            function setConsent(value) {
                var d = new Date();
                d.setTime(d.getTime() + (365*24*60*60*1000));
                document.cookie = 'arthur_ai_cookie_consent=' + value + ';expires=' + d.toUTCString() + ';path=/';
                document.getElementById('arthur-ai-cookie-banner').style.display = 'none';
            }
            document.getElementById('arthur-ai-cookie-accept').addEventListener('click', function(){ setConsent('accept'); });
            document.getElementById('arthur-ai-cookie-reject').addEventListener('click', function(){ setConsent('reject'); });
        })();
        </script>
        <?php
    }
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Implements runtime redirects and 404 logging based on configured rules.
 *
 * This customiser reads redirect rules saved via the manage_redirects and
 * configure_404_logging_and_redirects actions. During template_redirect it
 * checks the current request path against stored rules and performs the
 * appropriate redirect using wp_redirect(). It also logs 404 requests when
 * logging is enabled.
 */
class Arthur_AI_Redirects_Customiser {

    public static function init() {
        add_action( 'template_redirect', array( __CLASS__, 'maybe_redirect_or_log' ), 0 );
    }

    /**
     * Perform redirects based on stored rules and log 404s when configured.
     */
    public static function maybe_redirect_or_log() {
        if ( is_admin() ) {
            return;
        }
        // Fetch redirect rules array keyed by normalised path
        $rules = get_option( 'arthur_ai_redirect_rules', array() );
        if ( ! is_array( $rules ) ) {
            $rules = array();
        }
        // Determine current request path (without query string)
        $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';
        $path        = parse_url( $request_uri, PHP_URL_PATH );
        if ( ! $path ) {
            $path = '/';
        }
        $path = '/' . ltrim( untrailingslashit( $path ), '/' );
        // Check for a matching redirect rule
        if ( isset( $rules[ $path ] ) ) {
            $rule = $rules[ $path ];
            if ( isset( $rule['enabled'] ) && $rule['enabled'] && ! empty( $rule['target_url'] ) ) {
                $status = isset( $rule['status_code'] ) ? intval( $rule['status_code'] ) : 302;
                wp_redirect( $rule['target_url'], $status );
                exit;
            }
        }
        // If no redirect happened, handle 404 logging after query resolution
        if ( get_option( 'arthur_ai_404_logging_enabled', false ) ) {
            if ( is_404() ) {
                $log = get_option( 'arthur_ai_404_log', array() );
                if ( ! is_array( $log ) ) {
                    $log = array();
                }
                $log[] = array(
                    'uri'       => $request_uri,
                    'timestamp' => current_time( 'mysql' ),
                );
                // Limit log size to 100 entries
                if ( count( $log ) > 100 ) {
                    $log = array_slice( $log, -100 );
                }
                update_option( 'arthur_ai_404_log', $log );
            }
        }
    }
}
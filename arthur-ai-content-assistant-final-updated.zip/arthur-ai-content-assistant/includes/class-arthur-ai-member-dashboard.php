<?php
/**
 * Member dashboard rendering class.
 *
 * Provides a shortcode to display a consolidated view of a member’s
 * information including active membership levels, subscription products,
 * enrolled courses and progress, benefits and perks, and recommended
 * content. Also displays basic order history for WooCommerce customers. The
 * layout is simple HTML which can be overridden by site styling.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Member_Dashboard {
    /**
     * Initialise hooks.
     */
    public static function init() {
        add_shortcode( 'arthur_ai_my_membership_dashboard', array( __CLASS__, 'render_dashboard' ) );
    }

    /**
     * Shortcode callback to render dashboard.
     */
    public static function render_dashboard( $atts, $content = '' ) {
        if ( ! is_user_logged_in() ) {
            return '<p>' . esc_html__( 'You must be logged in to view your membership dashboard.', 'arthur-ai' ) . '</p>';
        }
        $user_id = get_current_user_id();
        $output  = '';
        // Membership levels
        $levels = self::get_user_membership_details( $user_id );
        if ( ! empty( $levels ) ) {
            $output .= '<h2>' . esc_html__( 'Your Memberships', 'arthur-ai' ) . '</h2><ul class="arthur-ai-membership-list">';
            foreach ( $levels as $level ) {
                $output .= '<li>' . esc_html( $level['name'] ) . '</li>';
            }
            $output .= '</ul>';
        }
        // Subscriptions
        if ( class_exists( 'WC_Subscriptions' ) ) {
            $subs = wcs_get_users_subscriptions( $user_id );
            if ( $subs ) {
                $output .= '<h2>' . esc_html__( 'Your Subscriptions', 'arthur-ai' ) . '</h2><ul class="arthur-ai-subscriptions">';
                foreach ( $subs as $sub ) {
                    $product_names = array();
                    foreach ( $sub->get_items() as $item ) {
                        $product_names[] = $item->get_name();
                    }
                    $status = $sub->get_status();
                    $output .= '<li>' . esc_html( implode( ', ', $product_names ) . ' (' . ucfirst( $status ) . ')' ) . '</li>';
                }
                $output .= '</ul>';
            }
        }
        // Courses and progress
        $courses = Arthur_AI_Lms_Customiser::get_all_user_courses( $user_id );
        if ( ! empty( $courses ) ) {
            $output .= '<h2>' . esc_html__( 'Your Courses', 'arthur-ai' ) . '</h2><ul class="arthur-ai-courses">';
            foreach ( $courses as $course_id ) {
                $title = get_the_title( $course_id );
                $output .= '<li><a href="' . esc_url( get_permalink( $course_id ) ) . '">' . esc_html( $title ) . '</a></li>';
            }
            $output .= '</ul>';
        }
        // Benefits/perks from membership levels
        $benefits = self::get_user_benefits( $user_id, $levels );
        if ( ! empty( $benefits ) ) {
            $output .= '<h2>' . esc_html__( 'Your Benefits & Perks', 'arthur-ai' ) . '</h2><ul class="arthur-ai-benefits">';
            foreach ( $benefits as $benefit ) {
                $output .= '<li>' . esc_html( $benefit ) . '</li>';
            }
            $output .= '</ul>';
        }
        // Order history (WooCommerce)
        if ( class_exists( 'WooCommerce' ) ) {
            $orders = wc_get_orders( array( 'customer' => $user_id, 'limit' => 5, 'orderby' => 'date', 'order' => 'DESC' ) );
            if ( $orders ) {
                $output .= '<h2>' . esc_html__( 'Recent Orders', 'arthur-ai' ) . '</h2><ul class="arthur-ai-orders">';
                foreach ( $orders as $order ) {
                    $order_id = $order->get_id();
                    $date     = $order->get_date_created();
                    $status   = wc_get_order_status_name( $order->get_status() );
                    $output  .= '<li>' . esc_html( '#' . $order_id . ' - ' . date_i18n( get_option( 'date_format' ), $date->getTimestamp() ) . ' - ' . $status ) . '</li>';
                }
                $output .= '</ul>';
            }
        }
        // Recommendations
        $recs = Arthur_AI_Lms_Customiser::get_recommendations_for_user( $user_id );
        if ( ! empty( $recs ) ) {
            $output .= '<h2>' . esc_html__( 'Recommended for You', 'arthur-ai' ) . '</h2><ul class="arthur-ai-recommendations">';
            foreach ( $recs as $id ) {
                $title = get_the_title( $id );
                $link  = get_permalink( $id );
                $output .= '<li><a href="' . esc_url( $link ) . '">' . esc_html( $title ) . '</a></li>';
            }
            $output .= '</ul>';
        }
        return '<div class="arthur-ai-member-dashboard">' . $output . '</div>';
    }

    /**
     * Fetch membership level details for the user using provider APIs or stored data.
     *
     * @param int $user_id
     * @return array List of arrays with keys name, id.
     */
    protected static function get_user_membership_details( $user_id ) {
        $details = array();
        // Woo Memberships
        if ( class_exists( 'WC_Memberships' ) && function_exists( 'wc_memberships_get_user_active_memberships' ) ) {
            $memberships = wc_memberships_get_user_active_memberships( $user_id );
            foreach ( $memberships as $membership ) {
                $plan = wc_memberships_get_membership_plan( $membership->plan_id );
                if ( $plan ) {
                    $details[] = array(
                        'provider' => 'woo_memberships',
                        'id'       => $plan->get_id(),
                        'name'     => $plan->get_name(),
                    );
                }
            }
        }
        // PMPro
        if ( function_exists( 'pmpro_getMembershipLevelForUser' ) ) {
            $level = pmpro_getMembershipLevelForUser( $user_id );
            if ( $level ) {
                $details[] = array(
                    'provider' => 'pmpro',
                    'id'       => $level->id,
                    'name'     => $level->name,
                );
            }
        }
        // MemberPress
        if ( class_exists( 'MeprUser' ) ) {
            $mepr_user = new MeprUser( $user_id );
            $products  = $mepr_user->active_products();
            foreach ( $products as $prod ) {
                $details[] = array(
                    'provider' => 'memberpress',
                    'id'       => $prod->ID,
                    'name'     => $prod->post_title,
                );
            }
        }
        return $details;
    }

    /**
     * Aggregate benefits/perks from membership level definitions stored in options.
     */
    protected static function get_user_benefits( $user_id, $membership_details ) {
        $benefits = array();
        $levels_option = get_option( 'arthur_ai_membership_levels', array() );
        if ( empty( $levels_option ) || empty( $membership_details ) ) {
            return $benefits;
        }
        foreach ( $membership_details as $detail ) {
            $level_id = $detail['id'];
            foreach ( $levels_option as $record ) {
                if ( strval( $record['id'] ) === strval( $level_id ) && ! empty( $record['benefits'] ) ) {
                    foreach ( $record['benefits'] as $benefit ) {
                        if ( is_string( $benefit ) ) {
                            $benefits[] = $benefit;
                        } elseif ( is_array( $benefit ) ) {
                            // Flatten arrays into strings when possible
                            $benefits[] = implode( ', ', array_map( 'sanitize_text_field', $benefit ) );
                        }
                    }
                }
            }
        }
        return $benefits;
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Outputs Open Graph and Twitter Card metadata for posts when no SEO plugin
 * provides these tags or when custom social meta has been set by AI actions.
 */
class Arthur_AI_Social_Customiser {

    public static function init() {
        add_action( 'wp_head', array( __CLASS__, 'output_social_tags' ), 1 );
    }

    /**
     * Output OG and Twitter meta tags based on custom meta keys.
     */
    public static function output_social_tags() {
        if ( is_admin() || is_feed() ) {
            return;
        }
        if ( ! is_singular() ) {
            return;
        }
        $post_id = get_queried_object_id();
        if ( ! $post_id ) {
            return;
        }
        // Custom meta keys for social tags
        $og_title   = get_post_meta( $post_id, '_arthur_ai_og_title', true );
        $og_desc    = get_post_meta( $post_id, '_arthur_ai_og_description', true );
        $og_image   = get_post_meta( $post_id, '_arthur_ai_og_image', true );
        $tw_title   = get_post_meta( $post_id, '_arthur_ai_tw_title', true );
        $tw_desc    = get_post_meta( $post_id, '_arthur_ai_tw_description', true );
        $tw_image   = get_post_meta( $post_id, '_arthur_ai_tw_image', true );
        // Output OG tags
        if ( $og_title ) {
            echo '<meta property="og:title" content="' . esc_attr( $og_title ) . '" />' . "\n";
        }
        if ( $og_desc ) {
            echo '<meta property="og:description" content="' . esc_attr( $og_desc ) . '" />' . "\n";
        }
        if ( $og_image ) {
            echo '<meta property="og:image" content="' . esc_url( $og_image ) . '" />' . "\n";
        }
        // Add default OG type and URL if any OG tags exist
        if ( $og_title || $og_desc || $og_image ) {
            echo '<meta property="og:type" content="article" />' . "\n";
            echo '<meta property="og:url" content="' . esc_url( get_permalink( $post_id ) ) . '" />' . "\n";
        }
        // Output Twitter tags
        if ( $tw_title ) {
            echo '<meta name="twitter:title" content="' . esc_attr( $tw_title ) . '" />' . "\n";
        }
        if ( $tw_desc ) {
            echo '<meta name="twitter:description" content="' . esc_attr( $tw_desc ) . '" />' . "\n";
        }
        if ( $tw_image ) {
            echo '<meta name="twitter:image" content="' . esc_url( $tw_image ) . '" />' . "\n";
        }
    }
}
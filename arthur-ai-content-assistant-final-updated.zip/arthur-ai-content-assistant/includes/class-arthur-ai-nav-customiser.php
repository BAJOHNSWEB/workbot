<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Customises navigation menu output based on user roles and configured rules.
 */
class Arthur_AI_Nav_Customiser {

    /**
     * Initialise hooks.
     */
    public static function init() {
        add_filter( 'wp_nav_menu_args', array( __CLASS__, 'filter_nav_menu_args' ) );
    }

    /**
     * Filter wp_nav_menu args to override menus based on role rules.
     *
     * @param array $args Menu arguments.
     * @return array Modified arguments.
     */
    public static function filter_nav_menu_args( $args ) {
        $rules = get_option( 'arthur_ai_role_based_menus', array() );
        if ( ! is_array( $rules ) || empty( $rules ) ) {
            return $args;
        }
        // Determine location key
        if ( empty( $args['theme_location'] ) ) {
            return $args;
        }
        $location = (string) $args['theme_location'];
        if ( ! isset( $rules[ $location ] ) || ! is_array( $rules[ $location ] ) ) {
            return $args;
        }
        $user = wp_get_current_user();
        $user_roles = array();
        if ( $user && ! empty( $user->roles ) ) {
            $user_roles = (array) $user->roles;
        } else {
            $user_roles = array( 'logged_out' );
        }
        foreach ( $rules[ $location ] as $rule ) {
            if ( ! is_array( $rule ) || empty( $rule['role'] ) || empty( $rule['menu_id'] ) ) {
                continue;
            }
            $role    = (string) $rule['role'];
            $menu_id = (int) $rule['menu_id'];
            if ( ( 'logged_out' === $role && in_array( 'logged_out', $user_roles, true ) ) || in_array( $role, $user_roles, true ) ) {
                $args['menu'] = $menu_id;
                unset( $args['theme_location'] );
                break;
            }
        }
        return $args;
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * WooCommerce customiser for checkout fields, guest checkout mode,
 * checkout instructions, shipping, tax configuration and email trigger rules.
 *
 * This helper reads configuration stored by the AI actions and applies
 * modifications at runtime via WooCommerce hooks. It is only
 * initialised when WooCommerce is active.
 */
class Arthur_AI_WooCommerce_Customiser {

    /**
     * Initialise hooks when WooCommerce is active.
     */
    public static function init() {
        // Bail if WooCommerce is not loaded
        if ( ! class_exists( 'WooCommerce' ) ) {
            return;
        }

        // Checkout fields customisation
        add_filter( 'woocommerce_checkout_fields', array( __CLASS__, 'filter_checkout_fields' ) );

        // Guest checkout override
        add_filter( 'pre_option_woocommerce_enable_guest_checkout', array( __CLASS__, 'override_guest_checkout_option' ) );

        // Checkout instructions before form
        add_action( 'woocommerce_before_checkout_form', array( __CLASS__, 'output_checkout_instructions' ) );

        // Email customisation and trigger handling are handled by Arthur_AI_Email_Customiser.

        // Shipping and tax configuration on init
        add_action( 'init', array( __CLASS__, 'apply_shipping_configuration' ), 15 );
        add_action( 'init', array( __CLASS__, 'apply_tax_configuration' ), 15 );
    }

    /**
     * Customise checkout fields based on stored configuration.
     *
     * The configuration option 'arthur_ai_checkout_fields_customisation' should be
     * an associative array with 'billing', 'shipping' and 'additional' keys.
     * Each key may contain arrays for 'add', 'update' and 'remove' actions.
     *
     * @param array $fields Checkout fields passed in by WooCommerce.
     * @return array Modified checkout fields.
     */
    public static function filter_checkout_fields( $fields ) {
        $config = get_option( 'arthur_ai_checkout_fields_customisation', array() );
        if ( ! is_array( $config ) ) {
            return $fields;
        }
        foreach ( array( 'billing', 'shipping', 'additional' ) as $section ) {
            if ( ! isset( $config[ $section ] ) || ! is_array( $config[ $section ] ) ) {
                continue;
            }
            $section_config = $config[ $section ];
            // Remove fields
            if ( isset( $section_config['remove'] ) && is_array( $section_config['remove'] ) ) {
                foreach ( $section_config['remove'] as $remove_key ) {
                    if ( isset( $fields[ $section ][ $remove_key ] ) ) {
                        unset( $fields[ $section ][ $remove_key ] );
                    }
                }
            }
            // Update existing fields
            if ( isset( $section_config['update'] ) && is_array( $section_config['update'] ) ) {
                foreach ( $section_config['update'] as $key => $settings ) {
                    if ( isset( $fields[ $section ][ $key ] ) && is_array( $settings ) ) {
                        $fields[ $section ][ $key ] = array_merge( $fields[ $section ][ $key ], $settings );
                    }
                }
            }
            // Add new fields
            if ( isset( $section_config['add'] ) && is_array( $section_config['add'] ) ) {
                foreach ( $section_config['add'] as $key => $settings ) {
                    if ( ! isset( $fields[ $section ][ $key ] ) ) {
                        $fields[ $section ][ $key ] = $settings;
                    }
                }
            }
        }
        return $fields;
    }

    /**
     * Override the guest checkout option based on stored setting.
     *
     * @param mixed $value The current option value.
     * @return string 'yes' or 'no'.
     */
    public static function override_guest_checkout_option( $value ) {
        $allow = get_option( 'arthur_ai_allow_guest_checkout', '' );
        if ( '' === $allow ) {
            return $value;
        }
        return $allow ? 'yes' : 'no';
    }

    /**
     * Output checkout instructions before the checkout form.
     */
    public static function output_checkout_instructions() {
        $content = get_option( 'arthur_ai_checkout_instructions', '' );
        if ( $content ) {
            echo wp_kses_post( $content );
        }
    }

    /**
     * Initialise email customisations and trigger filters.
     *
     * Reads custom subjects, headings and body content from the
     * arthur_ai_woo_email_customisations option and adds appropriate filters.
     * Also reads email trigger rules from arthur_ai_email_triggers and
     * applies enable/disable filters.
     */
    public static function init_email_customisations() {
        $customisations = get_option( 'arthur_ai_woo_email_customisations', array() );
        if ( is_array( $customisations ) ) {
            foreach ( $customisations as $email_id => $settings ) {
                if ( isset( $settings['subject'] ) ) {
                    add_filter( 'woocommerce_email_subject_' . $email_id, function( $subject, $order ) use ( $settings ) {
                        return $settings['subject'];
                    }, 10, 2 );
                }
                if ( isset( $settings['heading'] ) ) {
                    add_filter( 'woocommerce_email_heading_' . $email_id, function( $heading, $order ) use ( $settings ) {
                        return $settings['heading'];
                    }, 10, 2 );
                }
                if ( isset( $settings['body_html'] ) ) {
                    add_filter( 'woocommerce_email_content_' . $email_id, function( $content, $order ) use ( $settings ) {
                        return wp_kses_post( $settings['body_html'] );
                    }, 10, 2 );
                }
            }
        }
        // Email triggers
        $triggers = get_option( 'arthur_ai_email_triggers', array() );
        if ( is_array( $triggers ) ) {
            foreach ( $triggers as $email_id => $rule ) {
                if ( isset( $rule['enabled'] ) ) {
                    add_filter( 'woocommerce_email_enabled_' . $email_id, function( $enabled, $order ) use ( $rule ) {
                        return $rule['enabled'] ? true : false;
                    }, 10, 2 );
                }
            }
        }
    }

    /**
     * Apply shipping configuration stored by the AI actions.
     *
     * The option arthur_ai_shipping_config should be an array of zones with
     * methods and settings. Each zone definition should include
     * 'name', optional 'zone_id', and 'methods' array. Each method entry
     * includes 'method_id' and 'settings' array of key/value pairs.
     */
    public static function apply_shipping_configuration() {
        $config = get_option( 'arthur_ai_shipping_config', array() );
        if ( ! is_array( $config ) || empty( $config ) ) {
            return;
        }
        // Ensure shipping methods are loaded
        WC()->shipping()->init();
        foreach ( $config as $zone_def ) {
            if ( ! is_array( $zone_def ) || ! isset( $zone_def['name'] ) ) {
                continue;
            }
            $zone_id = 0;
            // Find existing zone by name if provided
            $zones = WC_Shipping_Zones::get_zones();
            foreach ( $zones as $zone ) {
                if ( isset( $zone['zone_name'] ) && $zone['zone_name'] === $zone_def['name'] ) {
                    $zone_id = isset( $zone['id'] ) ? $zone['id'] : 0;
                    break;
                }
            }
            // Create zone if not found
            if ( ! $zone_id ) {
                $zone_id = WC_Shipping_Zones::create_shipping_zone( array( 'zone_name' => $zone_def['name'] ) );
            }
            if ( ! $zone_id ) {
                continue;
            }
            $zone = new WC_Shipping_Zone( $zone_id );
            // Add or update methods
            if ( isset( $zone_def['methods'] ) && is_array( $zone_def['methods'] ) ) {
                foreach ( $zone_def['methods'] as $method_def ) {
                    if ( ! isset( $method_def['method_id'] ) ) {
                        continue;
                    }
                    $method_id = $method_def['method_id'];
                    // Check if method already exists in zone
                    $existing = null;
                    foreach ( $zone->get_shipping_methods() as $instance ) {
                        if ( $instance->id === $method_id ) {
                            $existing = $instance;
                            break;
                        }
                    }
                    if ( ! $existing ) {
                        $zone->add_shipping_method( $method_id );
                        // Reload zone methods after adding
                        $zone = new WC_Shipping_Zone( $zone_id );
                        foreach ( $zone->get_shipping_methods() as $instance ) {
                            if ( $instance->id === $method_id ) {
                                $existing = $instance;
                                break;
                            }
                        }
                    }
                    if ( $existing && isset( $method_def['settings'] ) && is_array( $method_def['settings'] ) ) {
                        $settings = $existing->get_instance_settings();
                        foreach ( $method_def['settings'] as $k => $v ) {
                            $settings[ $k ] = $v;
                        }
                        $existing->instance_settings = $settings;
                        $existing->save();
                    }
                }
            }
        }
    }

    /**
     * Apply tax configuration stored by the AI actions.
     *
     * The option arthur_ai_tax_config should contain 'classes' (array of
     * class names) and 'rates' (array of rate definitions). Each rate
     * definition should include tax_rate_country, tax_rate_state,
     * tax_rate, tax_rate_name, tax_rate_class, tax_rate_priority,
     * tax_rate_compound and tax_rate_shipping.
     */
    public static function apply_tax_configuration() {
        $config = get_option( 'arthur_ai_tax_config', array() );
        if ( ! is_array( $config ) ) {
            return;
        }
        // Add tax classes
        if ( isset( $config['classes'] ) && is_array( $config['classes'] ) ) {
            $classes      = array_map( 'sanitize_text_field', $config['classes'] );
            $existing     = array_filter( array_map( 'trim', explode( "\n", get_option( 'woocommerce_tax_classes' ) ) ) );
            $updated_list = array_unique( array_merge( $existing, $classes ) );
            update_option( 'woocommerce_tax_classes', implode( "\n", $updated_list ) );
        }
        // Add rates
        if ( isset( $config['rates'] ) && is_array( $config['rates'] ) ) {
            foreach ( $config['rates'] as $rate ) {
                if ( ! is_array( $rate ) ) {
                    continue;
                }
                // Provide defaults
                $defaults = array(
                    'tax_rate_country'  => '',
                    'tax_rate_state'    => '',
                    'tax_rate'          => '0.0000',
                    'tax_rate_name'     => '',
                    'tax_rate_class'    => '',
                    'tax_rate_priority' => 1,
                    'tax_rate_compound' => 0,
                    'tax_rate_shipping' => 1,
                );
                $rate_data = wp_parse_args( $rate, $defaults );
                // Save or update tax rate
                if ( method_exists( 'WC_Tax', '_save_rate' ) ) {
                    // Private method, but accessible via reflection
                    $rate_id = WC_Tax::_save_rate( $rate_data );
                }
            }
        }
    }
}
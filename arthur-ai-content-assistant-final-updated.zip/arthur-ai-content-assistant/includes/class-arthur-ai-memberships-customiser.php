<?php
/**
 * Memberships customiser.
 *
 * This helper class implements runtime behaviour for membership management
 * actions. It enforces content protection rules, handles signup/onboarding
 * flows, and links membership levels to LMS courses according to stored
 * configuration. It currently implements limited hooks for WooCommerce
 * Memberships. Additional provider hooks can be added as needed.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Memberships_Customiser {
    /**
     * Initialise hooks.
     */
    public static function init() {
        // Apply content protection on template redirect
        add_action( 'template_redirect', array( __CLASS__, 'maybe_protect_content' ) );
        // Hook into Woo Memberships membership status changes
        add_action( 'wc_memberships_user_membership_status_changed', array( __CLASS__, 'handle_wc_membership_status_changed' ), 10, 3 );
        // Redirect onboarding
        add_action( 'template_redirect', array( __CLASS__, 'maybe_handle_onboarding_redirect' ), 20 );
    }

    /**
     * Enforce membership content protection rules.
     */
    public static function maybe_protect_content() {
        if ( is_admin() || ! is_singular() ) {
            return;
        }
        global $post;
        if ( ! $post ) {
            return;
        }
        $rules_data = get_option( 'arthur_ai_membership_protection_rules', array() );
        if ( empty( $rules_data ) ) {
            return;
        }
        $post_id    = $post->ID;
        $post_type  = $post->post_type;
        $categories = wp_get_post_categories( $post_id );
        $tags       = wp_get_post_tags( $post_id, array( 'fields' => 'ids' ) );
        // Iterate through providers
        foreach ( $rules_data as $provider => $config ) {
            // Only handle if provider plugin is active
            if ( 'woo_memberships' === $provider && ! class_exists( 'WC_Memberships' ) ) {
                continue;
            }
            if ( 'pmpro' === $provider && ! function_exists( 'pmpro_getAllLevels' ) ) {
                continue;
            }
            if ( 'memberpress' === $provider && ! class_exists( 'MeprProduct' ) ) {
                continue;
            }
            $rules     = isset( $config['rules'] ) ? $config['rules'] : array();
            $behaviour = isset( $config['behaviour'] ) ? $config['behaviour'] : array();
            $redirect  = isset( $behaviour['redirect_url'] ) ? esc_url_raw( $behaviour['redirect_url'] ) : '';
            $teaser    = isset( $behaviour['teaser_mode'] ) ? (bool) $behaviour['teaser_mode'] : false;
            foreach ( $rules as $rule ) {
                $level_ids     = isset( $rule['level_ids'] ) && is_array( $rule['level_ids'] ) ? $rule['level_ids'] : array();
                $content_scope = isset( $rule['content_scope'] ) && is_array( $rule['content_scope'] ) ? $rule['content_scope'] : array();
                // Determine if this post matches the scope
                $matches = false;
                if ( isset( $content_scope['post_ids'] ) && in_array( $post_id, $content_scope['post_ids'], true ) ) {
                    $matches = true;
                }
                if ( ! $matches && isset( $content_scope['post_types'] ) && in_array( $post_type, $content_scope['post_types'], true ) ) {
                    $matches = true;
                }
                if ( ! $matches && isset( $content_scope['taxonomies'] ) && is_array( $content_scope['taxonomies'] ) ) {
                    foreach ( $content_scope['taxonomies'] as $tax => $terms ) {
                        $terms = is_array( $terms ) ? $terms : array( $terms );
                        $object_terms = wp_get_post_terms( $post_id, $tax, array( 'fields' => 'ids' ) );
                        if ( array_intersect( $terms, $object_terms ) ) {
                            $matches = true;
                            break;
                        }
                    }
                }
                if ( ! $matches ) {
                    continue;
                }
                // Check if user has required membership
                $user_id = get_current_user_id();
                $allowed = false;
                if ( $user_id > 0 ) {
                    $allowed = self::user_has_membership( $user_id, $provider, $level_ids );
                }
                if ( ! $allowed ) {
                    // Not allowed: either redirect or show teaser message
                    if ( $redirect ) {
                        wp_safe_redirect( $redirect );
                        exit;
                    }
                    // Show a generic message and exit
                    wp_die( __( 'This content is restricted to members.', 'arthur-ai' ) );
                }
            }
        }
    }

    /**
     * Determine if a user has at least one of the specified membership levels.
     */
    protected static function user_has_membership( $user_id, $provider, $level_ids ) {
        foreach ( $level_ids as $level_id ) {
            $level_id = trim( $level_id );
            if ( 'woo_memberships' === $provider ) {
                if ( function_exists( 'wc_memberships_is_user_active_member' ) && wc_memberships_is_user_active_member( $user_id, $level_id ) ) {
                    return true;
                }
            } elseif ( 'pmpro' === $provider ) {
                if ( function_exists( 'pmpro_hasMembershipLevel' ) && pmpro_hasMembershipLevel( $level_id, $user_id ) ) {
                    return true;
                }
            } elseif ( 'memberpress' === $provider ) {
                if ( class_exists( 'MeprUser' ) ) {
                    $mepr_user = new MeprUser( $user_id );
                    $products  = $mepr_user->active_products();
                    foreach ( $products as $prod ) {
                        if ( $prod->ID == $level_id ) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    /**
     * Handle WooCommerce Memberships status changes to enrol users in courses or remove them.
     *
     * @param WC_Memberships_User_Membership $user_membership The membership object.
     * @param string                          $status_to The new status.
     * @param string                          $status_from The previous status.
     */
    public static function handle_wc_membership_status_changed( $user_membership, $status_to, $status_from ) {
        if ( ! $user_membership ) {
            return;
        }
        $user_id = $user_membership->user_id;
        $level_id = $user_membership->plan_id;
        // On activation
        if ( 'active' === $status_to ) {
            self::apply_membership_to_courses( $user_id, $level_id, 'woo_memberships' );
            self::maybe_start_onboarding( $user_id, 'woo_memberships', $level_id );
        }
        // On cancellation or expiration
        if ( in_array( $status_to, array( 'cancelled', 'expired' ), true ) ) {
            self::remove_membership_courses( $user_id, $level_id, 'woo_memberships' );
        }
    }

    /**
     * Apply membership-course mapping to enrol user in courses when membership activates.
     */
    public static function apply_membership_to_courses( $user_id, $level_id, $provider ) {
        $map = get_option( 'arthur_ai_membership_lms_map', array() );
        if ( empty( $map ) || ! isset( $map[ $provider ] ) ) {
            return;
        }
        $provider_mappings = $map[ $provider ];
        foreach ( $provider_mappings as $lms_provider => $items ) {
            foreach ( $items as $item ) {
                if ( $item['membership_level_id'] == $level_id ) {
                    $courses = $item['course_ids'];
                    foreach ( $courses as $course_id ) {
                        // Use LMS customiser or generic enrolment helper
                        self::enrol_into_lms_course( $lms_provider, $user_id, $course_id );
                    }
                }
            }
        }
    }

    /**
     * Unenrol user from courses when membership expires or cancels.
     */
    public static function remove_membership_courses( $user_id, $level_id, $provider ) {
        $map = get_option( 'arthur_ai_membership_lms_map', array() );
        if ( empty( $map ) || ! isset( $map[ $provider ] ) ) {
            return;
        }
        $provider_mappings = $map[ $provider ];
        foreach ( $provider_mappings as $lms_provider => $items ) {
            foreach ( $items as $item ) {
                if ( $item['membership_level_id'] == $level_id ) {
                    foreach ( $item['course_ids'] as $course_id ) {
                        self::unenrol_from_lms_course( $lms_provider, $user_id, $course_id );
                    }
                }
            }
        }
    }

    /**
     * Enrol user into a course for a specific LMS provider.
     */
    protected static function enrol_into_lms_course( $lms_provider, $user_id, $course_id ) {
        if ( 'learndash' === $lms_provider && function_exists( 'ld_update_course_access' ) ) {
            ld_update_course_access( $user_id, $course_id, 'add' );
        } elseif ( 'lifterlms' === $lms_provider && class_exists( 'LLMS_Student' ) ) {
            $student = new LLMS_Student( $user_id );
            $student->enroll( $course_id );
        } elseif ( 'tutorlms' === $lms_provider && function_exists( 'tutor_utils' ) && method_exists( tutor_utils(), 'enroll_user' ) ) {
            tutor_utils()->enroll_user( $course_id, $user_id );
        } else {
            // store in meta if unsupported
            $enrolments = get_user_meta( $user_id, '_arthur_ai_enrolments', true );
            if ( ! is_array( $enrolments ) ) {
                $enrolments = array();
            }
            $enrolments[ $lms_provider ][ $course_id ] = array( 'status' => 'enrolled', 'progress' => 0 );
            update_user_meta( $user_id, '_arthur_ai_enrolments', $enrolments );
        }
    }

    /**
     * Unenrol a user from a course for a specific LMS provider.
     */
    protected static function unenrol_from_lms_course( $lms_provider, $user_id, $course_id ) {
        if ( 'learndash' === $lms_provider && function_exists( 'ld_update_course_access' ) ) {
            ld_update_course_access( $user_id, $course_id, 'remove' );
        } elseif ( 'lifterlms' === $lms_provider && class_exists( 'LLMS_Student' ) ) {
            $student = new LLMS_Student( $user_id );
            $student->unenroll( $course_id );
        } elseif ( 'tutorlms' === $lms_provider && function_exists( 'tutor_utils' ) && method_exists( tutor_utils(), 'unenroll_user' ) ) {
            tutor_utils()->unenroll_user( $course_id, $user_id );
        } else {
            $enrolments = get_user_meta( $user_id, '_arthur_ai_enrolments', true );
            if ( isset( $enrolments[ $lms_provider ][ $course_id ] ) ) {
                unset( $enrolments[ $lms_provider ][ $course_id ] );
                update_user_meta( $user_id, '_arthur_ai_enrolments', $enrolments );
            }
        }
    }

    /**
     * When a membership activates, check if onboarding configuration exists for this level and start the sequence.
     */
    protected static function maybe_start_onboarding( $user_id, $provider, $level_id ) {
        $config = get_option( 'arthur_ai_membership_onboarding', array() );
        if ( isset( $config[ $provider ] ) && isset( $config[ $provider ][ $level_id ] ) ) {
            $data = $config[ $provider ][ $level_id ];
            // Only start onboarding if user meta not already set
            if ( ! get_user_meta( $user_id, '_arthur_ai_onboarding_sequence', true ) ) {
                update_user_meta( $user_id, '_arthur_ai_onboarding_sequence', $data );
            }
        }
    }

    /**
     * Handle redirecting users through onboarding steps.
     */
    public static function maybe_handle_onboarding_redirect() {
        if ( is_admin() || ! is_user_logged_in() ) {
            return;
        }
        $data = get_user_meta( get_current_user_id(), '_arthur_ai_onboarding_sequence', true );
        if ( ! is_array( $data ) || empty( $data ) ) {
            return;
        }
        $signup_page_id   = isset( $data['signup_page_id'] ) ? intval( $data['signup_page_id'] ) : 0;
        $onboarding_pages = isset( $data['onboarding_pages'] ) && is_array( $data['onboarding_pages'] ) ? $data['onboarding_pages'] : array();
        $redirect         = isset( $data['post_signup_redirect'] ) ? $data['post_signup_redirect'] : '';
        $current_url      = home_url( add_query_arg( array() ) );
        // Determine next step
        $visited = (array) get_user_meta( get_current_user_id(), '_arthur_ai_onboarding_completed', true );
        // If on one of the onboarding pages, mark it as complete
        foreach ( $onboarding_pages as $page ) {
            $page_id = isset( $page['page_id'] ) ? intval( $page['page_id'] ) : 0;
            if ( $page_id && is_page( $page_id ) && ! in_array( $page_id, $visited, true ) ) {
                $visited[] = $page_id;
                update_user_meta( get_current_user_id(), '_arthur_ai_onboarding_completed', $visited );
            }
        }
        // Determine first incomplete page
        foreach ( $onboarding_pages as $page ) {
            $page_id = isset( $page['page_id'] ) ? intval( $page['page_id'] ) : 0;
            if ( $page_id && ! in_array( $page_id, $visited, true ) ) {
                // redirect if not already on this page
                if ( ! is_page( $page_id ) ) {
                    wp_safe_redirect( get_permalink( $page_id ) );
                    exit;
                }
                return;
            }
        }
        // All onboarding pages completed
        delete_user_meta( get_current_user_id(), '_arthur_ai_onboarding_sequence' );
        delete_user_meta( get_current_user_id(), '_arthur_ai_onboarding_completed' );
        if ( $redirect ) {
            wp_safe_redirect( $redirect );
            exit;
        }
    }
}
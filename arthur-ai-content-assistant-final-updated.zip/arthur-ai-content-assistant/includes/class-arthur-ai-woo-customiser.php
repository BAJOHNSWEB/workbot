<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Applies WooCommerce‑specific customisations configured by AI actions.
 *
 * All hooks are only registered when WooCommerce is active. Features include
 * changing the Add to Cart text, adding a custom product tab, modifying
 * checkout fields, requiring phone number, validating postcodes, tagging
 * orders, injecting a custom thank you message and prepending/appending
 * content to order emails.
 */
class Arthur_AI_Woo_Customiser {
    public static function init() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return;
        }
        // Add to cart button text
        add_filter( 'woocommerce_product_single_add_to_cart_text', array( __CLASS__, 'filter_add_to_cart_text_single' ) );
        add_filter( 'woocommerce_product_add_to_cart_text', array( __CLASS__, 'filter_add_to_cart_text_archive' ) );
        // Custom product tab
        add_filter( 'woocommerce_product_tabs', array( __CLASS__, 'filter_product_tabs' ) );
        // Checkout fields
        add_filter( 'woocommerce_checkout_fields', array( __CLASS__, 'filter_checkout_fields' ) );
        add_action( 'woocommerce_after_checkout_validation', array( __CLASS__, 'validate_postcode' ), 10, 2 );
        // Order tagging
        add_action( 'woocommerce_new_order', array( __CLASS__, 'handle_new_order' ), 10, 1 );
        // Thank you message
        add_action( 'woocommerce_thankyou', array( __CLASS__, 'output_custom_thankyou' ), 20 );
        // Email templates (intro/outro)
        add_filter( 'woocommerce_mail_content', array( __CLASS__, 'filter_email_content' ) );
    }

    /**
     * Modify add to cart text on single product pages.
     */
    public static function filter_add_to_cart_text_single( $text ) {
        $settings = get_option( 'arthur_ai_woo_add_to_cart_text', array() );
        if ( isset( $settings['single'] ) && '' !== $settings['single'] ) {
            return $settings['single'];
        }
        return $text;
    }

    /**
     * Modify add to cart text on archive/loop pages.
     */
    public static function filter_add_to_cart_text_archive( $text ) {
        $settings = get_option( 'arthur_ai_woo_add_to_cart_text', array() );
        if ( isset( $settings['archive'] ) && '' !== $settings['archive'] ) {
            return $settings['archive'];
        }
        return $text;
    }

    /**
     * Add a custom product tab.
     */
    public static function filter_product_tabs( $tabs ) {
        $tab = get_option( 'arthur_ai_woo_product_tab', array() );
        if ( is_array( $tab ) && ! empty( $tab['title'] ) && ! empty( $tab['content'] ) ) {
            $title    = $tab['title'];
            $content  = $tab['content'];
            $priority = isset( $tab['priority'] ) ? intval( $tab['priority'] ) : 50;
            $tabs['arthur_ai_custom_tab'] = array(
                'title'    => $title,
                'priority' => $priority,
                'callback' => function() use ( $content ) {
                    echo '<div class="arthur-ai-woo-product-tab">' . wp_kses_post( $content ) . '</div>';
                },
            );
        }
        return $tabs;
    }

    /**
     * Modify checkout fields for show/hide/rename and enforce phone requirement.
     */
    public static function filter_checkout_fields( $fields ) {
        // Generic field visibility/label configuration
        $config = get_option( 'arthur_ai_woo_checkout_fields_config', array() );
        if ( is_array( $config ) ) {
            foreach ( $config as $section => $section_fields ) {
                if ( isset( $fields[ $section ] ) && is_array( $section_fields ) ) {
                    foreach ( $section_fields as $key => $settings ) {
                        if ( isset( $fields[ $section ][ $key ] ) ) {
                            if ( isset( $settings['label'] ) ) {
                                $fields[ $section ][ $key ]['label'] = sanitize_text_field( $settings['label'] );
                            }
                            if ( isset( $settings['required'] ) ) {
                                $fields[ $section ][ $key ]['required'] = (bool) $settings['required'];
                            }
                            if ( isset( $settings['enabled'] ) ) {
                                $enabled = (bool) $settings['enabled'];
                                $fields[ $section ][ $key ]['enabled'] = $enabled;
                                // Remove field if disabled
                                if ( ! $enabled ) {
                                    unset( $fields[ $section ][ $key ] );
                                }
                            }
                        }
                    }
                }
            }
        }
        // Require phone number if configured.
        $require_phone = (bool) get_option( 'arthur_ai_woo_require_phone', false );
        if ( $require_phone ) {
            if ( isset( $fields['billing']['billing_phone'] ) ) {
                $fields['billing']['billing_phone']['required'] = true;
            }
        }
        return $fields;
    }

    /**
     * Validate postcode field based on configuration.
     */
    public static function validate_postcode( $data, $errors ) {
        $config = get_option( 'arthur_ai_woo_postcode_validation', array() );
        if ( ! is_array( $config ) || empty( $config ) ) {
            return;
        }
        $postcode = isset( $data['billing_postcode'] ) ? (string) $data['billing_postcode'] : '';
        if ( '' === $postcode ) {
            return;
        }
        $pattern = '';
        if ( isset( $config['pattern'] ) && '' !== $config['pattern'] ) {
            $pattern = $config['pattern'];
        } elseif ( isset( $config['country'] ) ) {
            $country = strtoupper( (string) $config['country'] );
            // Provide simple built‑in patterns for a few countries.
            $country_patterns = array(
                'US' => '/^[0-9]{5}(?:-[0-9]{4})?$/',
                'GB' => '/^([A-Z]{1,2}\d[A-Z\d]? \d[ABD-HJLN-UW-Z]{2})$/i',
                'CA' => '/^[A-Z]\d[A-Z] \d[A-Z]\d$/i',
                'DE' => '/^\d{5}$/',
                'AU' => '/^\d{4}$/',
            );
            if ( isset( $country_patterns[ $country ] ) ) {
                $pattern = $country_patterns[ $country ];
            }
        }
        if ( $pattern ) {
            if ( ! preg_match( $pattern, $postcode ) ) {
                $errors->add( 'invalid_postcode', __( 'Please enter a valid postcode.', 'arthur-ai' ) );
            }
        }
    }

    /**
     * Attach tags to new orders.
     */
    public static function handle_new_order( $order_id ) {
        $tags = get_option( 'arthur_ai_woo_auto_order_tags', array() );
        if ( is_array( $tags ) && ! empty( $tags ) ) {
            // Store as order meta (could also attach to a custom taxonomy).
            update_post_meta( $order_id, '_arthur_ai_order_tags', $tags );
        }
    }

    /**
     * Display a custom thank you message after checkout.
     */
    public static function output_custom_thankyou( $order_id ) {
        $msg = get_option( 'arthur_ai_woo_thankyou_message', '' );
        if ( $msg ) {
            echo '<div class="arthur-ai-woo-thankyou-message">' . wp_kses_post( $msg ) . '</div>';
        }
    }

    /**
     * Prepend or append content to WooCommerce emails.
     *
     * @param string $content The email content (already inlined with styles).
     * @return string
     */
    public static function filter_email_content( $content ) {
        $templates = get_option( 'arthur_ai_woo_email_templates', array() );
        if ( ! is_array( $templates ) || empty( $templates ) ) {
            return $content;
        }
        $intro = isset( $templates['intro'] ) ? $templates['intro'] : '';
        $outro = isset( $templates['outro'] ) ? $templates['outro'] : '';
        $new   = '';
        if ( $intro ) {
            $new .= wp_kses_post( $intro );
        }
        $new .= $content;
        if ( $outro ) {
            $new .= wp_kses_post( $outro );
        }
        return $new;
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Customises WordPress XML sitemaps to include/exclude specific content based on configured rules.
 */
class Arthur_AI_Sitemap_Customiser {

    /**
     * Hook filters for sitemap output.
     */
    public static function init() {
        add_filter( 'wp_sitemaps_post_types', array( __CLASS__, 'filter_post_types' ), 10, 2 );
        add_filter( 'wp_sitemaps_posts_query_args', array( __CLASS__, 'filter_posts_query_args' ), 10, 2 );

        // New: filter taxonomies in sitemap based on settings.
        add_filter( 'wp_sitemaps_taxonomies', array( __CLASS__, 'filter_taxonomies' ), 10, 2 );
    }

    /**
     * Filter post types shown in sitemaps.
     *
     * @param array $post_types Post types array.
     * @param WP_Sitemaps_Provider $provider Provider instance.
     * @return array Modified post types.
     */
    public static function filter_post_types( $post_types, $provider ) {
        $rules    = get_option( 'arthur_ai_sitemap_rules', array() );
        $settings = get_option( 'arthur_ai_sitemap_settings', array() );
        // Start with provided post_types list
        $modified = $post_types;
        // Exclude post types from original rules
        if ( isset( $rules['exclude']['post_types'] ) && is_array( $rules['exclude']['post_types'] ) ) {
            foreach ( $rules['exclude']['post_types'] as $pt ) {
                if ( isset( $modified[ $pt ] ) ) {
                    unset( $modified[ $pt ] );
                }
            }
        }
        // Apply include/exclude from new settings
        if ( isset( $settings['exclude_post_types'] ) && is_array( $settings['exclude_post_types'] ) ) {
            foreach ( $settings['exclude_post_types'] as $pt ) {
                if ( isset( $modified[ $pt ] ) ) {
                    unset( $modified[ $pt ] );
                }
            }
        }
        if ( isset( $settings['include_post_types'] ) && is_array( $settings['include_post_types'] ) && ! empty( $settings['include_post_types'] ) ) {
            // Keep only included types that are already registered
            $included = array();
            foreach ( $settings['include_post_types'] as $pt ) {
                if ( isset( $modified[ $pt ] ) ) {
                    $included[ $pt ] = $modified[ $pt ];
                }
            }
            $modified = $included;
        }
        return $modified;
    }

    /**
     * Filter query args for post lists in the sitemap.
     *
     * @param array $args Query arguments.
     * @param string $post_type Post type being generated.
     * @return array Modified query arguments.
     */
    public static function filter_posts_query_args( $args, $post_type ) {
        $rules    = get_option( 'arthur_ai_sitemap_rules', array() );
        $settings = get_option( 'arthur_ai_sitemap_settings', array() );
        if ( ! is_array( $rules ) ) {
            $rules = array();
        }
        $include_ids = array();
        $exclude_ids = array();
        // Legacy include/exclude rules
        if ( isset( $rules['include']['post_ids'] ) && is_array( $rules['include']['post_ids'] ) ) {
            foreach ( $rules['include']['post_ids'] as $pid ) {
                $pid = (int) $pid;
                $p   = get_post( $pid );
                if ( $p && $p->post_type === $post_type ) {
                    $include_ids[] = $pid;
                }
            }
        }
        if ( isset( $rules['exclude']['post_ids'] ) && is_array( $rules['exclude']['post_ids'] ) ) {
            foreach ( $rules['exclude']['post_ids'] as $pid ) {
                $pid = (int) $pid;
                $p   = get_post( $pid );
                if ( $p && $p->post_type === $post_type ) {
                    $exclude_ids[] = $pid;
                }
            }
        }
        // New settings: currently we do not support include/exclude individual IDs; but we respect old logic
        // Exclude entire post type if configured in either rules or settings and no include IDs
        $excluded = false;
        if ( isset( $rules['exclude']['post_types'] ) && is_array( $rules['exclude']['post_types'] ) && in_array( $post_type, $rules['exclude']['post_types'], true ) ) {
            $excluded = true;
        }
        if ( isset( $settings['exclude_post_types'] ) && is_array( $settings['exclude_post_types'] ) && in_array( $post_type, $settings['exclude_post_types'], true ) ) {
            $excluded = true;
        }
        if ( $excluded ) {
            if ( ! empty( $include_ids ) ) {
                $args['post__in'] = $include_ids;
            } else {
                $args['post__in'] = array( 0 );
            }
            return $args;
        }
        if ( ! empty( $include_ids ) ) {
            $args['post__in'] = array_unique( array_merge( $include_ids, isset( $args['post__in'] ) ? (array) $args['post__in'] : array() ) );
        }
        if ( ! empty( $exclude_ids ) ) {
            $args['post__not_in'] = array_unique( array_merge( $exclude_ids, isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array() ) );
        }
        return $args;
    }

    /**
     * Filter taxonomy providers in the sitemap based on include/exclude settings.
     *
     * @param array                $taxonomies Taxonomy providers.
     * @param WP_Sitemaps_Provider $provider   Provider instance.
     * @return array Modified list of taxonomies.
     */
    public static function filter_taxonomies( $taxonomies, $provider ) {
        $settings = get_option( 'arthur_ai_sitemap_settings', array() );
        if ( ! is_array( $settings ) ) {
            return $taxonomies;
        }
        $modified = $taxonomies;
        // Exclude taxonomies
        if ( isset( $settings['exclude_taxonomies'] ) && is_array( $settings['exclude_taxonomies'] ) ) {
            foreach ( $settings['exclude_taxonomies'] as $tax ) {
                if ( isset( $modified[ $tax ] ) ) {
                    unset( $modified[ $tax ] );
                }
            }
        }
        // If include_taxonomies specified, keep only those
        if ( isset( $settings['include_taxonomies'] ) && is_array( $settings['include_taxonomies'] ) && ! empty( $settings['include_taxonomies'] ) ) {
            $included = array();
            foreach ( $settings['include_taxonomies'] as $tax ) {
                if ( isset( $modified[ $tax ] ) ) {
                    $included[ $tax ] = $modified[ $tax ];
                }
            }
            $modified = $included;
        }
        return $modified;
    }
}
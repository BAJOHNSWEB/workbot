<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Applies Arthur AI customisations to the post/page editor.
 *
 * This class centralises various editor‑related behaviours configured by
 * AI actions, such as disabling Gutenberg, controlling available blocks,
 * auto‑inserting reusable blocks, hiding metaboxes, custom fields,
 * default values (featured image and category), title placeholders,
 * disabling comments and locking pages. Options are stored via
 * update_option() and read during hook callbacks.
 */
class Arthur_AI_Post_Editor_Customiser {

    /**
     * Initialise hooks.
     */
    public static function init() {
        // Disable Gutenberg for specific post types
        add_filter( 'use_block_editor_for_post_type', array( __CLASS__, 'filter_use_block_editor' ), 10, 2 );
        // Restrict available block types
        add_filter( 'allowed_block_types_all', array( __CLASS__, 'filter_allowed_block_types' ), 10, 2 );
        // Change title placeholder
        add_filter( 'enter_title_here', array( __CLASS__, 'filter_title_placeholder' ), 10, 2 );
        // Remove metaboxes and add custom fields
        add_action( 'add_meta_boxes', array( __CLASS__, 'customise_meta_boxes' ), 10, 2 );
        // Save custom fields and apply defaults on post save
        add_action( 'save_post', array( __CLASS__, 'handle_post_save' ), 10, 3 );
        // Disable comments and pings globally if configured
        add_filter( 'comments_open', array( __CLASS__, 'filter_comments_open' ), 99, 2 );
        add_filter( 'pings_open', array( __CLASS__, 'filter_comments_open' ), 99, 2 );
        // Lock editing of selected pages for non‑admins
        add_filter( 'user_has_cap', array( __CLASS__, 'filter_user_has_cap' ), 10, 4 );
        // Remove comment support on init if disabled
        add_action( 'init', array( __CLASS__, 'maybe_remove_comments_support' ), 100 );
    }

    /**
     * Disable the block editor for specified post types.
     */
    public static function filter_use_block_editor( $use_block_editor, $post_type ) {
        $disabled = get_option( 'arthur_ai_disable_gutenberg', array() );
        if ( is_array( $disabled ) && in_array( $post_type, $disabled, true ) ) {
            return false;
        }
        return $use_block_editor;
    }

    /**
     * Limit which Gutenberg blocks are available.
     *
     * @param bool|array $allowed_blocks Current allowed blocks. A boolean indicates all blocks allowed.
     * @param WP_Block_Editor_Context $editor_context Context object.
     * @return array|bool
     */
    public static function filter_allowed_block_types( $allowed_blocks, $editor_context ) {
        $enabled  = get_option( 'arthur_ai_enabled_blocks', array() );
        $disabled = get_option( 'arthur_ai_disabled_blocks', array() );
        // If enabled list is provided, use it exclusively
        if ( is_array( $enabled ) && ! empty( $enabled ) ) {
            $sanitised = array();
            foreach ( $enabled as $b ) {
                $b = sanitize_text_field( $b );
                if ( '' !== $b ) {
                    $sanitised[] = $b;
                }
            }
            if ( ! empty( $sanitised ) ) {
                return $sanitised;
            }
        }
        // Otherwise, if disabled list provided, compute allowed as difference
        if ( is_array( $disabled ) && ! empty( $disabled ) ) {
            // Get all registered block names
            if ( class_exists( 'WP_Block_Type_Registry' ) ) {
                $all_blocks = WP_Block_Type_Registry::get_instance()->get_all_registered();
                $all_names  = array_keys( $all_blocks );
                $sanitised_disabled = array();
                foreach ( $disabled as $b ) {
                    $b = sanitize_text_field( $b );
                    if ( '' !== $b ) {
                        $sanitised_disabled[] = $b;
                    }
                }
                $allowed = array_diff( $all_names, $sanitised_disabled );
                return array_values( $allowed );
            }
        }
        return $allowed_blocks;
    }

    /**
     * Override title placeholder text for specified post types.
     */
    public static function filter_title_placeholder( $title, $post ) {
        $placeholders = get_option( 'arthur_ai_title_placeholders', array() );
        if ( ! is_array( $placeholders ) || ! is_object( $post ) ) {
            return $title;
        }
        $pt = $post->post_type;
        if ( isset( $placeholders[ $pt ] ) && '' !== trim( $placeholders[ $pt ] ) ) {
            return $placeholders[ $pt ];
        }
        return $title;
    }

    /**
     * Remove or add metaboxes and custom fields.
     */
    public static function customise_meta_boxes( $post_type, $post ) {
        // Hide featured image box
        $hide_featured = get_option( 'arthur_ai_hide_featured_image_box', array() );
        if ( is_array( $hide_featured ) && in_array( $post_type, $hide_featured, true ) ) {
            remove_meta_box( 'postimagediv', $post_type, 'side' );
        }
        // Hide tags/categories boxes on posts
        if ( 'post' === $post_type ) {
            $hide_tags = get_option( 'arthur_ai_hide_tags_box', false );
            $hide_categories = get_option( 'arthur_ai_hide_categories_box', false );
            if ( $hide_tags ) {
                remove_meta_box( 'tagsdiv-post_tag', $post_type, 'side' );
            }
            if ( $hide_categories ) {
                remove_meta_box( 'categorydiv', $post_type, 'side' );
            }
        }
        // Add custom fields
        $custom_fields = get_option( 'arthur_ai_custom_fields', array() );
        if ( is_array( $custom_fields ) ) {
            foreach ( $custom_fields as $field ) {
                $key   = isset( $field['key'] ) ? sanitize_key( $field['key'] ) : '';
                if ( '' === $key ) {
                    continue;
                }
                $label = isset( $field['label'] ) ? sanitize_text_field( (string) $field['label'] ) : $key;
                $type  = isset( $field['type'] ) ? sanitize_key( (string) $field['type'] ) : 'text';
                $types = isset( $field['post_types'] ) && is_array( $field['post_types'] ) ? $field['post_types'] : array();
                // Only add for matching post types or all if empty
                if ( ! empty( $types ) && ! in_array( $post_type, $types, true ) ) {
                    continue;
                }
                add_meta_box( 'arthur_ai_cf_' . $key, esc_html( $label ), function( $post ) use ( $key, $label, $type ) {
                    $value = get_post_meta( $post->ID, $key, true );
                    echo '<div class="arthur-ai-custom-field">';
                    echo '<label for="arthur_ai_cf_' . esc_attr( $key ) . '" style="display:block;margin-bottom:4px;">' . esc_html( $label ) . '</label>';
                    if ( 'textarea' === $type ) {
                        echo '<textarea name="arthur_ai_cf[' . esc_attr( $key ) . ']" id="arthur_ai_cf_' . esc_attr( $key ) . '" style="width:100%;" rows="4">' . esc_textarea( $value ) . '</textarea>';
                    } else {
                        echo '<input type="text" name="arthur_ai_cf[' . esc_attr( $key ) . ']" id="arthur_ai_cf_' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" style="width:100%;" />';
                    }
                    echo '</div>';
                }, $post_type, 'normal', 'default' );
            }
        }
    }

    /**
     * Save custom fields and apply default behaviours on post save.
     */
    public static function handle_post_save( $post_id, $post, $update ) {
        // Do not proceed on autosave or revisions
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( wp_is_post_revision( $post_id ) ) {
            return;
        }
        // Save custom fields
        if ( isset( $_POST['arthur_ai_cf'] ) && is_array( $_POST['arthur_ai_cf'] ) ) {
            $custom_fields = get_option( 'arthur_ai_custom_fields', array() );
            $field_keys    = array();
            if ( is_array( $custom_fields ) ) {
                foreach ( $custom_fields as $field ) {
                    if ( isset( $field['key'] ) ) {
                        $field_keys[] = sanitize_key( $field['key'] );
                    }
                }
            }
            foreach ( $_POST['arthur_ai_cf'] as $key => $value ) {
                $key = sanitize_key( $key );
                if ( in_array( $key, $field_keys, true ) ) {
                    $value = is_string( $value ) ? trim( $value ) : '';
                    update_post_meta( $post_id, $key, sanitize_text_field( $value ) );
                }
            }
        }
        // Apply default behaviours only on first save of new posts
        $is_new = ! $update;
        // Auto insert reusable block into new pages
        if ( $is_new && 'page' === $post->post_type ) {
            $block_id = (int) get_option( 'arthur_ai_auto_reusable_block_id', 0 );
            $block_html = '';
            if ( $block_id > 0 ) {
                // Insert reusable block reference
                $block_html = '<!-- wp:block {"ref":' . $block_id . '} /-->';
            } else {
                $content = (string) get_option( 'arthur_ai_auto_reusable_block_content', '' );
                if ( '' !== trim( $content ) ) {
                    $block_html = $content;
                }
            }
            if ( '' !== $block_html ) {
                $current_content = $post->post_content;
                if ( strpos( $current_content, $block_html ) === false ) {
                    $new_content = $current_content . '\n\n' . $block_html;
                    // Update post content without triggering infinite recursion
                    remove_action( 'save_post', array( __CLASS__, 'handle_post_save' ), 10 );
                    wp_update_post( array( 'ID' => $post_id, 'post_content' => $new_content ) );
                    add_action( 'save_post', array( __CLASS__, 'handle_post_save' ), 10, 3 );
                }
            }
        }
        // Set default featured image
        $default_image_id = (int) get_option( 'arthur_ai_default_featured_image_id', 0 );
        if ( $default_image_id > 0 && ! has_post_thumbnail( $post_id ) ) {
            set_post_thumbnail( $post_id, $default_image_id );
        }
        // Set default category on new posts
        if ( $is_new && 'post' === $post->post_type ) {
            $default_cat = get_option( 'arthur_ai_default_category', '' );
            if ( $default_cat ) {
                $category_id = 0;
                if ( is_numeric( $default_cat ) ) {
                    $category_id = intval( $default_cat );
                } else {
                    // Interpret as slug and find term id
                    $term = get_term_by( 'slug', $default_cat, 'category' );
                    if ( $term && ! is_wp_error( $term ) ) {
                        $category_id = (int) $term->term_id;
                    }
                }
                if ( $category_id ) {
                    $current_cats = (array) wp_get_post_categories( $post_id );
                    if ( empty( $current_cats ) ) {
                        wp_set_post_categories( $post_id, array( $category_id ) );
                    }
                }
            }
        }
    }

    /**
     * Determine if comments should be open.
     */
    public static function filter_comments_open( $open, $post_id ) {
        $disable = get_option( 'arthur_ai_disable_comments', false );
        if ( $disable ) {
            return false;
        }
        return $open;
    }

    /**
     * Remove support for comments if disabled globally.
     */
    public static function maybe_remove_comments_support() {
        if ( get_option( 'arthur_ai_disable_comments', false ) ) {
            $post_types = get_post_types();
            foreach ( $post_types as $pt ) {
                if ( post_type_supports( $pt, 'comments' ) ) {
                    remove_post_type_support( $pt, 'comments' );
                }
                if ( post_type_supports( $pt, 'trackbacks' ) ) {
                    remove_post_type_support( $pt, 'trackbacks' );
                }
            }
        }
    }

    /**
     * Prevent non‑admin users from editing locked pages.
     */
    public static function filter_user_has_cap( $allcaps, $caps, $args, $user ) {
        // $args: 0 = requested capability, 1 = user id, 2 = object id
        if ( isset( $args[0] ) && isset( $args[2] ) && in_array( $args[0], array( 'edit_post', 'edit_page' ), true ) ) {
            $post_id = intval( $args[2] );
            $locked  = get_option( 'arthur_ai_locked_pages', array() );
            if ( is_array( $locked ) && in_array( $post_id, $locked, true ) ) {
                // Allow administrators to bypass
                if ( is_object( $user ) && is_array( $user->roles ) && ! in_array( 'administrator', $user->roles, true ) ) {
                    // Deny edit capability
                    $cap_key = $caps[0];
                    $allcaps[ $cap_key ] = false;
                }
            }
        }
        return $allcaps;
    }
}
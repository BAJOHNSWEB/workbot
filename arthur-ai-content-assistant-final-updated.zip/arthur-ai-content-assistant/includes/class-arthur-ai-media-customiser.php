<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Applies media library customisations such as image optimisation, renaming,
 * custom sizes and WebP conversion.
 */
class Arthur_AI_Media_Customiser {

    public static function init() {
        // Register custom image sizes on init.
        add_action( 'init', array( __CLASS__, 'register_custom_sizes' ) );
        // Optimise images and convert to WebP on metadata generation.
        add_filter( 'wp_generate_attachment_metadata', array( __CLASS__, 'maybe_optimise_images' ), 10, 2 );
        // Auto rename uploads.
        add_filter( 'sanitize_file_name', array( __CLASS__, 'filter_sanitize_file_name' ), 10, 3 );
        // Register media taxonomies (tags/categories) on init.
        add_action( 'init', array( __CLASS__, 'register_taxonomies' ) );
    }

    /**
     * Register additional image sizes defined by the user.
     */
    public static function register_custom_sizes() {
        $sizes = get_option( 'arthur_ai_custom_image_sizes', array() );
        if ( is_array( $sizes ) ) {
            foreach ( $sizes as $name => $def ) {
                $w = isset( $def['width'] ) ? (int) $def['width'] : 0;
                $h = isset( $def['height'] ) ? (int) $def['height'] : 0;
                $c = isset( $def['crop'] ) ? (bool) $def['crop'] : false;
                if ( $w > 0 && $h > 0 ) {
                    add_image_size( $name, $w, $h, $c );
                }
            }
        }
    }

    /**
     * Rename files according to the configured pattern.
     *
     * @param string $filename The sanitized filename.
     * @param string $filename_raw The original filename as supplied by the user.
     * @param string $source Source (unused).
     * @return string
     */
    public static function filter_sanitize_file_name( $filename, $filename_raw, $source ) {
        $pattern = (string) get_option( 'arthur_ai_auto_rename_uploads_pattern', '' );
        if ( '' === $pattern ) {
            return $filename;
        }
        $info = pathinfo( $filename );
        $ext  = isset( $info['extension'] ) ? '.' . $info['extension'] : '';
        $base = isset( $info['filename'] ) ? $info['filename'] : $filename;
        $replacements = array();
        // {date}
        $replacements['{date}'] = date( 'Ymd' );
        // {random}
        $replacements['{random}'] = substr( md5( uniqid( '', true ) ), 0, 8 );
        // {post_slug}
        $post_slug = '';
        // Try to determine parent post ID from request
        $post_id = 0;
        if ( isset( $_REQUEST['post_id'] ) ) {
            $post_id = intval( $_REQUEST['post_id'] );
        } elseif ( isset( $_REQUEST['post'] ) ) {
            $post_id = intval( $_REQUEST['post'] );
        }
        if ( $post_id > 0 ) {
            $post = get_post( $post_id );
            if ( $post ) {
                $post_slug = $post->post_name;
            }
        }
        $replacements['{post_slug}'] = $post_slug ? $post_slug : $base;
        $new_base = $pattern;
        foreach ( $replacements as $token => $value ) {
            $new_base = str_replace( $token, $value, $new_base );
        }
        // Sanitise the resulting name.
        $new_base = sanitize_title( $new_base );
        if ( '' === $new_base ) {
            return $filename;
        }
        return $new_base . $ext;
    }

    /**
     * Optimise images on metadata generation and optionally create WebP copies.
     *
     * @param array $metadata Attachment metadata.
     * @param int   $attachment_id Attachment ID.
     * @return array
     */
    public static function maybe_optimise_images( $metadata, $attachment_id ) {
        $file = get_attached_file( $attachment_id );
        if ( ! $file || ! file_exists( $file ) ) {
            return $metadata;
        }
        $mime      = wp_check_filetype( $file, null );
        $extension = isset( $mime['ext'] ) ? strtolower( $mime['ext'] ) : '';
        // Optimisation settings.
        $opt_enabled   = (bool) get_option( 'arthur_ai_auto_optimise_images_enabled', false );
        $jpeg_quality  = (int) get_option( 'arthur_ai_auto_optimise_images_quality_jpeg', 82 );
        $png_quality   = (int) get_option( 'arthur_ai_auto_optimise_images_quality_png', 7 );
        if ( $opt_enabled ) {
            if ( in_array( $extension, array( 'jpg', 'jpeg' ), true ) ) {
                self::compress_jpeg( $file, $jpeg_quality );
            } elseif ( 'png' === $extension ) {
                self::compress_png( $file, $png_quality );
            }
        }
        // WebP conversion settings.
        $webp_enabled  = get_option( 'arthur_ai_convert_images_to_webp_enabled', get_option( 'arthur_ai_convert_images_to_webp', false ) );
        $webp_quality  = (int) get_option( 'arthur_ai_convert_images_to_webp_quality', 80 );
        if ( $webp_enabled && function_exists( 'imagewebp' ) && in_array( $extension, array( 'jpg', 'jpeg', 'png' ), true ) ) {
            self::create_webp_copy( $file, $webp_quality );
        }
        return $metadata;
    }

    /**
     * Compress a JPEG image file in place using GD.
     *
     * @param string $file
     * @param int    $quality
     */
    protected static function compress_jpeg( $file, $quality ) {
        if ( ! function_exists( 'imagecreatefromjpeg' ) || ! function_exists( 'imagejpeg' ) ) {
            return;
        }
        $img = @imagecreatefromjpeg( $file );
        if ( ! $img ) {
            return;
        }
        // Overwrite file with new quality.
        @imagejpeg( $img, $file, $quality );
        imagedestroy( $img );
    }

    /**
     * Compress a PNG image using GD.
     *
     * The quality parameter is 0–9 where 9 is the highest compression.
     *
     * @param string $file
     * @param int    $quality
     */
    protected static function compress_png( $file, $quality ) {
        if ( ! function_exists( 'imagecreatefrompng' ) || ! function_exists( 'imagepng' ) ) {
            return;
        }
        $img = @imagecreatefrompng( $file );
        if ( ! $img ) {
            return;
        }
        // Ensure quality is within bounds 0–9.
        $q = max( 0, min( 9, (int) $quality ) );
        @imagepng( $img, $file, $q );
        imagedestroy( $img );
    }

    /**
     * Create a WebP copy of an image file if it doesn't already exist.
     *
     * @param string $file The original image file path.
     */
    protected static function create_webp_copy( $file, $quality = 80 ) {
        $dest = $file . '.webp';
        if ( file_exists( $dest ) ) {
            return;
        }
        $mime = wp_check_filetype( $file, null );
        $ext  = isset( $mime['ext'] ) ? strtolower( $mime['ext'] ) : '';
        if ( ! in_array( $ext, array( 'jpg', 'jpeg', 'png' ), true ) ) {
            return;
        }
        if ( 'png' === $ext && function_exists( 'imagecreatefrompng' ) ) {
            $img = @imagecreatefrompng( $file );
        } elseif ( function_exists( 'imagecreatefromjpeg' ) ) {
            $img = @imagecreatefromjpeg( $file );
        } else {
            return;
        }
        if ( ! $img ) {
            return;
        }
        $q = max( 1, min( 100, (int) $quality ) );
        @imagewebp( $img, $dest, $q );
        imagedestroy( $img );
    }

    /**
     * Optimise an existing attachment based on current settings.
     *
     * @param int $attachment_id Attachment ID to optimise.
     * @return bool True on success, false otherwise.
     */
    public static function optimise_existing_attachment( $attachment_id ) {
        $attachment_id = intval( $attachment_id );
        if ( $attachment_id <= 0 ) {
            return false;
        }
        $file = get_attached_file( $attachment_id );
        if ( ! $file || ! file_exists( $file ) ) {
            return false;
        }
        $mime      = wp_check_filetype( $file, null );
        $extension = isset( $mime['ext'] ) ? strtolower( $mime['ext'] ) : '';
        $opt_enabled  = (bool) get_option( 'arthur_ai_auto_optimise_images_enabled', false );
        $jpeg_q       = (int) get_option( 'arthur_ai_auto_optimise_images_quality_jpeg', 82 );
        $png_q        = (int) get_option( 'arthur_ai_auto_optimise_images_quality_png', 7 );
        $webp_enabled = get_option( 'arthur_ai_convert_images_to_webp_enabled', get_option( 'arthur_ai_convert_images_to_webp', false ) );
        $webp_q       = (int) get_option( 'arthur_ai_convert_images_to_webp_quality', 80 );
        if ( $opt_enabled ) {
            if ( in_array( $extension, array( 'jpg', 'jpeg' ), true ) ) {
                self::compress_jpeg( $file, $jpeg_q );
            } elseif ( 'png' === $extension ) {
                self::compress_png( $file, $png_q );
            }
        }
        if ( $webp_enabled && function_exists( 'imagewebp' ) && in_array( $extension, array( 'jpg', 'jpeg', 'png' ), true ) ) {
            self::create_webp_copy( $file, $webp_q );
        }
        return true;
    }

    /**
     * Register media taxonomies for attachments.
     *
     * These taxonomies allow attachments to be categorised and tagged in
     * the media library. They are only registered if they do not already
     * exist.
     */
    public static function register_taxonomies() {
        // Media tags taxonomy (non-hierarchical).
        if ( ! taxonomy_exists( 'media_tag' ) ) {
            register_taxonomy( 'media_tag', 'attachment', array(
                'label'             => __( 'Media Tags', 'arthur-ai' ),
                'public'            => true,
                'show_admin_column' => true,
                'hierarchical'      => false,
                'rewrite'           => array( 'slug' => 'media-tag' ),
            ) );
        }
        // Media categories taxonomy (hierarchical).
        if ( ! taxonomy_exists( 'media_category' ) ) {
            register_taxonomy( 'media_category', 'attachment', array(
                'label'             => __( 'Media Categories', 'arthur-ai' ),
                'public'            => true,
                'show_admin_column' => true,
                'hierarchical'      => true,
                'rewrite'           => array( 'slug' => 'media-category' ),
            ) );
        }
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Email customiser for WooCommerce emails.
 *
 * This helper applies template overrides (subject, heading, body) and
 * trigger rules for WooCommerce transactional emails based on
 * configuration saved by AI actions. It is initialised independently
 * of the WooCommerce customiser to ensure email hooks fire early.
 */
class Arthur_AI_Email_Customiser {

    /**
     * Initialise email customisations and triggers.
     */
    public static function init() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return;
        }
        add_action( 'init', array( __CLASS__, 'apply_email_customisations' ), 30 );
    }

    /**
     * Apply email template overrides and trigger rules.
     */
    public static function apply_email_customisations() {
        // Apply overrides
        $customisations = get_option( 'arthur_ai_woo_email_customisations', array() );
        if ( is_array( $customisations ) ) {
            foreach ( $customisations as $email_id => $settings ) {
                if ( isset( $settings['subject'] ) ) {
                    add_filter( 'woocommerce_email_subject_' . $email_id, function( $subject, $order ) use ( $settings ) {
                        return $settings['subject'];
                    }, 10, 2 );
                }
                if ( isset( $settings['heading'] ) ) {
                    add_filter( 'woocommerce_email_heading_' . $email_id, function( $heading, $order ) use ( $settings ) {
                        return $settings['heading'];
                    }, 10, 2 );
                }
                if ( isset( $settings['body_html'] ) ) {
                    add_filter( 'woocommerce_email_content_' . $email_id, function( $content, $order ) use ( $settings ) {
                        return wp_kses_post( $settings['body_html'] );
                    }, 10, 2 );
                }
            }
        }
        // Apply trigger rules
        $triggers = get_option( 'arthur_ai_email_triggers', array() );
        if ( is_array( $triggers ) ) {
            foreach ( $triggers as $email_id => $rule ) {
                if ( isset( $rule['enabled'] ) ) {
                    add_filter( 'woocommerce_email_enabled_' . $email_id, function( $enabled, $order ) use ( $rule ) {
                        return $rule['enabled'] ? true : false;
                    }, 10, 2 );
                }
            }
        }
    }
}
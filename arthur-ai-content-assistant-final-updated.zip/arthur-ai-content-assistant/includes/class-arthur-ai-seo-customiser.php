<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Outputs SEO meta tags, indexing flags and schema when no third‑party SEO
 * plugin is responsible for them. This customiser reads values stored by
 * Arthur AI actions and echoes appropriate tags in the head of the page.
 */
class Arthur_AI_SEO_Customiser {

    /**
     * Hook into WordPress.
     */
    public static function init() {
        // Output meta tags early in the head.
        add_action( 'wp_head', array( __CLASS__, 'output_meta_tags' ), 1 );
    }

    /**
     * Output custom SEO tags if no SEO plugin handles them.
     */
    public static function output_meta_tags() {
        // Skip in admin or if not on a singular object.
        if ( is_admin() || is_feed() ) {
            return;
        }
        if ( ! is_singular() ) {
            return;
        }
        global $post;
        if ( ! $post ) {
            return;
        }
        $post_id = $post->ID;
        // If a SEO plugin is active, only output robots/meta tags when flags are set to override.
        $seo_plugin_active = defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Meta' ) || defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' );
        // Title and description: output only when no SEO plugin is present.
        if ( ! $seo_plugin_active ) {
            $title  = get_post_meta( $post_id, '_arthur_ai_seo_title', true );
            $desc   = get_post_meta( $post_id, '_arthur_ai_seo_description', true );
            if ( $title ) {
                // Replace any existing title tag by outputting earlier (priority 1)
                echo '<title>' . esc_html( $title ) . '</title>' . "\n";
            }
            if ( $desc ) {
                echo '<meta name="description" content="' . esc_attr( $desc ) . '" />' . "\n";
            }
        }
        // Robots flags: these should always be respected if set on the post.
        $robots = array();
        $noindex  = get_post_meta( $post_id, '_arthur_ai_noindex', true );
        $nofollow = get_post_meta( $post_id, '_arthur_ai_nofollow', true );
        $noarchive = get_post_meta( $post_id, '_arthur_ai_noarchive', true );
        if ( $noindex ) {
            $robots[] = 'noindex';
        }
        if ( $nofollow ) {
            $robots[] = 'nofollow';
        }
        if ( $noarchive ) {
            $robots[] = 'noarchive';
        }
        if ( ! empty( $robots ) ) {
            echo '<meta name="robots" content="' . esc_attr( implode( ',', $robots ) ) . '" />' . "\n";
        }
        // Output schema markup if present
        $schema_json = get_post_meta( $post_id, '_arthur_ai_schema_json', true );
        if ( $schema_json ) {
            // Ensure valid JSON is output; if string, output as is; arrays are not expected here.
            echo '<script type="application/ld+json">' . $schema_json . '</script>' . "\n";
        }
    }
}
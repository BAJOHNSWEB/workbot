<?php
/**
 * Subscriptions customiser.
 *
 * Applies subscription renewal flow customisations for WooCommerce Subscriptions.
 * This includes overriding the subject, heading and body content of renewal
 * related transactional emails and handling basic failed payment policies. It
 * reads settings from the option `arthur_ai_subscription_flows` which is
 * configured by the AI via the `configure_subscription_renewal_flows` action.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Subscriptions_Customiser {
    /**
     * Initialise hooks if Woo Subscriptions is active.
     */
    public static function init() {
        if ( ! class_exists( 'WC_Subscriptions' ) ) {
            return;
        }
        // Apply email overrides for defined email IDs
        add_filter( 'woocommerce_email_subject_customer_renewal_invoice', array( __CLASS__, 'filter_email_subject' ), 10, 2 );
        add_filter( 'woocommerce_email_heading_customer_renewal_invoice', array( __CLASS__, 'filter_email_heading' ), 10, 2 );
        add_filter( 'woocommerce_email_content_customer_renewal_invoice', array( __CLASS__, 'filter_email_content' ), 10, 4 );
        add_filter( 'woocommerce_email_subject_customer_renewal_note', array( __CLASS__, 'filter_email_subject' ), 10, 2 );
        add_filter( 'woocommerce_email_heading_customer_renewal_note', array( __CLASS__, 'filter_email_heading' ), 10, 2 );
        add_filter( 'woocommerce_email_content_customer_renewal_note', array( __CLASS__, 'filter_email_content' ), 10, 4 );
        add_filter( 'woocommerce_email_subject_customer_completed_renewal_order', array( __CLASS__, 'filter_email_subject' ), 10, 2 );
        add_filter( 'woocommerce_email_heading_customer_completed_renewal_order', array( __CLASS__, 'filter_email_heading' ), 10, 2 );
        add_filter( 'woocommerce_email_content_customer_completed_renewal_order', array( __CLASS__, 'filter_email_content' ), 10, 4 );
        add_filter( 'woocommerce_email_subject_customer_payment_retry', array( __CLASS__, 'filter_email_subject' ), 10, 2 );
        add_filter( 'woocommerce_email_heading_customer_payment_retry', array( __CLASS__, 'filter_email_heading' ), 10, 2 );
        add_filter( 'woocommerce_email_content_customer_payment_retry', array( __CLASS__, 'filter_email_content' ), 10, 4 );
        // Failed payment handling
        add_action( 'woocommerce_subscription_renewal_payment_failed', array( __CLASS__, 'handle_failed_payment' ), 10, 2 );
        // Show failed payment message on My Account if necessary
        add_action( 'woocommerce_account_content', array( __CLASS__, 'maybe_display_failed_payment_message' ) );
    }

    /**
     * Retrieve configured flows from the database.
     */
    protected static function get_flows() {
        $flows = get_option( 'arthur_ai_subscription_flows', array() );
        return is_array( $flows ) ? $flows : array();
    }

    /**
     * Filter email subject based on configured overrides.
     *
     * @param string $subject The original subject.
     * @param WC_Order $order The order instance.
     * @return string
     */
    public static function filter_email_subject( $subject, $order ) {
        $flows = self::get_flows();
        if ( empty( $flows ) ) {
            return $subject;
        }
        $email_id = current_filter();
        // Map filter name to our internal keys
        $map = array(
            'woocommerce_email_subject_customer_renewal_invoice'           => 'upcoming_renewal',
            'woocommerce_email_subject_customer_renewal_note'              => 'upcoming_renewal',
            'woocommerce_email_subject_customer_completed_renewal_order'   => 'renewal_success',
            'woocommerce_email_subject_customer_payment_retry'             => 'renewal_failure',
        );
        if ( isset( $map[ $email_id ] ) && isset( $flows['renewal_emails'][ $map[ $email_id ] ]['subject'] ) ) {
            return $flows['renewal_emails'][ $map[ $email_id ] ]['subject'];
        }
        return $subject;
    }

    /**
     * Filter email heading based on configured overrides.
     */
    public static function filter_email_heading( $heading, $order ) {
        $flows = self::get_flows();
        if ( empty( $flows ) ) {
            return $heading;
        }
        $email_id = current_filter();
        $map = array(
            'woocommerce_email_heading_customer_renewal_invoice'         => 'upcoming_renewal',
            'woocommerce_email_heading_customer_renewal_note'            => 'upcoming_renewal',
            'woocommerce_email_heading_customer_completed_renewal_order' => 'renewal_success',
            'woocommerce_email_heading_customer_payment_retry'           => 'renewal_failure',
        );
        if ( isset( $map[ $email_id ] ) && isset( $flows['renewal_emails'][ $map[ $email_id ] ]['heading'] ) ) {
            return $flows['renewal_emails'][ $map[ $email_id ] ]['heading'];
        }
        return $heading;
    }

    /**
     * Filter email body content.
     *
     * @param string $content The email content.
     * @param bool   $is_plain_text Whether email is plain text.
     * @param object $order Order instance.
     * @param object $email Email object.
     */
    public static function filter_email_content( $content, $is_plain_text, $order, $email ) {
        $flows = self::get_flows();
        if ( empty( $flows ) ) {
            return $content;
        }
        $email_id = current_filter();
        $map = array(
            'woocommerce_email_content_customer_renewal_invoice'         => 'upcoming_renewal',
            'woocommerce_email_content_customer_renewal_note'            => 'upcoming_renewal',
            'woocommerce_email_content_customer_completed_renewal_order' => 'renewal_success',
            'woocommerce_email_content_customer_payment_retry'           => 'renewal_failure',
        );
        if ( isset( $map[ $email_id ] ) && isset( $flows['renewal_emails'][ $map[ $email_id ] ]['body_html'] ) ) {
            // Return custom HTML for HTML emails; for plain text, strip tags
            $html = $flows['renewal_emails'][ $map[ $email_id ] ]['body_html'];
            if ( $is_plain_text ) {
                return wp_strip_all_tags( $html );
            }
            return wp_kses_post( $html );
        }
        return $content;
    }

    /**
     * Handle failed subscription payment according to configured policy.
     */
    public static function handle_failed_payment( $subscription, $order ) {
        $flows = self::get_flows();
        if ( empty( $flows ) || empty( $flows['failed_payment_policy'] ) ) {
            return;
        }
        $policy = $flows['failed_payment_policy'];
        $max_retries = isset( $policy['max_retries'] ) ? intval( $policy['max_retries'] ) : 0;
        $retry_interval = isset( $policy['retry_interval'] ) ? intval( $policy['retry_interval'] ) : 0;
        $final_status = isset( $policy['final_status'] ) ? sanitize_key( $policy['final_status'] ) : '';
        $subscription_id = $subscription->get_id();
        // Woo Subscriptions automatically retries payments via its own settings; we just record a note and update status if necessary.
        if ( $max_retries > 0 ) {
            $note = sprintf( __( 'Payment failed. Will retry %d more time(s) every %d hour(s).', 'arthur-ai' ), $max_retries, $retry_interval );
            $subscription->add_order_note( $note );
        }
        if ( $final_status && in_array( $final_status, array( 'on-hold', 'cancelled' ), true ) ) {
            // If final status should be applied immediately after failure
            if ( $max_retries === 0 ) {
                $subscription->update_status( $final_status, __( 'Updated by Arthur_AI_Subscriptions_Customiser due to failed payment policy.', 'arthur-ai' ) );
            }
        }
    }

    /**
     * Display a message in My Account if subscription has failed and policy sets a message.
     */
    public static function maybe_display_failed_payment_message() {
        $flows = self::get_flows();
        if ( empty( $flows ) || empty( $flows['failed_payment_policy'] ) ) {
            return;
        }
        $policy = $flows['failed_payment_policy'];
        $message = isset( $policy['message'] ) ? $policy['message'] : '';
        if ( empty( $message ) ) {
            return;
        }
        // Check if user has any on-hold subscriptions due to failed payments
        $subscriptions = wcs_get_users_subscriptions( get_current_user_id(), array( 'status' => 'on-hold' ) );
        foreach ( $subscriptions as $subscription ) {
            if ( $subscription->has_status( 'on-hold' ) ) {
                echo '<div class="woocommerce-message arthur-ai-subscription-failed">' . wp_kses_post( $message ) . '</div>';
                break;
            }
        }
    }
}
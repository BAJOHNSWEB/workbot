<?php
/**
 * LMS customiser.
 *
 * Provides helper functions and hooks for LMS-related actions. This class
 * mainly exposes methods to retrieve a user’s enrolled courses and progress
 * across supported LMS providers and to evaluate recommendation rules.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Lms_Customiser {
    /**
     * Initialise hooks (none currently).
     */
    public static function init() {
        // At present, this customiser does not attach any hooks. It exists
        // primarily to expose helper methods for other components such as the
        // Member Dashboard. Future integrations could hook into LMS events to
        // enforce course structures or prerequisites.
    }

    /**
     * Get the list of courses a user is enrolled in for a given LMS provider.
     *
     * @param string $provider LMS provider slug (learndash, lifterlms, tutorlms).
     * @param int    $user_id  User ID.
     * @return array List of course IDs.
     */
    public static function get_user_courses( $provider, $user_id ) {
        $courses = array();
        if ( 'learndash' === $provider && defined( 'LEARNDASH_VERSION' ) ) {
            if ( function_exists( 'ld_get_mycourses' ) ) {
                $list = ld_get_mycourses( $user_id );
                if ( is_array( $list ) ) {
                    foreach ( $list as $course ) {
                        $courses[] = intval( $course->ID );
                    }
                }
            }
        } elseif ( 'lifterlms' === $provider && ( defined( 'LLMS_VERSION' ) || function_exists( 'llms' ) ) ) {
            if ( class_exists( 'LLMS_Student' ) ) {
                $student = new LLMS_Student( $user_id );
                $enrolled = $student->get_courses();
                if ( is_array( $enrolled ) ) {
                    foreach ( $enrolled as $course ) {
                        $courses[] = intval( $course );
                    }
                }
            }
        } elseif ( 'tutorlms' === $provider && ( function_exists( 'tutor_utils' ) || defined( 'TUTOR_VERSION' ) ) ) {
            if ( function_exists( 'tutor_utils' ) && method_exists( tutor_utils(), 'get_enrolled_courses_by_user' ) ) {
                $enrolled = tutor_utils()->get_enrolled_courses_by_user( $user_id );
                if ( is_array( $enrolled ) ) {
                    foreach ( $enrolled as $course ) {
                        if ( isset( $course->ID ) ) {
                            $courses[] = intval( $course->ID );
                        }
                    }
                }
            }
        }
        return $courses;
    }

    /**
     * Evaluate recommendation rules for a user and return recommended content.
     *
     * @param int $user_id User ID.
     * @return array Array of recommended content IDs (courses or posts).
     */
    public static function get_recommendations_for_user( $user_id ) {
        $rules = get_option( 'arthur_ai_member_recommendations', array() );
        if ( empty( $rules ) ) {
            return array();
        }
        $recommendations = array();
        // Determine user's membership levels
        $levels = self::get_user_membership_levels( $user_id );
        // Determine user's enrolled courses across providers
        $user_courses = self::get_all_user_courses( $user_id );
        // Determine completion percentages (not currently calculated)
        $course_progress = array();
        foreach ( $rules as $rule ) {
            $segment = isset( $rule['segment'] ) ? $rule['segment'] : array();
            $recs    = isset( $rule['recommendations'] ) ? $rule['recommendations'] : array();
            $match   = true;
            // Check membership level segment
            if ( isset( $segment['membership_levels'] ) && is_array( $segment['membership_levels'] ) ) {
                $match = false;
                foreach ( $segment['membership_levels'] as $level ) {
                    if ( in_array( $level, $levels, true ) ) {
                        $match = true;
                        break;
                    }
                }
            }
            if ( ! $match ) {
                continue;
            }
            // Check course enrolments
            if ( isset( $segment['enrolled_courses'] ) && is_array( $segment['enrolled_courses'] ) ) {
                foreach ( $segment['enrolled_courses'] as $cid ) {
                    if ( ! in_array( intval( $cid ), $user_courses, true ) ) {
                        $match = false;
                        break;
                    }
                }
            }
            if ( ! $match ) {
                continue;
            }
            // Additional criteria (completion thresholds) not implemented; assume match
            // Append recommendations
            foreach ( $recs as $content_id ) {
                $content_id = intval( $content_id );
                if ( $content_id && ! in_array( $content_id, $recommendations, true ) ) {
                    $recommendations[] = $content_id;
                }
            }
        }
        return $recommendations;
    }

    /**
     * Get user’s active membership level IDs across supported providers.
     */
    protected static function get_user_membership_levels( $user_id ) {
        $levels = array();
        // Woo Memberships
        if ( class_exists( 'WC_Memberships' ) && function_exists( 'wc_memberships_get_user_active_memberships' ) ) {
            $memberships = wc_memberships_get_user_active_memberships( $user_id );
            foreach ( $memberships as $membership ) {
                $levels[] = strval( $membership->plan_id );
            }
        }
        // PMPro
        if ( function_exists( 'pmpro_getMembershipLevelForUser' ) ) {
            $level = pmpro_getMembershipLevelForUser( $user_id );
            if ( $level && isset( $level->id ) ) {
                $levels[] = strval( $level->id );
            }
        }
        // MemberPress
        if ( class_exists( 'MeprUser' ) ) {
            $mepr_user = new MeprUser( $user_id );
            $products  = $mepr_user->active_products();
            foreach ( $products as $prod ) {
                $levels[] = strval( $prod->ID );
            }
        }
        return $levels;
    }

    /**
     * Get all courses a user is enrolled in across all supported providers.
     */
    protected static function get_all_user_courses( $user_id ) {
        $courses = array();
        $providers = array( 'learndash', 'lifterlms', 'tutorlms' );
        foreach ( $providers as $p ) {
            $courses = array_merge( $courses, self::get_user_courses( $p, $user_id ) );
        }
        return array_unique( $courses );
    }
}
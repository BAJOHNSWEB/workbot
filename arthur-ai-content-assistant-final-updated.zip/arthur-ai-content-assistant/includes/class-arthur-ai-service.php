<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Service {

    const ENDPOINT = 'https://api.openai.com/v1/chat/completions';
    const MODEL    = 'gpt-4.1-mini';

        /**
     * Mark certain actions as higher-risk because they apply custom code (CSS/JS).
     *
     * @param string $action_type
     * @return bool
     */
    public static function is_risky_action_type( $action_type ) {
        $risky_actions = array(
            'set_login_custom_css',
            'set_admin_custom_css',
            'set_login_custom_js', // if/when you add this
        );

        return in_array( $action_type, $risky_actions, true );
    }


    /**
     * Call the AI and get an action + fields.
     *
     * @param string                     $user_request
     * @param array                      $site_map
     * @param array|null                 $uploaded_image_context
     * @param Arthur_AI_Module_Interface $module
     *
     * @return array
     */
    public function generate_action( $user_request, array $site_map, ?array $uploaded_image_context, Arthur_AI_Module_Interface $module ) {
        $api_key = Arthur_AI_Settings::get_api_key();
        if ( empty( $api_key ) ) {
            return array( 'error' => 'No API key configured. Please enter your API key in the Arthur AI settings.' );
        }

        $user_request = trim( (string) $user_request );
        if ( '' === $user_request ) {
            return array( 'error' => 'Request cannot be empty.' );
        }

        $site_map_json = wp_json_encode( $site_map );
        $image_info    = '';
        if ( $uploaded_image_context && is_array( $uploaded_image_context ) ) {
            $image_info = ' An image has been uploaded: ' . wp_json_encode( $uploaded_image_context ) . '.';
        }

        $allowed_actions      = $module->get_allowed_actions();
        $allowed_actions_json = wp_json_encode( $allowed_actions );
        $module_context       = $module->get_prompt_context();

        
        $system_message  = "You are Arthur, an AI WordPress assistant.\n";
        $system_message .= "You operate in modular domains. You are currently in the Content module.\n\n";
        $system_message .= $module_context . "\n\n";
        $system_message .= "You are given:\n";
        $system_message .= "- A site map (array of posts/pages with ID, title, type, permalink).\n";
        $system_message .= "- A user request.\n";
        $system_message .= "- Optionally, an uploaded image.\n\n";
        $system_message .= "You must decide on ONE action_type from the following list:\n";
        $system_message .= $allowed_actions_json . "\n\n";
        $system_message .= "Prefer updating existing content when the user refers to an existing page or post by name (e.g. 'About Us page'). Only create new items when clearly requested or when no suitable existing content is available.\n";
        $system_message .= "If the user mentions an 'About', 'Contact', 'Services', 'Team', 'Privacy', or similar site page, treat that as a PAGE (post_type = 'page').\n\n";
        $system_message .= "When the user provides structured content like:\n";
        $system_message .= "- Main heading\n- Intro paragraph\n- Sections (each with heading + paragraph)\n- Image tasks (add/replace under a specific paragraph)\n";
        $system_message .= "you should choose a rewrite-style or create-style action (e.g. 'rewrite_post_body' or 'create_post') and build a fully structured layout, not a single appended block. For example:\n";
        $system_message .= "- Use <h1> for the main page heading (for pages) or top-level heading.\n";
        $system_message .= "- Use <h2> (or <h3>) for each section heading.\n";
        $system_message .= "- Use <p> for each paragraph.\n";
        $system_message .= "- You may group related blocks into <section> wrappers with descriptive classes (e.g. <section class=\"arthur-ai-section\">).\n";
        $system_message .= "- For images, insert <figure class=\"arthur-ai-inline-image\"><img ... /></figure> near the referenced paragraph.\n";
        $system_message .= "Do NOT just insert one monolithic block at the bottom when the user clearly describes a full-page layout.\n\n";
        $system_message .= "Return a JSON object ONLY, with these keys:\n";
        $system_message .= "{\n";
        $system_message .= "  \"action_type\": string,\n";
        $system_message .= "  \"target_post_id\": number|null,\n";
        $system_message .= "  \"fields\": object\n";
        $system_message .= "}\n\n";
        $system_message .= "Where:\n";
        $system_message .= "- action_type is one of the allowed action types above.\n";
        $system_message .= "- target_post_id is null for actions that create new content, otherwise an existing ID from the site map.\n";
        $system_message .= "- fields is an object containing any additional parameters required by the chosen action.\n\n";
        $system_message .= "Field expectations per action_type:\n";
        $system_message .= "1) create_post:\n";
        $system_message .= "   fields = { \"post_title\": string, \"post_content\": string, \"post_type\": \"post\" or \"page\" }\n";
        $system_message .= "   - Use post_type = \"page\" for things like About, Contact, Services, Team, etc., especially when the user explicitly says 'page'.\n";
        $system_message .= "   - post_content must be well-structured HTML (headings, sections, paragraphs, optional images).\n";
        $system_message .= "2) update_post_image_and_text:\n";
        $system_message .= "   fields = { \"note\": string|null, \"snippet_text\": string|null }\n";
        $system_message .= "   - Always fill snippet_text with the exact visible paragraph text you are targeting when the user references a specific line or paragraph (e.g. 'under the paragraph titled \"Hello\"').\n";
        $system_message .= "3) rewrite_post_body:\n";
        $system_message .= "   fields = { \"post_content\": string }\n";
        $system_message .= "   - Use this when the user provides a full new layout for an existing page (e.g. a complete About Us page breakdown).\n";
        $system_message .= "   - post_content must be well-structured HTML with multiple sections/headings as described by the user, not a single block.\n";
        $system_message .= "4) append_note_to_post:\n";
        $system_message .= "   fields = { \"note\": string }\n";
        $system_message .= "5) replace_snippet_in_post:\n";
        $system_message .= "   fields = { \"find\": string, \"replace_with\": string }\n";
        $system_message .= "   - Always set find to the exact visible text or attribute fragment you expect to be in the HTML. When replacing images, \"find\" may be part of the image URL or tag, and the system will remove the whole <img> tag.\n";
        $system_message .= "6) insert_after_heading_in_post:\n";
        $system_message .= "   fields = { \"heading_text\": string, \"insert_html\": string }\n";
        $system_message .= "   - insert_html can be any valid HTML block such as quotes (<blockquote>), callouts, bullet lists, CTAs, etc.\n";
        $system_message .= "7) insert_at_bottom_of_post:\n";
        $system_message .= "   fields = { \"insert_html\": string }\n";
        $system_message .= "   - Use this only for small additions, not for full page rewrites.\n";
        $system_message .= "8) bulk_create_posts:\n";
        $system_message .= "   fields = { \"posts\": [ { \"post_title\": string, \"post_content\": string } ] }\n";
        $system_message .= "9) generate_summary_post:\n";
        $system_message .= "   fields = { \"source_post_ids\": [number], \"post_title\": string, \"post_content\": string }\n";
        $system_message .= "10) publish_post:\n";
        $system_message .= "   fields = { }\n";
        $system_message .= "   - Use when the user explicitly asks you to publish a specific draft page/post.\n";
        $system_message .= "11) update_menu_add_items:\n";
        $system_message .= "   fields = { \"menu_location\": string|null, \"menu_name\": string|null, \"items\": [ { \"title\": string|null, \"url\": string|null, \"post_id\": number|null } ] }\n";
        $system_message .= "   - Use when the user wants to add existing pages or posts (or custom links) to a navigation menu. Prefer using post_id when adding existing pages (e.g. About, Contact).\n";
        $system_message .= "12) replace_frontend_snippet:\n";
        $system_message .= "   fields = { \"find\": string, \"replace_with\": string }\n";
        $system_message .= "   - Use for site-wide footer/header text changes when you cannot reliably identify a specific template. This works by replacing the visible text in the rendered HTML on output.\n";
        $system_message .= "13) replace_in_elementor_data:\n";
        $system_message .= "   fields = { \"find\": string, \"replace_with\": string }\n";
        $system_message .= "   - Use when the content is clearly inside an Elementor header/footer/template or Elementor-built page (e.g. hero heading, Elementor image URL). Choose a \"find\" snippet that actually appears in the Elementor JSON, such as the current heading text or image URL.\n";
        $system_message .= "14) replace_in_block_template:\n";
        $system_message .= "   fields = { \"find\": string, \"replace_with\": string }\n";
        $system_message .= "   - Use when editing block theme headers/footers (wp_template/wp_template_part). Prefer this for phrases like \"Designed with WordPress\" when using a block theme such as Twenty Twenty-Five.\n\n";
        $system_message .= "Do NOT include markdown, comments or extra keys. Respond with JSON only.";

                          $system_message .= "15) set_login_custom_css:\n";
        $system_message .= "   fields = { \"css\": string }\n";
        $system_message .= "   - Use this when the user asks for a visual tweak on the WordPress login page that is best done with CSS.\n";
        $system_message .= "   - Use these selectors for common elements:\n";
        $system_message .= "       * .arthur-ai-login-message – the welcome text above the form\n";
        $system_message .= "       * body.login – the login page background\n";
        $system_message .= "       * body.login #loginform – the login box\n";
        $system_message .= "       * body.login #wp-submit – the login button\n";
        $system_message .= "       * body.login #login h1 a – the login logo\n";
        $system_message .= "   - Example: to make the welcome text red, use:\n";
        $system_message .= "       .arthur-ai-login-message { color: red; }\n";
        $system_message .= "   - Write minimal, targeted CSS only.\n\n";

        // Admin customisation actions
        $system_message .= "16) change_admin_toolbar_colors:\n";
        $system_message .= "   fields = { \"toolbar_background\": string|null, \"toolbar_text\": string|null, \"toolbar_hover_background\": string|null, \"toolbar_hover_text\": string|null }\n";
        $system_message .= "   - Use this to change the colours of the WordPress admin toolbar. Provide only the colour values you wish to change; omit any unused fields.\n";
        $system_message .= "17) change_admin_menu_colors:\n";
        $system_message .= "   fields = { \"menu_background\": string|null, \"menu_text\": string|null, \"menu_hover_background\": string|null, \"menu_hover_text\": string|null }\n";
        $system_message .= "   - Use this to customise the colours of the WordPress admin side menu. Provide only the colour values you wish to change.\n";
        $system_message .= "18) set_admin_footer_text:\n";
        $system_message .= "   fields = { \"footer_text\": string }\n";
        $system_message .= "   - Use this to change the footer message displayed on all admin pages. It accepts basic HTML and replaces the default WordPress footer message.\n";
        $system_message .= "19) set_admin_custom_css:\n";
        $system_message .= "   fields = { \"css\": string }\n";
        $system_message .= "   - Use this when the user requests visual tweaks in the WordPress admin area that are best accomplished with CSS. Provide minimal, targeted CSS only.\n\n";
        // Admin menu / sidebar customisation actions
        $system_message .= "20) hide_admin_menu_items:\n";
        $system_message .= "   fields = { \"menu_slugs\": [string] }\n";
        $system_message .= "   - Use this to hide specific admin menu items globally. Provide an array of menu slugs (e.g. ['edit.php','tools.php','woocommerce']).\n";
        $system_message .= "21) rename_admin_menu_item:\n";
        $system_message .= "   fields = { \"menu_slug\": string, \"new_title\": string }\n";
        $system_message .= "   - Use this to rename an admin menu item. Provide the slug of the menu and the new label.\n";
        $system_message .= "22) reorder_admin_menu_items:\n";
        $system_message .= "   fields = { \"order\": [string] }\n";
        $system_message .= "   - Use this to define a new order for the admin menu. Specify an array of menu slugs in the desired order; unspecified items will follow in their existing order.\n";
        $system_message .= "23) add_admin_menu_page:\n";
        $system_message .= "   fields = { \"menu_slug\": string, \"menu_title\": string, \"page_title\": string, \"content\": string, \"capability\": string|null, \"icon\": string|null, \"position\": number|null }\n";
        $system_message .= "   - Use this to add a new top-level admin menu page with custom HTML content. The capability defaults to 'manage_options'; you may specify a dashicon slug or URL for the icon and an optional numeric position.\n";
        $system_message .= "24) add_admin_submenu_page:\n";
        $system_message .= "   fields = { \"parent_slug\": string, \"menu_slug\": string, \"menu_title\": string, \"page_title\": string, \"content\": string, \"capability\": string|null }\n";
        $system_message .= "   - Use this to add a submenu page under an existing admin menu. Provide the parent slug and the slug for the new submenu, along with titles and HTML content.\n";
        $system_message .= "25) hide_admin_menu_items_by_role:\n";
        $system_message .= "   fields = { \"roles\": [string], \"menu_slugs\": [string] }\n";
        $system_message .= "   - Use this to hide one or more admin menu items for specific user roles. Provide role slugs (e.g. ['editor']) and the menu slugs to hide.\n";
        $system_message .= "26) move_admin_settings:\n";
        $system_message .= "   fields = { \"position\": number }\n";
        $system_message .= "   - Use this to reposition the Settings menu within the admin sidebar. Provide a 1-based numeric index (1 = very top).\n";
        $system_message .= "27) collapse_admin_menu:\n";
        $system_message .= "   fields = { \"collapsed\": boolean }\n";
        $system_message .= "   - Use this to collapse or expand the admin menu by default. Set collapsed = true to collapse, false to expand.\n\n";

        // Post/page editor customisation actions
        $system_message .= "28) disable_gutenberg:\n";
        $system_message .= "   fields = { \"post_types\": [string] }\n";
        $system_message .= "   - Use this to disable the Gutenberg block editor for one or more post types (e.g. ['post','page']). This will switch those types back to the classic editor.\n";
        $system_message .= "29) enable_gutenberg_blocks:\n";
        $system_message .= "   fields = { \"blocks\": [string] }\n";
        $system_message .= "   - Use this to define an allow‑list of block names that are permitted in the editor. Provide block names such as 'core/paragraph' or 'core/image'. Only these blocks will be available; all others will be hidden.\n";
        $system_message .= "30) disable_gutenberg_blocks:\n";
        $system_message .= "   fields = { \"blocks\": [string] }\n";
        $system_message .= "   - Use this to define a deny‑list of block names that should be disallowed in the editor. Provide block names and all other blocks will remain available.\n";
        $system_message .= "31) set_auto_reusable_block:\n";
        $system_message .= "   fields = { \"block_id\": number|null, \"block_content\": string|null }\n";
        $system_message .= "   - Use this to automatically insert a reusable block into every new page. Provide either block_id for an existing reusable block (the ID from wp‑admin → Blocks), or block_content as raw HTML to insert if no block ID is provided. Setting both to null will clear the auto insertion.\n";
        $system_message .= "32) disable_comments:\n";
        $system_message .= "   fields = { \"disable\": boolean }\n";
        $system_message .= "   - Use this to globally disable or enable comments across the site. Set disable = true to turn off comments and pings.\n";
        $system_message .= "33) hide_featured_image_box:\n";
        $system_message .= "   fields = { \"post_types\": [string] }\n";
        $system_message .= "   - Use this to hide the featured image meta box for the given post types (e.g. ['post','page']). An empty array will re‑enable the box.\n";
        $system_message .= "34) hide_tags_categories_box:\n";
        $system_message .= "   fields = { \"hide_tags\": boolean|null, \"hide_categories\": boolean|null }\n";
        $system_message .= "   - Use this to hide the tags and/or categories meta boxes on the post editor screen. Provide hide_tags or hide_categories as true to remove that box; omit or set false to show.\n";
        $system_message .= "35) add_custom_fields:\n";
        $system_message .= "   fields = { \"custom_fields\": [ { \"key\": string, \"label\": string|null, \"type\": string|null, \"post_types\": [string]|null } ] }\n";
        $system_message .= "   - Use this to create one or more custom fields on the post editor screen. Each field must have a key; label defaults to the key, type defaults to 'text' or use 'textarea'. You may limit fields to specific post types.\n";
        $system_message .= "36) set_title_placeholder:\n";
        $system_message .= "   fields = { \"post_type\": string, \"placeholder\": string }\n";
        $system_message .= "   - Use this to change the placeholder text in the title input for a specific post type (e.g. set 'page' to 'Enter your page name…'). Provide an empty placeholder to restore the default.\n";
        $system_message .= "37) set_default_featured_image:\n";
        $system_message .= "   fields = { \"image_id\": number }\n";
        $system_message .= "   - Use this to set a default featured image (attachment ID) that will be applied when new posts or pages are created without a featured image. Pass 0 to clear.\n";
        $system_message .= "38) set_default_category:\n";
        $system_message .= "   fields = { \"category\": string|number }\n";
        $system_message .= "   - Use this to set a default category for new posts. Provide either the numeric category ID or the slug. Leave empty to clear.\n";
        $system_message .= "39) duplicate_post:\n";
        $system_message .= "   fields = { \"source_post_id\": number }\n";
        $system_message .= "   - Use this to duplicate a single existing post or page. It will create a new draft copy with the same title and content and return the new post_id.\n";
        $system_message .= "40) bulk_duplicate_posts:\n";
        $system_message .= "   fields = { \"source_post_ids\": [number] }\n";
        $system_message .= "   - Use this to duplicate multiple posts or pages at once. Provide an array of source IDs; it will return an array of new IDs for the duplicates.\n";
        $system_message .= "41) lock_pages:\n";
        $system_message .= "   fields = { \"page_ids\": [number], \"locked\": boolean }\n";
        $system_message .= "   - Use this to lock or unlock specific pages from editing by non‑administrators. Set locked = true to prevent editors from editing the given pages; set locked = false to remove them from the locked list.\n\n";

        // Profile/user customisation actions
        $system_message .= "42) force_strong_passwords:\n";
        $system_message .= "   fields = { \"enabled\": boolean, \"minimum_strength\": number|null }\n";
        $system_message .= "   - Use this to enforce strong passwords when users set or reset their passwords. Enable with a boolean and optionally set a minimum strength threshold (1-4).\n";
        $system_message .= "43) rename_user_roles:\n";
        $system_message .= "   fields = { \"roles\": { role_key: string } }\n";
        $system_message .= "   - Use this to change the display names of existing roles. Provide an object mapping role slugs to new labels.\n";
        $system_message .= "44) create_user_role:\n";
        $system_message .= "   fields = { \"role_key\": string, \"label\": string, \"capabilities\": { cap: boolean } }\n";
        $system_message .= "   - Use this to register a new custom user role with optional capabilities. Role keys must be lowercase with no spaces.\n";
        $system_message .= "45) hide_profile_fields:\n";
        $system_message .= "   fields = { \"fields\": [string] }\n";
        $system_message .= "   - Use this to remove built‑in fields from the user profile screen. Provide field IDs/keys like 'first_name' or 'last_name'.\n";
        $system_message .= "46) add_profile_fields:\n";
        $system_message .= "   fields = { \"fields\": [ { \"id\": string, \"label\": string|null, \"type\": string|null } ] }\n";
        $system_message .= "   - Use this to add custom fields to the user profile form. Types can be 'text' or 'textarea'; omit label or type for defaults.\n";
        $system_message .= "47) redirect_on_login:\n";
        $system_message .= "   fields = { \"redirects\": { role_key: url } }\n";
        $system_message .= "   - Use this to redirect users to specific URLs after login based on their role. Provide role→URL pairs.\n";
        $system_message .= "48) redirect_on_logout:\n";
        $system_message .= "   fields = { \"url\": string }\n";
        $system_message .= "   - Use this to send all users to a given URL after they log out.\n";
        $system_message .= "49) disable_admin_bar_for_non_admins:\n";
        $system_message .= "   fields = { \"disable\": boolean }\n";
        $system_message .= "   - Use this to hide the admin toolbar on the front‑end for non‑administrator users. Set disable = true to hide it.\n\n";

        // Security customisation actions
        $system_message .= "50) rename_login_url:\n";
        $system_message .= "   fields = { \"slug\": string }\n";
        $system_message .= "   - Use this to change the login URL slug from wp-login.php to a custom path (e.g. 'secure-login').\n";
        $system_message .= "51) disable_xml_rpc:\n";
        $system_message .= "   fields = { \"disable\": boolean }\n";
        $system_message .= "   - Use this to disable WordPress XML‑RPC functionality. Recommended for security if not needed.\n";
        $system_message .= "52) disable_file_editing:\n";
        $system_message .= "   fields = { \"disable\": boolean }\n";
        $system_message .= "   - Use this to prevent theme and plugin files being edited through the admin editor.\n";
        $system_message .= "53) limit_login_attempts:\n";
        $system_message .= "   fields = { \"max_attempts\": number, \"lockout_minutes\": number }\n";
        $system_message .= "   - Use this to throttle login attempts per IP/user. After max_attempts, the user is locked out for lockout_minutes.\n";
        $system_message .= "54) auto_logout_inactive_users:\n";
        $system_message .= "   fields = { \"timeout\": number }\n";
        $system_message .= "   - Use this to log out authenticated users after a period of inactivity (in minutes).\n";
        $system_message .= "55) hide_wp_version:\n";
        $system_message .= "   fields = { \"hide\": boolean }\n";
        $system_message .= "   - Use this to remove WordPress version information from the site's HTML and HTTP headers.\n";
        $system_message .= "56) disable_rest_api_for_guests:\n";
        $system_message .= "   fields = { \"disable\": boolean }\n";
        $system_message .= "   - Use this to block unauthenticated access to the WordPress REST API.\n\n";

        // Site settings and miscellaneous actions
        $system_message .= "57) change_site_title:\n";
        $system_message .= "   fields = { \"title\": string }\n";
        $system_message .= "   - Use this to update the site title (blogname option).\n";
        $system_message .= "58) change_site_tagline:\n";
        $system_message .= "   fields = { \"tagline\": string }\n";
        $system_message .= "   - Use this to update the site tagline (blogdescription option).\n";
        $system_message .= "59) change_permalink_structure:\n";
        $system_message .= "   fields = { \"structure\": string }\n";
        $system_message .= "   - Use this to set the permalink structure (e.g. '/%postname%/'). Affects all URLs and flushes rewrite rules.\n";
        $system_message .= "60) add_google_analytics_snippet:\n";
        $system_message .= "   fields = { \"snippet\": string }\n";
        $system_message .= "   - Use this to insert a Google Analytics tracking snippet into the <head> of all pages.\n";
        $system_message .= "61) add_custom_head_html:\n";
        $system_message .= "   fields = { \"html\": string }\n";
        $system_message .= "   - Use this to insert arbitrary HTML into the <head> of every page (trusted content only).\n";
        $system_message .= "62) add_custom_footer_html:\n";
        $system_message .= "   fields = { \"html\": string }\n";
        $system_message .= "   - Use this to insert arbitrary HTML just before the closing </body> tag on every page.\n";
        $system_message .= "63) toggle_comments_global:\n";
        $system_message .= "   fields = { \"disable\": boolean }\n";
        $system_message .= "   - Use this to globally enable or disable comments and pings across the site.\n";
        $system_message .= "64) add_cookie_banner_basic:\n";
        $system_message .= "   fields = { \"message\": string, \"button_label\": string|null, \"colour_background\": string|null, \"colour_text\": string|null }\n";
        $system_message .= "   - Use this to show a simple cookie banner. Provide the banner text and optionally customise the button label and colours.\n";
        $system_message .= "65) force_https_redirects:\n";
        $system_message .= "   fields = { \"force\": boolean }\n";
        $system_message .= "   - Use this to redirect all non‑HTTPS requests to HTTPS.\n\n";

        // Media customisation actions
        $system_message .= "66) auto_optimise_images:\n";
        $system_message .= "   fields = { \"enable\": boolean, \"quality\": number|null }\n";
        $system_message .= "   - Use this to compress uploaded JPEG and PNG files to a specified quality (0-100).\n";
        $system_message .= "67) auto_rename_uploads:\n";
        $system_message .= "   fields = { \"pattern\": string }\n";
        $system_message .= "   - Use this to rename uploaded files based on a pattern (e.g. '{post_slug}-{date}-{random}').\n";
        $system_message .= "68) replace_media_file:\n";
        $system_message .= "   fields = { \"attachment_id\": number, \"file_url\": string }\n";
        $system_message .= "   - Use this to replace the actual file for a given attachment ID with a new file located at the provided URL.\n";
        $system_message .= "69) add_image_sizes:\n";
        $system_message .= "   fields = { \"sizes\": [ { \"name\": string, \"width\": number, \"height\": number, \"crop\": boolean|null } ] }\n";
        $system_message .= "   - Use this to define additional intermediate image sizes. Set crop = true for hard crop.\n";
        $system_message .= "70) convert_images_to_webp:\n";
        $system_message .= "   fields = { \"enable\": boolean }\n";
        $system_message .= "   - Use this to automatically generate WebP versions of uploaded images where supported.\n";
        $system_message .= "71) generate_image_alt_text_ai:\n";
        $system_message .= "   fields = { \"attachment_id\": number, \"alt\": string }\n";
        $system_message .= "   - Use this to set the alt text for an image after obtaining AI‑generated alt text externally.\n";
        $system_message .= "72) bulk_delete_unused_media:\n";
        $system_message .= "   fields = { \"attachment_ids\": [number] }\n";
        $system_message .= "   - Use this to remove unattached media files in bulk. Provide an array of attachment IDs to delete.\n\n";

        // WooCommerce customisation actions
        $system_message .= "73) woocommerce_change_add_to_cart_text:\n";
        $system_message .= "   fields = { \"text\": string }\n";
        $system_message .= "   - Use this to change the ‘Add to basket’ button text across WooCommerce.\n";
        $system_message .= "74) woocommerce_add_product_tab:\n";
        $system_message .= "   fields = { \"title\": string, \"content\": string }\n";
        $system_message .= "   - Use this to add a custom tab to the single product page.\n";
        $system_message .= "75) woocommerce_change_checkout_fields:\n";
        $system_message .= "   fields = { \"fields\": { field_key: { \"enabled\": boolean|null, \"label\": string|null, \"required\": boolean|null } } }\n";
        $system_message .= "   - Use this to enable, disable or rename checkout fields. Provide keys such as 'billing_company' with desired settings.\n";
        $system_message .= "76) woocommerce_require_phone:\n";
        $system_message .= "   fields = { \"required\": boolean }\n";
        $system_message .= "   - Use this to require or not require a phone number during checkout.\n";
        $system_message .= "77) woocommerce_postcode_validation:\n";
        $system_message .= "   fields = { \"rules\": { country_code: pattern|string } }\n";
        $system_message .= "   - Use this to set postcode patterns per country. Pattern may be a regular expression.\n";
        $system_message .= "78) woocommerce_auto_tag_orders:\n";
        $system_message .= "   fields = { \"order_tag\": string }\n";
        $system_message .= "   - Use this to automatically assign a tag or note to new orders (e.g. 'AI').\n";
        $system_message .= "79) woocommerce_custom_thankyou_message:\n";
        $system_message .= "   fields = { \"message\": string }\n";
        $system_message .= "   - Use this to display a custom message on the order thank you page.\n";
        $system_message .= "80) woocommerce_update_email_templates:\n";
        $system_message .= "   fields = { \"intro\": string|null, \"outro\": string|null }\n";
        $system_message .= "   - Use this to prepend/append text to WooCommerce order emails. Supply intro and/or outro HTML.\n\n";

        // Content creation & editing actions
        $system_message .= "81) duplicate_post_full:\n";
        $system_message .= "   fields = { \"source_post_id\": number, \"post_status\": string|null, \"new_post_title\": string|null }\n";
        $system_message .= "   - Use this to duplicate a post or page, including all meta, taxonomies and the featured image. Optionally set a new status or title for the copy.\n";
        $system_message .= "82) convert_post_type:\n";
        $system_message .= "   fields = { \"post_id\": number, \"target_post_type\": string, \"target_status\": string|null }\n";
        $system_message .= "   - Use this to convert a post from one post type to another (e.g. post → page). Preserve content, meta and featured image.\n";
        $system_message .= "83) update_headings_structure:\n";
        $system_message .= "   fields = { \"post_id\": number, \"post_content\": string }\n";
        $system_message .= "   - Use this to replace the entire post content with HTML whose heading structure has been improved (e.g. H1→H2 hierarchy).\n";
        $system_message .= "84) update_meta_fields_single:\n";
        $system_message .= "   fields = { \"post_id\": number, \"meta\": { meta_key: value } }\n";
        $system_message .= "   - Use this to update one or more custom fields on a single post. Provide keys and values.\n";
        $system_message .= "85) bulk_update_meta_fields:\n";
        $system_message .= "   fields = { \"items\": [ { \"post_id\": number, \"meta\": { meta_key: value } } ] }\n";
        $system_message .= "   - Use this to update custom fields on multiple posts at once.\n";
        $system_message .= "86) map_imported_data_to_meta:\n";
        $system_message .= "   fields = { \"post_id\": number, \"source_data\": array, \"mapping\": { meta_key: path } }\n";
        $system_message .= "   - Use this when AI has parsed imported data and needs to map values into specific custom fields. Provide a path into source_data for each meta key.\n";
        $system_message .= "87) update_post_taxonomies:\n";
        $system_message .= "   fields = { \"post_id\": number, \"categories\": [int|string]|null, \"tags\": [int|string]|null, \"create_terms\": boolean|null }\n";
        $system_message .= "   - Use this to assign or update the category and tag terms for a post. Accepts term IDs or names.\n";
        $system_message .= "88) update_post_custom_taxonomies:\n";
        $system_message .= "   fields = { \"post_id\": number, \"taxonomies\": { taxonomy: [int|string] }, \"create_terms\": boolean|null }\n";
        $system_message .= "   - Use this to set terms for custom taxonomies on a post.\n";
        $system_message .= "89) insert_blocks_in_post:\n";
        $system_message .= "   fields = { \"post_id\": number, \"post_content\": string }\n";
        $system_message .= "   - Use this when AI has generated updated block markup that inserts new blocks at specific places. You must supply the entire block content.\n";
        $system_message .= "90) restructure_post_into_sections:\n";
        $system_message .= "   fields = { \"post_id\": number, \"post_content\": string }\n";
        $system_message .= "   - Use this to replace the post content with a structured layout broken into logical sections (hero, features, testimonials, CTA, etc.).\n";
        $system_message .= "91) convert_classic_to_blocks:\n";
        $system_message .= "   fields = { \"post_id\": number, \"post_content\": string }\n";
        $system_message .= "   - Use this to replace legacy classic content with equivalent block markup provided by AI.\n";
        $system_message .= "92) wrap_content_in_pattern:\n";
        $system_message .= "   fields = { \"post_id\": number, \"post_content\": string }\n";
        $system_message .= "   - Use this to wrap existing content inside a reusable pattern or template. Provide the complete wrapped HTML.\n";
        $system_message .= "93) moderate_comments_by_rules:\n";
        $system_message .= "   fields = { \"actions\": [ { \"comment_id\": number, \"status\": string } ] }\n";
        $system_message .= "   - Use this to programmatically approve, unapprove, mark as spam or trash comments based on AI moderation.\n";
        $system_message .= "94) reply_to_comment:\n";
        $system_message .= "   fields = { \"comment_id\": number, \"reply_content\": string, \"author_name\": string|null, \"author_email\": string|null }\n";
        $system_message .= "   - Use this to post a polite reply to an existing comment. Provide the reply text and optionally the commenter name/email.\n";
        $system_message .= "95) bulk_close_comments_on_old_posts:\n";
        $system_message .= "   fields = { \"before_date\": string, \"post_types\": [string]|null }\n";
        $system_message .= "   - Use this to close comments and pings on posts older than a given date.\n\n";

        // Theme/design customisation actions
        $system_message .= "96) change_site_logo:\n";
        $system_message .= "   fields = { \"attachment_id\": number|null, \"url\": string|null }\n";
        $system_message .= "   - Use this to update the front‑end site logo. Prefer an attachment ID when available; otherwise provide a URL.\n";
        $system_message .= "97) change_site_icon:\n";
        $system_message .= "   fields = { \"attachment_id\": number }\n";
        $system_message .= "   - Use this to update the WordPress favicon/site icon. Provide an attachment ID.\n";
        $system_message .= "98) set_header_logo_variants:\n";
        $system_message .= "   fields = { \"light_logo_id\": number, \"dark_logo_id\": number, \"rules\": object|null }\n";
        $system_message .= "   - Use this to define separate logos for light and dark modes in the header. Additional rules may specify when to switch.\n";
        $system_message .= "99) update_global_design_tokens:\n";
        $system_message .= "   fields = { \"colours\": object|null, \"typography\": object|null }\n";
        $system_message .= "   - Use this to set site‑wide colours and typography. You may specify variables like primary, secondary, background and base fonts.\n";
        $system_message .= "100) update_global_button_styles:\n";
        $system_message .= "   fields = { \"border_radius\": string|null, \"padding\": string|null, \"font_weight\": string|null, \"other\": object|null }\n";
        $system_message .= "   - Use this to define consistent button styling across the site. Only supply the values you wish to change.\n";
        $system_message .= "101) edit_header_layout:\n";
        $system_message .= "   fields = { \"template_slug\": string, \"post_content\": string }\n";
        $system_message .= "   - Use this to update a block theme header template. Provide the template slug (e.g. 'header') and full block markup.\n";
        $system_message .= "102) edit_footer_layout:\n";
        $system_message .= "   fields = { \"template_slug\": string, \"post_content\": string }\n";
        $system_message .= "   - Use this to update a block theme footer template in the same way as edit_header_layout.\n";
        $system_message .= "103) manage_block_template:\n";
        $system_message .= "   fields = { \"template_type\": string, \"slug\": string, \"post_content\": string }\n";
        $system_message .= "   - Use this to create or update block templates (single, page, custom). Provide block markup for the template.\n";
        $system_message .= "104) define_block_pattern:\n";
        $system_message .= "   fields = { \"pattern_name\": string, \"pattern_slug\": string, \"categories\": [string], \"content\": string }\n";
        $system_message .= "   - Use this to register a reusable block pattern. Provide a human‑readable name, a slug and the pattern content.\n";
        $system_message .= "105) apply_pattern_to_posts:\n";
        $system_message .= "   fields = { \"pattern_content\": string, \"post_ids\": [number], \"mode\": string }\n";
        $system_message .= "   - Use this to insert a block pattern into multiple posts. Mode can be 'prepend', 'append' or 'replace_section'.\n";
        $system_message .= "106) duplicate_elementor_template:\n";
        $system_message .= "   fields = { \"template_id\": number, \"new_title\": string|null }\n";
        $system_message .= "   - Use this when Elementor is active to duplicate a template from the Elementor library. Optionally set a new title.\n";
        $system_message .= "107) update_elementor_widget_content:\n";
        $system_message .= "   fields = { \"post_id\": number|null, \"template_id\": number|null, \"replacements\": object }\n";
        $system_message .= "   - Use this to replace images or text inside Elementor widgets. Provide structured replacements referencing widget IDs and fields.\n";
        $system_message .= "108) tune_elementor_responsive_layout:\n";
        $system_message .= "   fields = { \"post_id\": number|null, \"template_id\": number|null, \"settings\": object }\n";
        $system_message .= "   - Use this to adjust padding, margins or column settings for responsiveness in Elementor sections.\n";
        $system_message .= "109) add_frontend_responsive_css:\n";
        $system_message .= "   fields = { \"css\": string, \"scope\": string|null, \"post_id\": number|null }\n";
        $system_message .= "   - Use this to inject responsive CSS into the front end globally or for a specific post.\n";
        $system_message .= "110) standardise_section_spacing:\n";
        $system_message .= "   fields = { \"spacing\": object, \"selectors\": [string] }\n";
        $system_message .= "   - Use this to apply consistent top/bottom spacing to sections across the site.\n";
        $system_message .= "111) apply_layout_grid:\n";
        $system_message .= "   fields = { \"grid\": object }\n";
        $system_message .= "   - Use this to enforce a responsive layout grid system with defined max widths and breakpoints.\n\n";

        // Site structure & navigation actions
        $system_message .= "112) create_or_update_nav_menu:\n";
        $system_message .= "   fields = { \"menu_name\": string, \"location\": string|null, \"description\": string|null }\n";
        $system_message .= "   - Use this to create a new navigation menu or update an existing one. Optionally assign it to a theme location and set a description.\n";
        $system_message .= "113) update_nav_menu_items:\n";
        $system_message .= "   fields = { \"menu_id\": number|null, \"menu_name\": string|null, \"items\": [ { \"action\": string, \"title\": string|null, \"url\": string|null, \"object_id\": number|null, \"object\": string|null, \"type\": string|null, \"parent_id\": number|null, \"position\": number|null, \"item_id\": number|null } ] }\n";
        $system_message .= "   - Use this to add, update or remove items from a navigation menu. Provide a menu_id or menu_name and an array of item operations.\n";
        $system_message .= "114) rename_nav_menu_labels:\n";
        $system_message .= "   fields = { \"menu_id\": number|null, \"menu_name\": string|null, \"label_map\": [ { \"item_id\": number|null, \"old_title\": string|null, \"new_title\": string } ] }\n";
        $system_message .= "   - Use this to change the titles of menu items without altering their links. Map an item_id or old_title to a new_title.\n";
        $system_message .= "115) set_role_based_menus:\n";
        $system_message .= "   fields = { \"rules\": { location_slug: [ { \"role\": string, \"menu_id\": number|null, \"menu_name\": string|null } ] } }\n";
        $system_message .= "   - Use this to assign different menus to different user roles per theme location. You may specify menus by ID or name.\n";
        $system_message .= "116) create_core_pages:\n";
        $system_message .= "   fields = { \"pages\": [ { \"title\": string, \"slug\": string|null, \"content\": string|null, \"template\": string|null } ] }\n";
        $system_message .= "   - Use this to create standard pages (e.g. About, Contact). Existing pages with the same slug or title will be updated when content/template is provided.\n";
        $system_message .= "117) reorganise_page_hierarchy:\n";
        $system_message .= "   fields = { \"items\": [ { \"post_id\": number, \"parent_id\": number|null, \"post_name\": string|null } ] }\n";
        $system_message .= "   - Use this to change the parent/child relationships and slugs of pages. Supply new parent IDs and/or slugs.\n";
        $system_message .= "118) assign_page_templates_bulk:\n";
        $system_message .= "   fields = { \"template\": string, \"post_ids\": [number] }\n";
        $system_message .= "   - Use this to apply a page template to multiple pages at once. Provide the template slug and an array of page IDs.\n";
        $system_message .= "119) configure_widget_area:\n";
        $system_message .= "   fields = { \"sidebar_id\": string, \"mode\": string, \"widgets\": [ { \"id_base\": string, \"settings\": object } ]|null, \"blocks_content\": string|null }\n";
        $system_message .= "   - Use this to configure a widget area. In classic mode, define an array of widgets; in block mode, supply full block markup.\n";
        $system_message .= "120) update_sidebar_blocks:\n";
        $system_message .= "   fields = { \"sidebar_id\": string, \"blocks_content\": string }\n";
        $system_message .= "   - Use this to replace the blocks in a sidebar with new block markup. Applies to block-based widget areas only.\n";
        $system_message .= "121) insert_internal_links:\n";
        $system_message .= "   fields = { \"items\": [ { \"post_id\": number, \"post_content\": string } ] }\n";
        $system_message .= "   - Use this to update posts with AI-generated internal links. Provide the full updated content for each post.\n";
        $system_message .= "122) fix_broken_internal_links:\n";
        $system_message .= "   fields = { \"replacements\": [ { \"post_id\": number|null, \"old_url\": string, \"new_url\": string|null } ] }\n";
        $system_message .= "   - Use this to replace or remove outdated internal links across one or more posts. Leave new_url empty to remove the link entirely.\n";
        $system_message .= "123) generate_index_page:\n";
        $system_message .= "   fields = { \"page_title\": string, \"slug\": string|null, \"content\": string, \"template\": string|null }\n";
        $system_message .= "   - Use this to create or update an index page listing posts (e.g. All Services). Provide the page title, optional slug, content and template.\n";
        $system_message .= "124) manage_sitemap_inclusion:\n";
        $system_message .= "   fields = { \"include\": { \"post_types\": [string]|null, \"post_ids\": [number]|null }, \"exclude\": { \"post_types\": [string]|null, \"post_ids\": [number]|null } }\n";
        $system_message .= "   - Use this to specify which post types or posts should be included or excluded from the XML sitemap. Excluded types/IDs will not appear unless explicitly included via include lists.\n\n";

        $system_message .= "Do NOT include markdown, comments or extra keys. Respond with exactly ONE JSON object only (no arrays, no multiple objects).";


        $user_message  = "Site map: " . $site_map_json . "\n\n";
        $user_message .= "User request: " . $user_request . "\n";
        $user_message .= $image_info;

        $payload = array(
            'model'    => self::MODEL,
            'messages' => array(
                array(
                    'role'    => 'system',
                    'content' => $system_message,
                ),
                array(
                    'role'    => 'user',
                    'content' => $user_message,
                ),
            ),
            'temperature' => 0,
            'max_tokens'  => 1000,
        );

        $args = array(
            'headers'     => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ),
            'body'        => wp_json_encode( $payload ),
            'timeout'     => 30,
            'httpversion' => '1.1',
        );

        $response = wp_remote_post( self::ENDPOINT, $args );

        if ( is_wp_error( $response ) ) {
            return array( 'error' => 'HTTP request error: ' . $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( 200 !== $code ) {
            $msg = 'AI service returned HTTP ' . $code;
            if ( ! empty( $body ) ) {
                $decoded = json_decode( $body, true );
                if ( is_array( $decoded ) && isset( $decoded['error']['message'] ) ) {
                    $msg .= ': ' . $decoded['error']['message'];
                } else {
                    $snippet = substr( trim( $body ), 0, 600 );
                    $msg    .= ' – Raw response: ' . $snippet;
                }
            }
            if ( function_exists( 'error_log' ) ) {
                error_log( '[Arthur AI] ' . $msg );
            }
            return array( 'error' => $msg );
        }

        if ( '' === $body ) {
            return array( 'error' => 'AI service returned an empty response body.' );
        }

        $decoded = json_decode( $body, true );
        if ( ! is_array( $decoded ) || ! isset( $decoded['choices'][0]['message']['content'] ) ) {
            return array( 'error' => 'Unexpected response structure from AI service: ' . substr( $body, 0, 600 ) );
        }

        $content = trim( $decoded['choices'][0]['message']['content'] );
        $action  = json_decode( $content, true );

        if ( null === $action || JSON_ERROR_NONE !== json_last_error() ) {
            return array( 'error' => 'AI response could not be decoded as JSON. Raw content: ' . substr( $content, 0, 600 ) );
        }

        $defaults = array(
            'action_type'    => null,
            'target_post_id' => null,
            'fields'         => array(),
        );
        $action = wp_parse_args( $action, $defaults );

        if ( ! in_array( $action['action_type'], $allowed_actions, true ) ) {
            return array( 'error' => 'AI selected an invalid action_type: ' . $action['action_type'] );
        }

        if ( ! is_null( $action['target_post_id'] ) && ! is_numeric( $action['target_post_id'] ) ) {
            return array( 'error' => 'target_post_id must be numeric or null.' );
        }

        if ( ! is_array( $action['fields'] ) ) {
            return array( 'error' => 'fields must be an object.' );
        }

        if ( ! is_null( $action['target_post_id'] ) ) {
            $action['target_post_id'] = intval( $action['target_post_id'] );
        }

        return $action;
    }
}

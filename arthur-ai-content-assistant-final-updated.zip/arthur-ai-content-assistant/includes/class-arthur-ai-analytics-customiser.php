<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Analytics customiser outputs tracking scripts and triggers events.
 *
 * Based on the settings provided by the configure_tracking_scripts and
 * configure_tracking_events actions, this class outputs GA4, Meta
 * Pixel and generic scripts in the correct location (head or
 * footer). Custom event tracking can be extended as needed.
 */
class Arthur_AI_Analytics_Customiser {

    /**
     * Initialise hooks.
     */
    public static function init() {
        add_action( 'wp_head', array( __CLASS__, 'output_head_scripts' ), 20 );
        add_action( 'wp_footer', array( __CLASS__, 'output_footer_scripts' ), 20 );
    }

    /**
     * Output scripts in the head.
     */
    public static function output_head_scripts() {
        self::output_scripts_by_location( 'head' );
    }

    /**
     * Output scripts in the footer.
     */
    public static function output_footer_scripts() {
        self::output_scripts_by_location( 'body_end' );
    }

    /**
     * Output scripts filtered by location.
     *
     * @param string $location Target location ('head' or 'body_end').
     */
    protected static function output_scripts_by_location( $location ) {
        $scripts = get_option( 'arthur_ai_tracking_scripts', array() );
        if ( ! is_array( $scripts ) ) {
            return;
        }
        foreach ( $scripts as $type => $cfg ) {
            if ( empty( $cfg['enabled'] ) ) {
                continue;
            }
            if ( ( isset( $cfg['location'] ) && $cfg['location'] === $location ) || ( ! isset( $cfg['location'] ) && 'head' === $location ) ) {
                self::print_script( $type, $cfg['id_config'] );
            }
        }
    }

    /**
     * Print script based on type and config.
     *
     * @param string       $type     Script type (ga4, meta_pixel, generic).
     * @param string|array $config   ID or configuration string/array.
     */
    protected static function print_script( $type, $config ) {
        switch ( $type ) {
            case 'ga4':
                $measurement_id = is_array( $config ) && isset( $config['id'] ) ? $config['id'] : $config;
                if ( $measurement_id ) {
                    ?>
                    <!-- GA4 by Arthur AI -->
                    <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo esc_attr( $measurement_id ); ?>"></script>
                    <script>
                    window.dataLayer = window.dataLayer || [];
                    function gtag(){dataLayer.push(arguments);} gtag('js', new Date());
                    gtag('config', '<?php echo esc_js( $measurement_id ); ?>');
                    </script>
                    <?php
                }
                break;
            case 'meta_pixel':
                $pixel_id = is_array( $config ) && isset( $config['id'] ) ? $config['id'] : $config;
                if ( $pixel_id ) {
                    ?>
                    <!-- Meta Pixel by Arthur AI -->
                    <script>
                    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
                    n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
                    n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);
                    t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
                    document,'script','https://connect.facebook.net/en_US/fbevents.js');
                    fbq('init', '<?php echo esc_js( $pixel_id ); ?>');
                    fbq('track', 'PageView');
                    </script>
                    <noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=<?php echo esc_attr( $pixel_id ); ?>&ev=PageView&noscript=1" /></noscript>
                    <?php
                }
                break;
            case 'generic':
                // Output raw script if config contains script tag or JS.
                if ( is_string( $config ) ) {
                    echo $config;
                }
                break;
            default:
                break;
        }
    }
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Applies security‑related customisations configured via AI actions.
 *
 * This class enforces strong password policies, renames the login URL,
 * disables XML‑RPC, disables the file editors, limits login attempts,
 * auto‑logs out inactive users, hides the WordPress version and disables
 * the REST API for guests. All options are read from the database and
 * acted upon using WordPress hooks and filters. These implementations are
 * intentionally simple and should not be considered replacements for
 * dedicated security plugins.
 */
class Arthur_AI_Security_Customiser {

    /**
     * Initialise hooks.
     */
    public static function init() {
        // Strong passwords on profile update and registration.
        add_action( 'user_profile_update_errors', array( __CLASS__, 'enforce_strong_passwords' ), 10, 3 );
        add_filter( 'wp_authenticate_user', array( __CLASS__, 'filter_authenticate_user_password_strength' ), 10, 2 );

        // Custom login slug handling.
        add_filter( 'login_url', array( __CLASS__, 'filter_login_url' ), 10, 3 );
        add_action( 'init', array( __CLASS__, 'maybe_handle_custom_login_slug' ) );

        // Disable XML‑RPC.
        add_filter( 'xmlrpc_enabled', array( __CLASS__, 'filter_xmlrpc_enabled' ) );

        // Disable file editing.
        add_action( 'init', array( __CLASS__, 'maybe_disable_file_editing' ), 1 );

        // Limit login attempts.
        add_action( 'wp_login_failed', array( __CLASS__, 'handle_login_failed' ), 10, 1 );
        add_filter( 'wp_authenticate_user', array( __CLASS__, 'filter_authenticate_user_limit_attempts' ), 20, 2 );

        // Auto logout inactive users.
        add_action( 'init', array( __CLASS__, 'handle_auto_logout' ), 20 );

        // Hide WordPress version.
        add_filter( 'the_generator', array( __CLASS__, 'filter_the_generator' ) );

        // Disable REST API for guests.
        add_filter( 'rest_authentication_errors', array( __CLASS__, 'filter_rest_authentication_errors' ) );
    }

    /**
     * Enforce strong passwords when a user updates their profile in wp-admin.
     *
     * @param WP_Error $errors The error object to add messages to.
     * @param bool     $update Whether this is a user update (true) or registration (false).
     * @param stdClass  $user The user object.
     */
    public static function enforce_strong_passwords( $errors, $update, $user ) {
        $enabled   = (bool) get_option( 'arthur_ai_force_strong_passwords_enabled', false );
        $threshold = (int) get_option( 'arthur_ai_force_strong_passwords_threshold', 12 );
        if ( ! $enabled ) {
            return;
        }
        // Only enforce when password fields are present.
        if ( isset( $_POST['pass1'] ) ) {
            $pass = (string) $_POST['pass1'];
            if ( '' !== $pass ) {
                $error_msg = self::validate_password_strength( $pass, $threshold );
                if ( $error_msg ) {
                    $errors->add( 'weak_password', $error_msg );
                }
            }
        }
    }

    /**
     * Validate password strength on login.
     *
     * If a strong password is required, prevent login with weak passwords by
     * returning a WP_Error. This complements profile update enforcement.
     *
     * @param WP_User|WP_Error $user The authenticated user object or error.
     * @param string           $password The user submitted password.
     * @return WP_User|WP_Error
     */
    public static function filter_authenticate_user_password_strength( $user, $password ) {
        if ( is_wp_error( $user ) ) {
            return $user;
        }
        $enabled   = (bool) get_option( 'arthur_ai_force_strong_passwords_enabled', false );
        $threshold = (int) get_option( 'arthur_ai_force_strong_passwords_threshold', 12 );
        if ( $enabled && '' !== $password ) {
            $msg = self::validate_password_strength( $password, $threshold );
            if ( $msg ) {
                return new WP_Error( 'weak_password', $msg );
            }
        }
        return $user;
    }

    /**
     * Helper to check password strength. Returns an error message string on
     * failure or false on success.
     *
     * @param string $pass
     * @param int    $min_length
     * @return string|false
     */
    protected static function validate_password_strength( $pass, $min_length ) {
        $len = strlen( $pass );
        if ( $len < $min_length ) {
            return sprintf( __( 'Password must be at least %d characters long.', 'arthur-ai' ), $min_length );
        }
        // Require a mix of upper, lower, numbers and special chars.
        $has_upper   = preg_match( '/[A-Z]/', $pass );
        $has_lower   = preg_match( '/[a-z]/', $pass );
        $has_num     = preg_match( '/\d/', $pass );
        $has_special = preg_match( '/[^a-zA-Z0-9]/', $pass );
        $checks      = $has_upper + $has_lower + $has_num + $has_special;
        if ( $checks < 3 ) {
            return __( 'Password must include a mix of uppercase, lowercase, numbers and symbols.', 'arthur-ai' );
        }
        return false;
    }

    /**
     * Modify the login URL to use the custom slug if set.
     *
     * @param string $login_url    The original login URL.
     * @param string $redirect     Redirect target.
     * @param bool   $force_reauth Whether to force reauthentication.
     *
     * @return string
     */
    public static function filter_login_url( $login_url, $redirect, $force_reauth ) {
        $slug = (string) get_option( 'arthur_ai_login_slug', '' );
        if ( '' === $slug ) {
            return $login_url;
        }
        // Build URL to custom slug path on the site root.
        $url = home_url( '/' . trim( $slug, '/' ) . '/' );
        if ( $redirect ) {
            $url = add_query_arg( 'redirect_to', urlencode( $redirect ), $url );
        }
        if ( $force_reauth ) {
            $url = add_query_arg( 'reauth', '1', $url );
        }
        return $url;
    }

    /**
     * Serve the login page at the custom slug and redirect requests to the
     * default login URL when appropriate.
     */
    public static function maybe_handle_custom_login_slug() {
        $slug = (string) get_option( 'arthur_ai_login_slug', '' );
        if ( '' === $slug ) {
            return;
        }
        $slug    = trim( $slug, '/' );
        $request = isset( $_SERVER['REQUEST_URI'] ) ? explode( '?', (string) $_SERVER['REQUEST_URI'], 2 )[0] : '';
        $request = ltrim( $request, '/' );
        // Match custom slug path.
        if ( $request === $slug || 0 === strpos( $request, $slug . '/' ) ) {
            require_once ABSPATH . 'wp-login.php';
            exit;
        }
        // If hitting wp-login.php directly as a guest, redirect to the custom slug.
        if ( false !== stripos( $request, 'wp-login.php' ) && ! is_user_logged_in() ) {
            wp_safe_redirect( home_url( '/' . $slug . '/' ) );
            exit;
        }
    }

    /**
     * Disable XML‑RPC if the flag is set.
     *
     * @param bool $enabled Current enabled state.
     * @return bool
     */
    public static function filter_xmlrpc_enabled( $enabled ) {
        $flag = (bool) get_option( 'arthur_ai_disable_xml_rpc', false );
        if ( $flag ) {
            return false;
        }
        return $enabled;
    }

    /**
     * Define DISALLOW_FILE_EDIT constant if requested.
     */
    public static function maybe_disable_file_editing() {
        $flag = (bool) get_option( 'arthur_ai_disable_file_editing', false );
        if ( $flag && ! defined( 'DISALLOW_FILE_EDIT' ) ) {
            define( 'DISALLOW_FILE_EDIT', true );
        }
    }

    /**
     * Track failed login attempts and enforce simple lockouts.
     *
     * @param string $username The attempted username (not sanitised).
     */
    public static function handle_login_failed( $username ) {
        $settings = get_option( 'arthur_ai_limit_login_attempts', array() );
        if ( ! is_array( $settings ) || empty( $settings ) ) {
            return;
        }
        $max      = isset( $settings['max'] ) ? max( 1, (int) $settings['max'] ) : 5;
        $duration = isset( $settings['duration'] ) ? max( 1, (int) $settings['duration'] ) : 60;
        $whitelist = isset( $settings['whitelist'] ) && is_array( $settings['whitelist'] ) ? $settings['whitelist'] : array();
        $ip       = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( (string) $_SERVER['REMOTE_ADDR'] ) : 'unknown';
        // Skip logging attempts for whitelisted IPs.
        if ( in_array( $ip, $whitelist, true ) ) {
            return;
        }
        $key      = md5( $ip . '|' . strtolower( $username ) );
        $attempts = (int) get_transient( 'arthur_ai_login_attempts_' . $key );
        $attempts++;
        set_transient( 'arthur_ai_login_attempts_' . $key, $attempts, $duration * 60 );
        if ( $attempts >= $max ) {
            set_transient( 'arthur_ai_login_lock_' . $key, 1, $duration * 60 );
        }
    }

    /**
     * Deny authentication when a lockout is active due to too many failed attempts.
     *
     * @param WP_User|WP_Error $user     The user or error object from wp_authenticate_user.
     * @param string           $password The password provided.
     *
     * @return WP_User|WP_Error
     */
    public static function filter_authenticate_user_limit_attempts( $user, $password ) {
        // Only act on valid users.
        if ( is_wp_error( $user ) || ! $user instanceof WP_User ) {
            return $user;
        }
        $settings = get_option( 'arthur_ai_limit_login_attempts', array() );
        if ( ! is_array( $settings ) || empty( $settings ) ) {
            return $user;
        }
        $ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( (string) $_SERVER['REMOTE_ADDR'] ) : 'unknown';
        // Whitelist bypass.
        $whitelist = isset( $settings['whitelist'] ) && is_array( $settings['whitelist'] ) ? $settings['whitelist'] : array();
        if ( in_array( $ip, $whitelist, true ) ) {
            return $user;
        }
        $key = md5( $ip . '|' . strtolower( $user->user_login ) );
        if ( get_transient( 'arthur_ai_login_lock_' . $key ) ) {
            return new WP_Error( 'too_many_attempts', __( 'Too many failed login attempts. Please try again later.', 'arthur-ai' ) );
        }
        return $user;
    }

    /**
     * Log out users after they have been inactive for longer than the configured timeout.
     */
    public static function handle_auto_logout() {
        $timeout = (int) get_option( 'arthur_ai_auto_logout_timeout', 0 );
        if ( $timeout <= 0 ) {
            return;
        }
        if ( ! is_user_logged_in() ) {
            return;
        }
        $user_id = get_current_user_id();
        $last    = (int) get_user_meta( $user_id, 'arthur_ai_last_activity', true );
        $now     = time();
        if ( $last > 0 && ( $now - $last ) > ( $timeout * 60 ) ) {
            wp_logout();
            return;
        }
        // Update last activity time.
        update_user_meta( $user_id, 'arthur_ai_last_activity', $now );
    }

    /**
     * Remove the WordPress version generator from the output.
     *
     * @param string $gen The generator output.
     * @return string
     */
    public static function filter_the_generator( $gen ) {
        $enabled = (bool) get_option( 'arthur_ai_hide_wp_version', false );
        if ( $enabled ) {
            return '';
        }
        return $gen;
    }

    /**
     * Disable REST API access for non‑authenticated users when configured.
     *
     * @param WP_Error|null|bool $result Error from another authentication check, or null to continue, or true to abort.
     * @return WP_Error|null|bool
     */
    public static function filter_rest_authentication_errors( $result ) {
        // Respect existing errors.
        if ( ! empty( $result ) ) {
            return $result;
        }
        // New restrictions configuration.
        $restrictions = get_option( 'arthur_ai_rest_api_restrictions' );
        if ( $restrictions && is_array( $restrictions ) && isset( $restrictions['mode'] ) ) {
            $mode = $restrictions['mode'];
            if ( 'authenticated_only' === $mode ) {
                if ( ! is_user_logged_in() ) {
                    return new WP_Error( 'rest_disabled', __( 'REST API restricted to authenticated users.', 'arthur-ai' ), array( 'status' => 403 ) );
                }
            } elseif ( 'allow_public_for_routes' === $mode ) {
                $allowed = isset( $restrictions['allowed_routes'] ) ? (array) $restrictions['allowed_routes'] : array();
                // Determine requested route from current REST request.
                if ( ! is_user_logged_in() && defined( 'REST_REQUEST' ) && REST_REQUEST ) {
                    $route = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
                    $route = ltrim( wp_parse_url( $route, PHP_URL_PATH ), '/' );
                    $matched = false;
                    foreach ( $allowed as $prefix ) {
                        if ( 0 === strpos( $route, trim( $prefix, '/' ) ) ) {
                            $matched = true;
                            break;
                        }
                    }
                    if ( ! $matched ) {
                        return new WP_Error( 'rest_disabled', __( 'REST API access restricted.', 'arthur-ai' ), array( 'status' => 403 ) );
                    }
                }
            }
        } else {
            // Backwards compatibility: disable REST for guests flag.
            $flag = (bool) get_option( 'arthur_ai_disable_rest_api_for_guests', false );
            if ( $flag && ! is_user_logged_in() ) {
                return new WP_Error( 'rest_disabled', __( 'REST API restricted to authenticated users.', 'arthur-ai' ), array( 'status' => 403 ) );
            }
        }
        return $result;
    }
}
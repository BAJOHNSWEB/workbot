<?php
/**
 * Events customiser for The Events Calendar (TEC).
 *
 * This class reads configuration stored by the customise_event_views action
 * and applies view type filtering, default view selection and basic card
 * styling adjustments. It hooks into various TEC filters and outputs
 * minimal CSS to hide or show fields on event cards.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Events_Customiser {

    /**
     * Bootstraps the customiser by attaching hooks.
     */
    public static function init() {
        // Filter default view
        add_filter( 'tribe_get_option', array( __CLASS__, 'filter_default_view' ), 10, 2 );
        // Filter available views in the view selector
        add_filter( 'tribe_events_views', array( __CLASS__, 'filter_views' ) );
        // Output CSS for card settings
        add_action( 'wp_head', array( __CLASS__, 'output_event_card_css' ) );
    }

    /**
     * Override the default view if set in settings.
     *
     * @param mixed  $value  Default value from TEC.
     * @param string $option Option name.
     *
     * @return mixed
     */
    public static function filter_default_view( $value, $option ) {
        if ( in_array( $option, array( 'defaultView', 'tribeEventsTemplateDefaultView' ), true ) ) {
            $settings = get_option( 'arthur_ai_event_view_settings', array() );
            if ( ! empty( $settings['default_view'] ) ) {
                return $settings['default_view'];
            }
        }
        return $value;
    }

    /**
     * Remove views not in the configured list.
     *
     * @param array $views List of available views keyed by slug.
     *
     * @return array
     */
    public static function filter_views( $views ) {
        $settings = get_option( 'arthur_ai_event_view_settings', array() );
        if ( ! empty( $settings['view_types'] ) && is_array( $settings['view_types'] ) ) {
            foreach ( array_keys( $views ) as $slug ) {
                if ( ! in_array( $slug, $settings['view_types'], true ) ) {
                    unset( $views[ $slug ] );
                }
            }
        }
        return $views;
    }

    /**
     * Output CSS to hide event card fields based on settings.
     */
    public static function output_event_card_css() {
        $settings = get_option( 'arthur_ai_event_view_settings', array() );
        if ( empty( $settings['card_settings'] ) || ! is_array( $settings['card_settings'] ) ) {
            return;
        }
        $card = $settings['card_settings'];
        // Determine which fields to show; any unspecified fields will be hidden
        $all_fields = array( 'date', 'time', 'venue', 'excerpt', 'tickets' );
        $show       = isset( $card['fields_to_show'] ) && is_array( $card['fields_to_show'] ) ? $card['fields_to_show'] : array();
        $hide_fields= array_diff( $all_fields, $show );
        $css        = '';
        foreach ( $hide_fields as $field ) {
            switch ( $field ) {
                case 'venue':
                    $css .= '.tribe-events-venue, .tribe-events-venue-detail { display:none !important; }';
                    break;
                case 'date':
                    $css .= '.tribe-event-date-start, .tribe-event-date-end { display:none !important; }';
                    break;
                case 'time':
                    $css .= '.tribe-event-time { display:none !important; }';
                    break;
                case 'excerpt':
                    $css .= '.tribe-events-list .tribe-events-content, .tribe-events-photo .tribe-events-content { display:none !important; }';
                    break;
                case 'tickets':
                    $css .= '.tribe-events-event-cost, .tribe-events-event-meta .tribe-events-tickets-button { display:none !important; }';
                    break;
            }
        }
        if ( ! empty( $css ) ) {
            echo '<style id="arthur-ai-event-card-settings">' . $css . '</style>';
        }
    }
}
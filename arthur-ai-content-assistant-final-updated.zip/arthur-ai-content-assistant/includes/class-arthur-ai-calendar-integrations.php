<?php
/**
 * Calendar integrations helper.
 *
 * Provides utility methods to generate iCal feed links and stores
 * configuration for external calendar synchronisation. Future API
 * integrations (e.g. Google, Outlook) can be added here. This helper
 * currently exposes a static method for retrieving feed links from the
 * saved configuration.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Arthur_AI_Calendar_Integrations {
    /**
     * Initialise hooks. Currently not used but reserved for future.
     */
    public static function init() {
        // Nothing to hook yet; placeholder for future API sync.
    }

    /**
     * Get the configured external calendar sync settings.
     *
     * @return array
     */
    public static function get_sync_settings() {
        $config = get_option( 'arthur_ai_external_calendar_sync', array() );
        return is_array( $config ) ? $config : array();
    }

    /**
     * Get iCal feed links based on stored configuration.
     *
     * @return array
     */
    public static function get_ical_feed_links() {
        $config = self::get_sync_settings();
        if ( isset( $config['mode'] ) && 'ics_feed' === $config['mode'] && ! empty( $config['feed_links'] ) ) {
            return $config['feed_links'];
        }
        return array();
    }
}
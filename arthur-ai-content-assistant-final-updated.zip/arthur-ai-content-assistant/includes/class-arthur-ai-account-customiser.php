<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Account customiser for WooCommerce My Account area.
 *
 * This helper registers additional endpoints for the My Account page
 * and merges content into the dashboard. Endpoints and content are
 * configured via AI actions and stored in options.
 */
class Arthur_AI_Account_Customiser {

    /**
     * Initialise hooks if WooCommerce is active.
     */
    public static function init() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return;
        }
        add_action( 'init', array( __CLASS__, 'register_endpoints' ) );
        add_filter( 'query_vars', array( __CLASS__, 'add_query_vars' ) );
        add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'add_menu_items' ) );
        add_action( 'template_redirect', array( __CLASS__, 'maybe_flush_rewrite_rules' ) );
        // Dashboard merge
        add_action( 'woocommerce_account_dashboard', array( __CLASS__, 'output_merged_dashboard_content' ), 1 );
    }

    /**
     * Register additional My Account endpoints based on configuration.
     */
    public static function register_endpoints() {
        $endpoints = get_option( 'arthur_ai_my_account_endpoints', array() );
        if ( ! is_array( $endpoints ) ) {
            return;
        }
        foreach ( $endpoints as $slug => $data ) {
            $endpoint = sanitize_key( $slug );
            add_rewrite_endpoint( $endpoint, EP_ROOT | EP_PAGES );
            // Register a hook to render content
            add_action( 'woocommerce_account_' . $endpoint . '_endpoint', function() use ( $endpoint ) {
                $endpoints = get_option( 'arthur_ai_my_account_endpoints', array() );
                if ( isset( $endpoints[ $endpoint ]['content'] ) ) {
                    echo wp_kses_post( $endpoints[ $endpoint ]['content'] );
                }
            } );
        }
    }

    /**
     * Add query vars for endpoints.
     *
     * @param array $vars Existing query vars.
     * @return array
     */
    public static function add_query_vars( $vars ) {
        $endpoints = get_option( 'arthur_ai_my_account_endpoints', array() );
        if ( is_array( $endpoints ) ) {
            foreach ( $endpoints as $slug => $data ) {
                $vars[] = sanitize_key( $slug );
            }
        }
        return $vars;
    }

    /**
     * Add new menu items for custom endpoints.
     *
     * @param array $items Existing menu items.
     * @return array Modified menu items.
     */
    public static function add_menu_items( $items ) {
        $endpoints = get_option( 'arthur_ai_my_account_endpoints', array() );
        if ( is_array( $endpoints ) ) {
            foreach ( $endpoints as $slug => $data ) {
                $label = isset( $data['label'] ) ? $data['label'] : ucfirst( $slug );
                $items[ $slug ] = $label;
            }
        }
        return $items;
    }

    /**
     * Flush rewrite rules on first run when endpoints change.
     */
    public static function maybe_flush_rewrite_rules() {
        if ( get_option( 'arthur_ai_my_account_flush_needed', false ) ) {
            flush_rewrite_rules();
            delete_option( 'arthur_ai_my_account_flush_needed' );
        }
    }

    /**
     * Output merged dashboard content.
     */
    public static function output_merged_dashboard_content() {
        $content = get_option( 'arthur_ai_my_account_merge_dashboard', '' );
        if ( $content ) {
            echo wp_kses_post( $content );
        }
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Outputs front‑end customisations such as global design tokens, button styles,
 * responsive CSS, header logo variants and layout rules.
 */
class Arthur_AI_Theme_Customiser {

    /**
     * Hook into WordPress.
     */
    public static function init() {
        add_action( 'wp_head', array( __CLASS__, 'output_design_tokens_css' ) );
        add_action( 'wp_head', array( __CLASS__, 'output_button_styles_css' ) );
        add_action( 'wp_head', array( __CLASS__, 'output_header_logo_variants_css' ) );
        add_action( 'wp_head', array( __CLASS__, 'output_frontend_responsive_css' ) );
        add_action( 'wp_head', array( __CLASS__, 'output_section_spacing_css' ) );
        add_action( 'wp_head', array( __CLASS__, 'output_layout_grid_css' ) );
    }

    /**
     * Output CSS variables for design tokens.
     */
    public static function output_design_tokens_css() {
        $tokens = get_option( 'arthur_ai_design_tokens', array() );
        if ( ! is_array( $tokens ) || empty( $tokens ) ) {
            return;
        }
        echo '<style id="arthur-ai-design-tokens">\n:root {';
        if ( isset( $tokens['colours'] ) && is_array( $tokens['colours'] ) ) {
            foreach ( $tokens['colours'] as $name => $value ) {
                $name  = sanitize_key( $name );
                $value = esc_attr( $value );
                echo "--arthur-{$name}: {$value};";
            }
        }
        echo '}\n';
        echo '</style>';
    }

    /**
     * Output button styles.
     */
    public static function output_button_styles_css() {
        $styles = get_option( 'arthur_ai_button_styles', array() );
        if ( ! is_array( $styles ) || empty( $styles ) ) {
            return;
        }
        echo '<style id="arthur-ai-button-styles">\n';
        echo '.wp-block-button__link, .button, .btn {';
        foreach ( $styles as $prop => $val ) {
            $prop = sanitize_text_field( $prop );
            $val  = esc_attr( $val );
            echo "{$prop}: {$val};";
        }
        echo '}\n';
        echo '</style>';
    }

    /**
     * Output CSS for header logo variants.
     */
    public static function output_header_logo_variants_css() {
        $variants = get_option( 'arthur_ai_header_logo_variants', array() );
        if ( ! is_array( $variants ) || empty( $variants ) ) {
            return;
        }
        $light_id = isset( $variants['light_logo_id'] ) ? (int) $variants['light_logo_id'] : 0;
        $dark_id  = isset( $variants['dark_logo_id'] ) ? (int) $variants['dark_logo_id'] : 0;
        if ( ! $light_id && ! $dark_id ) {
            return;
        }
        $light_url = $light_id ? wp_get_attachment_image_url( $light_id, 'full' ) : '';
        $dark_url  = $dark_id ? wp_get_attachment_image_url( $dark_id, 'full' ) : '';
        echo '<style id="arthur-ai-logo-variants">\n';
        if ( $light_url ) {
            echo 'body:not(.dark-mode) .site-logo img { content: url(' . esc_url( $light_url ) . '); }\n';
        }
        if ( $dark_url ) {
            echo 'body.dark-mode .site-logo img { content: url(' . esc_url( $dark_url ) . '); }\n';
        }
        echo '</style>';
    }

    /**
     * Output responsive CSS stored globally or per post.
     */
    public static function output_frontend_responsive_css() {
        $global_css = get_option( 'arthur_ai_frontend_responsive_css', '' );
        $css        = '';
        if ( is_string( $global_css ) && '' !== trim( $global_css ) ) {
            $css .= $global_css;
        }
        // Per-post CSS
        if ( is_singular() ) {
            $post_id = get_queried_object_id();
            $per_css = get_option( 'arthur_ai_frontend_responsive_css_post_' . $post_id, '' );
            if ( is_string( $per_css ) && '' !== trim( $per_css ) ) {
                $css .= '\n' . $per_css;
            }
        }
        if ( '' !== $css ) {
            echo '<style id="arthur-ai-responsive-css">' . $css . '</style>';
        }
    }

    /**
     * Output CSS for standardised section spacing.
     */
    public static function output_section_spacing_css() {
        $config = get_option( 'arthur_ai_section_spacing', array() );
        if ( ! is_array( $config ) || empty( $config ) ) {
            return;
        }
        $spacing   = isset( $config['spacing'] ) && is_array( $config['spacing'] ) ? $config['spacing'] : array();
        $selectors = isset( $config['selectors'] ) && is_array( $config['selectors'] ) ? $config['selectors'] : array();
        if ( empty( $spacing ) || empty( $selectors ) ) {
            return;
        }
        $css = '';
        $sel = implode( ',', array_map( 'sanitize_text_field', $selectors ) );
        $css .= $sel . '{';
        foreach ( $spacing as $prop => $val ) {
            $css .= sanitize_text_field( $prop ) . ':' . esc_attr( $val ) . ';';
        }
        $css .= '}';
        echo '<style id="arthur-ai-section-spacing">' . $css . '</style>';
    }

    /**
     * Output CSS for layout grid settings.
     */
    public static function output_layout_grid_css() {
        $grid = get_option( 'arthur_ai_layout_grid', array() );
        if ( ! is_array( $grid ) || empty( $grid ) ) {
            return;
        }
        $css = '';
        if ( isset( $grid['max_width'] ) ) {
            $css .= '.arthur-ai-container{max-width:' . esc_attr( $grid['max_width'] ) . ';margin-left:auto;margin-right:auto;padding-left:1rem;padding-right:1rem;}';
        }
        if ( '' !== $css ) {
            echo '<style id="arthur-ai-layout-grid">' . $css . '</style>';
        }
    }
}
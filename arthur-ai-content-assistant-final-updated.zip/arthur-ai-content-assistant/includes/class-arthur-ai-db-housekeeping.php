<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Utility class for database cleanup and optimisation tasks.
 *
 * This class centralises the heavy lifting for the run_db_housekeeping action.
 * Methods here interact with the database via WordPress APIs and direct
 * queries to safely remove unneeded data such as old revisions, expired
 * transients, spam comments, auto drafts and orphaned postmeta. It also
 * exposes a method to optimise tables when needed.
 */
class Arthur_AI_Db_Housekeeping {

    /**
     * Run housekeeping tasks according to the provided configuration.
     *
     * @param array $config The housekeeping options.
     * @return array Counts of items removed per category.
     */
    public static function run( array $config ) {
        global $wpdb;
        $counts = array(
            'revisions_deleted'   => 0,
            'transients_deleted'  => 0,
            'comments_deleted'    => 0,
            'autodrafts_deleted'  => 0,
            'orphan_meta_deleted' => 0,
        );

        // 1. Revisions cleanup
        if ( isset( $config['revisions']['enabled'] ) && $config['revisions']['enabled'] ) {
            $max = isset( $config['revisions']['max_revisions'] ) ? max( 0, intval( $config['revisions']['max_revisions'] ) ) : 0;
            // Get parent posts that have revisions.
            $posts_with_revs = $wpdb->get_col( "SELECT DISTINCT post_parent FROM {$wpdb->posts} WHERE post_type = 'revision' AND post_parent != 0" );
            if ( $posts_with_revs ) {
                foreach ( $posts_with_revs as $parent_id ) {
                    $revs = wp_get_post_revisions( $parent_id, array( 'order' => 'DESC' ) );
                    $num  = count( $revs );
                    if ( $max > 0 && $num > $max ) {
                        $to_delete = array_slice( $revs, $max );
                    } elseif ( 0 === $max ) {
                        $to_delete = $revs;
                    } else {
                        $to_delete = array();
                    }
                    foreach ( $to_delete as $rev ) {
                        wp_delete_post( $rev->ID, true );
                        $counts['revisions_deleted']++;
                    }
                }
            }
        }

        // 2. Transients cleanup
        if ( isset( $config['transients'] ) ) {
            if ( ! empty( $config['transients']['delete_expired'] ) && function_exists( 'delete_expired_transients' ) ) {
                delete_expired_transients();
                // We cannot easily count how many were removed.
            }
            if ( ! empty( $config['transients']['delete_all'] ) ) {
                // Delete all transients directly.
                $rows = $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_%' OR option_name LIKE '_site_transient_%'" );
                if ( is_numeric( $rows ) ) {
                    $counts['transients_deleted'] += $rows;
                }
            }
        }

        // 3. Comments cleanup
        if ( isset( $config['comments'] ) ) {
            $statuses = array();
            if ( ! empty( $config['comments']['delete_spam'] ) ) {
                $statuses[] = 'spam';
            }
            if ( ! empty( $config['comments']['delete_trash'] ) ) {
                $statuses[] = 'trash';
            }
            if ( ! empty( $statuses ) ) {
                $comments = get_comments( array( 'status' => $statuses, 'fields' => 'ids', 'number' => 0 ) );
                foreach ( $comments as $cid ) {
                    wp_delete_comment( $cid, true );
                    $counts['comments_deleted']++;
                }
            }
        }

        // 4. Auto draft cleanup
        if ( isset( $config['other']['delete_autodrafts'] ) && $config['other']['delete_autodrafts'] ) {
            $autodrafts = get_posts( array( 'post_status' => 'auto-draft', 'post_type' => 'any', 'numberposts' => -1 ) );
            foreach ( $autodrafts as $draft ) {
                wp_delete_post( $draft->ID, true );
                $counts['autodrafts_deleted']++;
            }
        }

        // 5. Orphaned postmeta cleanup
        if ( isset( $config['other']['delete_orphan_postmeta'] ) && $config['other']['delete_orphan_postmeta'] ) {
            // Delete postmeta rows where post_id does not exist in posts table.
            $rows = $wpdb->query( "DELETE pm FROM {$wpdb->postmeta} pm LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID WHERE p.ID IS NULL" );
            if ( is_numeric( $rows ) ) {
                $counts['orphan_meta_deleted'] += $rows;
            }
        }

        return $counts;
    }

    /**
     * Optimise database tables.
     *
     * @param array $tables Tables to optimise. If empty, optimises all WordPress tables.
     * @return array List of tables optimised.
     */
    public static function optimise_tables( array $tables = array() ) {
        global $wpdb;
        $to_optimise = array();
        // Determine default tables if none provided.
        if ( empty( $tables ) ) {
            $prefix = $wpdb->prefix;
            $all    = $wpdb->get_col( "SHOW TABLES LIKE '{$prefix}%'");
            $to_optimise = $all;
        } else {
            foreach ( $tables as $tbl ) {
                $to_optimise[] = $wpdb->prefix . preg_replace( '/[^a-zA-Z0-9_]/', '', $tbl );
            }
        }
        $optimised = array();
        foreach ( $to_optimise as $table ) {
            $result = $wpdb->query( "OPTIMIZE TABLE {$table}" );
            if ( false !== $result ) {
                $optimised[] = $table;
            }
        }
        return $optimised;
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Integrations customiser to execute automation rules and webhooks.
 *
 * This class listens for supported WordPress events and triggers
 * configured automation rules. It also exposes helper functions for
 * sending data to configured email marketing and CRM integrations via
 * webhooks. Only basic functionality is implemented to avoid heavy
 * dependencies; additional triggers and actions can be added as needed.
 */
class Arthur_AI_Integrations_Customiser {

    /**
     * Initialise hooks for automation rules.
     */
    public static function init() {
        // WooCommerce new order trigger.
        if ( class_exists( 'WooCommerce' ) ) {
            add_action( 'woocommerce_checkout_order_processed', array( __CLASS__, 'handle_new_order' ), 10, 3 );
        }
        // New user registration trigger.
        add_action( 'user_register', array( __CLASS__, 'handle_new_user' ), 10, 1 );
    }

    /**
     * Process automation rules for a new order.
     *
     * @param int   $order_id Order ID.
     * @param array $posted_data Posted checkout data.
     * @param WC_Order $order Order object.
     */
    public static function handle_new_order( $order_id, $posted_data, $order ) {
        $rules = get_option( 'arthur_ai_automation_rules', array() );
        if ( ! is_array( $rules ) ) {
            return;
        }
        foreach ( $rules as $rule ) {
            if ( ! isset( $rule['trigger']['type'] ) || 'new_order' !== $rule['trigger']['type'] ) {
                continue;
            }
            // Optionally evaluate conditions: not implemented in this simple example.
            self::execute_actions( $rule['actions'], array( 'order' => $order ) );
        }
    }

    /**
     * Process automation rules for a new user.
     *
     * @param int $user_id User ID.
     */
    public static function handle_new_user( $user_id ) {
        $rules = get_option( 'arthur_ai_automation_rules', array() );
        if ( ! is_array( $rules ) ) {
            return;
        }
        $user = get_userdata( $user_id );
        foreach ( $rules as $rule ) {
            if ( ! isset( $rule['trigger']['type'] ) || 'new_user' !== $rule['trigger']['type'] ) {
                continue;
            }
            self::execute_actions( $rule['actions'], array( 'user' => $user ) );
        }
    }

    /**
     * Execute actions for a rule.
     *
     * @param array $actions List of actions definitions.
     * @param array $context Data context passed to actions.
     */
    protected static function execute_actions( $actions, $context = array() ) {
        if ( ! is_array( $actions ) ) {
            return;
        }
        foreach ( $actions as $action ) {
            if ( ! isset( $action['type'] ) ) {
                continue;
            }
            switch ( $action['type'] ) {
                case 'call_webhook':
                    if ( isset( $action['webhook_name'] ) ) {
                        self::call_named_webhook( $action['webhook_name'], $context );
                    }
                    break;
                case 'add_to_crm_list':
                    // This would push contact to CRM using configured credentials.
                    // Not implemented beyond storing config.
                    break;
                case 'add_tag':
                    // Tagging can be implemented via CRM integration or WP user meta.
                    break;
                case 'send_email':
                    // Could send an email via WP mail or integration service.
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * Send data to a named webhook configured via configure_global_webhooks.
     *
     * @param string $name    Webhook name.
     * @param array  $context Context data (order, user, etc.) to merge into the payload.
     */
    protected static function call_named_webhook( $name, $context ) {
        $webhooks = get_option( 'arthur_ai_global_webhooks', array() );
        if ( ! isset( $webhooks[ $name ] ) ) {
            return;
        }
        $hook = $webhooks[ $name ];
        $url  = $hook['url'];
        $method = isset( $hook['method'] ) ? $hook['method'] : 'POST';
        $headers = isset( $hook['headers'] ) ? $hook['headers'] : array();
        $body_template = isset( $hook['body_template'] ) ? $hook['body_template'] : array();
        // Replace placeholders in body template using context.
        $body = array();
        foreach ( $body_template as $key => $template ) {
            $body[ $key ] = self::render_template( $template, $context );
        }
        $args = array(
            'headers' => $headers,
            'body'    => wp_json_encode( $body ),
            'method'  => $method,
            'timeout' => 15,
        );
        // Respect logging setting.
        $logging_enabled = (bool) get_option( 'arthur_ai_form_logging_enabled', false );
        $resp = wp_remote_request( $url, $args );
        if ( $logging_enabled ) {
            $log = get_option( 'arthur_ai_webhook_log', array() );
            if ( ! is_array( $log ) ) {
                $log = array();
            }
            $log[] = array(
                'time' => current_time( 'mysql' ),
                'webhook' => $name,
                'request_body' => $body,
                'response' => is_wp_error( $resp ) ? $resp->get_error_message() : wp_remote_retrieve_body( $resp ),
            );
            // Limit log size.
            if ( count( $log ) > 100 ) {
                $log = array_slice( $log, -100 );
            }
            update_option( 'arthur_ai_webhook_log', $log );
        }
    }

    /**
     * Simple template renderer: replace {field} placeholders with context values.
     *
     * @param string $template Template string with placeholders.
     * @param array  $context  Context data.
     * @return string
     */
    protected static function render_template( $template, $context ) {
        if ( ! is_string( $template ) ) {
            return '';
        }
        return preg_replace_callback( '/\{([^{}]+)\}/', function( $matches ) use ( $context ) {
            $path = $matches[1];
            // Path can be like order.id or user.user_email.
            $parts = explode( '.', $path );
            $value = $context;
            foreach ( $parts as $part ) {
                if ( is_array( $value ) && isset( $value[ $part ] ) ) {
                    $value = $value[ $part ];
                } elseif ( is_object( $value ) && isset( $value->$part ) ) {
                    $value = $value->$part;
                } else {
                    $value = '';
                    break;
                }
            }
            return $value;
        }, $template );
    }
}
